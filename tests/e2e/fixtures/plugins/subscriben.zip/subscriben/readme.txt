=== Subscriben for WooCommerce ===
Contributors: TeamUpdraft, RightPress, DavidAnderson, dnutbourne
Tags: woocommerce, subscriptions, automatic, repeating
Requires at least: 5.0
Tested up to: 6.8
Stable tag: 0.12.11
License: GPLv3
License URI: https://www.gnu.org/licenses/gpl-3.0.en.html

WooCommerce subscriptions plugin

== Description ==

Subscriptions for WooCommerce.

== Installation ==

Standard WordPress installation procedure: search for the plugin from your dashboard's plugin page, then press on "Install", then on "Activate".

Or, download the plugin zip and upload it via the plugin installer in your WordPress dashboard (in Plugins -> Add New -> Upload), and then activate it.

= Requirements =

- WordPress 5.0 or later.

- WooCommerce 3.9 or later.

- PHP 7.1 or later.

== Changelog ==

* TWEAK: Ensure that Stripe exceptions include error details for logging in subscription
* TWEAK: Identify default payment method with Source API-based renewals
* FIX: Ensure successful scheduled payments update the payment due transaction status
* FIX: Fall back to customer's most recently added card when default card is missing in Stripe

= 2025-10-17 - 0.12.11 =

* FEATURE: Add plugin updater class for automatic updates
* TWEAK: Require WordPress 5.0+
* TWEAK: Throw exception if subscription population fails rather than continuing
* TWEAK: Tidy the create_renewal_order_current() method and introduce a filter to allow tax exemption
* TWEAK: Save the taxable address of the original order within the subscription and populate when loading
* TWEAK: Use the shipping address on a renewal order for calculating taxes if the shop settings are thus set
* TWEAK: If the original order was tax-exempt, then default to assuming renewal orders are
* TWEAK: Explicitly provide the is_vat_exempt meta-key on renewal orders
* TWEAK: Do not create the pending subscription upon checkout-page loading, but wait until the order is placed
* TWEAK: Do not use maybe_unserialize() on validated PayPal IPN data
* TWEAK: Provide a filter subscriben_paypal_ec_identify_order_from_custom to force identification of order from the transaction ID only
* TWEAK: Change priority of updraftmanager_manage_user_page_before_entitlements hook to 9
* FIX: Subscription renewals failing with outdated payment methods
* FIX: When creating custom item meta for renewal orders, do not treat each item as an array
* FIX: Fix the code that looks up an order by PayPal transaction ID to be compatible with HPOS
* FIX: Re-fetch the newly-created renewal order before calling the subscriben_created_renewal_order action; otherwise, under HPOS, item meta lines are not immediately visible on the object

= 2025-01-21 - 0.12.10 =

* NEW: Add filter to toggle "now then" pricing display in subscriptions
* FIX: Prevent a fatal error occurring when the charge ID is not reported in a Stripe error reporting that a transaction needs authentication
* FIX: Cancel subscription confirmation text
* FIX: PHP deprecated message "Implicit conversion from float to int loses precision"
* FIX: Fatal errors on saving Subscription items with empty values
* FIX: Plugin translations loading warning
* NEW: Adds renewal order attribution source
* TWEAK: Verified compatibility with WooCommerce 9.6

= 2024-11-11 - 0.12.9 =

* NEW: Minimum supported version of WooCommerce Stripe Gateway is now 8.8.0 or higher
* NEW: Added Checkout Block compatibility for PayPal and legacy Stripe payment methods
* TWEAK: Enhanced subscription notes for clearer communication on payment failures
* TWEAK: Integrated [Simba Plugin Updates Manager](https://wordpress.org/plugins/simba-plugin-updates-manager/) to display subscription details on the user license summary page
* TWEAK: Block-payment classes now load only if WooCommerce is active
* TWEAK: Verified compatibility with WordPress 6.7 and WooCommerce 9.4
* FIX: Resolved compatibility issues with WooCommerce Stripe Gateway

= 2024-09-09 - 0.12.8 =

* FIX: adds missing language POT files

= 2024-09-02 - 0.12.7 =

* TWEAK: Added Semaphore class to built-in libraries.
* TWEAK: Correct use of deprecated dynamic properties in Simba_Subscriptions_Subscription class
* TWEAK: Prevent PHP notices when PayPal IPN pay-load does not include some elements
* TWEAK: Prevent PHP notices when Stripe customer response does not include some elements
* TWEAK: Remove unused method Simba_Subscriptions_Helper::delete_meta()
* PERFORMANCE: Do not load unnecessary front-end JavaScript except when the relevant buttons are being output
* TWEAK: Mark as supporting WordPress 6.6 & WooCommerce 9.2

= 2023-11-29 - 0.12.6 =

* SECURITY: In all previous releases (including of this plugin's ancestor - the issue was inherited from the original fork) site editors (if your site had any) had the ability to view and delete subscriptions and transactions. This has now been corrected to the proper role (WooCommerce shop manager permissions required).
* TWEAK: Prevent PHP notice when potentially saving card meta-information
* TWEAK: Prevent PHP notice when line item has no _line_tax property
* TWEAK: Prevent PHP notice when the WooCommerce cart object is null
* TWEAK: Prevent PHP notice when custom ID returned is empty
* TWEAK: Declare various class variables explicitly because of dynamic property deprecation in PHP 8.2
* TWEAK: Removed a couple of unused PHP methods
* TWEAK: Mark as supporting WordPress 6.4, and requiring at least WordPress 4.9 and WooCommerce 3.9

= 2023-08-11 - 0.12.5 =

* TWEAK: Update old transactions' parent ids to allow faster searching.
* TWEAK: Updated transactions fetching code to use the post_parent value.

= 2023-07-07 - 0.12.3 =

* FIX: Display line tax correctly after a renewal where tax has changed
* TWEAK: Update the line tax in the Subscription page after a renewal

= 2023-06-08 - 0.12.2 =

* TWEAK: Remove obsolete order_get_currency() compatibility function
* FIX: Potentially incorrect currency used by Simba_Subscriptions_PayPal_EC_Payment_Request constructor
* TWEAK: Set subscription id as post parent of transaction post.

= 2023-01-19 - 0.12.1 =

* FIX: PayPal renewal orders don't end up populating the invoice number or item title at the PayPal end (seen in the balance-affecting spreadsheet - can't see what was bought)
* TWEAK: Added link in Subscriptions menu directly to the Subscriben logs in the WC tools
* FIX: In the auto renewal order attribute data's are not saving like initial order
* FIX: Prevent a PHP type error when adding taxes in ajax_update_renewal_quantity_and_price() (fix in 0.12.0 was incomplete)
* TWEAK: Cast to integer in Simba_Subscriptions_Subscription::get_new_adjusted_timestamp()

= 2022-09-17 - 0.12.0 =

* FEATURE: Added option to choose if a coupon should apply to just the initial order, or for each renewal
* FIX: Fixed Stripe fee and payout displaying twice in order edit page
* FIX: Do not attempt to save PayPal gateway-related information or process payments for non-subscription orders
* FIX: Fixed issue whereby '_subscriben_subscription_id' postmeta was added to the order multiple times
* FIX: Do not attempt to save PayPal gateway-related information for non-subscription orders
* FIX: The payment method never saved in auto renewal subscription order if user choose WooCommerce Stripe gateway for subscription payment
* FIX: Prevent paid orders from being automatically cancelled when the subscription is cancelled by the customer
* FIX: Prevent a PHP type error when adding taxes in ajax_update_renewal_quantity_and_price()
* FIX: Fix uncaught number formatting error when calculating shipping for the PayPal gateway
* TWEAK: Prevent a potential PHP notice when showing checkbox for cancelling associated subscription upon a refund
* TWEAK: Replace remaining uses of deprecated get_used_coupons() method
* TWEAK: Add logging when an invalid value for a new subscription date is passed

= 2022-03-26 - 0.11.2 =

* TWEAK: Allow filtering of subscription cancellation confirmation text
* TWEAK: Prevent PHP notice when showing order list when the subscription list was empty
* TWEAK: Prevent premature request of lock and remove unnecessary complexity in version update class

= 2022-03-11 - 0.11.1 =

* FIX: Auto renewal payment always failed for subscription renewal order
* FIX: My account is showing attribute slugs instead of attribute label
* TWEAK: Add PayPal transaction URL in order notes if user purchase with Subscriben's PayPal gateway
* TWEAK: process_subscription_payment() signature consistency (prevent PHP 8 fatal error)
* TWEAK: Prevent PHP notice when order list has no associated subscriptions
* TWEAK: Improving the order notes when an error occurs during payment
* TWEAK: Subscription new order template: also include link to cancel subscription (reduces support requests asking how to do it)
* TWEAK: Replace deprecated array-style access on WC_Order_Item_Product object in PayPal gateway

= 2021-12-09 - 0.10.1 =

* TWEAK: Replace expensive SQL query
* TWEAK: Do not set CURLOPT_VERBOSE option unless WP_DEBUG is set
* TWEAK: Cancelling renewal order does not cancel subscription payment attempt
* TWEAK: Refund orders: If the order is part of a subscription add checkbox to also cancel linked subscription
* TWEAK: The order note with the subscription link needs to be added when the renewal order is created and add the order ids of the other orders associated with the subscription to the order notes (making them clickable links).
* TWEAK: Port from previous semaphore classes to Updraft_Semaphore_3_0
* TWEAK: Replace some deprecated jQuery styles
* TWEAK: Various minor code-cleaning items suggested by PHPCS
* TWEAK: Prevent a fatal error seen when printing meta lines on WC 5.2
* TWEAK: Fix a sometimes-incorrect variable reference
* FIX: Tax name and label will now be updated for renewal orders if the tax rate has changed
* TWEAK: Replace deprecated WC_Order_Item_Meta
* TWEAK: Update Stripe gateway to match current WooCommerce Stripe Gateway plugin
* TWEAK: Explicitly check if WooCommerce taxes are enabled when recalculating subscription renewal tax
* FEATURE: Options to allow users to access downloads if the subscription is paused or cancelled

= 2020-12-31 - 0.10.0 =

* TWEAK: Replace deprecated jQuery styles
* TWEAK: Update requirements to WP 4.8+, WC 3.8+, PHP 7.1+
* FEATURE: Taxes on renewal orders will now be recalculated based on current tax rates
* FIX: Fix regression due to remaining call to removed is_demo() method
* FIX: Update use of woocommerce_email_header header for compatibility recent WooCommerce versions (preventing fatal errors)

= 2020-12-18 - 0.9.1 =

* FIX: Fixed issue where item data would not be associated with multi-product subscriptions
* FIX: Fixed issue where event metadata was not cleared correctly on subscription status change
* TWEAK: Replace a pattern deprecated in jQuery 3
* TWEAK: The order note indicating the subscription ID is now not marked as a customer note
* TWEAK: Don't use get_bloginfo() (template function) to get the WP version
* TWEAK: Support a limited form of late-loading
* TWEAK: Update jQuery document ready style to the one not deprecated in jQuery 3.0
* TWEAK: Rename various variables for current plugin naming
* TWEAK: Remove legacy events handling code
* TWEAK: Build system: added an extra check to Gulp to ensure that common-libs is present
* TWEAK: Avoid using badly-performing row-scanning in Simba_Subscriptions_User::find_subscriptions()
* TWEAK: When fetching transactions, set the posts_per_page parameter to make sure they are all fetched
* TWEAK: Remove and update references to third-party support

= 2020-09-04 - 0.9.0 =

* FEATURE: Added database transactions where supported
* FEATURE: Add the ability to edit the quantity and price of items in the subscription
* FIX: Fixed invalid reference in wp_localize_script call
* FIX: Replaced existing weak cron locking technique with better Semaphore locking
* FIX: Fixed an issue where Stripe wasn't saving source id when cart total is zero (free trial)
* FIX: Fixed rogue 1 unit duplicate transactions when using PayPal
* TWEAK: Direct access to $woocommerce->cart->tax_display_cart is deprecated in WooCommerce 4.4
* TWEAK: Order notes added by Subscriben are now not marked as added by an admin
* TWEAK: Mark as supporting WC 4.3 (requires at least WC 3.5 and WP 4.6)
* TWEAK: Update legacy table name
* TWEAK: Removed legacy PayPal Adaptive Payments gateway
* TWEAK: Removed option to enable old legacy Stripe gateway, replaced with information on official WooCommerce Stripe gateway
* FIX: Fixed missing and incorrect renewal order line item data

= 2020-01-06 - 0.8.6 =

* FIX: Subscriben is now compatible with Woocommerce Stripe 4.3.1
* FIX: Correct error handling in Simba_Subscriptions_WC_Stripe_Subs_Compat::process_subscription_payment() to prevent failures that are not acted upon
* TWEAK: Added a new hook 'subscriben_automatic_payment_failed' for when automatic payments fail
* TWEAK: Improve function to get formatted subscription price so it takes into account if the tax suffix should be displayed or not
* TWEAK: Rename legacy filter to new name subscriben_process_automatic_payment
* TWEAK: Remove legacy create_renewal_order_pre_wc30() method
* TWEAK: Mark as requiring PHP 5.6 (i.e. as current releases of WP)
* TWEAK: PHP 7.4 deprecation notice fixes

= 2019-11-05 - 0.8.5 =

* FIX: Variable subscription products will now use the correct price format for shop entries and single product pages
* TWEAK: Remove unused WC_Meta class
* TWEAK: Various small tweaks resulting from tweaks to automated code check rules
* TWEAK: Renamed many classes
* TWEAK: WC_Order::get_used_coupons() is deprecated in WC 3.7; replace
* TWEAK: Mark as supporting WC 3.8 (requires at least WC 3.2)
* TWEAK: Indicate cancelled subscriptions in the order list with a strike-through
* TWEAK: Removed the Linked Credit Cards section from WooCommerce account dashboard, and replaced with a link to the WooCommerce Stripe payment methods

= 2019-07-09 - 0.8.4 =

* FIX: Prevent a PHP fatal error if cancelling a subscription on a refunded order if a related order that was part of the subscription is not found
* FIX: Failed payments on renewal orders now correctly show as errors on subscription pages
* TWEAK: Update the Stripe API version to 2018-09-24
* TWEAK: Implemented support for the official WC Stripe gateway
* TWEAK: Add the ability for the bundled Stripe gateway to be hidden from the checkout, but still active so that it can be used for renewals
* TWEAK: Added additional information and error logging for Subscriptions

= 2019-06-11 - 0.8.3 =

* TWEAK: Correct the timings in the list of scheduled events for events more than a day ahead
* TWEAK: Add variation_id field to array returned from Subscriptio_Subscription->get_items()

= 2019-05-10 - 0.8.2 =

* TWEAK: Change the internal communication with bundled gateways to be closer to the official WC Subscriptions API

= 2019-05-02 - 0.8.1 =

* FIX: Variable products now correctly display and save the alternate currency signup fees
* TWEAK: Add a new order meta for faster looking up of related subscriptions
* TWEAK: Replace deprecated use of WC_Cart->posted on WC 3.1+
* TWEAK: For multi-subscription orders, put a comma between the items in the column on the WC orders screen
* TWEAK: Change some signatures on methods that looked up prices to prevent unnecessary repeat calls to wc_get_order()
* TWEAK: Update the Stripe API version by just under 3 years to 2018-01-23
* TWEAK: Make sure that the renewal_all_order_meta subscription property is an array, even if empty
* TWEAK: Abolish the get_wc_price_suffix() method
* TWEAK: Stop the get_formatted_price() method from using an incomplete WC_Product object, which made assumptions about WC's internals that risked fatal errors (seen) in other extensions
* TWEAK: Make Order_Handler::order_is_renewal() able to cope with non-existent orders being passed in

= 2019-03-25 - 0.8.0 =

* META: Version-numbering restarted from 0.8.0
* FIX: Check that order numbers within a subscription are non-zero before cancelling them
* FIX: Prevent a fatal error when getting meta-data for a non-existent order
* FIX: Prevent a fatal error seen in the subscriptions_endpoint_title() method
* FIX: Prevent a fatal error on the 'Subscriptions' page caused by duplicate metadata
* FIX: Previous releases defined 1 year = 365 days and (most seriously) 1 month = 30 days, which led to cumulative discrepancies over long time periods with subscription renewal dates where customers would experience/observe
* FEATURE: Add the subscription ID in WooCommerce order notes, and as a column in the orders table
* FEATURE: Add ability to view internals of Subscription object on the subscription back-end page (useful for debugging)
* FEATURE: Add the capability to indicate sign-up fees in multiple currencies if using the Aelia multi-currency add-on (or a filter)
* FEATURE: Add an admin page with rudimentary information on upcoming scheduled events
* TWEAK: Replaced changelog with readme.txt
* TWEAK: Make it possible to change sign-up fees via a filter, and convert them automatically via a couple of multi-currency plugins
* TWEAK: Bump official WP version requirements (4.4) and supported up to (current)
* TWEAK: Bump WooCommerce version requirement (3.0). (This is an absolute requirement; it uses a lot of WC 3.0+ methods).
* TWEAK: In the Subscriptions table, display first order as well as last
* TWEAK: Replace deprecated direct accesses to the WC_Cart::$taxes and WC_Cart::$shipping_taxes properties with the WC 3.2+ methods
* TWEAK: Created Subscriptio_Order_Handler::create_renewal_order_current(), using WC 3.0+ methods without legacy post-tied methods
* TWEAK: Rename the helper class to Simba_Subscriptions_Helper to prevent conflicts
* TWEAK: Replaced the deprecated (PHP 7.2) (unset) cast
* TWEAK: Port deprecated get_posts() call over to wc_get_orders()
* TWEAK: Include the order number of a newly-created scheduled order in the subscription order note
* TWEAK: When a scheduled order creation fails, include more information in the debugging message
* TWEAK: Remove a couple of compatibility methods for WooCommerce versions before 2.2
* TWEAK: Replace use of the deprecated $woocommerce global
* TWEAK: Remove unused methods from helper class: get_wc_product_id(), get_wc_order_id(), get_wc_cart_contents_weight(), is_request()
* TWEAK: Abstract calls to print_frontend_link_to_post() and other similar methods when a product/order is meant, for easier future changes when products/orders stop being posts
* TWEAK: Abolish the Subscriptio::product_is_active() method, by replacing it with WC 3.0+ compliant code
* TWEAK: Replace use of the post_is_active() method with WC 3.0+ compliant code when operating on orders
* TWEAK: Remove lots of code that existed for compatibility with WooCommerce versions before 3.0
* TWEAK: Abolish the unnecessary my_account_supports_tabbed_navigation() compatibility method
* TWEAK: Improve compatibility with the Aelia multi-currency switcher by not copying stale currency conversion data on renewal orders but instead saving the WC_Order object to allow automatic recalculation. This will also help with any other plugin that wants a chance to inject/update its own meta-data.
* TWEAK: Introduce the filter subscriptio_copy_meta_field_to_renewal_order allowing copying of meta-data to renewal orders to be more easily customisable
* TWEAK: Improved the accuracy of the check for whether the current page is the checkout
* TWEAK: Prevent deprecation warnings about use of count() on uncountable objects in PHP 7.2 in unwrap_post_meta()
* TWEAK: Remove the RightPress updater class

Version 2.3.8, 29 April 2017
------------------------------------------------------------------------------------
* Fix - Stripe payment gateway bug related to stored cards

Version 2.3.7, 15 April 2017
------------------------------------------------------------------------------------
* Fix - Limits for subscriptions are also limiting regular products
* Fix - Built-in Stripe payment gateway issues with currencies that have no decimals
* Tweak - Other minor bug fixes and improvements

Version 2.3.6, 5 April 2017
------------------------------------------------------------------------------------
* Fix - Manual payments via PayPal EC gateway do not work under some circumstances
* Fix - Month name display issue in built-in Stripe payment gateway extension
* Fix - Shipping fee is displayed when renewal order shipping fee is disabled
* Fix - Payment gateways not available to guest users when cart total is zero
* Fix - Default WooCommerce emails are not suppressed properly
* Fix - Undefined variable $context
* Fix - PHP notice when executing bulk action
* Tweak - Improved compatibility with WooCommerce 3.0

Version 2.3.5, 3 January 2017
------------------------------------------------------------------------------------
* Fix - Stripe token not saved when customer is not logged in during payment
* Fix - Zero tax rates are not displayed on renewal orders
* Fix - Shop manager can't access and save settings
* Tweak - Other minor bug fixes and improvements

Version 2.3.4, 22 December 2016
------------------------------------------------------------------------------------
* Fix - Issues related to free trial handling

Version 2.3.3, 21 December 2016
------------------------------------------------------------------------------------
* Fix - Incorrect recurring total when using a sign up fee (bug in last version)

Version 2.3.2, 24 November 2016
------------------------------------------------------------------------------------
* Fix - Error on thank you page when using subscription limits
* Tweak - Option to apply sale price to initial order only
* Tweak - Other minor bug fixes and improvements

Version 2.3.1, 26 September 2016
------------------------------------------------------------------------------------
* Fix - Product id set to variation id in variable order item meta
* Fix - Tax class determined incorrectly for variable products in some cases
* Fix - Invalid argument supplied for foreach() warning
* Tweak - Option to use PayPal Adaptive Payments for existing subscriptions only
* Tweak - Other minor bug fixes and improvements

Version 2.3, 2 September 2016
------------------------------------------------------------------------------------
* Feature - Event Scheduler class replaced by a more reliable one
* Feature - PayPal Express Checkout payment gateway extension
* Feature - Payment details can now be captured for free trials
* Feature - Tabbed navigation in My Account now supported
* Feature - WPML compatibility
* Feature - Partial RTL support
* Fix - Wrong date set in some occasions when manually changing event dates
* Fix - Wrong product quantities in multi-product renewal order
* Fix - Renewal order item tax data missing
* Fix - Downloadable product downloads issue
* Fix - Issues related to subscription emails
* Fix - Plain text email new line issue
* Fix - Subscription emails always sent to admin even when set not to
* Fix - Renewal orders not created due to fatal error on some setups
* Fix - Multi-product subscription issues related to billing cycle lengths
* Fix - Variable product subscription checkbox can't be unchecked
* Fix - Date picker does not display arrows
* Fix - Problems activating memberships based on multi-product subscriptions
* Fix - Subscription items list only shows first subscription in emails
* Fix - Cart is empty error when submitting manual payment for renewal order
* Fix - Error displayed when searching subscriptions and transactions lists
* Tweak - Better handling of order resuming and repeated failed payments
* Tweak - Order again functionality now disabled on renewal orders
* Tweak - Subscriptions list in My Account is now responsive
* Tweak - Price suffix is no longer displayed when not needed
* Tweak - Option to disable specific card types in Stripe settings
* Tweak - Updated RightPress automatic updates class
* Tweak - PayPal Adaptive Payments extension now deprecated
* Tweak - Other minor bug fixes and improvements
* Dev - New action hook subscriptio_created_renewal_order
* Dev - New filter hook subscriptio_renewal_order_tax
* Dev - New filter hook subscriptio_renewal_order_subtotal
* Dev - New filter hook subscriptio_renewal_order_total
* Dev - New filter hook subscriptio_renewal_order_line_subtotal
* Dev - New filter hook subscriptio_renewal_order_line_subtotal_tax
* Dev - New filter hook subscriptio_renewal_order_line_total
* Dev - New filter hook subscriptio_renewal_order_line_tax

Version 2.2.2, 28 February 2016
------------------------------------------------------------------------------------
* Fix - Order resuming issues (new order placed on top of unpaid one)
* Fix - Payment due date prevents payments from being made earlier
* Fix - Warning related to item meta in renewal orders
* Tweak - Added function existence check for mb_detect_encoding
* Tweak - Updated RightPress automatic updates class
* Tweak - Other minor bug fixes and improvements

Version 2.2.1, 24 January 2016
------------------------------------------------------------------------------------
* Tweak - Updated automatic updates class
* Dev - Added filter to disable sslverify (payments failing on misconfigured servers)

Version 2.2, 4 January 2016
------------------------------------------------------------------------------------
* Feature - Plugin now supports automatic updates
* Fix - Several issues with PayPal payment gateway resolved
* Fix - PayPal logo is not displayed on checkout for PayPal payment gateway
* Tweak - Stripe payment gateway now supports multiple languages
* Tweak - Changed language file directory name from woocommerce to subscriptio
* Tweak - Other minor bug fixes and improvements

Version 2.1.3, 9 November 2015
------------------------------------------------------------------------------------
* Fix - Non-unique taxonomy term slug issue
* Fix - Problems with renewal order subtotal for subscriptions created prior to 2.0

Version 2.1.2, 1 November 2015
------------------------------------------------------------------------------------
* Fix - Product object fatal error in WooCommerce 2.3
* Fix - Subscription not created in multi-product mode
* Tweak - Payment Due date now displayed on View Subscription page
* Tweak - Better loading of styles/scripts for improved compatibility
* Tweak - Better language file loading: WP_LANG_DIR . "/woocommerce/" now supported
* Tweak - Other minor bug fixes and improvements

Version 2.1.1, 11 September 2015
------------------------------------------------------------------------------------
* Feature - Added error logging for PayPal Gateway for easier debugging
* Fix - Trial notice appears for non-subscription products
* Fix - PHP Notice displayed on product page for not logged in users in some cases
* Tweak - Removed all instances of sslverify = false due to security concerns
* Tweak - Other minor bug fixes and improvements

Version 2.1, 25 August 2015
------------------------------------------------------------------------------------
* Feature - Subscription trials can now be limited
* Feature - A number of subscriptions per user can now be limited
* Feature - Downloadable product access now blocked if subscription is inactive
* Feature - Shop managers can now manually adjust scheduled subscription events
* Feature - Option to display lowest absolute price for variations
* Tweak - Subscription can now be cancelled if the initial order gets refunded
* Tweak - Improved display of variation subscription products
* Tweak - Improved compatibility with The Events Calendar
* Tweak - Other minor bug fixes and improvements
* Dev - New methods for developers to access data about subscribers

Version 2.0.2, 11 June 2015
------------------------------------------------------------------------------------
* Feature - New options for controlling PayPal Gateway Preapproval operation
* Fix - PayPal Gateway Preapproval operation issues
* Tweak - Other minor bug fixes and improvements

Version 2.0.1, 26 May 2015
------------------------------------------------------------------------------------
* Fix - "Can't use method return value in write context" bug

Version 2.0, 22 May 2015
------------------------------------------------------------------------------------
* Feature - PayPal payment gateway with support of automatic payments
* Feature - Subscriptions can now have multiple subscription products
* Feature - Pausing subscriptions can now be limited (count and duration)
* Feature - Shipping on renewal orders can now be enabled/disabled
* Feature - Method to prevent WooCommerce from cancelling renewal orders prematurely
* Feature - Option to change "Add to Cart" label for subscription products
* Fix - problems related to custom item/order meta data
* Fix - Recurring amount double-multiply on change of quantity
* Fix - Variable subscription product price formatting issues
* Fix - Original price for discounted products is not displayed
* Fix - Internationalization of dates on My Account page
* Fix - Tax suffix display issues
* Tweak - Updated Stripe API version
* Tweak - Other minor bug fixes and improvements
* Dev - New set of action hooks that run before subscription status change

Version 1.0.10, 8 April 2015
------------------------------------------------------------------------------------
* Fix - Payment Due reminders not being sent in some cases
* Fix - Problems with Stripe refunds for renewal orders
* Tweak - Other minor bug fixes and improvements

Version 1.0.9, 9 March 2015
------------------------------------------------------------------------------------
* Feature - Added support for WooCommerce 2.2 style refunds
* Fix - Issues with subscription price display including/excluding tax
* Tweak - Stripe no longer issues refunds on order status change to cancelled and refunded
* Tweak - Improved compatibility with WooCommerce 2.1+
* Tweak - Removed support for WooCommerce 2.0

Version 1.0.8, 2 March 2015
------------------------------------------------------------------------------------
* Tweak - Renewal orders with zero total are now automatically marked processing
* Tweak - Improved compatibility with latest versions of WooCommerce

Version 1.0.7, 3 February 2015
------------------------------------------------------------------------------------
* Fix - Stripe gateway error "Received unknown parameter: statement_description"
* Fix - Typo in multiple email templates

Version 1.0.6, 19 December 2014
------------------------------------------------------------------------------------
* Fix - New user accounts can't be created during checkout
* Fix - Typo in get_time_zone function
* Tweak - Improved compatibility with PHP 5.2
* Tweak - Improved checkout page Javascript to handle empty billing fields gracefully

Version 1.0.5, 3 December 2014
------------------------------------------------------------------------------------
* Fix - Subscription products can't be turned back to regular products
* Fix - More frontend navigation issues when URL rewrite is used
* Fix - Stripe extension prevents test transactions when SSL is off

Version 1.0.4, 23 October 2014
------------------------------------------------------------------------------------
* Fix - PayPal payment cancellation results in fatal error
* Fix - Subscription status not always set on checkout
* Tweak - Improved handling of New Order, Processing and Completed emails for renewals
* Tweak - Changed default renewal order payment status from on-hold to pending
* Tweak - Improved compatibility with WooCommerce version 2.2 (order statuses)
* Tweak - Improved compatibility with WooCommerce versions 2.0.X
* Tweak - Other minor bug fixes and improvements

Version 1.0.3, 9 October 2014
------------------------------------------------------------------------------------
* Fix - New subscriptions fail because of shipping settings
* Fix - Frontend navigation issues when URL rewrite is used for permalinks

Version 1.0.2, 23 September 2014
------------------------------------------------------------------------------------
* Feature - Stripe payment gateway extension for automatic payments
* Tweak - Other minor bug fixes and improvements

Version 1.0.1, 1 September 2014
------------------------------------------------------------------------------------
* Fix - "Can't use method return value in write context" bug
* Tweak - Improved function that determines system's time zone

Version 1.0, 30 August 2014
------------------------------------------------------------------------------------
* Initial release
