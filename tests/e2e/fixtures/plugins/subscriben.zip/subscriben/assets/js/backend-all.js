/**
 * Subscriben Plugin Backend Scripts (loaded on all pages)
 */
jQuery(function() {

	/**
	 * Toggle subscription settings fields for simple product
	 */
	function toggle_subscriben_simple_product_fields() {
		if (jQuery('select#product-type').val() === 'simple') {
			if (jQuery('input#_subscriben').is(':checked')) {
				jQuery('.show_if_subscriben_simple').show();
			} else {
				jQuery('.show_if_subscriben_simple').hide();
			}
		} else {
			jQuery('.show_if_subscriben_simple').hide();
		}
	}

	toggle_subscriben_simple_product_fields();

	jQuery('body').on('woocommerce-product-type-change', function() {
		toggle_subscriben_simple_product_fields();
	});

	jQuery('input#_subscriben').on('change', function() {
		toggle_subscriben_simple_product_fields();
	});

	/**
	 * Toggle subscription settings fields for variable product
	 */
	function toggle_subscriben_variable_product_fields() {
		if (jQuery('select#product-type').val() === 'variable') {
			jQuery('input._subscriben_variable').each(function() {

				// Set different elements in variable depending on WC version
				var variation_fields = jQuery(this).closest('div.woocommerce_variation').find('div.show_if_subscriben_variable');

				if (jQuery(this).is(':checked')) {

					// Display subscription options
					variation_fields.each(function() {
						jQuery(this).show();
					});

					// Write "Subscriben" on variable product handle (if not present)
					if (jQuery(this).closest('div.woocommerce_variation').find('.subscriben_variable_product_handle_icon').length == 0) {
						jQuery(this).closest('div.woocommerce_variation').find('h3').first().find('select').last().after('<i style="margin-left:10px;" class="fa fa-repeat subscriben_variable_product_handle_icon" title="' + subscriben_vars.title_subscription_product + '"></i>');
					}
				} else {

					// Hide subscription options
					variation_fields.each(function() {
						jQuery(this).hide();
					});

					// Remove "Subscriben" from variable product handle
					jQuery(this).closest('div.woocommerce_variation').find('.subscriben_variable_product_handle_icon').remove();
				}
			});
		}
	}

	toggle_subscriben_variable_product_fields();

	jQuery('input._subscriben_variable').each(function() {
		jQuery(this).on('change', function() {
			toggle_subscriben_variable_product_fields();
		});
	});

	// Make sure method is applied when variations loaded via AJAX in WC 2.4+
	jQuery(document).on('change', '#variable_product_options', function() {
		toggle_subscriben_variable_product_fields();
	});
	jQuery(document).on('click', '._subscriben_variable', function() {
		toggle_subscriben_variable_product_fields();
	});

	jQuery('#variable_product_options').on('woocommerce_variations_added', function() {
		toggle_subscriben_variable_product_fields();

		jQuery('input._subscriben_variable').last().each(function() {
			jQuery(this).on('change', function() {
				toggle_subscriben_variable_product_fields();
			});
		});
	});

	/**
	 * Display admin shipping address edit fields
	 */
	jQuery('#subscriben_admin_edit_address').on('click', function(e) {
		e.preventDefault();
		jQuery(this).hide();
		jQuery('.subscriben_admin_address').hide();
		jQuery('.subscriben_admin_address_fields').show();
	});
	jQuery('#subscriben_cancel_address_edit').on('click', function(e) {
		e.preventDefault();
		jQuery('.subscriben_admin_address_fields').hide();
		jQuery('.subscriben_admin_address').show();
		jQuery('#subscriben_admin_edit_address').show();
	});

	/**
	 * Show or hide pause fields
	 */
	jQuery('#subscriben_customer_pausing_allowed').each(function() {
		if (!jQuery(this).is(':checked')) {
			jQuery('#subscriben_max_pauses').parent().parent().hide();
			jQuery('#subscriben_max_pause_duration').parent().parent().hide();
		}
	});

	jQuery('#subscriben_customer_pausing_allowed').on('change', function() {
		if (jQuery(this).is(':checked')) {
			jQuery('#subscriben_max_pauses').parent().parent().show();
			jQuery('#subscriben_max_pause_duration').parent().parent().show();
		} else {
			jQuery('#subscriben_max_pauses').parent().parent().hide();
			jQuery('#subscriben_max_pause_duration').parent().parent().hide();
		}
	});
	
	/**
	 * Modify data property of WooCommerce refund ajax request for adding subscription checkbox value in data property to cancel subscription
	 */
	jQuery.ajaxPrefilter(function(options, originalOptions, jqXHR) {
		if ('POST' === originalOptions.type || 'POST' === options.type) {
			var subscriptions = new Array();
			if ('undefined' !== typeof originalOptions.data  && originalOptions.data.hasOwnProperty('action')) {
				if ('woocommerce_refund_line_items' === originalOptions.data.action) {
					var subscription_checkboxs = document.getElementsByClassName("cancel-meta");
					for (var i = 0; i < subscription_checkboxs.length; i++) {
						if (subscription_checkboxs[i].checked) {
							subscriptions.push(subscription_checkboxs[i].value);
						}
					}
					options.data = jQuery.param(jQuery.extend(originalOptions.data, { subscriptions_cancel : subscriptions}));
				}
			}
		}
	});
	
	/**
	 * Handle expiration date change
	 */
	jQuery('.subscriben_date_change_link').on('click', function(e) {

		e.preventDefault();

		// Get nearest date input field and show it (for short time)
		var date_field = jQuery(this).closest('p').find('input[name=subscription_date]').first().show();

		// Get current date
		var current_date_field = jQuery(this).closest('p').find('input[name=subscription_default_date]').first();
		var current_date = current_date_field.val();

		// Datepicker configuration
		var datepicker_config = {
			showButtonPanel:    true,
			currentText:        subscriben_vars.current_text,
			closeText:          subscriben_vars.close_text,
			dateFormat:         'yy-mm-dd'
		};

		// Set current date (if any)
		if (current_date !== '') {
			datepicker_config.defaultDate = current_date;
			date_field.val(current_date);
		}

		// On select
		datepicker_config.onSelect = function(date) {
			subscriben_date_changed(date, jQuery(this));
			current_date_field.val(date);
			date_field.datepicker('destroy');
		};

		// On close
		datepicker_config.onClose = function() {
			date_field.datepicker('destroy');
		};

		// Initialize datepicker
		date_field.datepicker(datepicker_config);

		// Show the datepicker and hide the field
		date_field.datepicker('show').hide();
	});

	/**
	 * Handle expiration date change
	 */
	function subscriben_date_changed(date, field)
	{
		var block = field.parent('p');

		jQuery.post(
			ajaxurl,
			{
				'action':          'change_scheduled_date',
				'user_id':         block.find('input[name=subscription_user_id]').first().val(),
				'subscription_id': block.find('input[name=subscription_id]').first().val(),
				'date_type':       block.find('input[name=subscription_date_type]').first().val(),
				'date':            date
			},
			function(response) {
				var result = JSON.parse(response);

				// Update date in view
				if (typeof result.newdate !== 'undefined') {

					// Update the date if no errors caused
					if (result.newdate !== 'error') {
						block.find('.subscriben_date_change_link').html(result.newdate);
					} else {
						alert(subscriben_vars.date_change_alert);
					}

					// Reload the page to update transactions list
					location.reload();
				}
			}
		);
	}
	
	// Hide the subscription item edit fields
	jQuery('#subscriben_subscription_items_edit_container').hide();
	
	jQuery('#subscriben_subscription_items_update').on('click', function(e) {
		jQuery('#subscriben_subscription_items_container').hide();
		jQuery('#subscriben_subscription_items_edit_container').show();
	});
	
	// Update price automatically when quantity is updated
	jQuery('.subscriben_subscription_items_list_quantity input').on('change', function(e) {
		var row = jQuery(this).closest('tr');
		
		var totalField = row.find('.subscriben_subscription_items_list_total input');
		var taxField = row.find('.subscriben_subscription_items_list_tax input');
		
		// We use a semi-fixed single value attribute to prevent math problems
		var ogTotal = totalField.attr('singleVal');
		var ogTax = taxField.attr('singleVal');
		var quantity = jQuery(this).val();
		
		totalField.val(ogTotal*quantity);
		taxField.val(ogTax*quantity);
	});
	
	// Update tax/total single item value
	jQuery('.subscriben_subscription_items_list_total input, .subscriben_subscription_items_list_tax input').on('change', function(e) {
		var newVal = jQuery(this).val();
		var quantity = jQuery(this).closest('tr').find('.subscriben_subscription_items_list_quantity input').val();
		
		var newSingle = newVal/quantity;
		
		jQuery(this).attr('singleVal', parseFloat(newSingle.toFixed(3)));
	});
	
	/**
	 * Handle item quantity/price change
	 */
	jQuery('#subscriben_subscription_items_submit').on('click', function(e) {
		e.preventDefault();
		
		// We don't have a separate form, as the whole post is a form
		var values = {}
		jQuery.each(jQuery(".subscriben_subscription_items_edit"), function(i, field) {
			values[field.id] = field.value;
		});
		
		jQuery.post(
			ajaxurl,
			{
				'action': 'update_renewal_quantity_and_price',
				'form_data': JSON.stringify(values),
			},
			function(response) {
				//Do the thing with the response
				var result = jQuery.parseJSON(response);
				
				if (result.success !== true) {
					alert(subscriben_vars.price_change_fail_alert+' '+result.error);
				}
				
				// Reload the page to update transactions list
				location.reload();
			}
		);
	});
});
