/**
 * Subscriben Plugin Frontend Scripts
 */
jQuery(function() {

	/**
	 * Prompt user to confirm actions
	 */
	jQuery('#subscriben_button_pause_subscription').on('click', function(e) {
		e.preventDefault();
		if (confirm(subscriben_vars.confirm_pause)) {
			window.location = this.href;
		}
	});
	jQuery('#subscriben_button_resume_subscription').on('click', function(e) {
		e.preventDefault();
		if (confirm(subscriben_vars.confirm_resume)) {
			window.location = this.href;
		}
	});
	jQuery('#subscriben_button_cancel_subscription').on('click', function(e) {
		e.preventDefault();
		
		var confirm_text = subscriben_vars.confirm_cancel;
		
		// Check if the button has a custom confirm text
		if (jQuery(this).data('confirm-text') && jQuery(this).data('confirm-text') !== '') {
			confirm_text = jQuery(this).data('confirm-text');
		}
		
		// Display the confirm popup
		if (confirm(confirm_text)) {
			window.location = this.href;
		}
	});
});
