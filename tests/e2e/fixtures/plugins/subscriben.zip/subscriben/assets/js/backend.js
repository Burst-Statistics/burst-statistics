/**
 * Subscriben Plugin Backend Scripts
 */
jQuery(function($) {
	
	$('.subscription-debug-details-show-hide').on('click', function() {
		
		var subscription_id = $(this).data('subscription-id');
		if (subscription_id) {
			$('.subscription-debug-details-'+subscription_id).slideToggle('fast');
		}
		
		return false;
	});
});
