(function () {
	// External dependencies
	const { registerPaymentMethod } = window.wc.wcBlocksRegistry;
	const { __ } = window.wp.i18n;
	const { decodeEntities } = window.wp.htmlEntities;
	const { createElement, useState, useEffect, useRef } = window.wp.element;

	// Retrieve settings passed via wp_localize_script in PHP
	const settings = window.subscribenStripeSettings || {};
	
	// Check if settings are empty, log to console and return
	if (Object.keys(settings).length === 0) {
		console.log('Subscriben Stripe Settings are empty:', settings);
		return;
	}

	// Check if inline checkout is enabled and Stripe library is not available
	if (settings.inlineCheckout && typeof Stripe === 'undefined') {
		console.log('Subscriben Stripe library is not available.');
		return;
	}

	// Check if inline checkout is disabled and Stripe Checkout library is not available
	if (!settings.inlineCheckout && typeof StripeCheckout === 'undefined') {
		console.log('Subscriben Stripe Checkout library is not available.');
		return;
	}

	// Initialize Stripe and Elements if inlineCheckout is true
	let stripe, elements;
	if (settings.inlineCheckout) {
		stripe = Stripe(settings.publishableKey);
		elements = stripe.elements();
	}

	// Custom function to render and manage credit card fields
	const Content = function (props) {
		const { eventRegistration, emitResponse, billing } = props;
		const { onPaymentSetup } = eventRegistration;

		// Determine if there are saved cards
		const cardsAvailable = settings.cards && Object.keys(settings.cards).length > 0;

		// Set initial state based on whether there are saved cards
		const [cardElement, setCardElement] = useState(null);
		
		// Determine default card ID
		const defaultCardId =
			cardsAvailable && settings.defaultCard
				? settings.defaultCard
				: cardsAvailable
				? Object.keys(settings.cards)[0]
				: 'none';

		const [cardId, setCardId] = useState(defaultCardId);
		const [showCCForm, setShowCCForm] = useState(cardId === 'none');

		const billingData = billing.billingAddress || billing.billingData || {};

		// Create a reference to the card Element container
		const cardElementRef = useRef(null);

		// Initialize the card Element when the component mounts or showCCForm changes
		useEffect(() => {
			if (!settings.inlineCheckout) {
				return;
			}
			if (!showCCForm) {
				return;
			}
			
			const cardOptions = {
				hidePostalCode: true,
			};
			const card = elements.create('card', cardOptions);
			
			if (cardElementRef.current) {
				card.mount(cardElementRef.current);

				setCardElement(card);

				// Handle real-time validation errors from the card Element
				card.on('change', function (event) {
					const displayError = document.getElementById('card-errors');
					displayError.textContent = event.error ? event.error.message : '';
				});
			}

			return () => {
				// Clean up when the component unmounts or showCCForm changes
				card.destroy();
				setCardElement(null);
			};
		}, [showCCForm]);

		// Set up onPaymentSetup
		useEffect(() => {
			const unsubscribe = onPaymentSetup(async () => {
				// Prepare paymentMethodData to include card_id
				let paymentMethodData = {
					card_id: cardId,
				};

				// If a saved card is selected, return immediately
				if (cardId && cardId !== 'none') {
					return {
						type: emitResponse.responseTypes.SUCCESS,
						meta: {
							paymentMethodData,
						},
					};
				}

				// If "Use a new card" is selected
				if (showCCForm) {
					if (settings.inlineCheckout) {
						// Handle inline checkout using Stripe Elements
						if (cardElement) {
							// Ensure billing data is available
							if (!billingData || !billingData.first_name || !billingData.last_name) {
								return {
									type: emitResponse.responseTypes.ERROR,
									message: __('Please fill out your billing details.', 'subscriben-stripe'),
								};
							}

							// Use billingData to construct billingDetails
							const billingDetails = {
								name: `${billingData.first_name || ''} ${billingData.last_name || ''}`,
								address_line1: billingData.address_1 || '',
								address_line2: billingData.address_2 || '',
								address_city: billingData.city || '',
								address_state: billingData.state || '',
								address_zip: billingData.postcode || '',
								address_country: billingData.country || '',
							};

							// Create token using Stripe Elements
							const result = await stripe.createToken(cardElement, billingDetails);

							if (result.error) {
								return {
									type: emitResponse.responseTypes.ERROR,
									message:
										result.error.message ||
										__('Failed to tokenize card details', 'subscriben-stripe'),
								};
							}

							// Extract token ID
							const { id: tokenId } = result.token;

							// Add token to paymentMethodData
							paymentMethodData.token = tokenId;

							// Return success response with token and card_id
							return {
								type: emitResponse.responseTypes.SUCCESS,
								meta: {
									paymentMethodData,
								},
							};
						} else {
							// Return error if card Element is not initialized
							return {
								type: emitResponse.responseTypes.ERROR,
								message: __('Payment form is not ready', 'subscriben-stripe'),
							};
						}
					} else {
						// Handle non-inline checkout (Stripe Checkout modal)
						return new Promise((resolve) => {
							// Define the response handler
							const stripeResponseHandler = function (token) {
								// Add token to paymentMethodData
								paymentMethodData.token = token.id;

								// Return success response with token and card_id
								resolve({
									type: emitResponse.responseTypes.SUCCESS,
									meta: {
										paymentMethodData,
									},
								});
							};

							// Open Stripe Checkout modal
							StripeCheckout.open({
								key: settings.publishableKey,
								name: settings.title || '',
								description: settings.description || '',
								panelLabel: settings.modalLabel || '',
								image: settings.modalImage || '',
								amount: settings.modalAmount,
								currency: settings.modalCurrency,
								locale: 'auto',
								email: billingData.email || '',
								token: stripeResponseHandler,
							});
						});
					}
				} else {
					// If showCCForm is false and no saved card is selected, return an error
					return {
						type: emitResponse.responseTypes.ERROR,
						message: __('Please select a payment method.', 'subscriben-stripe'),
					};
				}
			});

			return () => {
				unsubscribe();
			};
		}, [settings.inlineCheckout, cardElement, cardId, billingData, showCCForm]);
		
		// Handle card selection change
		const handleCardSelectionChange = (e) => {
			setCardId(e.target.value);
			if (e.target.value === 'none') {
				setShowCCForm(true);
			} else {
				setShowCCForm(false);
			}
		};
		
		// Render the description and debug mode if applicable
		const renderDescription = () => {
			const descriptionElements = [];
			if (settings.description) {
				descriptionElements.push(
					createElement('div', { key: 'description' }, settings.description)
				);
			}
			if (settings.isDebug) {
				descriptionElements.push(
					createElement(
						'div',
						{
							className: 'wc-block-components-notices',
							key: 'test-mode-notice',
						},
						createElement(
							'div',
							{
								className: 'wc-block-store-notice wc-block-components-notice-banner is-warning',
							},
							[
								createElement(
									'svg',
									{
										xmlns: 'http://www.w3.org/2000/svg',
										viewBox: '0 0 24 24',
										width: '24',
										height: '24',
										'aria-hidden': 'true',
										focusable: 'false',
										key: 'svg-icon',
									},
									createElement('path', {
										d: 'M12 3.2c-4.8 0-8.8 3.9-8.8 8.8 0 4.8 3.9 8.8 8.8 8.8 4.8 0 8.8-3.9 8.8-8.8 0-4.8-4-8.8-8.8-8.8zm0 16c-4 0-7.2-3.3-7.2-7.2C4.8 8 8 4.8 12 4.8s7.2 3.3 7.2 7.2c0 4-3.2 7.2-7.2 7.2zM11 17h2v-6h-2v6zm0-8h2V7h-2v2z',
									})
								),
								createElement(
									'div',
									{
										className: 'wc-block-components-notice-banner__content',
										key: 'test-mode-content',
									},
									[
										createElement(
											'div',
											{ key: 'test-mode-desc' },
											[
												__('Test Mode enabled.', 'subscriben-stripe'),
												' ',
												__('Click', 'subscriben-stripe'),
												' ',
												createElement(
													'a',
													{
														href: 'https://stripe.com/docs/testing#cards',
														target: '_blank',
														key: 'test-mode-link',
														style: { textDecoration: 'underline' },
													},
													__('here', 'subscriben-stripe')
												),
												' ',
												__('for a list of test card numbers.', 'subscriben-stripe'),
											]
										),
									]
								),
							]
						)
					)
				);
			}
			return createElement(
				'div',
				{ className: 'subscriben_stripe_description', key: 'description-wrapper' },
				descriptionElements
			);
		};

		// Render card selection if saved cards are available
		const renderCardSelection = () => {
			if (!cardsAvailable) {
				return null;
			}

			const cardOptions = [];

			// Helper function to parse card details from the string
			function parseCardDetails(cardString) {
				const nameMatch = cardString.match(/^(.*?)\sending/); // Extract card name until "ending with"
				const last4Match = cardString.match(/ending with (\d{4})/); // Extract last 4 digits
				const expiryMatch = cardString.match(/\(expires (\d{1,2})\/(\d{4})\)/); // Extract expiry month/year

				return {
					name: nameMatch ? nameMatch[1] : __('Card', 'subscriben-stripe'), // Fallback to 'Card' if card name is undefined
					last4: last4Match ? last4Match[1] : '****',
					expiryMonth: expiryMatch ? expiryMatch[1] : 'MM',
					expiryYear: expiryMatch ? expiryMatch[2] : 'YYYY',
				};
			}

			// Render saved cards as radio buttons
			Object.entries(settings.cards)
				.filter(([card_id]) => card_id !== 'none')
				.forEach(([card_id, cardString]) => {
					// Parse card details from the card string
					const { name, last4, expiryMonth, expiryYear } = parseCardDetails(cardString);

					cardOptions.push(
						createElement(
							'div',
							{
								key: `card-${card_id}`,
								style: {
									marginBottom: '10px',
									padding: '8px',
									border: '1px solid #ccc',
									borderRadius: '4px',
								},
							},
							[
								createElement('input', {
									type: 'radio',
									id: `subscriben_stripe_card_id_${card_id}`,
									name: 'subscriben_stripe_card_id',
									value: card_id,
									checked: cardId === card_id,
									onChange: handleCardSelectionChange,
									key: `input-${card_id}`,
									style: {
										marginRight: '8px',
									},
								}),
								createElement(
									'label',
									{
										htmlFor: `subscriben_stripe_card_id_${card_id}`,
										key: `label-${card_id}`,
										style: {
											fontSize: '.875em',
											display: 'inline',
											fontWeight: 'bold',
										},
									},
									// Translators: 1. card name (e.g., "Visa"), 2. last 4 digits of the card.
									sprintf(
										__('%1$s ending in %2$s', 'subscriben-stripe'), 
										name, 
										last4
									)
								),
								createElement(
									'span',
									{
										key: `span-${card_id}`,
										style: {
											fontSize: '.75em',
											display: 'block',
											color: '#666',
											marginTop: '4px',
										},
									},
									// Translators: 1. expiration month, 2. expiration year.
									sprintf(
										__('Expires %1$s/%2$s', 'subscriben-stripe'),
										expiryMonth,
										expiryYear
									)
								),
							]
						)
					);
				});

			// Add the 'Use a new card' option
			cardOptions.push(
				createElement(
					'div',
					{
						key: 'card-new',
						style: {
							marginBottom: '10px',
							padding: '8px',
							border: '1px solid #ccc',
							borderRadius: '4px',
						},
					},
					[
						createElement('input', {
							type: 'radio',
							id: 'subscriben_stripe_card_id_new',
							name: 'subscriben_stripe_card_id',
							value: 'none',
							checked: cardId === 'none',
							onChange: handleCardSelectionChange,
							key: 'input-new',
							style: {
								marginRight: '8px',
							},
						}),
						createElement(
							'label',
							{
								htmlFor: 'subscriben_stripe_card_id_new',
								key: 'label-new',
								style: {
									fontSize: '.875em',
									display: 'inline',
									fontWeight: 'bold',
								},
							},
							__('Use a new card', 'subscriben-stripe')
						),
					]
				)
			);
			
			return createElement(
				'div',
				{ className: 'subscriben_stripe_card_options', key: 'card-options' },
				cardOptions
			);
		};

		// Render card fields using Stripe Elements
		const renderCardFields = () => {
			if (!showCCForm) {
				return null;
			}
			return createElement(
				'div',
				{
					className: 'subscriben_stripe_card_fields',
					id: 'subscriben_stripe-cc-form',
					key: 'card-fields',
					style: { marginBottom: '12px' },
				},
				[
					createElement(
						'div',
						{
							className: 'wc-block-components-text-input wc-block-components-card-number is-active',
							key: 'card-element-container',
						},
						[
							createElement('div', {
								id: 'card-element',
								className: 'wc-block-components-text-input__input wc-credit-card-form-card-number',
								key: 'card-element',
								ref: cardElementRef,
								style: {
									border: '1px solid hsla(0, 0%, 7%, 0.11)',
									borderRadius: '4px',
									padding: '16px',
								},
							}),
							// Error message container
							createElement('div', {
								id: 'card-errors',
								role: 'alert',
								style: {
									fontSize: '.875em',
									color: '#eb1c26',
									marginTop: '5px'
								},
								key: 'card-errors',
							}),
						]
					),
				]
			);
		};

		// Render the credit card form
		return createElement(
			'div',
			{ className: 'subscriben_stripe_credit_card_form', key: 'credit-card-form' },
			[
				renderDescription(),
				renderCardSelection(),
				settings.inlineCheckout ? renderCardFields() : null,
			]
		);
	};
	
	// Label component to display the payment method's icon
	const Label = function () {
		return createElement('img', {
			src: settings.icon,
			alt: decodeEntities(settings.title || __('Credit Card (Stripe)', 'subscriben-stripe')),
			key: 'payment-method-label',
		});
	};

	// Payment method configuration object
	const subscribenStripePaymentMethod = {
		name: settings.name || 'subscriben_stripe',
		label: createElement(Label),
		content: createElement(Content, { key: 'content' }),
		edit: createElement(Content, { key: 'edit' }),
		canMakePayment: function () {
			return true;
		},
		ariaLabel: decodeEntities(settings.title || __('Pay via Subscriben Stripe', 'subscriben-stripe')),
		supports: {
			features: settings.supports || [],
		},
		key: 'subscriben-stripe-method',
	};

	// Register the payment method with WooCommerce Blocks
	registerPaymentMethod(subscribenStripePaymentMethod);
})();
