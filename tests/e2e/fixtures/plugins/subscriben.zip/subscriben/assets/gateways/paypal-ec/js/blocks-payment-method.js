(function () {
	// External dependencies
	const { registerPaymentMethod } = window.wc.wcBlocksRegistry;
	const { __ } = window.wp.i18n;
	const { decodeEntities } = window.wp.htmlEntities;
	const { createElement } = window.wp.element;

	// Retrieve settings passed via wp_localize_script in PHP
	const settings = window.subscribenPayPalECSettings || {};
	
	// Check if settings are empty, log to console and return
	if (Object.keys(settings).length === 0) {
		console.log('PayPal EC Settings are empty:', settings);
		return;
	}

	// Content component to display the payment method's description
	const Content = function () {
		// Render the description and debug mode if applicable
		const renderDescription = () => {
			const descriptionElements = [];
			if (settings.description) {
				descriptionElements.push(
					createElement('div', { key: 'description' }, settings.description)
				);
			}
			if (settings.isSandbox) {
				descriptionElements.push(
					createElement(
						'div',
						{
							className: 'wc-block-components-notices',
							key: 'test-mode-notice',
						},
						createElement(
							'div',
							{
								className: 'wc-block-store-notice wc-block-components-notice-banner is-warning',
							},
							[
								createElement(
									'svg',
									{
										xmlns: 'http://www.w3.org/2000/svg',
										viewBox: '0 0 24 24',
										width: '24',
										height: '24',
										'aria-hidden': 'true',
										focusable: 'false',
										key: 'svg-icon',
									},
									createElement('path', {
										d: 'M12 3.2c-4.8 0-8.8 3.9-8.8 8.8 0 4.8 3.9 8.8 8.8 8.8 4.8 0 8.8-3.9 8.8-8.8 0-4.8-4-8.8-8.8-8.8zm0 16c-4 0-7.2-3.3-7.2-7.2C4.8 8 8 4.8 12 4.8s7.2 3.3 7.2 7.2c0 4-3.2 7.2-7.2 7.2zM11 17h2v-6h-2v6zm0-8h2V7h-2v2z',
									})
								),
								createElement(
									'div',
									{
										className: 'wc-block-components-notice-banner__content',
										key: 'test-mode-content',
									},
									[
										createElement(
											'div',
											{ key: 'test-mode-desc' },
											[
												__('Test Mode enabled.', 'subscriben-stripe'),
											]
										),
									]
								),
							]
						)
					)
				);
			}
			return createElement(
				'div',
				{ className: 'subscriben_stripe_description', key: 'description-wrapper' },
				descriptionElements
			);
		};
		
		return renderDescription();
	};

	// Payment method configuration object
	const subscribenPayPalECPaymentMethod = {
		name: settings.name || 'subscriben_paypal_ec',
		label: decodeEntities(settings.title || __('PayPal', 'subscriben-paypal-ec')),
		content: createElement(Content, { key: 'content' }),
		edit: createElement(Content, { key: 'edit' }),
		canMakePayment: function () {
			return true;
		},
		ariaLabel: decodeEntities(settings.title || __('Pay via PayPal', 'subscriben-paypal-ec')),
		supports: {
			features: settings.supports || [],
		},
		key: 'subscriben-paypal-ec',
		placeOrderButtonLabel: settings.orderButtonLabel || __('Go to PayPal', 'subscriben-paypal-ec'),
	};

	// Register the payment method with WooCommerce Blocks
	registerPaymentMethod(subscribenPayPalECPaymentMethod);
})();
