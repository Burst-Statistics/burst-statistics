/**
 * Scripts for Stripe modal credit card form
 */
jQuery(function() {

	/**
	 * Hide new card form if saved cards exist
	 */
	if (jQuery('input[name=subscriben_stripe_card_id]').length < 2) {
		jQuery('fieldset#subscriben_stripe-cc-form').hide();
	}

	/**
	 * Switch between cards
	 */
	jQuery('input[name=subscriben_stripe_card_id]').on('change', function() {
		if (jQuery('input[name=subscriben_stripe_card_id]:checked').val() === 'none' || (jQuery(this).attr('type') === 'hidden' && jQuery(this).val() === 'none')) {
			jQuery('fieldset#subscriben_stripe-cc-form').show();
		}
		else {
			jQuery('fieldset#subscriben_stripe-cc-form').hide();
		}
	});

	/**
	 * Open Stripe Checkout modal
	 */
	function subscriben_stripe_open_stripe_modal() {

		// Revert to default action if not our method or customer is not adding a new card
		if (jQuery('input[name=payment_method]:checked').val() !== 'subscriben_stripe' || (jQuery('input[type=radio][name=subscriben_stripe_card_id]:checked').val() !== 'none' && jQuery('input[type=hidden][name=subscriben_stripe_card_id]').val() !== 'none') || jQuery('input[name=subscriben_stripe_token]').length !== 0) {
			return true;
		}

		// Reset any previously set values
		subscriben_stripe_stripe_form_reset();


		// Process response from Stripe
		var subscriben_stripe_stripe_response_handler = function(response) {
			var form = jQuery('form#order_review').length > 0 ? jQuery('form#order_review') : jQuery('form.checkout');

			// Reset any previously set values
			subscriben_stripe_stripe_form_reset();

			// Set token
			form.append(jQuery('<input type="hidden" name="subscriben_stripe_token" />').val(response.id));

			// Submit form programmatically
			form.trigger('submit');
		}

		// Open Stripe Checkout
		StripeCheckout.open({
			key:            subscriben_stripe_config.publishable_key,
			name:           subscriben_stripe_config.checkout_name,
			description:    subscriben_stripe_config.checkout_description,
			panelLabel:     subscriben_stripe_config.checkout_label,
			image:          subscriben_stripe_config.checkout_image,
			amount:         jQuery('#subscriben_stripe_card_amount').val() !== subscriben_stripe_config.checkout_amount ? jQuery('#subscriben_stripe_card_amount').val() : subscriben_stripe_config.checkout_amount,
			currency:       subscriben_stripe_config.checkout_currency,
			locale:         'auto',
			email:          jQuery('#billing_email').val() ? jQuery('#billing_email').val() : subscriben_stripe_config.checkout_email,
			token:          subscriben_stripe_stripe_response_handler
		});

		return false;
	}

	jQuery('form.checkout').on('checkout_place_order_subscriben_stripe', function() {
		return subscriben_stripe_open_stripe_modal();
	});
	jQuery('form#order_review').on('submit', function() {
		return subscriben_stripe_open_stripe_modal();
	});

	/**
	 * Reset warnings and hidden fields
	 */
	function subscriben_stripe_stripe_form_reset() {
		jQuery('input[name=subscriben_stripe_token]').remove();
	}

});
