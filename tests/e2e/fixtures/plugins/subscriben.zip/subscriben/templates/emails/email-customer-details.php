<?php
/**
 * Customer email customer details
 */

 // phpcs:disable VariableAnalysis.CodeAnalysis.VariableAnalysis.UndefinedVariable -- This file can be ignore as the variables are passed to this file

// Exit if accessed directly
if (!defined('ABSPATH')) {
	exit;
}

?>

<?php if (Simba_Subscriptions_WC_Legacy::order_get_billing_email($order)) : ?>
	<p><strong><?php _e('Email:', 'subscriben'); ?></strong> <?php echo Simba_Subscriptions_WC_Legacy::order_get_billing_email($order); ?></p>
<?php endif; ?>
<?php if (Simba_Subscriptions_WC_Legacy::order_get_billing_phone($order)) : ?>
	<p><strong><?php _e('Tel:', 'subscriben'); ?></strong> <?php echo Simba_Subscriptions_WC_Legacy::order_get_billing_phone($order); ?></p>
<?php endif; ?>

<?php wc_get_template('emails/email-addresses.php', array('order' => $order, 'sent_to_admin' => $sent_to_admin));

// phpcs:enable VariableAnalysis.CodeAnalysis.VariableAnalysis.UndefinedVariable -- This file can be ignore as the variables are passed to this file