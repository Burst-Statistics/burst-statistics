<?php
/**
 * Customer Subscription Completed Order email template (plain text)
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
	exit;
}

echo $email_heading . "\n\n";

echo sprintf(__('Hi there. Your recent subscription renewal order on %s has been completed. Your order details are shown below for your reference:', 'subscriben'), get_option('blogname')) . "\n\n";

echo "****************************************************\n\n";

do_action('woocommerce_email_before_order_table', $order, $sent_to_admin, $plain_text);

echo __('Order:', 'subscriben') . ' ' . $order->get_order_number() . "\n";

do_action('woocommerce_email_order_meta', $order, $sent_to_admin, $plain_text);

Simba_Subscriptions::include_template('emails/plain/email-order-items', array('order' => $order, 'plain_text' => true));

echo "\n****************************************************\n\n";

do_action('woocommerce_email_after_order_table', $order, $sent_to_admin, $plain_text);

echo __('Customer details', 'subscriben') . "\n";

Simba_Subscriptions::include_template('emails/plain/email-customer-details', array('order' => $order, 'plain_text' => true));

echo "\n****************************************************\n\n";

echo apply_filters('woocommerce_email_footer_text', get_option('woocommerce_email_footer_text'));
