<?php
/**
 * Customer Subscription Cancelled email template
 */
 // phpcs:disable VariableAnalysis.CodeAnalysis.VariableAnalysis.UndefinedVariable -- This file can be ignore as the variables are passed to this file
// Exit if accessed directly
if (!defined('ABSPATH')) {
	exit;
}

?>

<?php do_action('woocommerce_email_header', $email_heading, $email); ?>

<p><?php printf(__('Your subscription on %s has been cancelled.', 'subscriben'), get_option('blogname')); ?></p>

<p><?php _e('Details of the cancelled subscription are shown below for your reference:', 'subscriben'); ?></p>

<?php do_action('subscriben_email_before_subscription_table', $subscription, $sent_to_admin, $plain_text); ?>

<h2><?php echo __('Subscription:', 'subscriben') . ' ' . $subscription->get_subscription_number(); ?></h2>
<?php Simba_Subscriptions::include_template('emails/email-subscription-items', array('subscription' => $subscription, 'plain_text' => false)); ?>

<?php do_action('subscriben_email_after_subscription_table', $subscription, $sent_to_admin, $plain_text); ?>

<?php do_action('woocommerce_email_footer');
// phpcs:enable VariableAnalysis.CodeAnalysis.VariableAnalysis.UndefinedVariable -- This file can be ignore as the variables are passed to this file