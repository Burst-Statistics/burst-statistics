<?php
/**
 * Customer email subscription cancel link
 */

// phpcs:disable VariableAnalysis.CodeAnalysis.VariableAnalysis.UndefinedVariable -- This file can be ignore as the variables are passed to this file

// Exit if accessed directly
if (!defined('ABSPATH')) {
	exit;
}

?>

<dl>
<?php
$s=0;
foreach ($subscriptions as $subscription) {
	$actions = $subscription->get_frontend_actions(false);
	if (!empty($actions)) {
		$s++;
		if (1 == $s) {
		?>
			<p><?php _e('To cancel the associated subscription for this order please use the following link:', 'subscriben'); ?></p>
			<table cellspacing="0" cellpadding="6" style="width: 100%; border: 1px solid #eee;" border="1" bordercolor="#eee">
				<thead>
					<tr>
						<th scope="col" style="text-align:left; border: 1px solid #eee;"><?php _e('Subscription', 'subscriben'); ?></th>
						<th scope="col" style="text-align:left; border: 1px solid #eee;"><?php _e('Action', 'subscriben'); ?></th>
					</tr>
				</thead>
				<tbody>
		<?php
		}
		?>
		<tr>
			<td style="text-align:left; vertical-align:middle; border: 1px solid #eee; word-wrap:break-word;"><?php echo __('Subscription: ', 'subscriben') . ' ' . $subscription->get_subscription_number(); ?></td>
			<td style="text-align:center; vertical-align:middle; border: 1px solid #eee;">
		<?php
		foreach ($actions as $action_key => $action) {
			if ('cancel_subscription' == $action_key) {
			?>
				<a style="background-color:#557da1;padding:10px 15px;color:#fff;text-decoration:none;font-weight:bold;" href="<?php echo $subscription->get_frontend_link('view-subscription'); ?>"><?php echo $action['title']; ?></a>
			<?php
			}
		}
		?>
			</td>
		</tr>
	<?php
	}
}
if ($s > 0) {
	?>
	</tbody>
	</table>
	<?php
}
