<?php
/**
 * Customer email customer details (plain text)
 */
// phpcs:disable VariableAnalysis.CodeAnalysis.VariableAnalysis.UndefinedVariable
// Exit if accessed directly
if (!defined('ABSPATH')) {
	exit;
}

if (Simba_Subscriptions_WC_Legacy::order_get_billing_email($order)) {
	echo __('Email:', 'subscriben');
	echo Simba_Subscriptions_WC_Legacy::order_get_billing_email($order) . "\n";
}
if (Simba_Subscriptions_WC_Legacy::order_get_billing_phone($order)) {
	echo __('Tel:', 'subscriben');
	echo Simba_Subscriptions_WC_Legacy::order_get_billing_phone($order) . "\n";
}

wc_get_template('emails/plain/email-addresses.php', array('order' => $order, 'sent_to_admin' => $sent_to_admin));
// phpcs:enable VariableAnalysis.CodeAnalysis.VariableAnalysis.UndefinedVariable