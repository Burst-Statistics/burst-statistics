<?php
/**
 * Customer Subscription Payment Overdue email template
 */
 // phpcs:disable VariableAnalysis.CodeAnalysis.VariableAnalysis.UndefinedVariable -- This file can be ignore as the variables are passed to this file
// Exit if accessed directly
if (!defined('ABSPATH')) {
	exit;
}

?>

<?php do_action('woocommerce_email_header', $email_heading, $email); ?>

<p><?php printf(__('Your recent subscription renewal order on %s is late for payment.', 'subscriben'), get_option('blogname')); ?></p>

<p><?php printf(__('If you do not pay it by <strong>%s</strong>, your %s will be <strong>%s</strong>.', 'subscriben'), $next_action_datetime, _n('subscription', 'subscriptions', count($order->get_items()), 'subscriben'), $next_action); ?></p>

<p><?php _e('To pay for this order please use the following link:', 'subscriben'); ?></p>
<p style="padding:10px 0;"><a style="background-color:#557da1;padding:10px 15px;color:#fff;text-decoration:none;font-weight:bold;" href="<?php echo esc_url($order->get_checkout_payment_url()); ?>"><?php _e('pay now', 'subscriben'); ?></a></p>

<p><?php _e('Your order details are shown below for your reference:', 'subscriben'); ?></p>

<?php do_action('woocommerce_email_before_order_table', $order, $sent_to_admin, $plain_text); ?>

<h2><?php echo __('Order:', 'subscriben') . ' ' . $order->get_order_number(); ?></h2>
<?php Simba_Subscriptions::include_template('emails/email-order-items', array('order' => $order, 'plain_text' => false)); ?>

<?php do_action('woocommerce_email_after_order_table', $order, $sent_to_admin, $plain_text); ?>

<?php do_action('woocommerce_email_order_meta', $order, $sent_to_admin, $plain_text); ?>

<h2><?php _e('Customer details', 'subscriben'); ?></h2>
<?php Simba_Subscriptions::include_template('emails/email-customer-details', array('order' => $order, 'plain_text' => false, 'sent_to_admin' => $sent_to_admin)); ?>

<?php do_action('woocommerce_email_footer');
// phpcs:enable VariableAnalysis.CodeAnalysis.VariableAnalysis.UndefinedVariable -- This file can be ignore as the variables are passed to this file