<?php
/**
 * Customer email subscription items (plain text)
 */

// phpcs:disable VariableAnalysis.CodeAnalysis.VariableAnalysis.UndefinedVariable

// Exit if accessed directly
if (!defined('ABSPATH')) {
	exit;
}

echo "\n\n" . sprintf(__('Product: %s', 'subscriben'), ($subscription->variation_id ? sprintf(__('Variation #%1$s of', 'subscriben'), $subscription->variation_id) . ' ' : '') . $subscription->product_name);

echo "\n" . sprintf(__('Quantity: %s', 'subscriben'), $subscription->quantity);

echo "\n" . sprintf(__('Cost: %s', 'subscriben'), $subscription->get_formatted_recurring_amount());

if ($subscription->needs_shipping()) {

	echo "\n\n" . sprintf(__('Shipping: %s', 'subscriben'), $subscription->shipping['name']);

	echo "\n" . sprintf(__('Quantity: %s', 'subscriben'), $subscription->quantity);

	echo "\n" . sprintf(__('Cost: %s', 'subscriben'), $subscription->get_formatted_price(($subscription->renewal_order_shipping + $subscription->renewal_order_shipping_tax)));
}

// phpcs:enable VariableAnalysis.CodeAnalysis.VariableAnalysis.UndefinedVariable