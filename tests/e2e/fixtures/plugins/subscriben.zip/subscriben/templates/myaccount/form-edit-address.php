<?php
/**
 * Customer Subscription Edit Shipping Address
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
	exit;
}

?>

<?php do_action('woocommerce_account_navigation'); ?>
<div class="woocommerce-MyAccount-content">

<?php do_action('subscriben_before_subscription_address_edit'); ?>

<p class="subscriben_subscription_info"><?php printf(__('You are editing shipping address for subscription %s.', 'subscriben'), $subscription->get_subscription_number()); ?></p>

<?php wc_print_notices(); ?>

<form method="post">

	<?php foreach ($address as $key => $field) : ?>
		<?php woocommerce_form_field($key, $field, $field['value']); ?>
	<?php endforeach; ?>

	<p>
		<input type="hidden" name="action" value="subscriben_edit_address" />
		<input type="submit" class="button" name="save_address" value="<?php _e('Save Address', 'subscriben'); ?>" />
	</p>

</form>

<?php do_action('subscriben_after_subscription_address_edit'); ?>

</div>
