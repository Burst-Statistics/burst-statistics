<?php
/**
 * Customer Subscription View
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
	exit;
}

?>

<?php wc_print_notices(); ?>

<?php do_action('woocommerce_account_navigation'); ?>
<div class="woocommerce-MyAccount-content">

<?php do_action('subscriben_before_subscription', $subscription); ?>

<?php if ('pending' == $subscription->status) : ?>
	<p class="subscriben_subscription_info"><?php printf(__('Subscription %s is pending first payment.', 'subscriben'), '<mark class="subscriben_subscription_info_number">'.$subscription->get_subscription_number().'</mark>'); ?></p>
<?php elseif (!$subscription->is_inactive()) : ?>
	<p class="subscriben_subscription_info"><?php printf(__('Subscription %s was started on %s and is currently %s%s.', 'subscriben'), '<mark class="subscriben_subscription_info_number">'.$subscription->get_subscription_number().'</mark>', '<mark class="subscriben_subscription_info_start">'. Simba_Subscriptions::get_adjusted_datetime($subscription->started, null, 'subscription_frontend_started') .'</mark>', '<mark class="subscriben_subscription_info_status">'.$subscription->get_formatted_status().'</mark>', $subscription->get_status_details()); ?></p>
<?php elseif ('cancelled' == $subscription->status) : ?>
	<p class="subscriben_subscription_info"><?php printf(__('Subscription %s has been %s.', 'subscriben'), '<mark class="subscriben_subscription_info_number">'.$subscription->get_subscription_number().'</mark>', '<mark class="subscriben_subscription_info_status">'.$subscription->get_formatted_status().'</mark>'); ?></p>
<?php else : ?>
	<p class="subscriben_subscription_info"><?php printf(__('Subscription %s has %s.', 'subscriben'), '<mark class="subscriben_subscription_info_number">'.$subscription->get_subscription_number().'</mark>', '<mark class="subscriben_subscription_info_status">'.$subscription->get_formatted_status().'</mark>'); ?></p>
<?php endif; ?>

<div class="subscriben_frontend_details">
	<div class="subscriben_frontend_details_general">
		<h2><?php _e('Subscription Details', 'subscriben'); ?></h2>

			<dl>
				<?php if ($subscription->overdue_since) : ?>
					<dt><?php _e('Overdue Since:', 'subscriben'); ?></dt><dd><?php echo Simba_Subscriptions::get_adjusted_datetime($subscription->overdue_since, null, 'subscription_frontend_overdue_since'); ?></dd>
				<?php endif; ?>

				<?php if ($subscription->paused_since) : ?>
					<dt><?php _e('Paused Since:', 'subscriben'); ?></dt><dd><?php echo Simba_Subscriptions::get_adjusted_datetime($subscription->paused_since, null, 'subscription_frontend_paused_since'); ?></dd>
				<?php endif; ?>

				<?php if ($subscription->suspended_since) : ?>
					<dt><?php _e('Suspended Since:', 'subscriben'); ?></dt><dd><?php echo Simba_Subscriptions::get_adjusted_datetime($subscription->suspended_since, null, 'subscription_frontend_suspended_since'); ?></dd>
				<?php endif; ?>

				<?php if ($subscription->cancelled_since) : ?>
					<dt><?php _e('Cancelled Since:', 'subscriben'); ?></dt><dd><?php echo Simba_Subscriptions::get_adjusted_datetime($subscription->cancelled_since, null, 'subscription_frontend_cancelled_since'); ?></dd>
				<?php endif; ?>

				<?php if ($subscription->expired_since) : ?>
					<dt><?php _e('Expired Since:', 'subscriben'); ?></dt><dd><?php echo Simba_Subscriptions::get_adjusted_datetime($subscription->expired_since, null, 'subscription_frontend_expired_since'); ?></dd>
				<?php endif; ?>

				<dt><?php _e('Recurring Amount:', 'subscriben'); ?></dt><dd><?php echo $subscription->get_formatted_recurring_amount(); ?></dd>

				<?php if ($subscription->payment_method_title) : ?>
					<dt><?php _e('Payment Method:', 'subscriben'); ?></dt><dd><?php echo $subscription->payment_method_title; ?></dd>
				<?php endif; ?>

				<?php if ($scheduled_payment = Simba_Subscriptions_Event_Scheduler::get_scheduled_event_timestamp('payment', $subscription->id)) : ?>
					<dt><?php _e('Payment Due:', 'subscriben'); ?></dt><dd><?php echo Simba_Subscriptions::get_adjusted_datetime($scheduled_payment, null, 'subscription_frontend_payment_due'); ?></dd>
				<?php endif; ?>

				<?php $actions = $subscription->get_frontend_actions(false); ?>
				<?php if (!empty($actions)) : ?>
					<dt><?php _e('Actions:', 'subscriben'); ?></dt><dd>
					<?php foreach ($actions as $action_key => $action) : ?>
						<a href="<?php echo $action['url']; ?>" id="subscriben_button_<?php echo sanitize_html_class($action_key); ?>" class="button subscriben_button subscriben_button_<?php echo sanitize_html_class($action_key); ?>"<?php echo (!empty($action['confirm_text'])) ? ' data-confirm-text="'.esc_attr($action['confirm_text']).'"' : ''; ?>><?php echo $action['title']; ?></a>
					<?php endforeach; ?>
					</dd>
				<?php endif; ?>
			</dl>

	</div>
	<?php if ($subscription->needs_shipping()) : ?>
		<div class="subscriben_frontend_details_shipping">
			<h2><?php _e('Shipping Details', 'subscriben'); ?></h2>

			<dl>
				<dt><?php _e('Shipping Method:', 'subscriben'); ?></dt><dd><?php echo $subscription->shipping['name']; ?></dd>
				<dt><?php _e('Shipping Address:', 'subscriben'); ?></dt><dd>
					<address><p>
						<?php echo wp_kses(Simba_Subscriptions::get_formatted_shipping_address($subscription->shipping_address), array('br' => array())); ?>
					</p></address>
				</dd>
			</dl>

		</div>
	<?php endif; ?>
	<div style="clear: both;"></div>
</div>

<h2><?php _e('Subscription Items', 'subscriben'); ?></h2>

<table class="shop_table subscriben_frontend_items_list">
	<thead>
		<tr>
			<th class="subscriben_frontend_items_list_item"><?php _e('Item', 'subscriben'); ?></th>
			<th class="subscriben_frontend_items_list_quantity"><?php _e('Qty', 'subscriben'); ?></th>
			<th class="subscriben_frontend_items_list_total"><?php _e('Total', 'subscriben'); ?></th>
			<th class="subscriben_frontend_items_list_tax"><?php _e('Tax', 'subscriben'); ?></th>
		</tr>
	</thead>

	<tbody>
		<?php foreach ($subscription->get_items() as $item) : ?>
			<tr>
				<td class="subscriben_frontend_items_list_item">
					<?php if (!$item['deleted']) : ?>
						<?php Simba_Subscriptions_Helper::print_frontend_link_to_product($item['product_id'], $item['name'], '', ($item['quantity'] > 1 ? 'x ' . $item['quantity'] : '')); ?>
					<?php else : ?>
						<?php echo $item['name']; ?>
					<?php endif; ?>
					<?php $subscription->show_variable_item_meta($item); ?>
				</td>
				<td class="subscriben_frontend_items_list_quantity"><?php echo $item['quantity']; ?></td>
				<td class="subscriben_frontend_items_list_total"><?php echo $subscription->get_formatted_price($item['total']); ?></td>
				<td class="subscriben_frontend_items_list_tax"><?php echo $subscription->get_formatted_price($item['tax']); ?></td>
			</tr>
		<?php endforeach; ?>

		<?php if ($subscription->needs_shipping()) : ?>
			<tr>
				<td class="subscriben_frontend_items_list_item"><?php echo $subscription->shipping['name']; ?></td>
				<td class="subscriben_frontend_items_list_quantity"><?php echo '1'; ?></td>
				<td class="subscriben_frontend_items_list_total"><?php echo $subscription->get_formatted_price($subscription->renewal_order_shipping); ?></td>
				<td class="subscriben_frontend_items_list_tax"><?php echo $subscription->get_formatted_price($subscription->renewal_order_shipping_tax); ?></td>
			</tr>
		<?php endif; ?>
	</tbody>
</table>

<?php define('SUBSCRIBEN_PRINTING_RELATED_ORDERS', $subscription->id); ?>
<?php wc_get_template('myaccount/my-orders.php', array('order_count' => -1)); ?>

<?php do_action('subscriben_after_subscription', $subscription); ?>

</div>
