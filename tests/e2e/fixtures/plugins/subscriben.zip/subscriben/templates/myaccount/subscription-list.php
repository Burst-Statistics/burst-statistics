<?php
/**
 * Customer Subscription List
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
	exit;
}

?>

<?php if ($display_title) : ?>
	<h2><?php echo $title; ?></h2>
<?php endif; ?>

<?php if (!empty($subscriptions)) : ?>

	<?php do_action('subscriben_before_subscription_list'); ?>

	<table class="shop_table shop_table_responsive subscriben_subscription_list my_account_orders">

		<thead>
			<tr>
				<th class="subscriben_list_id"><?php _e('ID', 'subscriben'); ?></th>
				<th class="subscriben_list_status"><?php _e('Status', 'subscriben'); ?></th>
				<th class="subscriben_list_product"><?php _e('Products', 'subscriben'); ?></th>
				<th class="subscriben_list_recurring"><?php _e('Recurring', 'subscriben'); ?></th>
				<th class="subscriben_list_actions">&nbsp;</th>
			</tr>
		</thead>

		<tbody>

		<?php foreach ($subscriptions as $subscription) : ?>

			<tr class="subscriben_subscription_list_subscription">
				<td data-title="<?php _e('ID', 'subscriben'); ?>" class="subscriben_list_id"><?php echo '<a href="' . $subscription->get_frontend_link('view-subscription') . '">' . $subscription->get_subscription_number() . '</a>'; ?></td>
				<td data-title="<?php _e('Status', 'subscriben'); ?>" class="subscriben_list_status"><?php echo $subscription->get_formatted_status(true); ?></td>
				<td data-title="<?php _e('Products', 'subscriben'); ?>" class="subscriben_list_product">
					<?php foreach (Simba_Subscriptions_Subscription::get_subscription_items($subscription->id) as $item) : ?>
						<?php if (!$item['deleted']) : ?>
							<?php Simba_Subscriptions_Helper::print_frontend_link_to_product($item['product_id'], $item['name'], '', ($item['quantity'] > 1 ? 'x ' . $item['quantity'] : '')); ?>
						<?php else : ?>
							<?php echo $item['name']; ?>
						<?php endif; ?>
						<?php echo '<br>'; ?>
					<?php endforeach; ?>
				</td>
				<td data-title="<?php _e('Recurring', 'subscriben'); ?>" class="subscriben_list_recurring"><?php echo $subscription->get_formatted_recurring_amount(); ?></td>
				<td class="order-actions subscriben_list_actions">
					<?php foreach ($subscription->get_frontend_actions() as $action_key => $action) : ?>
						<a href="<?php echo $action['url']; ?>" class="button subscriben_button_<?php echo sanitize_html_class($action_key); ?>"<?php echo (!empty($action['confirm_text'])) ? ' data-confirm-text="'.esc_attr($action['confirm_text']).'"' : ''; ?>><?php echo $action['title']; ?></a>
					<?php endforeach; ?>
				</td>
			</tr>

		<?php endforeach; ?>

		</tbody>

	</table>

	<?php do_action('subscriben_after_subscription_list'); ?>

<?php else : ?>

	<p><?php _e('You have no subscriptions.', 'subscriben'); ?></p>

<?php endif;
