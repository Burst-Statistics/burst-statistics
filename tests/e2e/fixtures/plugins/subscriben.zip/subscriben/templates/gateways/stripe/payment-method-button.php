<?php
/**
 * Simba_Subscriptions Stripe Payment Method Button
 */

// Exit if accessed directly
if (!defined('ABSPATH')) die('No direct access.');

require_once(ABSPATH.'wp-admin/includes/plugin.php');

?>
<?php if (is_plugin_active('woocommerce-gateway-stripe/woocommerce-gateway-stripe.php')) : ?>
	<p><a type="button" class="button ud_stripe_update_card" href="<?php echo get_option('woocommerce_myaccount_payment_methods_endpoint'); ?>"><?php _e('View your payment methods', 'subscriben'); ?></a></p>
<?php endif;
