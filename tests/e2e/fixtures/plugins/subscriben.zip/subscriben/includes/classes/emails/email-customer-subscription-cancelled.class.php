<?php
/**
 * Exit if accessed directly
 */
if (!defined('ABSPATH')) {
	exit;
}

/**
 * Customer Subscription Cancelled email
 *
 * @class Simba_Subscriptions_Email_Customer_Subscription_Cancelled
 * @package Simba_Subscriptions
 */
if (!class_exists('Simba_Subscriptions_Email_Customer_Subscription_Cancelled')) {

class Simba_Subscriptions_Email_Customer_Subscription_Cancelled extends Simba_Subscriptions_Email {


	/**
	 * Constructor class
	 *
	 * @access public
	 * @return void
	 */
	public function __construct()
	{
		$this->id             = 'customer_subscription_cancelled';
		$this->customer_email = true;
		$this->title          = __('Subscription cancelled', 'subscriben');
		$this->description    = __('Subscription cancelled emails are sent to customers when subscriptions are cancelled - either manually (by customer or shop manager) or automatically (due to non-payment).', 'subscriben');

		$this->heading        = __('Your subscription has been cancelled', 'subscriben');
		$this->subject        = __('Your {site_title} subscription has been cancelled', 'subscriben');

		// Call parent constructor
		parent::__construct();
	}

}
}
