<?php
/**
 * Exit if accessed directly
 */
if (!defined('ABSPATH')) {
	exit;
}

/**
 * Customer Subscription New Order email
 *
 * @class Simba_Subscriptions_Email_Customer_Subscription_New_Order
 * @package Simba_Subscriptions
 */
if (!class_exists('Simba_Subscriptions_Email_Customer_Subscription_New_Order')) {

	class Simba_Subscriptions_Email_Customer_Subscription_New_Order extends Simba_Subscriptions_Email {

		/**
		 * Constructor class
		 *
		 * @access public
		 * @return void
		 */
		public function __construct() {
			$this->id             = 'customer_subscription_new_order';
			$this->customer_email = true;
			$this->title          = __('Subscription new order', 'subscriben');
			$this->description    = __('Subscription new order emails are sent to the customer when a new renewal order is generated.', 'subscriben');

			$this->heading        = __('New subscription renewal order {order_number}', 'subscriben');
			$this->subject        = __('New subscription renewal order {order_number}', 'subscriben');

			// Call parent constructor
			parent::__construct();
		}

		/**
		 * Trigger a notification
		 *
		 * @access public
		 * @param object $order
		 * @param array  $args
		 * @param bool   $send_to_admin
		 * @return void
		 */
		public function trigger($order, $args = array(), $send_to_admin = false) {
			if (!$order) {
				return;
			}

			$this->object = $order;

			if ($send_to_admin) {
				$this->recipient = get_option('admin_email');
			} else {
				$this->recipient = Simba_Subscriptions_WC_Legacy::order_get_billing_email($this->object);
			}

			// Replace macros
			$this->find[] = '{order_number}';
			$this->replace[] = $this->object->get_order_number();

			// Check if this email type is enabled, recipient is set and we are not on a development website
			if (!$this->is_enabled() || !$this->get_recipient() || !Simba_Subscriptions::is_main_site()) {
				return;
			}

			// Get subscription
			$subscriptions = Simba_Subscriptions_Order_Handler::get_subscriptions_from_order_id(Simba_Subscriptions_WC_Legacy::order_get_id($order));
			$subscription = reset($subscriptions);

			if (!$subscription) {
				return;
			}

			$this->template_variables = array(
				'subscription'  => $subscription,
				'subscriptions'  => $subscriptions,
				'order'         => $this->object,
				'email_heading' => $this->get_heading(),
				'sent_to_admin' => false,
				'email'         => $this,
			);

			$this->send($this->get_recipient(), $this->get_subject(), $this->get_content(), $this->get_headers(), $this->get_attachments());
		}

	}
}
