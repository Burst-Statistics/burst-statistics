<?php
/**
 * Exit if accessed directly
 */
if (!defined('ABSPATH')) {
	exit;
}

/**
 * Customer Subscription Expired email
 *
 * @class Simba_Subscriptions_Email_Customer_Subscription_Expired
 * @package Simba_Subscriptions
 */
if (!class_exists('Simba_Subscriptions_Email_Customer_Subscription_Expired')) {

class Simba_Subscriptions_Email_Customer_Subscription_Expired extends Simba_Subscriptions_Email {


	/**
	 * Constructor class
	 *
	 * @access public
	 * @return void
	 */
	public function __construct()
	{
		$this->id             = 'customer_subscription_expired';
		$this->customer_email = true;
		$this->title          = __('Subscription expired', 'subscriben');
		$this->description    = __('Subscription expired emails are sent to customers when subscriptions expire (if they are configured to expire).', 'subscriben');

		$this->heading        = __('Your subscription expired', 'subscriben');
		$this->subject        = __('Your {site_title} subscription expired', 'subscriben');

		// Call parent constructor
		parent::__construct();
	}

}
}
