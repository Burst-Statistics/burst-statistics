<?php
/**
 * Exit if accessed directly
 */
if (!defined('ABSPATH')) die('No direct access.');

/**
 * Defines the base compatibility class for Simba Subscriptions with WooCommerce Stripe.
 *
 * This class conditionally extends either the `WC_Stripe_UPE_Payment_Gateway` or the `WC_Gateway_Stripe`
 * class based on the availability and configuration of the WooCommerce Stripe Gateway plugin.
 *
 * - If the UPE (Universal Payment Experience) checkout is enabled, it extends `WC_Stripe_UPE_Payment_Gateway`.
 * - Otherwise, it falls back to extending `WC_Gateway_Stripe` (legacy Stripe gateway).
 */
if (class_exists('WC_Stripe_UPE_Payment_Gateway') && class_exists('WC_Stripe_Feature_Flags') && method_exists('WC_Stripe_Feature_Flags', 'is_upe_checkout_enabled') && \WC_Stripe_Feature_Flags::is_upe_checkout_enabled()) {
    class Simba_Subscriptions_WC_Stripe_Subs_Compat_Base extends WC_Stripe_UPE_Payment_Gateway {}
} else {
    class Simba_Subscriptions_WC_Stripe_Subs_Compat_Base extends WC_Gateway_Stripe {}
}

/**
 * Compatibility class for subscriptions
 *
 * This is the Team Updraft version of the official WC Stripe gateway class to make
 * the official gateway compatible with Subscriben.
 */
class Simba_Subscriptions_WC_Stripe_Subs_Compat extends Simba_Subscriptions_WC_Stripe_Subs_Compat_Base {
	/**
	 * Prefix for log entries written to the Stripe gateway log,
	 * so they can be distinguished from the gateway's own messages.
	 */
	const LOG_PREFIX = 'Subscriptions: ';

	/**
	 * Constructor
	 *
	 * Team Updraft changes: Remove hooks that we don't need
	 */
	public function __construct() {
		parent::__construct();

		// Stripe fee & payout displaying twice on order edit page so just remove one
		remove_action('woocommerce_admin_order_totals_after_total', array($this, 'display_order_fee'));
		remove_action('woocommerce_admin_order_totals_after_total', array($this, 'display_order_payout'), 20);

		add_action('woocommerce_scheduled_subscription_payment_' . $this->id, array($this, 'scheduled_subscription_payment'), 10, 2);
		add_action('wc_gateway_stripe_process_response', array($this, 'save_meta_data'), 10, 2);
		add_action('wc_gateway_stripe_process_payment_authentication_required', array($this, 'manage_payment_auth_failure'), 10, 2);
	}

	/**
	 * Overloads WC_Stripe_Payment_Gateway::generate_create_intent_request() in order to
	 * include additional flags, used when setting payment intents up for off-session usage.
	 *
	 * @param WC_Order $order           The order that is being paid for.
	 * @param object   $prepared_source The source that is used for the payment.
	 * @return array                    The arguments for the request.
	 */
	public function generate_create_intent_request($order, $prepared_source) {
		$request = parent::generate_create_intent_request($order, $prepared_source);

		// Non-subscription orders do not need any additional parameters.
		if (!$this->has_subscription($order)) {
			return $request;
		}

		// Let Stripe know that the payment should be prepared for future usage.
		$request['setup_future_usage'] = 'off_session';

		return $request;
	}

	/**
	 * Scheduled_subscription_payment function.
	 *
	 * @param $amount_to_charge float The amount to charge.
	 * @param $renewal_order    WC_Order A WC_Order object created to record the renewal payment.
	 */
	public function scheduled_subscription_payment($amount_to_charge, $renewal_order) {
		return $this->process_subscription_payment($amount_to_charge, $renewal_order, true, false);
	}

	/**
	 * Process_subscription_payment function.
	 *
	 * Team Updraft changes: Override the payment description to match our format
	 *                       Make sure true or false is returned so Subscriben knows the result
	 * Team Updraft changes: Add additional logging as subscription notes
	 *
	 * @since 3.0
	 * @since 4.0.4 Add third parameter flag to retry.
	 * @since 4.1.0 Add fourth parameter to log previous errors.
	 * @param $amount         float
	 * @param $renewal_order  mixed
	 * @param $retry          bool Should we retry the process?
	 * @param $previous_error object
	 */
	public function process_subscription_payment($amount, $renewal_order, $retry = true, $previous_error = false) {
		try {
			if ($amount * 100 < WC_Stripe_Helper::get_minimum_amount()) {
				
				// Store Stripe Source ID in the order meta data
				$this->prepare_order_source($renewal_order);
				
				/* translators: minimum amount */
				$localized_error = sprintf(__('Sorry, the minimum allowed order total is %1$s to use this payment method.', 'woocommerce-gateway-stripe'), wc_price(WC_Stripe_Helper::get_minimum_amount() / 100));
				throw new WC_Stripe_Exception(
					'Order ' . $renewal_order->get_id() . ' amount ' . $amount . ' is below Stripe minimum ' . WC_Stripe_Helper::get_minimum_amount() / 100,
					$localized_error
				);
			}
			
			// Team Updraft: Get the subscription object from the order meta
			$subscription = new Simba_Subscriptions_Subscription($renewal_order->get_meta('_subscriben_subscription_id', true));
			
			$order_id = $renewal_order->get_id();

			// Check for an existing intent, which is associated with the order.
			if ($this->has_authentication_already_failed($renewal_order)) {
				return false;
			}

			// Get source from order
			$prepared_source = $this->prepare_order_source($renewal_order);
			$prepared_source = $this->ensure_pm_for_renewal($prepared_source, $renewal_order);
			$source_object   = $prepared_source->source_object;

			WC_Stripe_Logger::log("Info: Begin processing subscription payment for order {$order_id} for the amount of {$amount}");

			/**
			 * If we're doing a retry and source is chargeable, we need to pass
			 * a different idempotency key and retry for success.
			 */
			if (is_object($source_object) && empty($source_object->error) && $this->need_update_idempotency_key($source_object, $previous_error)) {
				add_filter('wc_stripe_idempotency_key', array($this, 'change_idempotency_key'), 10, 2);
			}

			if (($this->is_no_such_source_error($previous_error) || $this->is_no_linked_source_error($previous_error)) && apply_filters('wc_stripe_use_default_customer_source', true)) {
				// Passing empty source will charge customer default.
				$prepared_source->source = '';
			}

			$this->lock_order_payment($renewal_order); // change from 4.3.1
			
			$response                   = $this->create_and_confirm_intent_for_off_session($renewal_order, $prepared_source, $amount);
			$is_authentication_required = $this->is_authentication_required_for_payment($response);

			// It's only a failed payment if it's an error and it's not of the type 'authentication_required'.
			// If it's 'authentication_required', then we should email the user and ask them to authenticate.
			if (!empty($response->error) && !$is_authentication_required) {
				// We want to retry.
				if ($this->is_retryable_error($response->error)) {
					if ($retry) {
						// Don't do anymore retries after this.
						if (5 <= $this->retry_interval) {
							return $this->process_subscription_payment($amount, $renewal_order, false, $response->error);
						}

						sleep($this->retry_interval);

						$this->retry_interval++;

						return $this->process_subscription_payment($amount, $renewal_order, true, $response->error);
					} else {
						$localized_message = sprintf(
							/* translators: 1) error message from Stripe; 2) request log URL */
							__( 'Sorry, we are unable to process the payment at this time. Reason: %1$s %2$s', 'woocommerce-gateway-stripe' ),
							$response->error->message,
							isset( $response->error->request_log_url ) ? make_clickable( $response->error->request_log_url ) : ''
						);
						$renewal_order->add_order_note( $localized_message );
						throw new WC_Stripe_Exception( print_r( $response, true ), $localized_message );
					}
				}

				$localized_messages = WC_Stripe_Helper::get_localized_messages();

				if ( 'card_error' === $response->error->type ) {
					$localized_message = isset( $localized_messages[ $response->error->code ] ) ? $localized_messages[ $response->error->code ] : $response->error->message;
				} elseif ( 'payment_intent_mandate_invalid' === $response->error->type ) {
					$localized_message = __(
						'The mandate used for this renewal payment is invalid. You may need to bring the customer back to your store and ask them to resubmit their payment information.',
						'woocommerce-gateway-stripe'
					);
				} else {
					$localized_message = isset( $localized_messages[ $response->error->type ] ) ? $localized_messages[ $response->error->type ] : $response->error->message;
				}

				if ( isset( $response->error->request_log_url ) ) {
					$localized_message .= ' ' . make_clickable( $response->error->request_log_url );
				}
				
				$renewal_order->add_order_note($localized_message);

				throw new WC_Stripe_Exception( print_r( $response, true ), $localized_message );
			}

			// Either the charge was successfully captured, or it requires further authentication.
			
			if ($is_authentication_required) {
				do_action('wc_gateway_stripe_process_payment_authentication_required', $renewal_order, $response);

				$error_message = __('This transaction requires authentication.', 'woocommerce-gateway-stripe');
				$renewal_order->add_order_note($error_message);

				$charges = $response->error->payment_intent->charges;
				
				if ($charges) {
					$charge = end($charges->data);
					$id = $charge->id;
					$renewal_order->set_transaction_id($id);
					$report_id = $id;
				} else {
					$report_id = __('Charge ID not found', 'subscriben');
				}
				$order_id = $renewal_order->get_id();

				
				$renewal_order->update_status('failed', sprintf(__('Stripe charge awaiting authentication by user: %s.', 'woocommerce-gateway-stripe'), $report_id));
				if ( is_callable( array( $renewal_order, 'save' ) ) ) {
					$renewal_order->save();
				}
				return false;
			} else {
				// The charge was successfully captured
				$renewal_order->set_payment_method($this->id);
				$renewal_order->set_payment_method_title($this->title);
				do_action('wc_gateway_stripe_process_payment', $response, $renewal_order);
				
				$last_charge = isset( $response->charges ) ? end( $response->charges->data ) : $this->get_latest_charge_from_intent( $response );
				$this->process_response($last_charge, $renewal_order);
			}
			$this->unlock_order_payment($renewal_order); // new change from 4.3.1, unlock before returning
			return true;
		} catch (WC_Stripe_Exception $e) {
			WC_Stripe_Logger::log('Error: ' . $e->getMessage());
			
			$error_message = is_callable( array( $e, 'getLocalizedMessage' ) ) ? wp_kses_post( $e->getLocalizedMessage() ) : $e->getMessage();
			
			if (is_object($subscription)) {
				$subscription->add_note(__('Error processing subscription payment:', 'woocommerce-gateway-stripe').' '.$error_message, 'error', $order_id);
			} else {
				$order_id = is_object($renewal_order) ? $renewal_order->get_id() : $renewal_order;
				error_log("Error processing subscription payment (order_id=$order_id): ".$error_message);
			}
			
			do_action('wc_gateway_stripe_process_payment_error', $e, $renewal_order);

			/* translators: error message */
			$renewal_order->update_status('failed');

		} catch (Throwable $e) {
			// Log unexpected exception or error types before rethrowing
			WC_Stripe_Logger::log(sprintf(
				'Caught %s during renewal for order %d: %s (in %s on line %d)', get_class($e), $renewal_order->get_id(), $e->getMessage(), $e->getFile(), $e->getLine()
			));
			throw $e;
		}
		
		return false;
	}
	
	/**
	 * Ensure we have a concrete PaymentMethod (pm_...) for a renewal and that it
	 * belongs to the right Stripe customer. If we're relying on the customer's
	 * default, resolve it; if the saved pm_ is unattached/mismatched, fix it.
	 *
	 * As a last resort, fall back to legacy default_source if no PaymentMethod available
	 *
	 * @param object   $prepared_source Result of prepare_order_source().
	 * @param WC_Order $renewal_order   The renewal order.
	 * @return object                   Updated $prepared_source.
	 * @throws WC_Stripe_Exception      When no usable payment method exists.
	 */
	private function ensure_pm_for_renewal($prepared_source, WC_Order $renewal_order) {
		// Must have a Stripe customer to proceed
		if (empty($prepared_source->customer)) {
			throw new WC_Stripe_Exception(
				'Failed to process renewal for order ' . $renewal_order->get_id() . '. Stripe customer id is missing in the order',
				__( 'Customer not found', 'woocommerce-gateway-stripe' )
			);
		}

		// If we're relying on Stripe's default, resolve a concrete payment method now
		if ($prepared_source->source === '' || $prepared_source->source === false) {
			$cust = WC_Stripe_API::request([], 'customers/' . $prepared_source->customer);
			$pm   = $cust->invoice_settings->default_payment_method ?? null;
			// Only set payment_method for "pm_" IDs (default_payment_method is always a pm_ ID).
			// generate_payment_request() passes this to Stripe as the 'payment_method' parameter,
			// which only accepts pm_ (not src_ or card_) identifiers.
			if ($pm) {
				$prepared_source->payment_method = $pm;
			}
			
			if (!$pm && !empty($cust->default_source)) {
				$pm = $cust->default_source;
				WC_Stripe_Logger::info(
					self::LOG_PREFIX . 'payment method resolved via fallback (default_source fallback)',
					array('order_id' => $renewal_order->get_id(), 'stripe_customer_id' => $prepared_source->customer, 'payment_method' => $pm, 'fallback_path' => 'default_source', 'step' => 'ensure_pm_for_renewal')
				);				
			}

			if (!$pm) {
				throw new WC_Stripe_Exception(
					'No default payment method found for Stripe customer ' . $prepared_source->customer . ' on order ' . $renewal_order->get_id(),
					__('Stripe customer has no default payment method for renewal.', 'subscriben')
				);
			}

			// The source property holds the payment identifier regardless of type (pm_, src_, or card_)
			// The correct Stripe API parameter is resolved downstream by WC_Stripe_Helper::add_payment_method_to_request_array().
			$prepared_source->source = $pm;

			$renewal_order->update_meta_data('_stripe_source_id', $pm);
			if (is_callable(array($renewal_order, 'save_meta_data'))) {
				$renewal_order->save_meta_data();
			}

			// Payment method came from this customer's record, so it's already attached
			return $prepared_source;
		}

		// If we already have a pm_, ensure it's attached to THIS customer
		if (0 === strpos((string) $prepared_source->source, 'pm_')) {
			$pm_obj = $prepared_source->source_object ?: WC_Stripe_API::get_payment_method($prepared_source->source);

			if (empty($pm_obj->customer)) {
				// Attach to this customer
				WC_Stripe_API::request(
					[ 'customer' => $prepared_source->customer ],
					'payment_methods/' . $prepared_source->source . '/attach'
				);
			} elseif ($pm_obj->customer !== $prepared_source->customer) {
				// Mismatch: fall back to customer's default pm
				$cust = WC_Stripe_API::request([], 'customers/' . $prepared_source->customer);
				$pm   = $cust->invoice_settings->default_payment_method ?? null;
				// Only set payment_method for "pm_" IDs (default_payment_method is always a pm_ ID).
				// generate_payment_request() passes this to Stripe as the 'payment_method' parameter,
				// which only accepts pm_ (not src_ or card_) identifiers.
				if ($pm) {
					$prepared_source->payment_method = $pm;			
				}
				
				if (!$pm && !empty($cust->default_source)) {
					$pm = $cust->default_source;
					WC_Stripe_Logger::log('Renewal for order ' . $renewal_order->get_id() . ' using default_source fallback (customer mismatch): ' . $pm);
				}

				if (!$pm) {
					throw new WC_Stripe_Exception(
						'Payment method ' . $prepared_source->source . ' belongs to customer ' . $pm_obj->customer . ' not ' . $prepared_source->customer . '. No default payment method available for order ' . $renewal_order->get_id(),
						__('Saved payment method belongs to a different customer and no default is set.', 'subscriben')
					);
				}

				// The source property holds the payment identifier regardless of type (pm_, src_, or card_)
				// The correct Stripe API parameter is resolved downstream by WC_Stripe_Helper::add_payment_method_to_request_array().
				$prepared_source->source = $pm;

				$renewal_order->update_meta_data('_stripe_source_id', $pm);
				if (is_callable(array($renewal_order, 'save'))) {
					$renewal_order->save_meta_data();
				}
			}
		}

		return $prepared_source;
	}

	/**
	 * Helper: fetch cus_ and pm_ from the subscription's first paid order.
	 * Returns ['customer' => 'cus_..', 'source' => 'pm_..'] or null.
	 * 
	 * @param WC_Order|int $renewal_order The renewal order or its ID.
	 * @return array|null                  Array with 'customer' and 'source' keys or null
	 */
	private function get_stripe_ids_from_first_order($renewal_order) {
		if (!$renewal_order instanceof WC_Order && is_numeric($renewal_order)) {
			$renewal_order = wc_get_order($renewal_order);
		}
		
		if (!$renewal_order instanceof WC_Order) {
			return null;
		}

		$subscription_id = $renewal_order->get_meta('_subscriben_subscription_id', true);
		
		if (!$subscription_id) {
			return null;
		}

		$subscription = new Simba_Subscriptions_Subscription($subscription_id);
		$order_ids    = isset($subscription->all_order_ids) ? (array) $subscription->all_order_ids : array();
		$order_ids    = array_values(array_filter(array_map('intval', $order_ids)));
		
		if (!$order_ids) {
			return null;
		}

		sort($order_ids, SORT_NUMERIC);

		// Prefer the first paid order (processing/completed)
		foreach ($order_ids as $order_id) {
			$order = wc_get_order($order_id);
			
			if (!$order) {
				continue;
			}
			
			if (!in_array($order->get_status(), array('processing', 'completed'), true)) {
				continue;
			}

			$cus = $order->get_meta('_stripe_customer_id', true) ?: $order->get_meta('stripe_customer_id', true);
			$src = $order->get_meta('_stripe_source_id', true)
				?: $order->get_meta('stripe_source_id', true)
				?: $order->get_meta('_stripe_card_id', true)
				?: $order->get_meta('stripe_card_id', true);

			if ($cus && $src) {
				return array('customer' => $cus, 'source' => $src);
			}
		}

		// Fall back to very first order if no paid one matched
		$order = wc_get_order($order_ids[0]);
		if ($order) {
			$cus = $order->get_meta('_stripe_customer_id', true) ?: $order->get_meta('stripe_customer_id', true);
			$src = $order->get_meta('_stripe_source_id', true)
				?: $order->get_meta('stripe_source_id', true)
				?: $order->get_meta('_stripe_card_id', true)
				?: $order->get_meta('stripe_card_id', true);
			
			if ($cus && $src) {
				return array('customer' => $cus, 'source' => $src);
			}
		}

		return null;
	}

	/**
	 * Get payment source from an order. This could be used in the future for
	 * a subscription as an example, therefore using the current user ID would
	 * not work - the customer won't be logged in :)
	 *
	 * Not using 2.6 tokens for this part since we need a customer AND a card
	 * token, and not just one.
	 *
	 * Team Updraft changes: Use Subscriben customer meta data for Stripe customer ID
	 *                       and payment source (if the order is using our bundled Stripe gateway)
	 *
	 * @since 3.1.0
	 * @version 4.0.0
	 * @param WC_Order|null $order
	 * @return object
	 */
	public function prepare_order_source($order = null) {
		$stripe_customer = new WC_Stripe_Customer();
		$stripe_source   = false;
		$token_id        = false;
		$source_object   = false;

		if ($order) {
			if (!$order instanceof WC_Order && is_numeric($order)) {
				$order = wc_get_order($order);
			}
			
			if (!$order instanceof WC_Order) {
				return (object) array(
					'token_id'       => false,
					'customer'       => false,
					'source'         => false,
					'source_object'  => false,
					'payment_method' => null,
				);
			}

			$wc_customer = new WC_Customer($order->get_customer_id());

			// Customer ID
			$stripe_customer_id =
				$order->get_meta('_stripe_customer_id', true)
				?: $order->get_meta('stripe_customer_id', true)
				?: $wc_customer->get_meta('_subscriben_stripe_customer_id', true)
				?: $wc_customer->get_meta('_stripe_customer_id', true);

			// Customer ID: fallback from first order if missing
			if (empty($stripe_customer_id)) {
				$fallback = $this->get_stripe_ids_from_first_order($order);
				if ($fallback && !empty($fallback['customer'])) {
					$stripe_customer_id = $fallback['customer'];
				}
			}

			// Customer ID: if we have a customer ID, set it on the Stripe customer object
			if ($stripe_customer_id) {
				$stripe_customer->set_id($stripe_customer_id);
			}

			// Source ID
			$source_id =
				$order->get_meta('_stripe_source_id', true)
				?: $order->get_meta('stripe_source_id', true)
				?: $order->get_meta('_stripe_card_id', true)
				?: $order->get_meta('stripe_card_id', true);

			// Source ID: fallback from customer default token if missing
			if (empty($source_id)) {
				if ($token = WC_Payment_Tokens::get_customer_default_token($order->get_customer_id())) {
					$source_id = $token->get_token();
					$token_id  = $token->get_id();
				}
			}

			// Source ID: fallback from first order if still missing
			if (empty($source_id)) {
				$fallback = isset($fallback) && $fallback ? $fallback : $this->get_stripe_ids_from_first_order($order);
				if ($fallback && !empty($fallback['source'])) {
					$source_id = $fallback['source'];
				}
			}

			// Only accept pm_ for renewals
			if ($source_id && 0 === strpos($source_id, 'pm_')) {
				$stripe_source = $source_id;
				$source_object = WC_Stripe_API::get_payment_method($source_id);
				
			// Resolve default pm on the customer
			} else {
				$default_pm = null;
				$fallback_path = 'none';

				if ($stripe_customer_id) {
					// Try invoice_settings.default_payment_method first.
					$cust = WC_Stripe_API::retrieve('customers/' . $stripe_customer_id);

					if ($cust && !is_wp_error($cust) && empty($cust->error)) {
						$default_pm = isset($cust->invoice_settings->default_payment_method) ? $cust->invoice_settings->default_payment_method : null;
						if ($default_pm) {
							$fallback_path = 'invoice_settings.default_payment_method';
						}
					}

					// Fallbacks.
					if (!$default_pm) {
						// Default is missing. Get most recently added payment method (endpoint retrieves newest first)
						$list = WC_Stripe_API::retrieve(
							'customers/' . $stripe_customer_id . '/payment_methods?type=card&limit=1'
						);

						if (!is_wp_error($list) && !empty($list->data[0]->id)) {
							// NOTE: the payment_methods endpoint *can* return legacy "src_" payment ID's
							// so from this point on $default_pm cannot be assumed to be a "pm_" payment ID.
							$default_pm    = $list->data[0]->id;
							$fallback_path = 'payment_methods_first_card';
						}
					}
				}

				if ($default_pm) {
					$stripe_source = $default_pm;
					// NOTE: calls the legacy sources API if $default_pm is a "src_"
					$source_object = WC_Stripe_API::get_payment_method($default_pm);
					
					$order->update_meta_data('_stripe_source_id', $default_pm);
					if (is_callable(array($order, 'save'))) {
						$order->save_meta_data();
					}

					WC_Stripe_Logger::info(
						self::LOG_PREFIX . 'payment method resolved via fallback',
						array('order_id' => $order->get_id(), 'stripe_customer_id' => ($stripe_customer_id ?: 'none'), 'payment_method' => $default_pm, 'fallback_path' => $fallback_path, 'step' => 'prepare_order_source')
					);
				} else {
					// Let ensure_pm_for_renewal resolve (handles src_/card_ via default_source if there's nothing else available)
					$stripe_source = '';

					WC_Stripe_Logger::info(
						self::LOG_PREFIX . 'no payment method resolved, deferring to ensure_pm_for_renewal.',
						array('order_id' => $order->get_id(), 'stripe_customer_id' => ($stripe_customer_id ?: 'none'), 'step' => 'prepare_order_source')
					);
				}
			}

			// Normalize customer meta on the order (and user) for next cycles
			if ($stripe_customer_id && !$order->get_meta('_stripe_customer_id', true)) {
				$order->update_meta_data('_stripe_customer_id', $stripe_customer_id);
				if (is_callable(array($order, 'save'))) {
					$order->save_meta_data();
				}
			}
			
			if ($order->get_customer_id() && $stripe_customer_id) {
				$wc_customer->update_meta_data('_subscriben_stripe_customer_id', $stripe_customer_id);
				$wc_customer->update_meta_data('_stripe_customer_id', $stripe_customer_id);
				$wc_customer->save_meta_data();
			}
		}

		return (object) array(
			'token_id'       => $token_id,
			'customer'       => $stripe_customer ? $stripe_customer->get_id() : false,
			'source'         => $stripe_source, // payment method ID or '' (use Stripe default)
			'source_object'  => $source_object,
			'payment_method' => null,
		);
	}
	
	/**
	 * If this is the "Pass the SCA challenge" flow, remove a variable that is checked by WC Subscriptions
	 * so WC Subscriptions doesn't redirect to the checkout
	 */
	public function remove_order_pay_var() {
		global $wp;
		if (isset($_GET['wc-stripe-confirmation'])) {
			$this->order_pay_var = $wp->query_vars['order-pay'];
			$wp->query_vars['order-pay'] = null;
		}
	}

	/**
	 * Restore the variable that was removed in remove_order_pay_var()
	 */
	public function restore_order_pay_var() {
		global $wp;
		if (isset($this->order_pay_var)) {
			$wp->query_vars['order-pay'] = $this->order_pay_var;
		}
	}

	/**
	 * Checks if a renewal already failed because a manual authentication is required.
	 *
	 * @param WC_Order $renewal_order The renewal order.
	 * @return boolean
	 */
	public function has_authentication_already_failed($renewal_order) {
		$existing_intent = $this->get_intent_from_order($renewal_order);

		if (!$existing_intent || 'requires_payment_method' !== $existing_intent->status || empty($existing_intent->last_payment_error) || 'authentication_required' !== $existing_intent->last_payment_error->code) {
			return false;
		}

		// Make sure all emails are instantiated.
		WC_Emails::instance();

		/**
		 * A payment attempt failed because SCA authentication is required.
		 *
		 * @param WC_Order $renewal_order The order that is being renewed.
		 */
		do_action('wc_gateway_stripe_process_payment_authentication_required', $renewal_order);

		// Fail the payment attempt (order would be currently pending because of retry rules).
		$charge    = isset( $existing_intent->charges ) ? end( $existing_intent->charges->data ) : $this->get_latest_charge_from_intent( $existing_intent );;
		$charge_id = $charge->id;
		/* translators: %s is the stripe charge Id */
		$renewal_order->update_status( 'failed', sprintf( __( 'Stripe charge awaiting authentication by user: %s.', 'woocommerce-gateway-stripe' ), $charge_id ) );

		return true;
	}
	
	/**
	 * Save additional meta data from the Stripe response to a charge request
	 *
	 * @access public
	 * @param stdClass $response Response object from Stripe charge request
	 * @param WC_Order $order    A WC_Order object.
	 * @return bool
	 */
	public function save_meta_data($response, $order) {
		WC_Stripe_Logger::log('Saving Stripe response as customer meta data.');

		$user_id = $order->get_customer_id();

		$customer = new WC_Customer($user_id);
		
		// Save user id
		$customer->update_meta_data('_subscriben_stripe_customer_id', $response->customer);
		
		// Save card details
		if (isset($response->source) && !empty($response->source->card)) {
			$customer->update_meta_data('_subscriben_stripe_customer_cards', array(
				$response->source->id => array(
					'brand'     => $response->source->card->brand,
					'funding'   => $response->source->card->funding,
					'exp_month' => $response->source->card->exp_month,
					'exp_year'  => $response->source->card->exp_year,
					'last4'     => $response->source->card->last4
				)
			));
		}

		// Set card as default
		if (isset($response->source) && !empty($response->source->id)) {
			$customer->update_meta_data('_subscriben_stripe_customer_default_card', $response->source->id);
		}
		
		$customer->save();
	}
	
	/**
	 * Team Updraft:
	 * This method is triggered on payment authentication failure and updates the subscription accordingly
	 *
	 * @param WC_Order $renewal_order A WC_Order object.
	 */
	public function manage_payment_auth_failure($renewal_order) {
		$subscription = new Simba_Subscriptions_Subscription($renewal_order->get_meta('_subscriben_subscription_id', true));
		if ($subscription) {
			$order_id = $renewal_order->get_id();
			$subscription->update_subscription_details(array('status' => 'pending'));
			$subscription->add_note(__('Payment for the latest order requires authentication.', 'woocommerce-gateway-stripe'), 'error', $order_id);
		}
	}
	
	/**
	 * Team Updraft:
	 * Override parent method to check against the existence of our own subscription type
	 *
	 * @param WC_Order|int $order WC_Order object or order id
	 * @return bool
	 */
	public function has_subscription($order) {
		// We need the full order object
		if (!is_a($order, 'WC_Order')) {
			// Check if we have been passed an order id, and fetch the object. If not this cannot be an order so return false
			if (is_numeric($order)) {
				$order = wc_get_order($order);
			} else return false;
		}
		
		// Check if the subscription metadata is set
		return $order->meta_exists('_subscriben_subscription_id');
	}
	
}
