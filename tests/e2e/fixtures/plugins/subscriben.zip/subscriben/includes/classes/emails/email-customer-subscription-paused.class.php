<?php
/**
 * Exit if accessed directly
 */
if (!defined('ABSPATH')) {
	exit;
}

/**
 * Customer Subscription Paused email
 *
 * @class Simba_Subscriptions_Email_Customer_Subscription_Paused
 * @package Simba_Subscriptions
 */
if (!class_exists('Simba_Subscriptions_Email_Customer_Subscription_Paused')) {

class Simba_Subscriptions_Email_Customer_Subscription_Paused extends Simba_Subscriptions_Email {


	/**
	 * Constructor class
	 *
	 * @access public
	 * @return void
	 */
	public function __construct()
	{
		$this->id             = 'customer_subscription_paused';
		$this->customer_email = true;
		$this->title          = __('Subscription paused', 'subscriben');
		$this->description    = __('Subscription paused emails are sent to customers when subscriptions are paused by administrator or customers (if they are allowed to).', 'subscriben');

		$this->heading        = __('Your subscription has been paused', 'subscriben');
		$this->subject        = __('Your {site_title} subscription has been paused', 'subscriben');

		// Call parent constructor
		parent::__construct();
	}

}
}
