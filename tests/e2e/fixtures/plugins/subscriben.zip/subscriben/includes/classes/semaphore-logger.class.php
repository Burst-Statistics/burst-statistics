<?php
/**
 * Exit if accessed directly
 */
if (!defined('ABSPATH')) {
	exit;
}

/**
 * Semaphore error logger
 *
 * @class Simba_Subscriptions_Semaphore_Logger
 * @package Simba_Subscriptions
 */
if (!class_exists('Simba_Subscriptions_Semaphore_Logger')) {
		
	class Simba_Subscriptions_Semaphore_Logger {
		
		// A callable to be called with a log line as the parameter
		protected $logger;
		
		/**
		 * Constructor for the logger object.
		 *
		 * @param Callable|'error_log' $logger a callable to be called with a log line as the parameter
		 */
		public function __construct($logger = 'error_log') {
			$this->logger = $logger;
		}
	
		
		/**
		 * Log information
		 *
		 * @param String $line  - the line to log
		 * @param String $level - the log level: notice, warning, error
		 */
		public function log($line, $level) {
			if (is_callable($this->logger) && ('error' == $level || 'warning' == $level || (defined('WP_DEBUG') && WP_DEBUG)))  return call_user_func($this->logger, $line);
		}
	
	}
}
