<?php
/**
 * Exit if accessed directly
 */
if (!defined('ABSPATH')) {
	exit;
}

/**
 * Customer Subscription Processing Order email
 *
 * @class Simba_Subscriptions_Email_Customer_Subscription_Processing_Order
 * @package Simba_Subscriptions
 */
if (!class_exists('Simba_Subscriptions_Email_Customer_Subscription_Processing_Order')) {

	class Simba_Subscriptions_Email_Customer_Subscription_Processing_Order extends Simba_Subscriptions_Email {


		/**
		 * Constructor class
		 *
		 * @access public
		 * @return void
		 */
		public function __construct() {
			$this->id             = 'customer_subscription_processing_order';
			$this->customer_email = true;
			$this->title          = __('Subscription processing order', 'subscriben');
			$this->description    = __('Subscription processing order emails are sent to customers after payment and before order is complete.', 'subscriben');

			$this->heading        = __('Thank you for your order', 'subscriben');
			$this->subject        = __('Your {site_title} renewal order receipt from {order_date}', 'subscriben');

			// Call parent constructor
			parent::__construct();
		}

		/**
		 * Trigger a notification
		 *
		 * @access public
		 * @param object $order
		 * @param array  $args
		 * @param bool   $send_to_admin
		 * @return void
		 */
		public function trigger($order, $args = array(), $send_to_admin = false) {
			if (!$order) {
				return;
			}

			$this->object = $order;

			if ($send_to_admin) {
				$this->recipient = get_option('admin_email');
			} else {
				$this->recipient = Simba_Subscriptions_WC_Legacy::order_get_billing_email($this->object);
			}

			// Replace macros
			$this->find[] = '{order_date}';
			$this->replace[] = Simba_Subscriptions_WC_Legacy::order_get_formatted_date_created($this->object);

			// Check if this email type is enabled, recipient is set and we are not on a development website
			if (!$this->is_enabled() || !$this->get_recipient() || !Simba_Subscriptions::is_main_site()) {
				return;
			}

			// Get subscription
			$subscriptions = Simba_Subscriptions_Order_Handler::get_subscriptions_from_order_id($order->get_id());
			$subscription = reset($subscriptions);

			if (!$subscription) {
				return;
			}

			$this->template_variables = array(
				'subscription'  => $subscription,
				'subscriptions'  => $subscriptions,
				'order'         => $this->object,
				'email_heading' => $this->get_heading(),
				'sent_to_admin' => false,
				'email'         => $this,
			);

			$this->send($this->get_recipient(), $this->get_subject(), $this->get_content(), $this->get_headers(), $this->get_attachments());
		}

	}
}
