<?php
/**
 * Exit if accessed directly
 */
if (!defined('ABSPATH')) {
	exit;
}

/**
 * Main subscription class
 *
 * @class Simba_Subscriptions_Subscription
 * @package Simba_Subscriptions
 */
if (!class_exists('Simba_Subscriptions_Subscription')) {

class Simba_Subscriptions_Subscription {

	public $id;

	public $status;

	public $status_title;
	
	public $started;
	
	public $started_readable;
	
	public $payment_due;
	
	public $payment_due_readable;
	
	public $expires;
	
	public $expires_readable;
	
	public $overdue_since;
	
	public $pre_paused_status;
	
	public $pre_paused_events;
	
	public $paused_since;
	
	public $resumes;
	
	public $resumes_readable;
	
	public $suspended_since;
	
	public $cancelled_since;
	
	public $expired_since;
	
	public $price_time_unit;
	
	public $price_time_value;
	
	public $free_trial_time_unit;
	
	public $free_trial_time_value;
	
	public $max_length_time_unit;
	
	public $max_length_time_value;
	
	public $signup_fee;
	
	public $last_order_id;
	
	public $all_order_ids;
	
	public $user_id;
	
	public $user_full_name;
	
	public $product_id;
	
	public $product_name;
	
	public $variation_id;
	
	public $quantity;
	
	public $products_multiple;
	
	public $payment_method;
	
	public $payment_method_title;
	
	public $shipping_address;
	
	public $shipping;
	
	public $taxes;
	
	public $taxable_address;

	public $membership_ids;

	public $order_item_id;
	
	public $renewal_line_subtotal;
	
	public $renewal_line_subtotal_tax;
	
	public $renewal_line_total;
	
	public $renewal_line_tax;
	
	public $renewal_order_shipping;
	
	public $renewal_order_shipping_tax;
	
	public $renewal_cart_discount;
	
	public $renewal_order_discount;
	
	public $renewal_order_tax;
	
	public $renewal_order_total;
	
	public $renewal_order_subtotal;
	
	public $renewal_order_currency;
	
	public $renewal_prices_include_tax;
	
	public $renewal_customer_ip_address;
	
	public $renewal_customer_user_agent;
	
	public $renewal_tax_class;
	
	public $renewal_customer_note;
	
	public $renewal_all_order_meta;
	
	public $renewal_all_items_meta;

	/**
	 * Constructor class
	 *
	 * @access public
	 * @param mixed $id
	 * @return void
	 */
	public function __construct($id = null) {
		if ($id) {
			$this->id = $id;
			$this->populate();
		}
	}
	
	/**
	 * Return subscription or false on error
	 *
	 * @access public
	 * @param int $subscription_id
	 * @return object|bool
	 */
	public static function get_by_id($subscription_id) {
		if (is_numeric($subscription_id)) {
			$post = get_post($subscription_id);

			if ($post && 'subscription' == $post->post_type) {
				return new Simba_Subscriptions_Subscription($subscription_id);
			}
		}

		return false;
	}

	/**
	 * Return subscription for given WC order ID or false on error
	 *
	 * This was added as part of support for the WC Subscriptions official API. This change included
	 * dropping the in built Simba_Subscriptions hooks and using the official WC Subscriptions ones. This means we
	 * are now using scheduled_subscription_payment_*, and this hook only passes the WC order object.
	 *
	 * Therefore we need a way to retrieve a subscription record based on a WC order ID.
	 * So we have now introduced the new meta _subscriben_subscription_id
	 *
	 * @param Integer $order_id
	 *
	 * @return array|bool
	 */
	public static function get_by_order_id($order_id) {
		if (!is_numeric($order_id)) return false;
		
		$order = wc_get_order($order_id);

		if ($order) {

			if ($order->meta_exists('_subscriben_subscription_id')) {
				$subscription_ids_raw = $order->get_meta('_subscriben_subscription_id', false);
				$subscription_ids = array();
				foreach ($subscription_ids_raw as $meta_item) {
					$data = $meta_item->get_data();
					$subscription_ids[] = $data['value'];
				}
			}

			if (!empty($subscription_ids)) {
				// build array of subscription objects to return
				$subscriptions = array();

				foreach ($subscription_ids as $subscription_id) {
					$subscriptions[$subscription_id] = new Simba_Subscriptions_Subscription($subscription_id);
				}

				return $subscriptions;
			}
		}

		return false;
	}

	/**
	 * Define and return all subscription statuses
	 *
	 * @access public
	 * @return array
	 */
	public static function get_statuses() {
		return array(
			'pending'   => array(     // Usually pending payment
				'title' => __('pending', 'subscriben'),
			),
			'active'    => array(     // Active, new payment may be pending or even overdue
				'title' => __('active', 'subscriben'),
			),
			'paused' => array(        // Inactive, paused by administrator or customer
				'title' => __('paused', 'subscriben'),
			),
			'suspended' => array(     // Inactive, payment overdue
				'title' => __('suspended', 'subscriben'),
			),
			'cancelled' => array(     // Order cancelled, failed, subscription cancelled independently of order or subscription cancelled due to no payment
				'title' => __('cancelled', 'subscriben'),
			),
			'failed'    => array(     // Technical problems (like payment gateway issues etc), admin action needed
				'title' => __('failed', 'subscriben'),
			),
			'trial'     => array(     // Subscription is in trial, i.e. user has not paid for it yet, just trying out
				'title' => __('trial', 'subscriben'),
			),
			'overdue'   => array(     // Payment is overdue but subscription is still active before it is suspended or cancelled
				'title' => __('overdue', 'subscriben'),
			),
			'expired'   => array(     // Subscription expired (maximum length reached)
				'title' => __('expired', 'subscriben'),
			),
		);
	}

	/**
	 * Load existing subscription details
	 *
	 * @access public
	 * @return void
	 */
	public function populate() {
		if (!$this->id) {
			return false;
		}

		// Get status
		$statuses = self::get_statuses();
		$post_terms = wp_get_post_terms($this->id, 'subscription_status');

		if (is_wp_error($post_terms)) throw new Exception("populate() failed: wp_get_post_terms() call failed for ID {$this->id} (code ".$post_terms->get_error_code()."): ".$post_terms->get_error_message());
		
		$this->status = !empty($post_terms) ? Simba_Subscriptions_Helper::clean_term_slug($post_terms[0]->slug) : '';
		$this->status_title = !empty($post_terms) ? $statuses[$this->status]['title'] : '';

		// Get other fields
		$post_meta = Simba_Subscriptions_Helper::unwrap_post_meta(get_post_meta($this->id));

		if (empty($post_meta)) {
			return false;
		}

		// This is used for rudimentary protection against duplicate storage; items not listed here that are actually arrays will only load the first array member into the subscription object
		$properties_that_can_be_arrays = apply_filters('subscriben_subscription_properties_allow_arrays', array(
			'all_order_ids',
			'products_multiple',
			'renewal_all_order_meta',
			'renewal_all_items_meta',
			'pre_paused_events',
			'taxes',
			'taxable_address',
			'shipping',
			'shipping_address',
			'renewal_line_subtotal',
			'renewal_line_subtotal_tax',
			'renewal_line_total',
			'renewal_line_tax',
		));

		// Subscription object properties to populate from database
		$properties_to_populate = array(

			// Time related properties
			'started',              // Timestamp when subscription was first activated (or went into trial mode)
			'started_readable',     // Same as 'started' but in human readable format (ISO date/time)
			'payment_due',          // Next payment due timestamp (start of next billing period)
			'payment_due_readable', // Same as 'payment_due' but in human readable format (ISO date/time)
			'expires',              // Subscription expiration timestamp
			'expires_readable',     // Same as 'expires' but in human readable format (ISO date/time)
			'overdue_since',        // Timestamp since which subscription is marked as overdue
			'pre_paused_status',    // Status of the subscription just before it was paused
			'pre_paused_events',    // Scheduled events of the subscription just before it was paused
			'paused_since',         // Timestamp since which subscription is paused (value reset to null on resume)
			'resumes',              // Subscription auto-resume timestamp
			'resumes_readable',     // Same as 'resumes' but in human readable format (ISO date/time)
			'suspended_since',      // Timestamp since which subscription is suspended (value reset to null on unsuspension)
			'cancelled_since',      // Timestamp since which subscription is cancelled
			'expired_since',        // Timestamp since which subscription is expired

			// Subscription settings
			'price_time_unit',          // Product price time unit, e.g. week, month etc.
			'price_time_value',         // How many price_time_units product price includes?
			'free_trial_time_unit',     // Free trial time unit, e.g. week, month etc.
			'free_trial_time_value',    // How many free_trial_time_units free trial includes?
			'max_length_time_unit',     // Simba_Subscriptions expiration time unit, e.g. week, month etc.
			'max_length_time_value',    // How many max_length_time_units does the subscription expiration time include?
			'signup_fee',               // Signup fee charged on first order

			// Other properties
			'last_order_id',        // ID of last order related to this subscription
			'all_order_ids',        // Array of IDs of all orders that were related to this subscription over time
			'user_id',              // Associated user ID - comes from _customer_user_id
			'user_full_name',       // Associated user full name
			'product_id',           // Associated product ID
			'product_name',         // Associated product name
			'variation_id',         // Associated variation ID
			'quantity',             // Quantity of product or variation ordered
			'products_multiple',    // The above info, but for multiple products in one subscription

			
			// Reminder of some properties no longer stored in renewal_all_order_meta since stopping to use get_post_meta() to populate it: _cart_discount, _cart_discount_tax, _cart_hash, _created_via, _customer_ip_address, _customer_user, _customer_user_agent, _date_paid, _download_permissions_granted, _edit_lock, _order_currency, _order_key, _order_shipping, _order_shipping_tax, _order_stock_reduced, _order_tax, _order_total, _order_version, _paid_date, _payment_method, _payment_method_title, _prices_include_tax, _recorded_coupon_usage_counts, _recorded_sales
			
			// Properties needed for renewal orders
			'payment_method',
			'payment_method_title',
			'shipping_address',
			'shipping',
			'taxes',
			'taxable_address',
			'renewal_line_subtotal',
			'renewal_line_subtotal_tax',
			'renewal_line_total',
			'renewal_line_tax',
			'renewal_order_shipping',
			'renewal_order_shipping_tax',
			'renewal_cart_discount',
			'renewal_order_discount',
			'renewal_order_tax',
			'renewal_order_total',
			'renewal_order_subtotal',
			'renewal_order_currency',
			'renewal_prices_include_tax',
			'renewal_customer_ip_address',
			'renewal_customer_user_agent',
			'renewal_tax_class',
			'renewal_customer_note',
			'renewal_all_order_meta',
			'renewal_all_items_meta',
		);
		
		$properties_that_are_not_arrays = apply_filters('subscription_subscription_properties_not_arrays', array_diff($properties_to_populate, $properties_that_can_be_arrays), $this->id);// phpcs:ignore VariableAnalysis.CodeAnalysis.VariableAnalysis.UnusedVariable

		$properties_to_populate = apply_filters('subscriben_subscription_properties_to_populate', $properties_to_populate, $this->id);
		
		foreach ($properties_to_populate as $property) {
		
			$property_data = isset($post_meta[$property]) ? maybe_unserialize($post_meta[$property]) : null;
			
			if ('renewal_all_order_meta' == $property && empty($property_data) && !is_array($property_data)) $property_data = array();
		
			if (is_array($property_data) && !in_array($property, $properties_that_can_be_arrays)) {
				$property_data = reset($property_data);
			}
		
			$this->$property = $property_data;
			
			if ('all_order_ids' == $property) {

				// Fix "unwrapped" single array item
				if (!is_array($this->all_order_ids)) {
					$this->all_order_ids = array($this->all_order_ids);
				}

				// Reverse order of elements (we want the most recent to appear first)
				$this->all_order_ids = array_reverse($this->all_order_ids);
			} elseif ('shipping' == $property && !empty($this->shipping) && isset($this->shipping[0])) {
				$this->shipping = $this->shipping[0];
			} elseif ('pre_paused_events' == $property && !is_array($this->pre_paused_events)) {
				$this->pre_paused_events = array();
			} elseif ('renewal_order_subtotal' == $property && is_null($this->$property)) {
				$this->$property = $this->renewal_order_total;
			}
		}

		return true;
	}

	/**
	 * Create subscription from new order item
	 *
	 * @access public
	 * @param object $order
	 * @param array  $deprecated
	 * @param int    $order_item_id
	 * @param array  $order_item
	 * @param object $product
	 * @param array  $deprecated_2
	 * @param array  $renewal
	 * @return void
	 * @throws Exception To rollback the transaction.
	 */
	public function create_from_order_item($order, $deprecated, $order_item_id, $order_item, $product, $deprecated_2, $renewal) {
		
		wc_transaction_query('start');

		try {
		
			// Create post
			$this->id = wp_insert_post(array(
				'post_title'        => '',
				'post_name'         => '',
				'post_status'       => 'publish',
				'post_type'         => 'subscription',
				'ping_status'       => 'closed',
				'comment_status'    => 'closed',
			));

			// Post created?
			if (0 == $this->id) {
				throw new Exception(__('Error saving subscription object.', 'subscriben'));
			}

			// Get order customer note
			$order_customer_note = Simba_Subscriptions_WC_Legacy::order_get_customer_note($order);
			
			$currency = $order->get_currency();
			
			// Get subscription product settings
			$price_time_unit_setting        = Simba_Subscriptions_WC_Legacy::product_get_meta($product, '_subscriben_price_time_unit', true);
			$price_time_value_setting       = Simba_Subscriptions_WC_Legacy::product_get_meta($product, '_subscriben_price_time_value', true);
			$free_trial_time_unit_setting   = Simba_Subscriptions_WC_Legacy::product_get_meta($product, '_subscriben_free_trial_time_unit', true);
			$free_trial_time_value_setting  = Simba_Subscriptions_WC_Legacy::product_get_meta($product, '_subscriben_free_trial_time_value', true);
			$max_length_time_unit_setting   = Simba_Subscriptions_WC_Legacy::product_get_meta($product, '_subscriben_max_length_time_unit', true);
			$max_length_time_value_setting  = Simba_Subscriptions_WC_Legacy::product_get_meta($product, '_subscriben_max_length_time_value', true);
			$signup_fee_setting             = Simba_Subscriptions::get_signup_fee_from_product($product, $currency);

			// Get product id and variation id
			$product_id = Simba_Subscriptions_WC_Legacy::order_item_get_product_id($order_item);
			$variation_id = Simba_Subscriptions_WC_Legacy::order_item_get_variation_id($order_item);
			$variation_id = !empty($variation_id) ? $variation_id : null;

			$tax_class = Simba_Subscriptions_WC_Legacy::order_item_get_tax_class($order_item);
			$tax_class = !empty($tax_class) ? $tax_class : '';

			// This used to use get_post_meta($order->get_id() . The post meta includes lots of items that are either already handled separately via dedicated WC methods (e.g. order currency, payment_method), or are internal to the aspect as a post (e.g. edit_lock). The duplication of data seemed harmful to me, so we are deliberately not adding them back after switching over to a non-post method (WC_Order::get_meta_data()). On an analysis of grabbing the same information using both methods from the same order, the "missing" keys now are: _cart_discount, _cart_discount_tax, _cart_hash, _created_via, _customer_ip_address, _customer_user, _customer_user_agent, _date_paid, _download_permissions_granted, _edit_lock, _order_currency, _order_key, _order_shipping, _order_shipping_tax, _order_stock_reduced, _order_tax, _order_total, _order_version, _paid_date, _payment_method, _payment_method_title, _prices_include_tax, _recorded_coupon_usage_counts, _recorded_sales

			// Update subscription details
			$this->update_subscription_details(array(

				// Subscription status
				'status' => 'pending',

				// Subscription settings
				'price_time_unit'       => !empty($price_time_unit_setting) ? $price_time_unit_setting : null,
				'price_time_value'      => !empty($price_time_value_setting) ? $price_time_value_setting : null,
				'free_trial_time_unit'  => !empty($free_trial_time_unit_setting) ? $free_trial_time_unit_setting : null,
				'free_trial_time_value' => !empty($free_trial_time_value_setting) ? $free_trial_time_value_setting : null,
				'max_length_time_unit'  => !empty($max_length_time_unit_setting) ? $max_length_time_unit_setting : null,
				'max_length_time_value' => !empty($max_length_time_value_setting) ? $max_length_time_value_setting : null,
				'signup_fee'            => !empty($signup_fee_setting) ? $signup_fee_setting : null,

				// Other properties
				'user_id'           => $order->get_customer_id(),
				'last_order_id'     => $order->get_id(),
				'all_order_ids'     => $order->get_id(),
				'product_id'        => $product_id,
				'product_name'      => Simba_Subscriptions_WC_Legacy::order_item_get_name($order_item),
				'variation_id'      => $variation_id,
				'quantity'          => Simba_Subscriptions_WC_Legacy::order_item_get_quantity($order_item),
				'user_full_name'    => join(' ', array(Simba_Subscriptions_WC_Legacy::order_get_billing_first_name($order), Simba_Subscriptions_WC_Legacy::order_get_billing_last_name($order))),

				// Properties needed for renewal orders
				'shipping_address'              => !empty($renewal['shipping_address']) ? $renewal['shipping_address'] : '',
				'shipping'                      => $renewal['shipping'],
				'taxes'                         => $renewal['taxes'],
				'taxable_address'               => Simba_Subscriptions::get_customer_taxable_address(),
				'renewal_line_subtotal'         => $renewal['renewal_line_subtotal'],
				'renewal_line_subtotal_tax'     => $renewal['renewal_line_subtotal_tax'],
				'renewal_line_total'            => $renewal['renewal_line_total'],
				'renewal_line_tax'              => $renewal['renewal_line_tax'],
				'renewal_order_shipping'        => $renewal['renewal_order_shipping'],
				'renewal_order_shipping_tax'    => $renewal['renewal_order_shipping_tax'],
				'renewal_cart_discount'         => $renewal['renewal_cart_discount'],
				'renewal_order_discount'        => $renewal['renewal_order_discount'],
				'renewal_order_tax'             => $renewal['renewal_order_tax'],
				'renewal_order_subtotal'        => $renewal['renewal_order_subtotal'],
				'renewal_order_total'           => $renewal['renewal_order_total'],
				'renewal_order_currency'        => $currency,
				'renewal_prices_include_tax'    => Simba_Subscriptions_WC_Legacy::order_get_prices_include_tax($order),
				'renewal_customer_ip_address'   => Simba_Subscriptions_WC_Legacy::order_get_customer_ip_address($order),
				'renewal_customer_user_agent'   => Simba_Subscriptions_WC_Legacy::order_get_customer_user_agent($order),
				'renewal_tax_class'             => $tax_class,
				'renewal_customer_note'         => !empty($order_customer_note) ? $order_customer_note : '',
				
				// Save all order meta in case there's custom data added
				// N.B. Simba_Subscriptions_Helper::get_all_order_meta() will return repeated keys only once
				'renewal_all_order_meta'        => Simba_Subscriptions_Helper::get_all_order_meta($order),
				'renewal_all_items_meta'        => array(
					$product_id => array(
						'item_meta'       => $order_item['item_meta'],
						'item_meta_array' => $order_item['item_meta_array'] ?? '',
					)
				),
			));

			// Add meta-data to the order, defining its subscription ID
			// This is needed, as previously there was no quick way to find an order's respective subscription record
			Simba_Subscriptions_WC_Legacy::order_add_meta_data($order, '_subscriben_subscription_id', $this->id);

			// Allow other plugins to add subscription meta
			do_action('subscriben_subscription_save_meta', $this, $order, $deprecated, $order_item_id, $order_item, $product, $deprecated_2, $renewal);
			
			// Commit transaction, if supported
			wc_transaction_query('commit');
			
			return $this->id;
			
			
		} catch (Exception $e) {

			// Rollback transaction, if supported
			wc_transaction_query('rollback');

			// Propagate exception
			throw $e;
		}
	}

	/**
	 * Create subscription from all subscription products in order
	 *
	 * @access public
	 * @param object $order
	 * @param array  $deprecated
	 * @param array  $all_subs
	 * @param array  $renewal
	 * @return void
	 * @throws Exception To rollback the transaction.
	 */
	public function create_from_all_order_items($order, $deprecated, $all_subs, $renewal) {
		
		wc_transaction_query('start');

		try {
			// Create post
			$this->id = wp_insert_post(array(
				'post_title'        => '',
				'post_name'         => '',
				'post_status'       => 'publish',
				'post_type'         => 'subscription',
				'ping_status'       => 'closed',
				'comment_status'    => 'closed',
			));

			// Post created?
			if (0 == $this->id) {
				throw new Exception(__('Error saving subscription object.', 'subscriben'));
			}

			// Get order customer note
			$order_customer_note = Simba_Subscriptions_WC_Legacy::order_get_customer_note($order);

			$currency = $order->get_currency();
			
			// Update subscription details
			$this->update_subscription_details(array(

				// Subscription status
				'status' => 'pending',

				// User and order details
				'user_full_name'    => join(' ', array(Simba_Subscriptions_WC_Legacy::order_get_billing_first_name($order), Simba_Subscriptions_WC_Legacy::order_get_billing_last_name($order))),
				'user_id'           => Simba_Subscriptions_WC_Legacy::order_get_customer_id($order),
				'last_order_id'     => $order->get_id(),
				'all_order_ids'     => $order->get_id(),

				// Properties needed for renewal orders
				'shipping_address'              => !empty($renewal['shipping_address']) ? $renewal['shipping_address'] : '',
				'shipping'                      => $renewal['shipping'],
				'taxes'                         => $renewal['taxes'],
				'taxable_address'               => Simba_Subscriptions::get_customer_taxable_address(),
				'renewal_line_subtotal'         => $renewal['renewal_line_subtotal'],
				'renewal_line_subtotal_tax'     => $renewal['renewal_line_subtotal_tax'],
				'renewal_line_total'            => $renewal['renewal_line_total'],
				'renewal_line_tax'              => $renewal['renewal_line_tax'],
				'renewal_order_shipping'        => $renewal['renewal_order_shipping'],
				'renewal_order_shipping_tax'    => $renewal['renewal_order_shipping_tax'],
				'renewal_cart_discount'         => $renewal['renewal_cart_discount'],
				'renewal_order_discount'        => $renewal['renewal_order_discount'],
				'renewal_order_tax'             => $renewal['renewal_order_tax'],
				'renewal_order_subtotal'        => $renewal['renewal_order_subtotal'],
				'renewal_order_total'           => $renewal['renewal_order_total'],
				'renewal_order_currency'        => $currency,
				'renewal_prices_include_tax'    => Simba_Subscriptions_WC_Legacy::order_get_prices_include_tax($order),
				'renewal_customer_ip_address'   => Simba_Subscriptions_WC_Legacy::order_get_customer_ip_address($order),
				'renewal_customer_user_agent'   => Simba_Subscriptions_WC_Legacy::order_get_customer_user_agent($order),
				'renewal_customer_note'         => !empty($order_customer_note) ? $order_customer_note : '',
			));

			// Also prepare to update time units and values
			$time_fields = array(
				'price_time_unit'        => '_subscriben_price_time_unit',
				'price_time_value'       => '_subscriben_price_time_value',
				'free_trial_time_unit'   => '_subscriben_free_trial_time_unit',
				'free_trial_time_value'  => '_subscriben_free_trial_time_value',
				'max_length_time_unit'   => '_subscriben_max_length_time_unit',
				'max_length_time_value'  => '_subscriben_max_length_time_value',
			);

			// Set array for update values
			$time_fields_update = array();

			// Get first product
			$all_subs_keys = array_keys($all_subs);
			$first_product_id = array_shift($all_subs_keys);
			$first_product = wc_get_product($first_product_id);

			foreach ($time_fields as $key => $time_field) {
				$time_fields_update[$key] = $first_product->get_meta($time_field, true);
				$time_fields_update[$key] = !empty($time_fields_update[$key]) ? $time_fields_update[$key] : null;
			}

			// Now update the fields
			$this->update_subscription_details($time_fields_update);

		// Combine signup fees
		$total_signup_fee = 0;

		$default_currency = get_option('woocommerce_currency');
		
		$signup_meta_key = ($currency == $default_currency) ? '_subscriben_signup_fee' : '_subscriben_signup_fee_'.$currency;
		
		foreach ($all_subs as $product_details) {
			$signup_fee = isset($product_details['product_post_meta'][$signup_meta_key]) ? $product_details['product_post_meta'][$signup_meta_key] : 0;
			$total_signup_fee += $signup_fee;
		}

			$default_currency = get_option('woocommerce_currency');
			
			$signup_meta_key = ($currency == $default_currency) ? '_subscriben_signup_fee' : '_subscriben_signup_fee_'.$currency;
			
			foreach ($all_subs as $product_details) {
				$signup_fee = isset($product_details['product_post_meta'][$signup_meta_key]) ? $product_details['product_post_meta'][$signup_meta_key] : 0;
				$total_signup_fee += $signup_fee;
			}

			// Now update the signup fee
			$this->update_subscription_details(array(
				'signup_fee' => (0 != $total_signup_fee) ? $total_signup_fee : null
			));
			
			$products_multiple = array();
			$items_tax_class = array();
			$items_meta = array();
			
			// Multiple product details
			foreach ($all_subs as $product_details) {

				// Save product details
				$products_multiple[] = array(// phpcs:ignore VariableAnalysis.CodeAnalysis.VariableAnalysis.UndefinedVariable
					'product_id'   => $product_details['product_id'],
					'product_name' => Simba_Subscriptions_WC_Legacy::order_item_get_name($product_details['order_item']),
					'variation_id' => $product_details['variation_id'],
					'quantity'     => Simba_Subscriptions_WC_Legacy::order_item_get_quantity($product_details['order_item']),
					'total'        => Simba_Subscriptions_WC_Legacy::order_item_get_total($product_details['order_item']),
					'tax'          => Simba_Subscriptions_WC_Legacy::order_item_get_total_tax($product_details['order_item']),
				);

				// Save product items tax class
				$product_id_to_use = !empty($product_details['variation_id']) ? $product_details['variation_id'] : $product_details['product_id'];
				$items_tax_class[$product_id_to_use] = Simba_Subscriptions_WC_Legacy::order_item_get_tax_class($product_details['order_item']);// phpcs:ignore VariableAnalysis.CodeAnalysis.VariableAnalysis.UndefinedVariable
				$items_tax_class[$product_id_to_use] = !empty($items_tax_class[$product_id_to_use]) ? $items_tax_class[$product_id_to_use] : '';// phpcs:ignore VariableAnalysis.CodeAnalysis.VariableAnalysis.UndefinedVariable

				// Set other meta
				$items_meta[$product_details['product_id']] = array( // phpcs:ignore VariableAnalysis.CodeAnalysis.VariableAnalysis.UndefinedVariable 
					// WC31: this should work until WC 3.1, then change to some other method of handling this data
					'item_meta' => $product_details['order_item']['item_meta'],
					'item_meta_array' => isset($product_details['order_item']['item_meta_array']) ? $product_details['order_item']['item_meta_array'] : '',
				);
			}
			
			// Save product data
			$this->update_subscription_details(array(
				'products_multiple' => $products_multiple,
				'renewal_tax_class' => $items_tax_class,
				'renewal_all_items_meta' => $items_meta
			));

			// Add postmeta to the order, defining it's subscription ID
			// This is needed, as previously there was no quick way to find an order's respective subscription record
			Simba_Subscriptions_WC_Legacy::order_add_meta_data($order, '_subscriben_subscription_id', $this->id);

			// Allow other plugins to add subscription meta
			do_action('subscriben_multisubscription_save_meta', $this, $order, $deprecated, $all_subs, $renewal);

			// Commit transaction, if supported
			wc_transaction_query('commit');
			
			return $this->id;

		} catch (Exception $e) {

			// Rollback transaction, if supported
			wc_transaction_query('rollback');

			// Propagate exception
			throw $e;
		}
	}
	
	/**
	 * Check subscription products for compatibility
	 *
	 * @access public
	 * @param array $all_subs
	 * @return bool
	 */
	public static function check_compatibility($all_subs) {
		$previous_hash = null;

		foreach ($all_subs as $subs_product_id => $subs_product) {

			// Load product
			$product = wc_get_product($subs_product_id);

			// Get subscription product settings
			$current_hash = md5(json_encode(array(
				Simba_Subscriptions_WC_Legacy::product_get_meta($product, '_subscriben_price_time_unit', true),
				Simba_Subscriptions_WC_Legacy::product_get_meta($product, '_subscriben_price_time_value', true),
				Simba_Subscriptions_WC_Legacy::product_get_meta($product, '_subscriben_free_trial_time_unit', true),
				Simba_Subscriptions_WC_Legacy::product_get_meta($product, '_subscriben_free_trial_time_value', true),
				Simba_Subscriptions_WC_Legacy::product_get_meta($product, '_subscriben_max_length_time_unit', true),
				Simba_Subscriptions_WC_Legacy::product_get_meta($product, '_subscriben_max_length_time_value', true),
			)));

			// Check if current subscription product settings match previous product settings
			if (null !== $previous_hash && $previous_hash !== $current_hash) {
				return false;
			}

			$previous_hash = $current_hash;
		}

		return true;
	}

	/**
	 * Update subscription details (or create those that may change over time)
	 *
	 * @access public
	 * @param array $params
	 * @return void
	 * @throws Exception To rollback the transaction.
	 */
	public function update_subscription_details($params) {
		
		wc_transaction_query('start');

		try {
			
			// Taxonomies to update
			$taxonomies_to_update = array(
				'status'   => 'subscription_status',
			);

			foreach ($taxonomies_to_update as $taxonomy_key => $taxonomy) {
				if (!empty($params[$taxonomy_key])) {

					// Set object parameter
					$this->$taxonomy_key = $params[$taxonomy_key];

					// Status? Update readable title as well
					if ('status' == $taxonomy_key) {
						$statuses = self::get_statuses();
						$this->status_title = $statuses[$this->status]['title'];
					}

					// Save post terms
					if (!wp_set_post_terms($this->id, $params[$taxonomy_key], $taxonomy)) {
						throw new Exception(__('Error updating subscription field', 'subscriben') . ' ' . $taxonomy . '.');
					}
				}
			}

			// Update unique fields
			$fields_to_update = apply_filters('subscriben_subscription_fields_to_update', array(
				'user_id',
				'last_order_id',
				'product_id',
				'product_name',
				'variation_id',
				'quantity',
				'products_multiple',
				'user_full_name',
				'shipping_address',
				'shipping',
				'taxes',
				'taxable_address',
				'started',
				'started_readable',
				'payment_due',
				'payment_due_readable',
				'expires',
				'expires_readable',
				'overdue_since',
				'pre_paused_status',
				'pre_paused_events',
				'paused_since',
				'resumes',
				'resumes_readable',
				'suspended_since',
				'cancelled_since',
				'expired_since',
				'price_time_unit',
				'price_time_value',
				'free_trial_time_unit',
				'free_trial_time_value',
				'max_length_time_unit',
				'max_length_time_value',
				'signup_fee',
				'payment_method',
				'payment_method_title',
				'renewal_line_subtotal',
				'renewal_line_subtotal_tax',
				'renewal_line_total',
				'renewal_line_tax',
				'renewal_order_shipping',
				'renewal_order_shipping_tax',
				'renewal_cart_discount',
				'renewal_order_discount',
				'renewal_order_tax',
				'renewal_order_subtotal',
				'renewal_order_total',
				'renewal_order_currency',
				'renewal_prices_include_tax',
				'renewal_customer_ip_address',
				'renewal_customer_user_agent',
				'renewal_tax_class',
				'renewal_customer_note',
				'renewal_all_order_meta',
				'renewal_all_items_meta',
			), $this->id);

			foreach ($fields_to_update as $field) {
				if (!empty($params[$field])) {

					// Set object parameter
					$this->$field = $params[$field];

					// Save to post meta
					update_post_meta($this->id, $field, $params[$field]);
				}
			}

			// Add to set
			$fields_to_add = apply_filters('subscriben_subscription_fields_to_add', array(
				'all_order_ids',
			), $this->id);

			foreach ($fields_to_add as $field) {
				if (!empty($params[$field])) {

					// Set object parameter
					$this->$field = isset($this->$field) && is_array($this->$field) && !empty($this->$field) ? $this->$field : array();
					array_push($this->$field, $params[$field]);

					// Save to post meta
					if (!add_post_meta($this->id, $field, $params[$field])) {
						throw new Exception(__('Error adding to subscription field', 'subscriben') . ' ' . $field . '.');
					}
				}
			}
			
			// Commit transaction, if supported
			wc_transaction_query('commit');
		} catch (Exception $e) {

			// Rollback transaction, if supported
			wc_transaction_query('rollback');

			// Propagate exception
			throw $e;
		}
	}
	
	/**
	 * Clear subscription details (set object property to null and delete WP post meta
	 *
	 * @access public
	 * @param array $params
	 * @return bool
	 * @throws Exception To rollback the transaction.
	 */
	public function clear_subscription_details($params) {
		
		wc_transaction_query('start');

		try {
			
			foreach ($params as $param) {
				$this->$param = null;
				delete_post_meta($this->id, $param);
			}
			
			// Commit transaction, if supported
			wc_transaction_query('commit');
		} catch (Exception $e) {

			// Rollback transaction, if supported
			wc_transaction_query('rollback');

			// Propagate exception
			throw $e;
		}
	}

	/**
	 * Register new payment for this subscription
	 *
	 * @access public
	 * @param int    $order_id
	 * @param object $transaction
	 * @return void
	 */
	public function pay_by_order($order_id, $transaction) {
		$update_subscription_details = array();

		try {

			// Failed or cancelled subscription?
			if (in_array($this->status, array('cancelled', 'failed'))) {
				throw new Exception(__('Trying to modify cancelled or failed subscription.', 'subscriben'));
			}

			// Note old status
			$old_status = $this->status;

			// Activating for the first time?
			if ('pending' == $old_status) {

				// Set started time
				$update_subscription_details['started'] = time();
				$update_subscription_details['started_readable'] = Simba_Subscriptions_Helper::get_iso_datetime($update_subscription_details['started']);

				// Free trial?
				if ($this->can_be_in_trial() && $this->is_trial()) {
					$this->status = 'trial';
					$this->add_trial_user_meta();
				} else {
					$this->status = 'active';
				}

				// Simba_Subscriptions expires after specific period of time?
				if (!empty($this->max_length_time_unit) && !empty($this->max_length_time_value)) {

					// Calculate subscription expiration date/time
					$update_subscription_details['expires'] = $this->calculate_expiration_time();

					// Do we have correct expiration settings?
					if (false === $update_subscription_details['expires']) {
						throw new Exception(__('Failed calculating value for field', 'subscriben') . ' expires.');
					}

					// Set readable expiration date
					$update_subscription_details['expires_readable'] = Simba_Subscriptions_Helper::get_iso_datetime($update_subscription_details['expires']);

					// Schedule expiration event
					if (!Simba_Subscriptions_Event_Scheduler::schedule_expiration($this->id, $update_subscription_details['expires'])) {
						throw new Exception(__('Failed scheduling expiration event.', 'subscriben'));
					}
				}
			} else {
				$this->status = 'active';
			}

			// Before status change hooks
			$this->before_status_change($old_status, $this->status);

			$update_subscription_details['status'] = $this->status;

			// Calculate next payment due date/time
			$update_subscription_details['payment_due'] = $this->calculate_next_payment_time();

			// Next payment due date calculated successfully?
			if (false === $update_subscription_details['payment_due']) {
				throw new Exception(__('Failed calculating value for field', 'subscriben') . ' payment_due.');
			}

			// Set readable next payment due date
			$update_subscription_details['payment_due_readable'] = Simba_Subscriptions_Helper::get_iso_datetime($update_subscription_details['payment_due']);

			// Schedule next payment event
			if (!Simba_Subscriptions_Event_Scheduler::schedule_payment($this->id, $update_subscription_details['payment_due'])) {
				throw new Exception(__('Failed scheduling next payment event.', 'subscriben'));
			}

			// Schedule renewal order event
			if (!Simba_Subscriptions_Event_Scheduler::schedule_order($this->id, self::calculate_renewal_order_time($update_subscription_details['payment_due']))) {
				throw new Exception(__('Failed scheduling renewal order event.', 'subscriben'));
			}

			// Mark that this subscription was paid by this specific order (so we don't apply the same payment multiple times)
			if (!add_post_meta($this->id, 'paid_by_orders', $order_id)) {
				throw new Exception(__('Error adding to subscription field', 'subscriben') . ' paid_by_orders.');
			}

			// Load order object
			$order = wc_get_order($order_id);

			// Get payment method
			if ($payment_method = Simba_Subscriptions_WC_Legacy::order_get_payment_method($order)) {
				$update_subscription_details['payment_method'] = $payment_method;
			}

			// Get payment method title
			if ($payment_method_title = Simba_Subscriptions_WC_Legacy::order_get_payment_method_title($order)) {
				$update_subscription_details['payment_method_title'] = $payment_method_title;
			}

			// Update subscription details in database
			$this->update_subscription_details($update_subscription_details);

			// Update transaction
			$transaction->update_result('success');

			if ('trial' == $this->status) {
				$transaction->update_note(__('Trial started, next payment due date set.', 'subscriben'), true);
			} else {
				$transaction->update_note(__('Payment applied, next payment due date set.', 'subscriben'), true);

				if ($old_status != $this->status) {
					$transaction->update_note(sprintf(__('Subscription status changed from %s to %s.', 'subscriben'), $old_status, $this->status), true);
				}
			}

			// Fire actions
			do_action('subscriben_payment_applied', $this->id, $order_id);
			$this->on_status_change($old_status, $this->status);
		} catch (Exception $e) {
			$transaction->update_result('error');
			$transaction->update_note(__('Error', 'subscriben') . ': ' . $e->getMessage(), true);
		}
	}

	/**
	 * Check if payment on specific order has already been applied to this subscription
	 *
	 * @access public
	 * @param int $order_id
	 * @return bool
	 */
	public function paid_by_order($order_id) {
		$paid_by_orders = Simba_Subscriptions_Helper::unwrap_post_meta(get_post_meta($this->id, 'paid_by_orders'));
		$paid_by_orders = is_array($paid_by_orders) ? $paid_by_orders : array($paid_by_orders);

		if (empty($paid_by_orders) || !in_array((string) $order_id, $paid_by_orders)) {
			return false;
		}

		return true;
	}

	/**
	 * Pause subscription
	 *
	 * @access public
	 * @return void
	 */
	public function pause() {
		// Only subscriptions with specific statuses can be paused
		if (!in_array($this->status, array('trial', 'active', 'overdue', 'suspended'))) {
			return;
		}

		// Handle pause limit if set
		if (($current_pause_amount = $this->check_pause_limit()) !== false) {
			Simba_Subscriptions_WC_Legacy::customer_update_meta_data($this->user_id, '_subscriben_pause_limit', array($this->id => ++$current_pause_amount));
		} else {
			return;
		}

		// Schedule auto-resuming
		if (Simba_Subscriptions::option('max_pause_duration') > 0) {

			// Calculate subscription resuming date/time
			$resumes = $this->calculate_resuming_time();

			// Do we have correct resuming settings?
			if (false === $resumes) {
				return;
			}

			// Set readable resuming date
			$resumes_readable = Simba_Subscriptions_Helper::get_iso_datetime($resumes);

			// Update the details
			$this->update_subscription_details(array(
				'resumes'          => $resumes,
				'resumes_readable' => $resumes_readable,
			));

			// Schedule resume event
			if (!Simba_Subscriptions_Event_Scheduler::schedule_resume($this->id, $resumes)) {
				return;
			}
		}

		$old_status = $this->status;

		// Before status change hooks
		$this->before_status_change($old_status, 'paused');

		// Change subscription status and set timestamp
		$this->update_subscription_details(array(
			'status'            => 'paused',
			'pre_paused_status' => $old_status,
			'pre_paused_events' => Simba_Subscriptions_Event_Scheduler::get_scheduled_events_timestamps($this->id),
			'paused_since'      => time(),
		));

		// Unschedule almost all events (they were just saved to subscription property pre_paused_events)
		Simba_Subscriptions_Event_Scheduler::unschedule_multiple(array(
			'payment',
			'order',
			'reminder',
			'suspension',
			'cancellation',
			'expiration',
		), $this->id);

		// Fire actions hooks
		if ('paused' != $old_status) {
			$this->on_status_change($old_status, 'paused');
		}

		// Send notifications
		Simba_Subscriptions_Mailer::send('paused', $this);
	}

	/**
	 * Resume paused subscription
	 *
	 * @access public
	 * @return void
	 */
	public function resume() {
		// Check if subscription is really paused
		if ('paused' != $this->status) {
			return;
		}

		$old_status = $this->status;

		// Before status change hooks
		$this->before_status_change($old_status, $this->pre_paused_status);

		// Revert status
		$properties_to_update = array(
			'status' => $this->pre_paused_status,
		);

		// Offset all scheduled events by the amount of time this subscription was paused
		$time_offset = max(array(0, (time() - $this->paused_since)));

		// Offset payment due date
		if (!empty($this->payment_due)) {
			$properties_to_update['payment_due'] = $this->payment_due + $time_offset;
			$properties_to_update['payment_due_readable'] = Simba_Subscriptions_Helper::get_iso_datetime($properties_to_update['payment_due']);
		}

		// Offset expiration date
		if (!empty($this->expires)) {
			$properties_to_update['expires'] = $this->expires + $time_offset;
			$properties_to_update['expires_readable'] = Simba_Subscriptions_Helper::get_iso_datetime($properties_to_update['expires']);
		}

		// Offset overdue since date
		if (!empty($this->overdue_since)) {
			$properties_to_update['overdue_since'] = $this->overdue_since + $time_offset;
		}

		// Offset suspended since date
		if (!empty($this->suspended_since)) {
			$properties_to_update['suspended_since'] = $this->suspended_since + $time_offset;
		}

		// Save subscription properties
		$this->update_subscription_details($properties_to_update);

		// Schedule saved events
		foreach ($this->pre_paused_events as $event) {
			$new_event_time = $event['timestamp'] + $time_offset;
			// Note: Do not change 'hook' to 'event' in the line below (backwards compatibility)
			Simba_Subscriptions_Event_Scheduler::schedule($event['hook'], $this->id, $new_event_time);
		}

		// Fire actions hooks
		if ($old_status != $this->pre_paused_status) {
			$this->on_status_change($old_status, $this->pre_paused_status);
		}

		// Clear properties related to paused subscriptions
		$this->clear_subscription_details(array(
			'pre_paused_status',
			'paused_since',
			'resumes',
			'resumes_readable',
		));

		// Unschedule auto-resuming event
		Simba_Subscriptions_Event_Scheduler::unschedule_resume($this->id);

		// Send notifications
		Simba_Subscriptions_Mailer::send('resumed', $this);
	}

	/**
	 * Overdue subscription
	 *
	 * @access public
	 * @return void
	 */
	public function overdue() {
		$old_status = $this->status;

		// Before status change hooks
		$this->before_status_change($old_status, 'overdue');

		// Change subscription status and set timestamp
		$this->update_subscription_details(array(
			'status'            => 'overdue',
			'overdue_since'     => time(),
		));

		// Fire actions hooks
		$this->on_status_change($old_status, 'overdue');

	}

	/**
	 * Suspend subscription
	 *
	 * @access public
	 * @return void
	 */
	public function suspend() {
		$old_status = $this->status;

		// Before status change hooks
		$this->before_status_change($old_status, 'suspended');

		// Change subscription status and set timestamp
		$this->update_subscription_details(array(
			'status'            => 'suspended',
			'suspended_since'   => time(),
		));

		// Fire actions hooks
		$this->on_status_change($old_status, 'suspended');

		// Send notifications
		Simba_Subscriptions_Mailer::send('suspended', $this);
	}

	/**
	 * Cancel subscription
	 *
	 * @access public
	 * @return void
	 */
	public function cancel() {
		$old_status = $this->status;

		// Before status change hooks
		$this->before_status_change($old_status, 'cancelled');

		// Cancel all unpaid renewal orders
		foreach ($this->all_order_ids as $order_id) {
			if ($order_id && Simba_Subscriptions_Order_Handler::order_is_renewal($order_id) && !$this->paid_by_order($order_id)) {
				$order = wc_get_order($order_id);
				$order->update_status('cancelled', __('Unpaid subscription renewal order cancelled.', 'subscriben'));
			}
		}

		// Change subscription status
		$this->update_subscription_details(array(
			'status'            => 'cancelled',
			'cancelled_since'   => time(),
		));

		// Clear payment due and expires dates
		$this->clear_subscription_details(array(
			'payment_due',
			'payment_due_readable',
			'expires',
			'expires_readable',
			'overdue_since',
			'pre_paused_status',
			'pre_paused_events',
			'paused_since',
			'resumes',
			'resumes_readable',
			'suspended_since',
		));

		// Clear any other scheduled events
		Simba_Subscriptions_Event_Scheduler::unschedule_all($this->id);

		// Fire actions hooks
		if ('cancelled' != $old_status) {
			$this->on_status_change($old_status, 'cancelled');
		}

		// Send notifications
		Simba_Subscriptions_Mailer::send('cancelled', $this);
	}

	/**
	 * Expire subscription
	 *
	 * @access public
	 * @return void
	 */
	public function expire() {
		$old_status = $this->status;

		// Before status change hooks
		$this->before_status_change($old_status, 'expired');

		// Change subscription status
		$this->update_subscription_details(array(
			'status'            => 'expired',
			'expired_since'     => time(),
		));

		// Clear payment due and expires dates
		$this->clear_subscription_details(array(
			'payment_due',
			'payment_due_readable',
			'expires',
			'expires_readable',
			'overdue_since',
			'pre_paused_status',
			'pre_paused_events',
			'paused_since',
			'resumes',
			'resumes_readable',
			'suspended_since',
		));

		// Clear any other scheduled events
		Simba_Subscriptions_Event_Scheduler::unschedule_all($this->id);

		// Fire actions hooks
		$this->on_status_change($old_status, 'expired');

		// Send notifications
		Simba_Subscriptions_Mailer::send('expired', $this);
	}

	/**
	 * Calculate next renewal order time
	 *
	 * @access public
	 * @param int $payment_due
	 * @return int
	 */
	public function calculate_renewal_order_time($payment_due) {
		// Calculate offset in seconds
		$offset_in_seconds = self::get_period_length_in('second', 'day', Simba_Subscriptions::option('renewal_order_day_offset'));

		$fifteen_minutes = Simba_Subscriptions::$debug ? 15 : 900;
		$one_minute = Simba_Subscriptions::$debug ? 1 : 60;

		// Calculate renewal time
		$renewal_order_time = $payment_due - $offset_in_seconds;

		// Make sure it's at least 15 minutes in the future
		$renewal_order_time = ($renewal_order_time >= (time() + $fifteen_minutes)) ? $renewal_order_time : (time() + $fifteen_minutes);

		// Make sure it does not fall before next payment time
		$renewal_order_time = (($renewal_order_time + $one_minute) <= $payment_due) ? $renewal_order_time : ($payment_due - $one_minute);

		return $renewal_order_time;
	}

	/**
	 * Calculate next payment time
	 *
	 * @access public
	 * @return int
	 */
	public function calculate_next_payment_time() {
		// Get subscription period length in seconds
		$time_units = 'trial' == $this->status ? $this->free_trial_time_unit : $this->price_time_unit;
		$time_value = 'trial' == $this->status ? $this->free_trial_time_value : $this->price_time_value;

		$period_length_in_seconds = self::get_period_length_in('second', $time_units, $time_value);

		// Something wrong with settings? Don't create a mess then..
		if (!$period_length_in_seconds) {
			return false;
		}

		// Has this subscription been suspended? User does not have to pay for this amount of time
		$suspension_length = is_numeric($this->suspended_since) ? max(array(0, time() - $this->suspended_since)) : 0;

		// Calculate next payment time
		$next_payment_time = (is_numeric($this->payment_due) ? $this->payment_due : time()) + $period_length_in_seconds + $suspension_length;

		// Use scale of 1:10080 (1 minute = 1 week) when debugging
		$twenty_minutes = Simba_Subscriptions::$debug ? 20 : 1200;

		// Make sure it's at least 20 minutes in the future
		$next_payment_time = ($next_payment_time >= (time() + $twenty_minutes)) ? $next_payment_time : (time() + $twenty_minutes);

		return $next_payment_time;
	}

	/**
	 * Calculate expiration time
	 *
	 * @access public
	 * @return mixed
	 */
	public function calculate_expiration_time() {
		// Get expiration period length in seconds
		$period_length_in_seconds = self::get_period_length_in('second', $this->max_length_time_unit, $this->max_length_time_value);

		// Something wrong with settings? Don't create a mess then..
		if (!$period_length_in_seconds) {
			return false;
		}

		// Calculate expiration time
		$expiration_time = time() + $period_length_in_seconds;

		// Use scale of 1:10080 (1 minute = 1 week) when debugging
		$thirty_minutes = Simba_Subscriptions::$debug ? 30 : 1800;

		// Make sure it's at least 30 minutes in the future
		$expiration_time = ($expiration_time >= (time() + $thirty_minutes)) ? $expiration_time : (time() + $thirty_minutes);

		return $expiration_time;
	}

	/**
	 * Calculate overdue time
	 *
	 * @access public
	 * @return mixed
	 */
	public function calculate_overdue_time() {
		// Check if overdue time is enabled
		if (!Simba_Subscriptions::option('overdue_enabled') || !Simba_Subscriptions::option('overdue_length')) {
			return false;
		}

		// Get overdue period length in seconds
		$period_length_in_seconds = self::get_period_length_in('second', 'day', Simba_Subscriptions::option('overdue_length'));

		// Something wrong with settings? Don't create a mess then..
		if (!$period_length_in_seconds) {
			return false;
		}

		// Calculate expiration time
		$overdue_time = time() + $period_length_in_seconds;

		// Use scale of 1:10080 (1 minute = 1 week) when debugging
		$thirty_minutes = Simba_Subscriptions::$debug ? 30 : 1800;

		// Make sure it's at least 30 minutes in the future
		$overdue_time = ($overdue_time >= (time() + $thirty_minutes)) ? $overdue_time : (time() + $thirty_minutes);

		return $overdue_time;
	}

	/**
	 * Calculate resuming time
	 *
	 * @access public
	 * @return mixed
	 */
	public function calculate_resuming_time() {
		// Check if pause max time is enabled
		if (Simba_Subscriptions::option('max_pause_duration') <= 0) {
			return false;
		}

		// Get pause period length in seconds
		$period_length_in_seconds = self::get_period_length_in('second', 'day', Simba_Subscriptions::option('max_pause_duration'));

		// Something wrong with settings? Don't create a mess then..
		if (!$period_length_in_seconds) {
			return false;
		}

		// Calculate resuming time
		$resuming_time = time() + $period_length_in_seconds;

		// Use scale of 1:10080 (1 minute = 1 week) when debugging
		$thirty_minutes = Simba_Subscriptions::$debug ? 30 : 1800;

		// Make sure it's at least 30 minutes in the future
		$resuming_time = ($resuming_time >= (time() + $thirty_minutes)) ? $resuming_time : (time() + $thirty_minutes);

		return $resuming_time;
	}

	/**
	 * Calculate suspension time
	 *
	 * @access public
	 * @param int $time
	 * @return mixed
	 */
	public function calculate_suspension_time($time = null) {
		$time = $time ? $time : time();

		// Check if suspensions are enabled
		if (!Simba_Subscriptions::option('suspensions_enabled') || !Simba_Subscriptions::option('suspensions_length')) {
			return false;
		}

		// Get suspension period length in seconds
		$period_length_in_seconds = self::get_period_length_in('second', 'day', Simba_Subscriptions::option('suspensions_length'));

		// Something wrong with settings? Don't create a mess then..
		if (!$period_length_in_seconds) {
			return false;
		}

		// Calculate expiration time
		$suspension_time = time() + $period_length_in_seconds;

		// Use scale of 1:10080 (1 minute = 1 week) when debugging
		$thirty_minutes = Simba_Subscriptions::$debug ? 30 : 1800;

		// Make sure it's at least 30 minutes in the future
		$suspension_time = ($suspension_time >= (time() + $thirty_minutes)) ? $suspension_time : (time() + $thirty_minutes);

		return $suspension_time;
	}

	/**
	 * Return subscription length
	 * $units_to and $units_from should be passed in a singular form (e.g. day)
	 *
	 * @access public
	 * @param string $units_to
	 * @param string $units_from
	 * @param int    $value
	 * @return mixed
	 */
	public static function get_period_length_in($units_to, $units_from, $value) {
		// Get time units
		$time_units = Simba_Subscriptions::get_time_units();

		// Check if given units are supported
		if (!isset($time_units[$units_from])) {
			return false;
		}

		// Extend with more units to convert to
		$time_units = array_merge(array(
			'second'    => array(
				'seconds'   => 1,
			),
			'minute'    => array(
				'seconds'   => 60,
			),
			'hour'      => array(
				'seconds'   => 3600,
			),
		), Simba_Subscriptions::get_time_units());

		// Check if units to convert to are supported
		if (!isset($time_units[$units_to])) {
			return false;
		}

		// Check if $value is a number
		if (!is_numeric($value) || $value < 0) {
			return false;
		}

		// Calculate value in seconds
		$value_in_seconds = $value * $time_units[$units_from]['seconds'];

		// Use scale of 1:10080 (1 minute = 1 week) when debugging
		$value_in_seconds = Simba_Subscriptions::$debug ? $value_in_seconds / 10080 : $value_in_seconds;

		// Calculate value in required units
		return round($value_in_seconds / $time_units[$units_to]['seconds']);
	}

	/**
	 * Change subscription's scheduled date
	 *
	 * @access public
	 * @return void
	 */
	public static function ajax_change_scheduled_date() {
		// Check if current user can edit subscription settings
		if (!Simba_Subscriptions::is_admin()) {
			return;
		}

		// Get variables
		$user_id         = $_POST['user_id'];// phpcs:ignore VariableAnalysis.CodeAnalysis.VariableAnalysis.UnusedVariable
		$subscription_id = $_POST['subscription_id'];
		$date_type       = $_POST['date_type'];
		$date            = $_POST['date'];

		// Pass the data for checks and process the result
		if ($new_timestamp = self::scheduled_date_check_and_change($date, $date_type, $subscription_id)) {
			echo json_encode(array(
				'newdate' => Simba_Subscriptions::get_adjusted_datetime($new_timestamp),
			));
			exit;
		} else {
			echo json_encode(array(
				'newdate' => 'error',
			));
			exit;
		}
	}

	/**
	 * Get date change fields
	 *
	 * @access public
	 * @param int    $timestamp
	 * @param string $type
	 * @return string
	 */
	public function get_date_change_fields($timestamp, $type) {
		if (empty($type)) {
			return;
		}

		$default_date = $timestamp ? Simba_Subscriptions::get_adjusted_datetime($timestamp, 'Y-m-d') : '';

		return sprintf('
			<input type="text" name="subscription_date" style="display:none; position:relative; top:-25px;">
			<input type="hidden" name="subscription_default_date" value="%s">
			<input type="hidden" name="subscription_date_type" value="%s">
			<input type="hidden" name="subscription_user_id" value="%s">
			<input type="hidden" name="subscription_id" value="%s">', $default_date, $type, $this->user_id, $this->id);
	}

	/**
	 * Check and change subscription's scheduled date
	 *
	 * @access public
	 * @param string $new_date
	 * @param string $date_type
	 * @param int    $subscription_id
	 * @return bool|int
	 */
	public static function scheduled_date_check_and_change($new_date, $date_type, $subscription_id) {
		// Get all current events timestamps
		$scheduled_events = array(
			'renewal_order' => Simba_Subscriptions_Event_Scheduler::get_scheduled_event_timestamp('order', $subscription_id),
			'payment' => Simba_Subscriptions_Event_Scheduler::get_scheduled_event_timestamp('payment', $subscription_id),
			'reminder' => Simba_Subscriptions_Event_Scheduler::get_scheduled_event_timestamp('reminder', $subscription_id),
			'suspension' => Simba_Subscriptions_Event_Scheduler::get_scheduled_event_timestamp('suspension', $subscription_id),
			'cancellation' => Simba_Subscriptions_Event_Scheduler::get_scheduled_event_timestamp('cancellation', $subscription_id),
			'expiration' => Simba_Subscriptions_Event_Scheduler::get_scheduled_event_timestamp('expiration', $subscription_id),
		);

		// Start transaction
		$transaction = new Simba_Subscriptions_Transaction(null, 'date_change', $subscription_id);

		// Check if dates are set at all
		if (empty($scheduled_events[$date_type]) || empty($new_date)) {
			return false;
		}

		// Check if date is set in future
		if (strtotime($new_date) <= time()) {
			$transaction->update_result('error');
			$transaction->update_note(__('Scheduled date should be in future', 'subscriben'), true);
			return false;
		}

		// Changing renewal order date
		if ('renewal_order' == $date_type) {

			// Create timestamp
			$new_timestamp = self::get_new_adjusted_timestamp($scheduled_events['renewal_order'], $new_date);

			// Check if order date is set before payment due
			if ($new_timestamp >= $scheduled_events['payment']) {
				$transaction->update_result('error');
				$transaction->update_note(__('Renewal order date should be before payment due.', 'subscriben'), true);
				return false;
			}

			// Re-schedule if checks were passed
			Simba_Subscriptions_Event_Scheduler::unschedule_order($subscription_id, $scheduled_events['renewal_order']);
			Simba_Subscriptions_Event_Scheduler::schedule_order($subscription_id, $new_timestamp);
			$transaction->update_result('success');
			$transaction->update_note(__('Renewal order date changed.', 'subscriben'), true);
			return $new_timestamp;
		}

		// Changing payment due date
		if ('payment' == $date_type) {

			// Create timestamp
			$new_timestamp = self::get_new_adjusted_timestamp($scheduled_events['payment'], $new_date);

			// Check if it's not set before renewal order
			if ($new_timestamp <= $scheduled_events['renewal_order']) {
				$transaction->update_result('error');
				$transaction->update_note(__('Payment Due date should be after renewal order.', 'subscriben'), true);
				return false;
			} elseif ($new_timestamp <= $scheduled_events['reminder']) {// Check if it's not set before next reminder
				$transaction->update_result('error');
				$transaction->update_note(__('Payment Due date should be after scheduled reminder.', 'subscriben'), true);
				return false;
			}

			// Re-schedule if checks were passed
			Simba_Subscriptions_Event_Scheduler::unschedule_payment($subscription_id, $scheduled_events['payment']);
			Simba_Subscriptions_Event_Scheduler::schedule_payment($subscription_id, $new_timestamp);

			// Get subscription object
			$subscription = Simba_Subscriptions_Subscription::get_by_id($subscription_id);

			// Set next payment due date in properties
			$subscription->update_subscription_details(array(
				'payment_due'          => $new_timestamp,
				'payment_due_readable' => Simba_Subscriptions_Helper::get_iso_datetime($new_timestamp),
			));

			// Update transaction
			$transaction->update_result('success');
			$transaction->update_note(__('Payment Due date changed.', 'subscriben'), true);

			return $new_timestamp;
		}

		// Changing next payment reminder date
		if ('reminder' == $date_type) {

			// Create timestamp
			$new_timestamp = self::get_new_adjusted_timestamp($scheduled_events['reminder'], $new_date);

			// Check for which event is the reminder
			if (!empty($scheduled_events['payment'])) {
				$reminder_scheduled_event = $scheduled_events['payment'];
			} elseif (!empty($scheduled_events['suspension'])) {
				$reminder_scheduled_event = $scheduled_events['suspension'];
			} elseif (!empty($scheduled_events['cancellation'])) {
				$reminder_scheduled_event = $scheduled_events['cancellation'];
			}

			// Check if it's set before the next event
			if ($new_timestamp >= $reminder_scheduled_event) {
				$transaction->update_result('error');
				$transaction->update_note(__('Payment Reminder date should be set before the next event.', 'subscriben'), true);
				return false;
			}

			// Re-schedule if checks were passed
			Simba_Subscriptions_Event_Scheduler::unschedule_reminder($subscription_id, $scheduled_events['reminder']);
			Simba_Subscriptions_Event_Scheduler::schedule_reminder($subscription_id, $new_timestamp);
			$transaction->update_result('success');
			$transaction->update_note(__('Payment Reminder date changed.', 'subscriben'), true);
			return $new_timestamp;
		}

		// Changing suspension date
		if ('suspension' == $date_type) {

			// Create timestamp
			$new_timestamp = self::get_new_adjusted_timestamp($scheduled_events['suspension'], $new_date);

			// Check if it's set after payment due date
			if ($new_timestamp <= $scheduled_events['payment']) {
				$transaction->update_result('error');
				$transaction->update_note(__('Suspension date should be after Payment Due date.', 'subscriben'), true);
				return false;
			} elseif ($new_timestamp <= $scheduled_events['reminder']) {// Check if it's not set before next reminder
				$transaction->update_result('error');
				$transaction->update_note(__('Suspension date should be after scheduled reminder.', 'subscriben'), true);
				return false;
			}

			// Re-schedule if checks were passed
			Simba_Subscriptions_Event_Scheduler::unschedule_suspension($subscription_id, $scheduled_events['suspension']);
			Simba_Subscriptions_Event_Scheduler::schedule_suspension($subscription_id, $new_timestamp);
			$transaction->update_result('success');
			$transaction->update_note(__('Suspension date changed.', 'subscriben'), true);
			return $new_timestamp;
		}

		// Changing suspension date
		if ('cancellation' == $date_type) {

			// Create timestamp
			$new_timestamp = self::get_new_adjusted_timestamp($scheduled_events['cancellation'], $new_date);

			// Check if it's not set before next reminder
			if ($new_timestamp <= $scheduled_events['reminder']) {
				$transaction->update_result('error');
				$transaction->update_note(__('Cancellation date should be after scheduled reminder.', 'subscriben'), true);
				return false;
			} elseif ($new_timestamp <= $scheduled_events['suspension']) { // Check if it's not set before suspension
				$transaction->update_result('error');
				$transaction->update_note(__('Cancellation date should be after suspension date.', 'subscriben'), true);
				return false;
			}

			// Re-schedule if checks were passed
			Simba_Subscriptions_Event_Scheduler::unschedule_cancellation($subscription_id, $scheduled_events['cancellation']);
			Simba_Subscriptions_Event_Scheduler::schedule_cancellation($subscription_id, $new_timestamp);
			$transaction->update_result('success');
			$transaction->update_note(__('Cancellation date changed.', 'subscriben'), true);
			return $new_timestamp;
		}

		// Changing suspension date
		if ('expiration' == $date_type) {

			// Create timestamp
			$new_timestamp = self::get_new_adjusted_timestamp($scheduled_events['expiration'], $new_date);

			// Check if it's set after all other events
			foreach ($scheduled_events as $event_name => $event) {
				if ($new_timestamp < $event && 'expiration' != $event_name) {
					$transaction->update_result('error');
					$transaction->update_note(__('Expiration date should be after other scheduled events.', 'subscriben'), true);
					return false;
				}
			}

			// Re-schedule if checks were passed
			Simba_Subscriptions_Event_Scheduler::unschedule_expiration($subscription_id, $scheduled_events['expiration']);
			Simba_Subscriptions_Event_Scheduler::schedule_expiration($subscription_id, $new_timestamp);
			$transaction->update_result('success');
			$transaction->update_note(__('Expiration date changed.', 'subscriben'), true);
			return $new_timestamp;
		}

		// Return false by default
		return false;
	}

	/**
	 * Get new adjusted timestamp using the current timestamp
	 * New date must be in format Y-m-d
	 *
	 * @access public
	 * @param int    $current_timestamp
	 * @param string $new_date
	 * @return int
	 */
	public static function get_new_adjusted_timestamp($current_timestamp, $new_date) {
		// Get datetime object with correct time zone
		if ($current_timestamp) {
			$dt = Simba_Subscriptions_Helper::get_datetime_object($current_timestamp);
		} else {
			$dt = Simba_Subscriptions_Helper::get_datetime_object();
			$dt->setTime(23, 59, 59);
		}

		// Split date
		$new_date = explode('-', $new_date);

		// Do not proceed if date does not look valid
		if (count($new_date) !== 3) {
			error_log("Simba_Subscriptions_Subscription::get_new_adjusted_timestamp(): Invalid date passed: ".serialize($new_date));
			exit;
		}

		// Set year, month and day
		$dt->setDate((int) $new_date[0], (int) $new_date[1], (int) $new_date[2]);

		// Get timestamp and return
		return $dt->format('U');
	}

	/**
	 * Check if subscription is in trial mode or if new subscription is applicable for trial
	 *
	 * @access public
	 * @return bool
	 */
	public function is_trial() {
		// Has a status indicating this is a trial?
		if ('trial' == $this->status) {
			return true;
		}

		// Trial applicable to newly placed subscription?
		if (isset($this->free_trial_time_unit) && isset($this->free_trial_time_value) && self::get_period_length_in('second', $this->free_trial_time_unit, $this->free_trial_time_value)) {
			return true;
		}

		return false;
	}

	/**
	 * Get reminder timestamps
	 *
	 * @access public
	 * @param string $type
	 * @param int    $base_timestamp
	 * @return array
	 */
	public function get_reminders($type, $base_timestamp) {// phpcs:ignore VariableAnalysis.CodeAnalysis.VariableAnalysis.UnusedVariable
		$reminders = array();

		if (!Simba_Subscriptions::option('reminders_enabled') || !Simba_Subscriptions::option('reminders_days')) {
			return $reminders;
		}

		$days = explode(',', Simba_Subscriptions::option('reminders_days'));

		// Iterate over days array and calculate timestamps for events
		foreach ($days as $day) {

			// Calculate offset in seconds
			$offset_in_seconds = $day * 86400;

			// Use scale of 1:10080 (1 minute = 1 week) when debugging
			$offset_in_seconds = Simba_Subscriptions::$debug ? $offset_in_seconds / 10080 : $offset_in_seconds;

			// Calculate current reminder event timestamp
			$timestamp = $base_timestamp - $offset_in_seconds;

			// Only proceed if this moment in time has not yet passed
			if (time() < $timestamp) {
				$reminders[] = $timestamp;
			}
		}

		return $reminders;
	}

	/**
	 * Load ONLY valid subscription (subscription exists, not in trash, user exists etc)
	 *
	 * @access public
	 * @param int  $subscription_id
	 * @param bool $transaction
	 * @return mixed
	 */
	public static function get_valid_subscription($subscription_id, $transaction = null) {
		// Check if subscription ID was passed in
		if (!is_numeric($subscription_id) || $subscription_id < 1) {

			if ($transaction) {
				$transaction->update_result('error');
				$transaction->update_note(__('Subscription ID unknown.', 'subscriben'), true);
			}

			return false;
		}

		// Update transaction with subscription ID
		if ($transaction) {
			$transaction->add_subscription_id($subscription_id);
		}

		// Get subscription by its ID
		$subscription = self::get_by_id($subscription_id);

		// Check if subscription exists
		if (!isset($subscription->id)) {

			if ($transaction) {
				$transaction->update_result('error');
				$transaction->update_note(__('Subscription no longer exists.', 'subscriben'), true);
			}

			return false;
		}

		// Check if subscription is not cancelled or expired
		if (in_array($subscription->status, array('cancelled', 'expired'))) {

			if ($transaction) {
				$transaction->update_result('error');
				$transaction->update_note(__('Subscription is cancelled or expired.', 'subscriben'), true);
			}

			return false;
		}

		// Check if user exists
		if (!isset($subscription->user_id) || !($user = get_userdata($subscription->user_id))) {// phpcs:ignore VariableAnalysis.CodeAnalysis.VariableAnalysis.UnusedVariable

			if ($transaction) {
				$transaction->update_result('error');
				$transaction->update_note(__('User no longer exists.', 'subscriben'), true);
			}

			return false;
		}

		// Check if subscription shouldn't be expired (better be safe than sorry...)
		if (!defined('SUBSCRIBEN_DOING_EXPIRATION') && $subscription->expires && time() >= $subscription->expires) {

			// Expire the subscription now
			Simba_Subscriptions_Event_Scheduler::scheduled_expiration($subscription->id);

			if ($transaction) {
				$transaction->update_result('error');
				$transaction->update_note(__('Subscription was already expired. Scheduled tasks failing?', 'subscriben'), true);
			}

			return false;
		}

		// Update transaction with product and variation IDs
		if ($transaction) {
			$transaction->add_product_id($subscription->product_id);
			$transaction->add_variation_id($subscription->variation_id);
		}

		// All tests passed.. Return subscription object
		return $subscription;
	}

	/**
	 * Logic to execute before status change
	 *
	 * @access public
	 * @param string $old_status
	 * @param string $new_status
	 * @return void
	 */
	public function before_status_change($old_status, $new_status) {
		if ($new_status != $old_status) {
			do_action('subscriben_status_changing_from_' . $old_status . '_to_' . $new_status, $this);
			do_action('subscriben_status_changing_to_' . $new_status, $this, $old_status);
			do_action('subscriben_status_changing', $this, $old_status, $new_status);
		}
	}

	/**
	 * Logic to execute on any status change
	 *
	 * @access public
	 * @param string $old_status
	 * @param string $new_status
	 * @return void
	 */
	public function on_status_change($old_status, $new_status) {
		if ($new_status != $old_status) {
			do_action('subscriben_status_changed_from_' . $old_status . '_to_' . $new_status, $this);
			do_action('subscriben_status_changed_to_' . $new_status, $this, $old_status);
			do_action('subscriben_status_changed', $this, $old_status, $new_status);
		}
	}

	/**
	 * Get formatted subscription number
	 *
	 * @access public
	 * @return string
	 */
	public function get_subscription_number() {
		return apply_filters('subscriben_formatted_subscription_number', _x('#', 'hash before subscription number', 'subscriben') . $this->id, $this);
	}

	/**
	 * Get subscription items
	 *
	 * @access public
	 * @return array
	 */
	public function get_items() {
		$items = array();

		// Prepare all items for multi-product subscription
		if (!empty($this->products_multiple)) {

			foreach ($this->products_multiple as $product) {

				// Set quantity and meta
				$quantity = !empty($product['quantity']) ? $product['quantity'] : 1;
				$meta = isset($this->renewal_all_items_meta[$product['product_id']]) ? $this->renewal_all_items_meta[$product['product_id']] : '';

				// Prepare and save item in correct format
				$items[] = $this->prepare_item($product['product_id'], $product['product_name'], $quantity, $product['total'], $product['tax'], $product['variation_id'], $meta);
			}
		} elseif (!empty($this->product_id)) {// Prepare one item for single-product subscription

			// Set quantity and meta
			$quantity = !empty($this->quantity) ? $this->quantity : 1;
			$meta = isset($this->renewal_all_items_meta[$this->product_id]) ? $this->renewal_all_items_meta[$this->product_id] : '';

			// Prepare and save item in correct format
			$items[] = $this->prepare_item($this->product_id, $this->product_name, $quantity, $this->renewal_line_total, $this->renewal_line_tax, $this->variation_id, $meta);
		}

		return $items;
	}

	/**
	 * Prepare subscription item
	 *
	 * @access public
	 * @param int    $product_id
	 * @param string $product_name
	 * @param int    $quantity
	 * @param int    $total
	 * @param int    $tax
	 * @param mixed  $variation_id
	 * @param mixed  $meta
	 * @return array
	 */
	public function prepare_item($product_id, $product_name, $quantity, $total, $tax, $variation_id = '', $meta = '') {
		$item = array(
			'product_id'    => $product_id,
			'quantity'      => $quantity,
			'total'         => $total,
			'tax'           => $tax,
			'meta'          => $meta,
			'deleted'       => false,
			'variation_id'	=> $variation_id,
		);

		// Is this a variable product?
		$item['name'] = (!empty($variation_id) && is_admin()) ? sprintf(__('Variation #%1$s of', 'subscriben'), $variation_id) . ' ' : '';

		// Is this product still active?
		if (false != wc_get_product($product_id)) {// phpcs:ignore VariableAnalysis.CodeAnalysis.VariableAnalysis.UnusedVariable

			// Get current product name
			$item['name'] .= get_the_title($product_id);

			// Is variation still active?
			if (!empty($variation_id) && false == wc_get_product($variation_id)) {
				$item['name'] .= ' (' . __('variation deleted', 'subscriben') . ')';
			}
		} else {
			$item['name'] .= $product_name;
			$item['name'] .= ' (' . __('deleted', 'subscriben') . ')' . ($quantity > 1 ? ' x ' . $quantity : '');
			$item['deleted'] = true;
		}

		return $item;
	}

	/**
	 * Show variable subscription item meta
	 *
	 * @access public
	 * @param array $item
	 * @return void
	 */
	public function show_variable_item_meta($item) {
		if (!is_array($item) || empty($item)) {
			return false;
		}

		if (!isset($item['meta']['item_meta']) && !isset($item['meta']['item_meta_array'])) {
			return false;
		}

		$item_meta = array_merge($item, array('item_meta' => $item['meta']['item_meta'], 'item_meta_array' => $item['meta']['item_meta_array']));
		unset($item_meta['meta']);
		
		$prepped_item_meta = array();
		
		foreach ($item_meta['item_meta_array'] as $id => $meta_object) {
			if (is_callable(array($meta_object, 'get_data'))) {
				$prepped_item_meta[] = $meta_object->get_data();
			} else {
				if (!isset($meta_object->id)) $meta_object->id = $id;
				$prepped_item_meta[] = $meta_object;
			}
		}
		
		$item_meta_object = new WC_Order_Item_Product();
		if (isset($item['product_id'])) {
			$product = wc_get_product($item['product_id']);
			if ($product) {
				$item_meta_object->set_product($product);
			}
		}
		if (isset($item['variation_id'])) {
			$item_meta_object->set_variation_id($item['variation_id']);
		}
		$item_meta_object->set_meta_data($prepped_item_meta);
		
		wc_display_item_meta($item_meta_object);
	}

	/**
	 * Get subscription items statically
	 *
	 * @access public
	 * @param int $subscription_id
	 * @return array
	 */
	public static function get_subscription_items($subscription_id) {

		$subscription = self::get_by_id($subscription_id);

		return ($subscription && !empty($subscription->id)) ? $subscription->get_items() : array();

	}

	/**
	 * Check if subscription is free
	 *
	 * @param int     $subscription_id
	 * @param boolean $first_time
	 * @return boolean
	 */
	public static function is_free($subscription_id) {
		// Get all subscription items
		$subscription_items = self::get_subscription_items($subscription_id);

		// Iterate over subscription items and check if at least one of them is not free
		foreach ($subscription_items as $item) {
			if (!empty($item['total'])) {
				return false;
			}
		}

		// All subscription items were free
		return true;
	}

	/**
	 * Get formatted price
	 *
	 * @access public
	 * @param float $price
	 * @param bool  $display_price_suffix
	 * @return string
	 */
	public function get_formatted_price($price, $display_price_suffix = false) {
		return Simba_Subscriptions::get_formatted_price($price, $this->renewal_order_currency, false, $display_price_suffix);
	}

	/**
	 * Get formatted recurring amount
	 *
	 * @access public
	 * @return string
	 */
	public function get_formatted_recurring_amount() {
		$renewal_order_total = Simba_Subscriptions::option('shipping_renewal_charge') ? $this->renewal_order_total : $this->renewal_order_subtotal;
		return Simba_Subscriptions_Subscription_Product::format_recurring_amount($renewal_order_total, $this->price_time_unit, $this->price_time_value, $this->renewal_order_currency, false, false);
	}

	/**
	 * Get formatted status for frontend display
	 *
	 * @access public
	 * @param bool $capital
	 * @return string
	 */
	public function get_formatted_status($capital = false) {
		$title = $capital ? ucfirst($this->status_title) : $this->status_title;
		return apply_filters('subscriben_formatted_status', $title);
	}

	/**
	 * Get actions for frontend subscription list
	 *
	 * @access public
	 * @param bool $list_view
	 * @return array
	 */
	public function get_frontend_actions($list_view = true) {
		$actions = array();

		// View subscription
		if ($list_view) {
			$actions['view'] = array(
				'title' => __('View', 'subscriben'),
				'url'   => $this->get_frontend_link('view-subscription'),
			);
		}

		// Subscription inactive? No other actions allowed then...
		if ($this->is_inactive()) {
			return apply_filters('subscriben_subscription_actions', $actions, $this);
		}

		// Edit shipping address
		if (!$list_view && $this->needs_shipping()) {
			if (apply_filters('subscriben_allow_shipping_address_edit', true)) {
				$actions['edit_address'] = array(
					'title' => __('Edit Address', 'subscriben'),
					'url'   => $this->get_frontend_link('subscription-address'),
				);
			}
		}

		// Pause subscription
		if (!$list_view && $this->can_be_paused() && $this->allow_customer_subscription_pausing()) {
			$actions['pause_subscription'] = array(
				'title' => __('Pause Subscription', 'subscriben'),
				'url'   => $this->get_frontend_link('pause-subscription'),
			);
		}

		// Resume subscription
		if (!$list_view && $this->can_be_resumed() && $this->allow_customer_subscription_pausing()) {
			// Allow individual control for resume action
			if (apply_filters('subscriben_allow_subscription_resuming', true)) {
				$actions['resume_subscription'] = array(
					'title' => __('Resume Subscription', 'subscriben'),
					'url'   => $this->get_frontend_link('resume-subscription'),
				);
			}
		}

		// Cancel subscription
		if (!$list_view && $this->can_be_cancelled() && $this->allow_customer_subscription_cancelling()) {
			$actions['cancel_subscription'] = array(
				'title' => __('Cancel Subscription', 'subscriben'),
				'url'   => $this->get_frontend_link('cancel-subscription'),
			);
		}

		return apply_filters('subscriben_subscription_actions', $actions, $this);
	}

	/**
	 * Get frontend link
	 *
	 * @access public
	 * @param string $view
	 * @return string
	 */
	public function get_frontend_link($view) {
		return wc_get_endpoint_url($view, $this->id, get_permalink(wc_get_page_id('myaccount')));
	}

	/**
	 * Check if subscription is inactive
	 *
	 * @access public
	 * @return bool
	 */
	public function is_inactive() {
		if (in_array($this->status, array('expired', 'cancelled', 'failed'))) {
			return true;
		}

		false;
	}

	/**
	 * Check if customers are allowed to pause/resume subscriptions
	 *
	 * @access public
	 * @return bool
	 */
	public function allow_customer_subscription_pausing() {
		if (Simba_Subscriptions::option('customer_pausing_allowed') && apply_filters('subscriben_allow_subscription_pausing', true)) {
			return true;
		}

		return false;
	}

	/**
	 * Check pause limit for customer's subscription
	 *
	 * @access public
	 * @return bool|int
	 */
	public function check_pause_limit() {
		// Get pause limit
		$user_current_pause_amount = Simba_Subscriptions_WC_Legacy::customer_get_meta($this->user_id, '_subscriben_pause_limit', true);

		// Convert to correct format
		if (!empty($user_current_pause_amount)) {
			$user_current_pause_amount = Simba_Subscriptions_Helper::unwrap_post_meta($user_current_pause_amount);
			if (!isset($user_current_pause_amount[$this->id])) {
				return 0;
			}
		} else {
			return 0;
		}

		// Don't allow pause if max amount of pauses reached
		if (Simba_Subscriptions::option('customer_pausing_allowed') && Simba_Subscriptions::option('max_pauses') > 0 && ($user_current_pause_amount[$this->id] >= Simba_Subscriptions::option('max_pauses'))) {
			return false;
		}

		return (int) $user_current_pause_amount[$this->id];
	}

	/**
	 * Check if customers are allowed to cancel subscriptions
	 *
	 * @access public
	 * @return bool
	 */
	public function allow_customer_subscription_cancelling() {
		if (Simba_Subscriptions::option('customer_cancelling_allowed') && apply_filters('subscriben_allow_subscription_cancelling', true)) {
			return true;
		}

		return false;
	}

	/**
	 * Cancel subscription by customer
	 *
	 * @access public
	 * @return void
	 */
	public function cancel_by_customer() {
		// Write transaction
		$transaction = new Simba_Subscriptions_Transaction(null, 'manual_cancellation');
		$transaction->add_subscription_id($this->id);
		$transaction->add_product_id($this->product_id);
		$transaction->add_variation_id($this->variation_id);
		$scheduled_events = array(
			'renewal_order' => Simba_Subscriptions_Event_Scheduler::get_scheduled_event_timestamp('order', $this->id),
			'payment' => Simba_Subscriptions_Event_Scheduler::get_scheduled_event_timestamp('payment', $this->id),
		);

		try {
			// Cancel subscription
			$this->cancel();

			// Update transaction
			$transaction->update_result('success');
			$transaction->update_note(__('Subscription cancelled manually by customer.', 'subscriben'), true);
			
			// Unschedule order and payment
			Simba_Subscriptions_Event_Scheduler::unschedule_order($this->id, $scheduled_events['renewal_order']);
			Simba_Subscriptions_Event_Scheduler::unschedule_payment($this->id, $scheduled_events['payment']);
			
			// Cancel recent order
			if (count($this->all_order_ids) > 0) {
				$order_id = current($this->all_order_ids);
				$order = wc_get_order($order_id);
				if ($order) {
					// If the order has not been paid for yet, cancel that order
					if (!$order->is_paid()) $order->update_status('cancelled', __('Order cancelled by customer.', 'subscriben'));
				}
			}

			return true;
		} catch (Exception $e) {
			$transaction->update_result('error');
			$transaction->update_note($e->getMessage());
			return false;
		}
	}

	/**
	 * Pause subscription by customer
	 *
	 * @access public
	 * @return void
	 */
	public function pause_by_customer() {
		// Write transaction
		$transaction = new Simba_Subscriptions_Transaction(null, 'subscription_pause');
		$transaction->add_subscription_id($this->id);
		$transaction->add_product_id($this->product_id);
		$transaction->add_variation_id($this->variation_id);

		try {
			// Pause subscription
			$this->pause();

			// Update transaction
			$transaction->update_result('success');
			$transaction->update_note(__('Subscription paused by customer.', 'subscriben'), true);

			return true;
		} catch (Exception $e) {
			$transaction->update_result('error');
			$transaction->update_note($e->getMessage());
			return false;
		}
	}

	/**
	 * Resume subscription by customer
	 *
	 * @access public
	 * @return void
	 */
	public function resume_by_customer() {
		// Write transaction
		$transaction = new Simba_Subscriptions_Transaction(null, 'subscription_resume');
		$transaction->add_subscription_id($this->id);
		$transaction->add_product_id($this->product_id);
		$transaction->add_variation_id($this->variation_id);

		try {
			// Resume subscription
			$this->resume();

			// Update transaction
			$transaction->update_result('success');
			$transaction->update_note(__('Subscription resumed by customer.', 'subscriben'), true);

			return true;
		} catch (Exception $e) {
			$transaction->update_result('error');
			$transaction->update_note($e->getMessage());
			return false;
		}
	}

	/**
	 * Check if subscription can be paused
	 *
	 * @access public
	 * @return bool
	 */
	public function can_be_paused() {
		return in_array($this->status, array('active', 'suspended', 'trial', 'overdue')) && $this->check_pause_limit() !== false ? true : false;
	}

	/**
	 * Check if subscription can be resumed
	 *
	 * @access public
	 * @return bool
	 */
	public function can_be_resumed() {
		return in_array($this->status, array('paused')) ? true : false;
	}

	/**
	 * Check if subscription can be cancelled
	 *
	 * @access public
	 * @return bool
	 */
	public function can_be_cancelled() {
		return in_array($this->status, array('pending', 'active', 'paused', 'suspended', 'trial', 'overdue')) ? true : false;
	}

	/**
	 * Check if subscription can be in trial state for this customer
	 *
	 * @access public
	 * @return bool
	 */
	public function can_be_in_trial() {
		// Check settings
		$limit_trials = Simba_Subscriptions::option('limit_trials');

		if (0 == $limit_trials || empty($limit_trials)) {
			return true;
		} elseif (in_array($limit_trials, array(1, 2))) {

			// One-product subscription
			if (isset($this->product_id)) {

				if (Simba_Subscriptions_Subscription_Product::allow_trial($this->product_id)) {
					return true;
				}
			} elseif (!empty($this->products_multiple)) {// Multi-product subscription

				foreach ($this->products_multiple as $product) {

					// Check if at least one product is not allowed
					if (!Simba_Subscriptions_Subscription_Product::allow_trial($product['product_id'])) {
						return false;
					}
				}

				return true;
			}
		}

		return false;
	}

	/**
	 * Check if subscription needs shipping
	 *
	 * @access public
	 * @return bool
	 */
	public function needs_shipping() {
		return (is_array($this->shipping) && !empty($this->shipping['name']) && Simba_Subscriptions::option('shipping_renewal_charge'));
	}

	/**
	 * Update shipping address
	 *
	 * @access public
	 * @param array $address
	 * @param bool  $is_frontend
	 * @param bool  $is_customer
	 * @return bool
	 */
	public function update_shipping_address($address, $is_frontend = false, $is_customer = false) {
		$fields = array(
			'shipping_first_name',
			'shipping_last_name',
			'shipping_company',
			'shipping_address_1',
			'shipping_address_2',
			'shipping_city',
			'shipping_state',
			'shipping_postcode',
			'shipping_country',
		);

		$shipping_address = array();

		foreach ($fields as $field) {
			if ($is_frontend) {
				$shipping_address['_' . $field] = isset($address[$field]) ? $address[$field] : '';
			} else {
				$shipping_address['_' . $field] = isset($address['_' . $field]) ? $address['_' . $field] : '';
			}
		}

		// Check if address has changed
		if (array_diff($this->shipping_address, $shipping_address) || array_diff($shipping_address, $this->shipping_address)) {

			// Write transaction
			$transaction = new Simba_Subscriptions_Transaction(null, 'address_changed');
			$transaction->add_subscription_id($this->id);
			$transaction->add_product_id($this->product_id);
			$transaction->add_variation_id($this->variation_id);

			try {

				// Save fields
				$this->update_subscription_details(array('shipping_address' => $shipping_address));

				// Update transaction
				$transaction->update_result('success');

				if ($is_customer) {
					$transaction->update_note(__('Shipping address changed by customer.', 'subscriben'), true);
				} else {
					$transaction->update_note(__('Shipping address changed by administrator.', 'subscriben'), true);
				}

				return true;
			} catch (Exception $e) {
				$transaction->update_result('error');
				$transaction->update_note($e->getMessage());
				return false;
			}
		}

		return true;
	}

	/**
	 * Get admin shipping address edit fields
	 *
	 * @access public
	 * @return array
	 */
	public static function get_admin_shipping_fields() {
		return array(
			'_shipping_first_name'  => array(
				'type'      => 'text',
				'title'     => __('First Name', 'subscriben'),
			),
			'_shipping_last_name'   => array(
				'type'      => 'text',
				'title'     => __('Last Name', 'subscriben'),
			),
			'_shipping_company'     => array(
				'type'      => 'text',
				'title'     => __('Company', 'subscriben'),
			),
			'_shipping_address_1'   => array(
				'type'      => 'text',
				'title'     => __('Address 1', 'subscriben'),
			),
			'_shipping_address_2'   => array(
				'type'      => 'text',
				'title'     => __('Address 2', 'subscriben'),
			),
			'_shipping_city'        => array(
				'type'      => 'text',
				'title'     => __('City', 'subscriben'),
			),
			'_shipping_postcode'    => array(
				'type'      => 'text',
				'title'     => __('Postcode', 'subscriben'),
			),
			'_shipping_country'     => array(
				'type'      => 'select',
				'title'     => __('Country', 'subscriben'),
				'values'    => array('' => __('Select a country&hellip;', 'subscriben')) + WC()->countries->get_shipping_countries(),
			),
			'_shipping_state'       => array(
				'type'      => 'text',
				'title'     => __('State/County', 'subscriben'),
			),
		);
	}

	/**
	 * Get status details
	 *
	 * @access public
	 * @return string
	 */
	public function get_status_details() {
		if ('paused' === $this->status && Simba_Subscriptions::option('max_pause_duration') > 0 && !empty($this->resumes)) {
			return ' ' . __('until', 'subscriben') . ' ' . Simba_Subscriptions::get_adjusted_datetime($this->resumes, null, 'subscription_frontend_resumes_readable');
		}

		return '';
	}

	/**
	 * Maybe record subscription product's id - to limit trials
	 *
	 * @access public
	 * @return void
	 */
	public function add_trial_user_meta() {
		// Check settings if it needs to be recorded
		if (!empty($this->user_id) && in_array(Simba_Subscriptions::option('limit_trials'), array(1, 2))) {

			// One-product subscription
			if (isset($this->product_id)) {
				Simba_Subscriptions_WC_Legacy::customer_add_meta_data($this->user_id, '_subscriben_trial_product_ids', $this->product_id, false);
			} elseif (!empty($this->products_multiple)) {// Multi-product subscription

				// Add all products
				foreach ($this->products_multiple as $product) {
					Simba_Subscriptions_WC_Legacy::customer_add_meta_data($this->user_id, '_subscriben_trial_product_ids', $product['product_id'], false);
				}
			}
		}
	}

	/**
	 * Removes subscription post completely
	 *
	 * Warning! Use only when really needed and add a transaction log entry to explain what happened
	 *
	 * @access public
	 * @return bool
	 */
	public function delete() {
		return wp_delete_post($this->id, true);
	}

	/**
	 * Add a new transaction to the subscriptions with a type of "info"
	 * Used for adding helpful information regarding subscriptions
	 *
	 * @access public
	 * @param string $message
	 * @param string $type     success/error, defaults to success
	 * @param int    $order_id can be used to relate the transaction to a specific subscription order
	 * @return void
	 */
	public function add_note($message, $type = 'success', $order_id = null) {
		$transaction = new Simba_Subscriptions_Transaction(null, 'info', $this->id, $order_id);
		$transaction->update_result($type);
		$transaction->update_note(__($message, 'subscriben'));
	}
	
	/**
	 * Update the subscription's renewal price and quantity
	 *
	 * @access public
	 * @return void
	 */
	public static function ajax_update_renewal_quantity_and_price() {
		// Check if current user can edit subscription settings
		if (empty($_POST) || !is_user_logged_in() || !Simba_Subscriptions::is_admin() || !isset($_POST['form_data'])) {
			die('Security check');
		}
		
		$form_data = json_decode(stripslashes($_POST['form_data']), true);

		// Get variables
		// $user_id         = $form_data['sub_user_id'];
		$subscription_id = $form_data['sub_id'];
		// Unset as we go as we will want to eventually loop through remaining keys
		unset($form_data['sub_user_id']);
		unset($form_data['sub_id']);
		
		/*
		Items should be a serialised array
		Each item's structure: product_id (fixed), variation_id, quantity, total (notax), tax, product_name
		We also want to handle the shipping details (need to mark shipping with unique id)
		*/
		$item_data = array();
		$shipping_data = array();
		
		// Need to sort the remaining fields from the form data
		// Shipping first
		if (isset($form_data['sub_shipping_total']) && isset($form_data['sub_shipping_tax'])) {
			$shipping_data['total'] = $form_data['sub_shipping_total'];
			$shipping_data['tax'] = $form_data['sub_shipping_tax'];
			unset($form_data['sub_shipping_total']);
			unset($form_data['sub_shipping_tax']);
		}
		
		// We should now have an array of item data with a key structure of 'subitem_<field>_<product id>-<variation id>'
		// We explode that to sort the fields to items
		foreach ($form_data as $key => $value) {
			$key_info = explode('_', $key);
			$item_data[$key_info[2]][$key_info[1]] = $value;
		}
	
		// Abort if empty item data array
		if (empty($item_data)) {
			echo json_encode(array(
				'success' => false,
				'error' => __('Item data was not sent.', 'subscriben'),
			));
			exit;
		}
		
		// Fetch the subscription-
		$subscription = self::get_by_id($subscription_id);
		
		// Abort if no subscription
		if (empty($subscription)) {
			echo json_encode(array(
				'success' => false,
				'error' => __('No subscription was found.', 'subscriben'),
			));
			exit;
		}
		
		$params = array();
		// Handle single product subscription. If shipping is included, the subscription will be structured like a multi-product subscription
		if (count($item_data) == 1 && empty($shipping_data)) {
			foreach ($item_data as $datum) {
				$var_id = (!empty($datum['var'])) ? intval($datum['var']) : null;
				$item_id = (!is_null($var_id)) ? $var_id : $datum['id'];
				
				if (empty($datum['tax'])) $datum['tax'] = 0;
				
				$params['product_id'] = intval($datum['id']);
				$params['variation_id'] = intval($datum['var']);
				$params['quantity'] = $datum['quantity'];
				$params['renewal_line_subtotal'] = $datum['total'];
				$params['renewal_line_subtotal_tax'] = $datum['tax'];
				$params['renewal_line_total'] = $params['renewal_line_subtotal'];
				$params['renewal_line_tax'] = $datum['tax'];
				$params['renewal_order_tax'] = $datum['tax'];
				$params['renewal_order_subtotal'] = $datum['total'] + $datum['tax'];
				$params['renewal_order_total'] = $params['renewal_order_subtotal'];
				
				// Single item subscriptions when multi-product subscriptions are enabled need 'products_multiple' row
				if (isset($subscription->products_multiple) && !empty($subscription->products_multiple)) {
					$params['products_multiple'][] = array(
						'product_id' => intval($datum['id']),
						'product_name' => $datum['name'],
						'variation_id' => $var_id,
						'quantity' => intval($datum['quantity']),
						'total' => $datum['total'],
						'tax' => $datum['tax']
					);
				}
			}
		} else {
			$params['renewal_order_tax'] = 0;
			$params['renewal_order_subtotal'] = 0;
			$params['renewal_order_total'] = 0;
			
			foreach ($item_data as $datum) {
				$var_id = (!empty($datum['var'])) ? intval($datum['var']) : null;
				$item_id = (!is_null($var_id)) ? $var_id : $datum['id'];
				
				$datum['total'] = is_numeric($datum['total']) ? floatval($datum['total']) : 0;
				$datum['tax'] = is_numeric($datum['tax']) ? floatval($datum['tax']) : 0;
				
				$params['products_multiple'][] = array(
					'product_id' => intval($datum['id']),
					'product_name' => $datum['name'],
					'variation_id' => $var_id,
					'quantity' => intval($datum['quantity']),
					'total' => $datum['total'],
					'tax' => $datum['tax']
				);
				
				$params['renewal_line_subtotal'][$item_id] = $datum['total'];
				$params['renewal_line_subtotal_tax'][$item_id] = $datum['tax'];
				$params['renewal_line_total'][$item_id] = $datum['total'];
				$params['renewal_line_tax'][$item_id] = $datum['tax'];
				
				$params['renewal_order_tax'] += $datum['tax'];
				$params['renewal_order_subtotal'] += $datum['total'] + $datum['tax'];
				$params['renewal_order_total'] += $datum['total'] + $datum['tax'];
			}
		}
		
		if (!empty($shipping_data)) {
			$shipping_data['total'] = is_numeric($shipping_data['total']) ? floatval($shipping_data['total']) : 0;
			$shipping_data['tax'] = is_numeric($shipping_data['tax']) ? floatval($shipping_data['tax']) : 0;
	
			$params['renewal_order_shipping'] = $shipping_data['total'];
			$params['renewal_order_shipping_tax'] = $shipping_data['tax'];
			$params['renewal_order_total'] += $shipping_data['total'] + $shipping_data['tax'];
		}

		// Set the taxes for the order as a whole
		// TODO handle compound taxes and multiple rates - The following does not take into account the possibility of more than one tax rate being applied, or if a tax rate is compound (i.e. is applied on top of other tax)
		if (isset($subscription->taxes) && is_array($subscription->taxes)) {
			$params['taxes'] = $subscription->taxes;
			$params['taxes'][0]['tax_amount'] = $params['renewal_order_tax'];
			if (isset($params['renewal_order_shipping'])) {
				$params['taxes'][0]['shipping_tax_amount'] = $params['renewal_order_shipping'];
			}
		}
		
		$subscription->update_subscription_details($params);
		
		$note_message = __('Subscription details updated by administrator', 'subscriben');
		$subscription->add_note($note_message);
		
		echo json_encode(array(
			'success' => true,
		));
		exit;
	}
}
}
