<?php
/**
 * Exit if accessed directly
 */
if (!defined('ABSPATH')) {
	exit;
}

/**
 * Methods related to checkout procedure
 *
 * @class Simba_Subscriptions_Checkout
 * @package Simba_Subscriptions
 */
if (!class_exists('Simba_Subscriptions_Checkout')) {

	class Simba_Subscriptions_Checkout {
		
		private $cart_prices_changed = false;

		/**
		 * Constructor class
		 *
		 * @access public
		 * @return void
		 */
		public function __construct() {
			// Change prices and totals in cart
			add_action('woocommerce_cart_loaded_from_session', array($this, 'change_prices'), 99);

			// Change cart item subtotal
			add_filter('woocommerce_cart_item_subtotal', array($this, 'change_cart_item_price_html'), 99, 2);

			// Some filters/actions need to be hooked on init
			add_action('init', array($this, 'on_init'));
		}

		/**
		 * Hook filters/actions that need to be hooked later
		 *
		 * @access public
		 * @return void
		 */
		public function on_init() {
			// Change cart item prices
			add_filter('woocommerce_cart_item_price', array($this, 'change_cart_item_price_html'), 99, 2);
		}

		/**
		 * Actually change subscription prices in cart (add signup fee, apportion if needed etc).
		 *
		 * @access public
		 * @param object $cart
		 * @return void
		 */
		public function change_prices($cart) {
			if ($this->cart_prices_changed || empty($cart->cart_contents)) {
				return;
			}

			// Iterate over all cart items and check if price needs to be updated for subscriptions
			foreach ($cart->cart_contents as $cart_item_key => $cart_item) {
				$id = !empty($cart_item['variation_id']) ? $cart_item['variation_id'] : $cart_item['product_id'];

				// Check if given item is subscription
				if (Simba_Subscriptions_Subscription_Product::is_subscription($id)) {

					// Get new price (or false if price does not need to be changed)
					$new_price = Simba_Subscriptions_Subscription_Product::get_new_price($id, Simba_Subscriptions_WC_Legacy::product_get_price($cart_item['data']));

					// Needs to be changed?
					if (false !== $new_price) {
						$woocommerce = WC();

						if (isset($woocommerce->cart->cart_contents[$cart_item_key])) {
							Simba_Subscriptions_WC_Legacy::product_set_price($woocommerce->cart->cart_contents[$cart_item_key]['data'], $new_price);
						}
					}
				}
			}

			$this->cart_prices_changed = true;
		}

		/**
		 * Change frontend cart item price with Simba_Subscriptions price (cosmetic change)
		 *
		 * @access public
		 * @param float $price_html
		 * @param array $cart_item
		 * @return string
		 */
		public function change_cart_item_price_html($price_html, $cart_item) {
			$id = !empty($cart_item['variation_id']) ? $cart_item['variation_id'] : $cart_item['product_id'];

			// Check if given item is subscription
			if (Simba_Subscriptions_Subscription_Product::is_subscription($id)) {

				$woocommerce = WC();

				// Is subtotal?
				$is_subtotal = current_filter() == 'woocommerce_cart_item_subtotal' ? true : false;

				// Set quantity for 1 item if it's "price" column
				if (!$is_subtotal) {
					$price = Simba_Subscriptions_WC_Legacy::product_get_price($cart_item['data']);
					$quantity = 1;
				} else {
					$quantity = $cart_item['quantity'];
				}

				// Direct access to $woocommerce->cart->tax_display_cart is deprecated in WooCommerce 4.4
				$tax_display_mode = is_callable(array($woocommerce->cart, 'get_tax_price_display_mode')) ? $woocommerce->cart->get_tax_price_display_mode() : $woocommerce->cart->tax_display_cart;
				
				// Get current item price in cart depending on tax display mode
				if ('excl' == $tax_display_mode) {
					$price = $cart_item['line_subtotal'];
					$display_tax_suffix = false;
				} else {
					$price = $cart_item['line_subtotal'] + $cart_item['line_subtotal_tax'];
					$display_tax_suffix = true;
				}

				// Format checkout price html and return
				return Simba_Subscriptions_Subscription_Product::get_formatted_subscription_price($id, true, $is_subtotal, $quantity, $price, false, false, $display_tax_suffix);
			}

			return $price_html;
		}

	}
	new Simba_Subscriptions_checkout();
}
