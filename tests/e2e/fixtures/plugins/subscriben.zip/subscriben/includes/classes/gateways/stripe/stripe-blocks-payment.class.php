<?php

use Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;

/**
 * Exit if accessed directly
 */
if (!defined('ABSPATH')) {
	exit;
}

final class Simba_Subscriptions_Stripe_Payment extends AbstractPaymentMethodType {
	
	/**
	 * Payment method name defined by payment methods extending this class.
	 *
	 * @var string
	 */
	protected $name = 'subscriben_stripe';
	
	/**
	 * An instance of the Subscriben Stripe Gateway
	 *
	 * @var Simba_Subscriptions_Stripe_Gateway
	 */
	private $gateway;

	/**
	 * Initializes the payment method type.
	 */
	public function initialize() {
		$name           = $this->get_name();
		$this->settings = get_option( 'woocommerce_' . $name . '_settings', array() );
		$gateways       = WC()->payment_gateways->payment_gateways();
		$this->gateway  = isset( $gateways[ $name ] ) ? $gateways[ $name ] : null;
	}

	/**
	 * Returns if this payment method should be active. If false, the scripts will not be enqueued.
	 *
	 * @return boolean
	 */
	public function is_active() {
		if ( $this->gateway && is_callable( array( $this->gateway, 'is_available' ) ) ) {
			return $this->gateway->is_available();
		} else {
			return false;
		}
	}

	/**
	 * Returns an array of scripts/handles to be registered for this payment method.
	 *
	 * @return array
	 */
	public function get_payment_method_script_handles() {
		if ( ! $this->is_active() ) {
			return array();
		}
		
		$stripe_js = array(
			'inline' => array(
				'handle' => 'subscriben-stripe-js',
				'url'    => 'https://js.stripe.com/v3/',
			),
			'modal'  => array(
				'handle' => 'subscriben-stripe-checkout-js',
				'url'    => 'https://checkout.stripe.com/checkout.js',
			),
		);
		
		wp_register_script(
			$stripe_js[$this->gateway->checkout_style]['handle'],
			$stripe_js[$this->gateway->checkout_style]['url'],
			array(),
			SUBSCRIBEN_VERSION,
			true
		);
		
		wp_register_script(
			'blocks-subscriben-stripe',
			SUBSCRIBEN_PLUGIN_URL . '/assets/gateways/stripe/js/blocks-payment-method.js',
			array(
				'wc-blocks-registry',
				'wp-i18n',
				'wp-html-entities',
				'wp-element',
			),
			SUBSCRIBEN_VERSION,
			true
		);

		wp_localize_script(
			'blocks-subscriben-stripe',
			'subscribenStripeSettings',
			$this->get_payment_method_data()
		);

		return array( $stripe_js[$this->gateway->checkout_style]['handle'], 'blocks-subscriben-stripe' );
	}

	/**
	 * Returns an array of key=>value pairs of data made available to the payment methods script.
	 *
	 * @return array
	 */
	public function get_payment_method_data() {
		if ( ! $this->gateway ) {
			return array();
		}
		
		// Get user cards
		extract($this->gateway->get_user_cards());
		
		$data = array(
			'name'           => $this->get_name(),
			'title'          => $this->get_setting( 'title' ),
			'description'    => $this->get_setting( 'description' ),
			'supports'       => $this->get_supported_features(),
			'icon'           => $this->gateway->icon,
			'inlineCheckout' => ( 'inline' === $this->gateway->checkout_style ),
			'isDebug'        => wc_string_to_bool( $this->gateway->debug ),
			'publishableKey' => $this->gateway->publishable_key,
			'cards'          => $cards,
			'defaultCard'    => $default_card,
		);
		
		// Add the modal specific data
		if ( 'modal' === $this->gateway->checkout_style ) {
			$data['modalAmount']   = $this->gateway->get_checkout_amount();
			$data['modalLabel']    = apply_filters( 'subscriben_stripe_checkout_modal_button_title', __( 'Pay Now', 'subscriben-stripe' ) );
			$data['modalImage']    = apply_filters( 'subscriben_stripe_checkout_modal_image_url', $this->gateway->checkout_image );
			$data['modalCurrency'] = strtolower( get_woocommerce_currency() );
		}
		
		return apply_filters( 'subscriben_stripe_payment_method_data', $data );
	}
	
	/**
	 * Returns an array of supported features.
	 *
	 * @return string[]
	 */
	public function get_supported_features() {
		if ( ! $this->gateway ) {
			return array();
		}
		
		return array_filter( $this->gateway->supports, array( $this->gateway, 'supports' ) );
	}
	
}
