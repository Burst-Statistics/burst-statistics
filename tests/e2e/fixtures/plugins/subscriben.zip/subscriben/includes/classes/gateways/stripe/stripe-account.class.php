<?php
/**
 * Exit if accessed directly
 */
if (!defined('ABSPATH')) {
	exit;
}

/**
 * Methods related to WooCommerce My Account area
 *
 * @class Simba_Subscriptions_Stripe_Account
 * @package Simba_Subscriptions
 */
if (!class_exists('Simba_Subscriptions_Stripe_Account')) {

	class Simba_Subscriptions_Stripe_Account {

		/**
		 * Constructor class
		 *
		 * @access public
		 * @param mixed $id
		 * @return void
		 */
		public function __construct($id = null) {// phpcs:ignore VariableAnalysis.CodeAnalysis.VariableAnalysis.UnusedVariable
			// Display payment method button
			add_action('woocommerce_account_dashboard', array($this, 'display_payment_method_button'));

			// Handle actions
			add_action('template_redirect', array($this, 'delete_card'));
			add_action('template_redirect', array($this, 'card_make_default'));
		}

		/**
		 * Display payment method button on My Account page
		 *
		 * @access public
		 * @return void
		 */
		public function display_payment_method_button() {
			if (!is_user_logged_in()) {
				return;
			}
			Simba_Subscriptions::include_template('gateways/stripe/payment-method-button');
		}

		/**
		 * Delete card
		 *
		 * @access public
		 * @return void
		 */
		public function delete_card() {
			$woocommerce = WC();// phpcs:ignore VariableAnalysis.CodeAnalysis.VariableAnalysis.UnusedVariable

			// Not our request?
			if ('GET' !== $_SERVER['REQUEST_METHOD'] || !isset($_GET['subscriben_stripe_delete_card'])) {
				return;
			}

			// User not logged in?
			if (!is_user_logged_in()) {
				return;
			}

			$user_id = get_current_user_id();

			// Load cards
			$cards = Simba_Subscriptions_WC_Legacy::customer_get_meta($user_id, '_subscriben_stripe_customer_cards', true);

			if (empty($cards)) {
				return;
			}

			$cards = maybe_unserialize($cards);

			// No such card?
			if (!isset($cards[stripslashes($_GET['subscriben_stripe_delete_card'])])) {
				return;
			}

			// Load customer id
			$customer_id = Simba_Subscriptions_WC_Legacy::customer_get_meta($user_id, '_subscriben_stripe_customer_id', true);

			if (empty($customer_id)) {
				return;
			}

			// Load payment gateway object to access its methods
			$gateway = new Simba_Subscriptions_Stripe_Gateway();

			// Send request to delete this card
			$response = $gateway->send_request('cards', 'delete', array(// phpcs:ignore VariableAnalysis.CodeAnalysis.VariableAnalysis.UnusedVariable
				'id'            => $customer_id,
				'secondary_id'  => stripslashes($_GET['subscriben_stripe_delete_card']),
			));

			// Delete card from user's card list
			unset($cards[stripslashes($_GET['subscriben_stripe_delete_card'])]);

			// Last card deleted?
			if (empty($cards)) {
				Simba_Subscriptions_WC_Legacy::customer_delete_meta_data($user_id, '_subscriben_stripe_customer_cards');
				Simba_Subscriptions_WC_Legacy::customer_delete_meta_data($user_id, '_subscriben_stripe_customer_default_card');
			} else {
				Simba_Subscriptions_WC_Legacy::customer_update_meta_data($user_id, '_subscriben_stripe_customer_cards', $cards);

				// Default card deleted?
				$default_card = Simba_Subscriptions_WC_Legacy::customer_get_meta($user_id, '_subscriben_stripe_customer_default_card', true);

				if (!empty($default_card) && stripslashes($_GET['subscriben_stripe_delete_card']) == $default_card) {
					$new_default = array_keys($cards);
					$new_default = array_shift($new_default);
					Simba_Subscriptions_WC_Legacy::customer_update_meta_data($user_id, '_subscriben_stripe_customer_default_card', $new_default);
				}
			}

			// Show success message
			Simba_Subscriptions_Helper::wc_add_notice(__('Credit card deleted successfully.', 'subscriben-stripe'));
			wp_safe_redirect(get_permalink(wc_get_page_id('myaccount')));
			exit;
		}

		/**
		 * Make card a default card
		 *
		 * @access public
		 * @return void
		 */
		public function card_make_default() {

			// Not our request?
			if ('GET' !== $_SERVER['REQUEST_METHOD'] || !isset($_GET['subscriben_stripe_card_make_default'])) {
				return;
			}

			// User not logged in?
			if (!is_user_logged_in()) return;

			$user_id = get_current_user_id();

			// Load cards
			$cards = Simba_Subscriptions_WC_Legacy::customer_get_meta($user_id, '_subscriben_stripe_customer_cards', true);

			if (empty($cards)) return;

			$cards = maybe_unserialize($cards);

			// No such card?
			if (!isset($cards[$_GET['subscriben_stripe_card_make_default']])) {
				return;
			}

			// Everything looks fine, change default card
			Simba_Subscriptions_WC_Legacy::customer_update_meta_data($user_id, '_subscriben_stripe_customer_default_card', stripslashes($_GET['subscriben_stripe_card_make_default']));

			// Show success message
			Simba_Subscriptions_Helper::wc_add_notice(__('Default card changed successfully.', 'subscriben-stripe'));
			wp_safe_redirect(get_permalink(wc_get_page_id('myaccount')));
			exit;
		}
	}

	new Simba_Subscriptions_Stripe_Account();
}
