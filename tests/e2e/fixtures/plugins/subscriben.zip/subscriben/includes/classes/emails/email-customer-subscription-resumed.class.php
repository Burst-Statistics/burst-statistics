<?php
/**
 * Exit if accessed directly
 */
if (!defined('ABSPATH')) {
	exit;
}

/**
 * Customer Subscription Resumed email
 *
 * @class Simba_Subscriptions_Email_Customer_Subscription_Resumed
 * @package Simba_Subscriptions
 */
if (!class_exists('Simba_Subscriptions_Email_Customer_Subscription_Resumed')) {

class Simba_Subscriptions_Email_Customer_Subscription_Resumed extends Simba_Subscriptions_Email {


	/**
	 * Constructor class
	 *
	 * @access public
	 * @return void
	 */
	public function __construct()
	{
		$this->id             = 'customer_subscription_resumed';
		$this->customer_email = true;
		$this->title          = __('Subscription resumed', 'subscriben');
		$this->description    = __('Subscription resumed emails are sent to customers when subscriptions are resumed (unpaused) by administrator or customers (if they are allowed to).', 'subscriben');

		$this->heading        = __('Your subscription has been resumed', 'subscriben');
		$this->subject        = __('Your {site_title} subscription has been resumed', 'subscriben');

		// Call parent constructor
		parent::__construct();
	}

}
}
