<?php

use Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;

/**
 * Exit if accessed directly
 */
if (!defined('ABSPATH')) {
	exit;
}

final class Simba_Subscriptions_PayPal_EC_Payment extends AbstractPaymentMethodType {
	
	/**
	 * Payment method name defined by payment methods extending this class.
	 *
	 * @var string
	 */
	protected $name = 'subscriben_paypal_ec';
	
	/**
	 * An instance of the Subscriben PayPal EC Gateway
	 *
	 * @var Simba_Subscriptions_PayPal_EC_Gateway
	 */
	private $gateway;

	/**
	 * Initializes the payment method type.
	 */
	public function initialize() {
		$name           = $this->get_name();
		$this->settings = get_option( 'woocommerce_' . $name . '_settings', array() );
		$gateways       = WC()->payment_gateways->payment_gateways();
		$this->gateway  = isset( $gateways[ $name ] ) ? $gateways[ $name ] : null;
	}

	/**
	 * Returns if this payment method should be active. If false, the scripts will not be enqueued.
	 *
	 * @return boolean
	 */
	public function is_active() {
		if ( $this->gateway && is_callable( array( $this->gateway, 'is_available' ) ) ) {
			return $this->gateway->is_available();
		} else {
			return false;
		}
	}

	/**
	 * Returns an array of scripts/handles to be registered for this payment method.
	 *
	 * @return array
	 */
	public function get_payment_method_script_handles() {
		if ( ! $this->is_active() ) {
			return array();
		}
		
		wp_register_script(
			'blocks-subscriben-paypal-ec',
			SUBSCRIBEN_PLUGIN_URL . '/assets/gateways/paypal-ec/js/blocks-payment-method.js',
			array(
				'wc-blocks-registry',
				'wp-i18n',
				'wp-html-entities',
				'wp-element',
			),
			SUBSCRIBEN_VERSION,
			true
		);

		wp_localize_script(
			'blocks-subscriben-paypal-ec',
			'subscribenPayPalECSettings',
			$this->get_payment_method_data()
		);

		return array( 'blocks-subscriben-paypal-ec' );
	}

	/**
	 * Returns an array of key=>value pairs of data made available to the payment methods script.
	 *
	 * @return array
	 */
	public function get_payment_method_data() {
		if ( ! $this->gateway ) {
			return array();
		}
		
		return array(
			'name'             => $this->get_name(),
			'title'            => $this->get_setting( 'title' ),
			'description'      => $this->get_setting( 'description' ),
			'supports'         => $this->get_supported_features(),
			'isSandbox'        => wc_string_to_bool( $this->gateway->sandbox ),
			'orderButtonLabel' => $this->gateway->order_button_text,
		);
	}
	
	/**
	 * Returns an array of supported features.
	 *
	 * @return string[]
	 */
	public function get_supported_features() {
		if ( ! $this->gateway ) {
			return array();
		}
		
		return array_filter( $this->gateway->supports, array( $this->gateway, 'supports' ) );
	}
}
