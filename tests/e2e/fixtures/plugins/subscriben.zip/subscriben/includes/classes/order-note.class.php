<?php
/**
 * Description: This class adds an order note with subscription post link and a column to shop order with subscription reference.
 */

// Basic security, prevents file from being loaded directly.
if (!defined('ABSPATH')) die('No direct access.');

class Simba_Subscriptions_Add_Dashboard_Info {

	/**
	 * Simba_Subscriptions_Enhancement constructor.
	 * Add hooks and filters
	 */
	public function __construct() {
		add_filter('manage_woocommerce_page_wc-orders_columns', array($this, 'shop_order_columns'), 99, 1);
		add_action('manage_woocommerce_page_wc-orders_custom_column', array($this, 'render_shop_order_columns'), 10, 2);
		add_filter('manage_shop_order_posts_columns', array($this, 'shop_order_columns'), 99, 1);
		add_action('manage_shop_order_posts_custom_column', array($this, 'render_shop_order_columns'), 2, 2);
	}

	/**
	 * Define custom columns for shop order post type.
	 *
	 * Only add subscription column. Leave rest of the columns intact as those are handled by WooCommerce itself.
	 *
	 * @param  Array $existing_columns
	 * @return Array - filtered value
	 */
	public function shop_order_columns($existing_columns) {
		$existing_columns['subscription'] = 'Subscription';
		return $existing_columns;
	}

	/**
	 * Output custom columns content for shop order post type.
	 *
	 * Get subscription post id and display them as link in Simba_Subscriptions column
	 *
	 * @param string $column
	 */
	public function render_shop_order_columns($column, $post_or_order_object) {
		$the_order = ($post_or_order_object instanceof WP_Post) ? wc_get_order($post_or_order_object->ID) : $post_or_order_object;
		
		if (! is_object($the_order) && is_numeric($the_order)) {
			$the_order = wc_get_order(absint($the_order));
		}
		
		switch ($column) {
			case 'subscription':
				// Search for related subscriptions
				$subscriptions = Simba_Subscriptions_Subscription::get_by_order_id($the_order->get_id());

				// Iterate and display links
				if (empty($subscriptions)) {
					echo 'n/a';
				} else {

					$first_one = true;
					
					foreach ($subscriptions as $subscription) {

						if ($first_one) {
							$first_one = false;
						} else {
							echo ', ';
						}
					
						if ('cancelled' == $subscription->status) {
							echo '<s>';
						}
						
						Simba_Subscriptions_Helper::print_link_to_post($subscription->id);
						
						if ('cancelled' == $subscription->status) {
							echo '</s>';
						}
					}
				}
				break;
		}
	}

}
// Instantiate enhancement class
new Simba_Subscriptions_Add_Dashboard_Info();
