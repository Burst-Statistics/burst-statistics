<?php
/**
 * Exit if accessed directly
 */
if (!defined('ABSPATH')) {
	exit;
}

/**
 * Main Simba_Subscriptions PayPal Express Checkout payment gateway class
 *
 * @class Simba_Subscriptions_PayPal_EC_Gateway
 * @package Simba_Subscriptions
 */
if (!class_exists('Simba_Subscriptions_PayPal_EC_Gateway') && class_exists('WC_Payment_Gateway')) {

	class Simba_Subscriptions_PayPal_EC_Gateway extends WC_Payment_Gateway {
		
		/**
		 * Sandbox mode
		 *
		 * @var string
		 */
		public $sandbox;
		
		/**
		 * API Username
		 *
		 * @var string
		 */
		private $api_username;
		
		/**
		 * API Password
		 *
		 * @var string
		 */
		private $api_password;
		
		/**
		 * API Signature
		 *
		 * @var string
		 */
		private $api_signature;
		
		/**
		 * Endpoint URL
		 *
		 * @var string
		 */
		private $endpoint_url;
		
		/**
		 * API Version
		 *
		 * @var string
		 */
		private $api_version;
		
		/**
		 * Enable logging
		 *
		 * @var bool
		 */
		private $enable_log;
		
		/**
		 * WC Logger
		 *
		 * @var \Simba_Subscriptions_WC_Logger
		 */
		public $wc_logger;
		
		/**
		 * Enable branding
		 *
		 * @var bool
		 */
		private $enable_branding;
		
		/**
		 * Address Override
		 *
		 * @var bool
		 */
		private $address_override;
		
		/**
		 * Notices
		 *
		 * @var array
		 */
		private $notices = array();

		/**
		 * Constructor class
		 *
		 * NOTE: at the time of writing,  the base class WC_Payment_Gateway has no constructor
		 * so we don't have a specific signature to match. If this changes in the future we will
		 * most likely have an issue here with signature mismatching
		 *
		 * @access public
		 * @param mixed $id
		 * @param bool  $enable_recurring_payment When set to true, the filter is subscribed to that enables recurring payments
		 * @return void
		 */
		public function __construct($id = null, $enable_recurring_payment = true) {// phpcs:ignore VariableAnalysis.CodeAnalysis.VariableAnalysis.UnusedVariable
			// Gateway configuration
			$this->id                 = 'subscriben_paypal_ec';
			$this->has_fields         = false;
			$this->supports           = array('products', 'refunds', 'subscriben');
			$this->method_title       = __('PayPal Express Checkout by Subscriben', 'subscriben-paypal-ec');
			$this->method_description = sprintf(wp_kses(__('Reference Transactions must be enabled on your PayPal account, learn more <a href="%s">here</a>.<br>PayPal requires all communications to be secured with TLS 1.2, make sure that your server <a href="%s">supports it</a>.', 'subscriben-paypal-ec'), array('a' => array('href' => array()), 'br' => array())), 'https://subscribenplugin.com/subscriben-paypal-express-checkout', 'https://subscribenplugin.com/faqs/tls-support/');
			$this->order_button_text  = __('Go to PayPal', 'subscriben-paypal-ec');

			// Load settings fields
			$this->init_form_fields();
			$this->init_settings();

			// Define properties
			$this->enabled            = apply_filters('subscriben_paypal_ec_enabled', $this->get_option('enabled'));
			$this->sandbox            = apply_filters('subscriben_paypal_ec_sandbox', $this->get_option('sandbox'));
			$this->title              = $this->get_option('title');
			$this->description        = $this->get_option('description');

			// API Credentials
			$this->api_username       = wc_string_to_bool($this->sandbox) ? $this->get_option('sandbox_api_username') : $this->get_option('api_username');
			$this->api_password       = wc_string_to_bool($this->sandbox) ? $this->get_option('sandbox_api_password') : $this->get_option('api_password');
			$this->api_signature      = wc_string_to_bool($this->sandbox) ? $this->get_option('sandbox_api_signature') : $this->get_option('api_signature');
			$this->endpoint_url       = wc_string_to_bool($this->sandbox) ? 'https://api-3t.sandbox.paypal.com/nvp' : 'https://api-3t.paypal.com/nvp';
			$this->api_version        = '64';

			// Log
			$this->enable_log         = wc_string_to_bool( $this->get_option('enable_log') );
			$this->wc_logger          = new \Simba_Subscriptions_WC_Logger( $this->id );
			
			// Disable logging
			if (!$this->enable_log) {
				$this->wc_logger->disable();
			}

			// Branding
			$this->enable_branding    = wc_string_to_bool( $this->get_option('enable_branding') );

			// Address Override
			$this->address_override   = wc_string_to_bool( $this->get_option('address_override') );

			// Save gateway settings
			add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));

			// Add support for WC subscriptions recurring payments
			if ($enable_recurring_payment) {
				add_filter('woocommerce_scheduled_subscription_payment_' . $this->id, array($this, 'process_recurring_payment'), 10, 3);
			}

			// Get admin notices and disable payment gateway if any
			$this->notices = $this->get_notices();

			// Disable payments and show admin notices if something is wrong with settings
			if (wc_string_to_bool($this->enabled) && !empty($this->notices)) {

				// Show admin notices
				if ('POST' !== $_SERVER['REQUEST_METHOD']) {
					add_action('admin_notices', array($this, 'show_admin_notices'));
				}

				// Disable payments
				if (count($this->notices) > 1 || !isset($this->notices['ssl'])) {
					$this->enabled = 'no';
				}
			}

			// Disable payments if PayPal is unavailable
			if (!$this->is_paypal_available_for_use()) {
				$this->enabled = 'no';
			}

			// Enqueue scripts
			add_action('admin_enqueue_scripts', array($this, 'enqueue_scripts'));

			// Save form data from checkout page
			add_action('woocommerce_after_checkout_validation', array($this, 'checkout_form_save'));

			// Process IPN message
			add_action('woocommerce_api_simba_subscriptions_paypal_ec_gateway', array($this, 'check_and_process_response'));
			// Backwards compatibility may be required for existing subscriptions - do not change the subscriptio_ here
			if (defined('SUBSCRIBEN_BACKWARDS_COMPATIBILITY') && SUBSCRIBEN_BACKWARDS_COMPATIBILITY) {
				add_action('woocommerce_api_subscriptio_paypal_ec_gateway', array($this, 'check_and_process_response'));
			}
		}


		/**
		 * Get notices for admin
		 *
		 * @access public
		 * @param bool $return_error
		 * @return array|bool
		 */
		public function get_notices() {
			$notices = array();

			// Check secret keys
			if ('no' == $this->sandbox && empty($this->api_username) || empty($this->api_password) || empty($this->api_signature)) {
				$notices['secret'] = __('Subscriben PayPal payment gateway requires all API credentials to be set.', 'subscriben-paypal-ec');
			}

			return $notices;
		}


		/**
		 * Show admin notices
		 *
		 * @access public
		 * @return void
		 */
		public function show_admin_notices() {
			foreach ($this->notices as $notice) {
				echo '<div class="error"><p>' . __($notice, 'subscriben-paypal-ec') . '</p></div>';
			}
		}


		/**
		 * Check if this gateway is available for use
		 *
		 * @access public
		 * @return bool
		 */
		public function is_available() {
			return 'yes' == $this->enabled ? true : false;
		}


		/**
		 * Check if PayPal is enabled and available in the user's country
		 *
		 * @access public
		 * @return bool
		 */
		public function is_paypal_available_for_use() {
			// Using the woocommerce filter
			$supported_currencies = apply_filters('woocommerce_paypal_supported_currencies', array('AUD', 'BRL', 'CAD', 'MXN', 'NZD', 'HKD', 'SGD', 'USD', 'EUR', 'JPY', 'TRY', 'NOK', 'CZK', 'DKK', 'HUF', 'ILS', 'MYR', 'PHP', 'PLN', 'SEK', 'CHF', 'TWD', 'THB', 'GBP', 'RMB', 'RUB'));

			return in_array(get_woocommerce_currency(), $supported_currencies);
		}

		/**
		 * Enqueue backend scripts
		 *
		 * @access public
		 * @return void
		 */
		public function enqueue_scripts() {
			wp_register_script('subscriben_paypal_ec_backend', SUBSCRIBEN_PLUGIN_URL . '/assets/gateways/paypal-ec/js/backend.js', array('jquery'), SUBSCRIBEN_VERSION);
			wp_enqueue_script('subscriben_paypal_ec_backend');
		}

		/**
		 * Get PayPal credentials for request
		 *
		 * @access public
		 * @return string
		 */
		public function get_credentials() {
			$credentials_string = 'USER=' . $this->api_username . '&PWD=' . $this->api_password . '&VERSION=' . $this->api_version . '&SIGNATURE=' . $this->api_signature;
			return $credentials_string;
		}


		/**
		 * Get return page URL - the page where payment call will be made
		 *
		 * @access public
		 * @return string
		 */
		public static function get_return_page() {
			// Try to get checkout/cart page id
			$checkout_page_id = wc_get_page_id('checkout');
			$cart_page_id = wc_get_page_id('cart');

			$return_page_url_id = !empty($checkout_page_id) ? $checkout_page_id : $cart_page_id;

			// Get url and return it
			return get_permalink($return_page_url_id);
		}


		/**
		 * Add branding parameters to customize the Express Checkout page
		 *
		 * @access public
		 * @param array $request
		 * @return array
		 */
		public function add_branding_fields($request) {
			return array_merge($request, array(
				'BRANDNAME'    => $this->get_option('branding_brandname'),
				'PAGESTYLE'    => $this->get_option('branding_pagestyle'),
				'HDRIMG'       => $this->get_option('branding_hdrimg'),
				'LOGOIMG'      => $this->get_option('branding_logoimg'),
				'PAYFLOWCOLOR' => $this->get_option('branding_payflowcolor'),
			));
		}


		/**
		 * Get the email to pre-fill on PayPal login page
		 *
		 * @access public
		 * @param array $checkout_form
		 * @return array
		 */
		public static function get_user_email($checkout_form = null) {
			$user_email = '';

			// Try to get email from posted form
			if (isset($checkout_form['billing_email'])) {
				$user_email = $checkout_form['billing_email'];
			} elseif (is_user_logged_in()) {// Or try to get it from WP user
				$current_user = wp_get_current_user();
				$user_email = $current_user->user_email;
			}

			return $user_email;
		}


		/**
		 * Send cURL request to PayPal
		 *
		 * @access public
		 * @param string $request
		 * @return object|string
		 */
		public function send_curl_request($request = '') {
			$curl = curl_init();

			if (defined('WP_DEBUG') && WP_DEBUG) curl_setopt($curl, CURLOPT_VERBOSE, 1);
			curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, Simba_Subscriptions::get_sslverify_value());
			curl_setopt($curl, CURLOPT_SSLVERSION, Simba_Subscriptions::get_sslversion_value());
			curl_setopt($curl, CURLOPT_TIMEOUT, 60);
			curl_setopt($curl, CURLOPT_URL, $this->endpoint_url);
			curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($curl, CURLOPT_POSTFIELDS, $request);

			$response = curl_exec($curl);
			$http_code = curl_getinfo($curl, CURLINFO_HTTP_CODE);

			// Check for errors
			if (false === $response || 200 != $http_code) {
				$curl_error = curl_error($curl);
				$response = array('error' => $curl_error);
			}

			// Convert to array
			$request_array = Simba_Subscriptions_PayPal_EC_NVP::convert_nvp_to_array($request);
			$response_array = Simba_Subscriptions_PayPal_EC_NVP::convert_nvp_to_array($response);

			// Maybe add to log
			$this->wc_logger->log(__('REQUEST: ', 'subscriben-paypal-ec'), 'info');
			$this->wc_logger->log($request_array, 'info');
			$this->wc_logger->log(__('RESPONSE: ', 'subscriben-paypal-ec'), 'info');
			$this->wc_logger->log($response_array, 'info');

			curl_close($curl);
			return $response;
		}


		/**
		 * Add checkout form data to session
		 *
		 * @access public
		 * @param string $posted
		 * @return void
		 */
		public function checkout_form_save($posted) {
			$this->session_set_var('checkout_form', serialize($posted));
		}


		/**
		 * Process the payment
		 *
		 * @access public
		 * @param obj $order_id
		 * @return array
		 */
		public function process_payment($order_id) {
			$woocommerce = WC();

			// Log the beginning
			$this->wc_logger->log(sprintf(__('Processing order started (order id: %s)', 'subscriben-paypal-ec'), $order_id), 'info');

			// Get order object
			$order = wc_get_order($order_id);
			$cart = $woocommerce->cart->get_cart();

			// Check order
			if (!$order) {
				$this->wc_logger->log(__('Cancelling - order not found', 'subscriben-paypal-ec'));
				Simba_Subscriptions_Helper::wc_add_notice(__('Order not found. We have not charged you for this order. Please try again.', 'subscriben-paypal-ec'), 'error');
				return array();
			}

			// Check if the order is renewal and try to auto-process it
			if (Simba_Subscriptions_Order_Handler::order_is_renewal($order)) {

				$this->wc_logger->log(__('Renewal order detected - trying to auto-process', 'subscriben-paypal-ec'), 'info');

				// Complete the payment if order was processed successfully
				$amount_to_charge = $order->get_total();
				if (apply_filters('subscriben_automatic_payment_' . $this->id, $amount_to_charge, $order, 0) === true) {

					$this->wc_logger->log(sprintf(__('Manual payment for renewal order successfully auto-completed (order id: %s)', 'subscriben-paypal-ec'), $order_id), 'info');

					return array(
						'result'   => 'success',
						'redirect' => esc_url($this->get_return_url($order)),
					);
				}
			} elseif (empty($cart)) {// Check cart
				$this->wc_logger->log(__('Cancelling - the cart is empty', 'subscriben-paypal-ec'));
				Simba_Subscriptions_Helper::wc_add_notice(__('The cart is empty - we have not charged you for this order.', 'subscriben-paypal-ec'), 'error');
				return array();
			}

			// Get review order page url and add order_id to it
			$return_page_url = self::get_return_page();

			// Set the return and cancel urls
			$return_url = add_query_arg(
				array(
					'order_id'               => $order_id,
					'subscriben_ppec_action' => 'do_payment',
				),
				$return_page_url
			);

			$cancel_url = $order->get_cancel_order_url_raw();

			// Prepare the express checkout page
			$express_checkout_response = $this->set_express_checkout($order, $return_url, $cancel_url);

			// Get token
			if (!empty($express_checkout_response['TOKEN'])) {

				// Save token
				$token = $express_checkout_response['TOKEN'];
				$this->session_set_var('TOKEN', $token);

				// Set redirect url
				$redirect_url = 'yes' == $this->sandbox ? 'https://www.sandbox.paypal.com/cgi-bin/webscr?cmd=_express-checkout&' . '&token=' . $token : 'https://www.paypal.com/cgi-bin/webscr?cmd=_express-checkout&' . '&token=' . $token;

				$this->wc_logger->log(__('Express Checkout is set, redirecting to PayPal', 'subscriben-paypal-ec'), 'info');

				// Redirect user
				return array(
					'result'    => 'success',
					'redirect'  => $redirect_url,
				);
			} else {// No token - should be error

				// Check for cURL error
				if (isset($express_checkout_response['error'])) {

					// Create error message
					$error_message = __('Error connecting to PayPal (Set Express Checkout): ', 'subscriben-paypal-ec') . $express_checkout_response['error'];

					// Log error
					$this->wc_logger->log($error_message);

					// Add error
					Simba_Subscriptions_Helper::wc_add_notice($error_message, 'error');
					return array();
				} else {

					$paypal_error = array(
						'full_response' => $express_checkout_response,
						'error_code'    => isset($express_checkout_response['L_ERRORCODE0']) ? $express_checkout_response['L_ERRORCODE0'] : '',
						'severity_code' => isset($express_checkout_response['L_SEVERITYCODE0']) ? $express_checkout_response['L_SEVERITYCODE0'] : '',
						'short_msg'     => isset($express_checkout_response['L_SHORTMESSAGE0']) ? $express_checkout_response['L_SHORTMESSAGE0'] : '',
						'long_msg'      => isset($express_checkout_response['L_LONGMESSAGE0']) ? $express_checkout_response['L_LONGMESSAGE0'] : '',
					);

					// Get the correct message
					$error_message = __('PayPal Set Express Checkout Request failed with message: ', 'subscriben-paypal-ec');
					$error_message .= !empty($paypal_error['long_msg']) ? $paypal_error['long_msg'] : (!empty($paypal_error['short_msg']) ? $paypal_error['short_msg'] : __('Unknown error (check log for more details)', 'subscriben-paypal-ec'));

					// Log error
					$this->wc_logger->log($error_message);

					// Add error
					Simba_Subscriptions_Helper::wc_add_notice($error_message, 'error');
					return array();
				}
			}
		}

		/**
		 * Get the transaction URL.
		 *
		 * @param  WC_Order $order Order object.
		 * @return string
		 */
		public function get_transaction_url($order) {
			if ('yes' == $this->sandbox) {
				$this->view_transaction_url = 'https://www.sandbox.paypal.com/cgi-bin/webscr?cmd=_view-a-trans&id=%s';
			} else {
				$this->view_transaction_url = 'https://www.paypal.com/cgi-bin/webscr?cmd=_view-a-trans&id=%s';
			}
			return parent::get_transaction_url($order);
		}


		/**
		 * Add support for automated payments via WC Simba_Subscriptions API
		 *
		 * $amount_to_charge is the specific total we need to charge for the given subscription
		 * There can be multiple subscriptions in an order so we have to use this total for recurring payments
		 *
		 * @access public
		 * @param float   $amount_to_charge
		 * @param object  $order
		 * @param integer $subscription_id
		 * @return bool
		 */
		public function process_recurring_payment($amount_to_charge, $order, $subscription_id) {// phpcs:ignore VariableAnalysis.CodeAnalysis.VariableAnalysis.UnusedVariable
			return Simba_Subscriptions_PayPal_EC_Subscriptions::process_renewal_order_payment($order, $amount_to_charge);
		}

		/**
		 * Initialize form fields
		 *
		 * @access public
		 * @return void
		 */
		public function init_form_fields() {
			$this->form_fields = array(
				'enabled' => array(
					'title'   => __('Enable/Disable', 'subscriben-paypal-ec'),
					'type'    => 'checkbox',
					'label'   => __('Enable PayPal Express Checkout', 'subscriben-paypal-ec'),
					'default' => 'no',
				),
				'sandbox' => array(
					'title'   => __('Sandbox Mode', 'subscriben-paypal-ec'),
					'type'    => 'checkbox',
					'label'   => __('Enable PayPal Sandbox mode', 'subscriben-paypal-ec'),
					'default' => 'no',
				),
				'enable_log' => array(
					'title'   => __('Enable Log', 'subscriben-paypal-ec'),
					'type'    => 'checkbox',
					'label'   => __('Enable logging of PayPal operations', 'subscriben-paypal-ec'),
					'default' => 'yes',
				),
				'title' => array(
					'title'       => __('Title', 'subscriben-paypal-ec'),
					'type'        => 'text',
					'description' => __('The title which the user sees during checkout.', 'subscriben-paypal-ec'),
					'default'     => __('PayPal', 'subscriben-paypal-ec'),
				),
				'description' => array(
					'title'       => __('Description', 'subscriben-paypal-ec'),
					'type'        => 'textarea',
					'description' => __('The description which the user sees during checkout.', 'subscriben-paypal-ec'),
					'default'     => __('Pay Securely via PayPal', 'subscriben-paypal-ec'),
				),
				'address_override' => array(
					'title'   => __('Address Override', 'subscriben-paypal-ec'),
					'type'    => 'checkbox',
					'label'   => __('Send address data entered on checkout page to PayPal.', 'subscriben-paypal-ec'),
					'default' => 'no',
				),
				'api_credentials' => array(
					'title'       => __('API Credentials', 'subscriben-paypal-ec'),
					'type'        => 'title',
					'description' => sprintf(wp_kses(__('Refer to <a href="%s">this knowledge base article</a> for some guidance on how to acquire your API credentials.', 'subscriben-paypal-ec'), array('a' => array('href' => array()))), 'https://subscribenplugin.com/subscriben-paypal-express-checkout'),
				),
				'sandbox_api_username' => array(
					'title'       => __('Sandbox API Username', 'subscriben-paypal-ec'),
					'type'        => 'text',
					'description' => __('Sandbox API Username from your PayPal Account.', 'subscriben-paypal-ec'),
					'default'     => '',
				),
				'sandbox_api_password' => array(
					'title'       => __('Sandbox API Password', 'subscriben-paypal-ec'),
					'type'        => 'text',
					'description' => __('Sandbox API Password from your PayPal Account.', 'subscriben-paypal-ec'),
					'default'     => '',
				),
				'sandbox_api_signature' => array(
					'title'       => __('Sandbox API Signature', 'subscriben-paypal-ec'),
					'type'        => 'text',
					'description' => __('Sandbox API Signature from your PayPal Account.', 'subscriben-paypal-ec'),
					'default'     => '',
				),
				'api_username' => array(
					'title'       => __('API Username', 'subscriben-paypal-ec'),
					'type'        => 'text',
					'description' => __('API Username from your PayPal Account.', 'subscriben-paypal-ec'),
					'default'     => '',
				),
				'api_password' => array(
					'title'       => __('API Password', 'subscriben-paypal-ec'),
					'type'        => 'text',
					'description' => __('API Password from your PayPal Account.', 'subscriben-paypal-ec'),
					'default'     => '',
				),
				'api_signature' => array(
					'title'       => __('API Signature', 'subscriben-paypal-ec'),
					'type'        => 'text',
					'description' => __('API Signature from your PayPal Account.', 'subscriben-paypal-ec'),
					'default'     => '',
				),
				'branding' => array(
					'title'       => __('Branding', 'subscriben-paypal-ec'),
					'type'        => 'title',
				),
				'enable_branding' => array(
					'title'   => __('Enable Branding Styles', 'subscriben-paypal-ec'),
					'type'    => 'checkbox',
					'label'   => __('Enable Branding Style changes for PayPal pages.', 'subscriben-paypal-ec'),
					'default' => 'yes',
				),
				'branding_brandname' => array(
					'title'       => __('Brand Name', 'subscriben-paypal-ec'),
					'type'        => 'text',
					'class'       => 'subscriben_paypal_ec_branding',
					'description' => __('Label that overrides the business name.', 'subscriben-paypal-ec'),
					'default'     => '',
				),
				'branding_pagestyle' => array(
					'title'       => __('Page Style', 'subscriben-paypal-ec'),
					'type'        => 'text',
					'class'       => 'subscriben_paypal_ec_branding',
					'description' => __('Name of the Custom Payment Page Style for payment pages - it is the same name as the Page Style Name you chose to add or edit the page style in your PayPal Account profile. ', 'subscriben-paypal-ec'),
					'default'     => '',
				),
				'branding_hdrimg' => array(
					'title'       => __('Top Image URL', 'subscriben-paypal-ec'),
					'type'        => 'text',
					'class'       => 'subscriben_paypal_ec_branding',
					'description' => __('URL for the image you want to appear at the top left of the payment page. The image has a maximum size of 750 pixels wide by 90 pixels high. PayPal requires that you provide an image that is stored on a secure (https) server. If you do not specify an image, the business name displays.', 'subscriben-paypal-ec'),
					'default'     => '',
				),
				'branding_logoimg' => array(
					'title'       => __('Logo Image URL', 'subscriben-paypal-ec'),
					'type'        => 'text',
					'class'       => 'subscriben_paypal_ec_branding',
					'description' => __('URL to your logo image. Use a valid graphics format, such as .gif, .jpg, or .png. Limit the image to 190 pixels wide by 60 pixels high.', 'subscriben-paypal-ec'),
					'default'     => '',
				),
				'branding_payflowcolor' => array(
					'title'       => __('Payment Page Background', 'subscriben-paypal-ec'),
					'type'        => 'text',
					'class'       => 'subscriben_paypal_ec_branding',
					'description' => __('Sets the background color for the payment page. By default, the color is white (6-character HTML hexadecimal ASCII color code)', 'subscriben-paypal-ec'),
					'default'     => '',
				),
			);
		}


		/**
		 * Get gateway icon
		 *
		 * @access public
		 * @return string
		 */
		public function get_icon() {

			$icon_label = esc_attr__('PayPal Express Checkout', 'subscriben-paypal-ec');
			$icon_html = '<img src="' . SUBSCRIBEN_PLUGIN_URL . '/assets/img/paypal_express_checkout_icon.gif" title="' . $icon_label . '" alt="' . $icon_label . '"/>';

			return apply_filters('woocommerce_gateway_icon', $icon_html, $this->id);
		}


		/**
		 * Checkbox field on Checkout page
		 *
		 * @access public
		 * @return void
		 */
		public function payment_fields() {
			echo $this->description;
		}


		/**
		 * Set express checkout page and get a token
		 *
		 * @access public
		 * @param obj $order
		 * @param obj $return_url
		 * @param obj $cancel_url
		 * @return array
		 */
		public function set_express_checkout($order, $return_url, $cancel_url) {
			// Get the posted checkout form from session
			$checkout_form = maybe_unserialize($this->session_get_var('checkout_form'));

			// Set the general fields of request
			$set_ec_request = array(
				'METHOD'       => 'SetExpressCheckout',
				'MAXAMT'       => '',
				'RETURNURL'    => $return_url,
				'CANCELURL'    => $cancel_url,
				'NOSHIPPING'   => '1',
				'SURVEYENABLE' => '0',
				'LOCALECODE'   => get_locale(),
				'EMAIL'        => self::get_user_email($checkout_form),
				'TOTALTYPE'    => 'Total',
			);

			// Maybe add branding
			if ($this->enable_branding) {
				$set_ec_request = $this->add_branding_fields($set_ec_request);
			}

			// Maybe override the address
			if ($this->address_override) {
				$set_ec_request['ADDROVERRIDE'] = 1;
			}

			// Prepare the NVP string
			$set_ec_request_nvp = Simba_Subscriptions_PayPal_EC_NVP::create_nvp_from_array($set_ec_request);

			// Create payment_request fields
			$payment_request_object = new Simba_Subscriptions_PayPal_EC_Payment_Request($order, $checkout_form, $this->address_override);
			$payment_request = $payment_request_object->get_payment_array();

			// Prepare the NVP string
			$payment_request_nvp = Simba_Subscriptions_PayPal_EC_NVP::create_nvp_from_payment_request_array($payment_request);

			// Maybe add billing agreement
			if (Simba_Subscriptions_Order_Handler::contains_subscription($order->get_id())) {

				$billing_agreement_request = array(
					'L_BILLINGTYPE0'            => 'MerchantInitiatedBilling',
					'L_PAYMENTTYPE0'            => 'Any',
					'L_BILLINGAGREEMENTCUSTOM0' => '',
				);

				$billing_agreement_request_nvp = Simba_Subscriptions_PayPal_EC_NVP::create_nvp_from_array($billing_agreement_request);
			}

			// Prepare and send request
			$nvp_request = $this->get_credentials() . $set_ec_request_nvp . (isset($billing_agreement_request_nvp) ? $billing_agreement_request_nvp : '') . $payment_request_nvp;
			$nvp_response = $this->send_curl_request($nvp_request);

			// Return response in array
			return Simba_Subscriptions_PayPal_EC_NVP::convert_nvp_to_array($nvp_response);
		}


		/**
		 * Do express checkout payment
		 *
		 * @access public
		 * @return void
		 */
		public function do_express_checkout_payment() {
			$woocommerce = WC();

			$this->wc_logger->log(__('Starting Do Express Checkout process', 'subscriben-paypal-ec'), 'info');

			// Get cart url
			$cart_url = get_permalink(wc_get_page_id('cart'));

			// Save token, PayerID, order_id
			$token = $this->session_get_var('TOKEN');
			$payer_id = isset($_GET['PayerID']) ? $_GET['PayerID'] : '';
			$order_id = isset($_GET['order_id']) ? $_GET['order_id'] : '';

			// Get the order
			$order = wc_get_order($order_id);

			// Check everything
			if (empty($token) || (empty($payer_id) && $order->get_total() != 0) || empty($order_id)) {

				// Add error
				Simba_Subscriptions_Helper::wc_add_notice(__('Unfortunately, your session for this payment has expired. Please try again.', 'subscriben-paypal-ec'), 'error');
				$this->wc_logger->log(__('Cancelling - session expired', 'subscriben-paypal-ec'));

				// Redirect to cart page
				wp_redirect($cart_url);
				exit();
			}

			// Handle order with free trial
			if ($order->get_total() == 0) {
				$this->handle_trial($order, $token);
			} elseif (self::is_order_paid($token)) {// Prevent double payments

				// Add error
				Simba_Subscriptions_Helper::wc_add_notice(__('Operation cancelled - current token was already used to make a payment.', 'subscriben-paypal-ec'), 'error');
				$this->wc_logger->log(__('Cancelling - order already paid', 'subscriben-paypal-ec'));

				// Redirect to cart page
				wp_redirect($cart_url);
				exit();
			}

			// Start making the request
			$do_ec_request = array(
				'METHOD'  => 'DoExpressCheckoutPayment',
				'TOKEN'   => urlencode($token),
				'PAYERID' => urlencode($payer_id),
				'AMT'           => $order->get_total(),
				'PAYMENTACTION' => 'Sale',
				'CURRENCYCODE'  => strtoupper($order->get_currency()),
			);

			// Prepare the NVP string
			$do_ec_request_nvp = Simba_Subscriptions_PayPal_EC_NVP::create_nvp_from_array($do_ec_request);

			// Create payment_request fields
			$payment_request_object = new Simba_Subscriptions_PayPal_EC_Payment_Request($order);
			$payment_request = $payment_request_object->get_payment_array();

			// Prepare the NVP string
			$payment_request_nvp = Simba_Subscriptions_PayPal_EC_NVP::create_nvp_from_payment_request_array($payment_request);

			// Save payment method
			$order->update_meta_data('_payment_method', $this->id);
			$order->update_meta_data('_payment_method_title', $this->title);
			$order->save();
			
			// Send request
			$nvp_request = $this->get_credentials() . $do_ec_request_nvp . $payment_request_nvp;
			$nvp_response = $this->send_curl_request($nvp_request);
			$nvp_response_array = Simba_Subscriptions_PayPal_EC_NVP::convert_nvp_to_array($nvp_response);

			// Check for cURL error
			if (isset($nvp_response_array['error'])) {
				$error_message = __('Error connecting to PayPal (Do Express Checkout): ', 'subscriben-paypal-ec') . $nvp_response_array['error'];

				// Log error
				$this->wc_logger->log($error_message);

				// Add error
				$order->add_order_note($error_message);
				Simba_Subscriptions_Helper::wc_add_notice($error_message, 'error');

				// Redirect to cart page
				wp_redirect($cart_url);
				exit();
			}

			// Get results
			$transaction_id = isset($nvp_response_array['PAYMENTINFO_0_TRANSACTIONID']) ? $nvp_response_array['PAYMENTINFO_0_TRANSACTIONID'] : '';
			$result_message = isset($nvp_response_array['ACK']) ? $nvp_response_array['ACK'] : '';
			$payment_status = isset($nvp_response_array['PAYMENTINFO_0_PAYMENTSTATUS']) ? $nvp_response_array['PAYMENTINFO_0_PAYMENTSTATUS'] : '';

			// Request was successful
			if (in_array($result_message, array('Success', 'SuccessWithWarning'))) {

				// Create notes
				$order_note = sprintf(__('PayPal Express Checkout payment operation completed (payment status: %s, transaction id: %s)', 'subscriben-paypal-ec'), $payment_status, $transaction_id);
				$log_entry = sprintf(__('Payment operation completed (payment status: %s, transaction id: %s)', 'subscriben-paypal-ec'), $payment_status, $transaction_id);

				// Payment completed
				if (in_array($payment_status, array('Completed', 'Processed'))) {

					// Complete the order
					$order->payment_complete($transaction_id);
				} else {// Pending and other statuses
					if ('Pending' == $payment_status && isset($nvp_response_array['PAYMENTINFO_0_PENDINGREASON'])) {
						$pending_reason_key = $nvp_response_array['PAYMENTINFO_0_PENDINGREASON'];
						$pending_reason = self::get_pending_reason($pending_reason_key);
						$log_entry .= sprintf(__(' Pending reason: %s (%s)', 'subscriben-paypal-ec'), $pending_reason_key, $pending_reason);
					}
				}

				// Write notes
				$order->add_order_note($order_note);
				$this->wc_logger->log($log_entry, 'info');

				// Create transaction url notes
				$transaction_url = $this->get_transaction_url($order);
				if ($transaction_url) {
					$payment_via = ' (<a href="' . esc_url($transaction_url) . '" target="_blank">' . esc_html($transaction_id) . '</a>)';
					$order_transaction_url_note = sprintf(__('PayPal Express Checkout Transaction URL: %s', 'subscriben-paypal-ec'), $payment_via);
					$order->add_order_note($order_transaction_url_note);
				}

				// Save transaction id
				$order->update_meta_data('_subscriben_paypal_ec_transaction_id', $transaction_id);

				// Add billing agreement id to user/post meta
				if (isset($nvp_response_array['BILLINGAGREEMENTID'])) {
					$key   = '_subscriben_paypal_ec_billing_agreement';
					$value = $nvp_response_array['BILLINGAGREEMENTID'];
					
					$order->update_meta_data($key, $value);
					
					$user_id = get_current_user_id();
					
					if ( empty( $user_id ) ) { // guest checkout
						$user_id = $order->get_customer_id();
					}
					
					if ( ! empty( $user_id ) ) {
						$customer = new WC_Customer($user_id);
						$customer->update_meta_data($key, $value);
						$customer->save();
					}
				}

				// Save token
				$order->update_meta_data('_subscriben_paypal_ec_token', $token);
				$order->save_meta_data();

				// Clean up
				$this->session_erase_var('TOKEN');
				$this->session_erase_var('checkout_form');

				// Empty cart
				$woocommerce->cart->empty_cart();

				wp_redirect($this->get_return_url($order));
				exit();
			} else {

				$paypal_error = array(
					'full_response' => $nvp_response_array,
					'error_code'    => isset($nvp_response_array['PAYMENTREQUEST_0_ERRORCODE']) ? $nvp_response_array['PAYMENTREQUEST_0_ERRORCODE'] : '',
					'severity_code' => isset($nvp_response_array['PAYMENTREQUEST_0_SEVERITYCODE']) ? $nvp_response_array['PAYMENTREQUEST_0_SEVERITYCODE'] : '',
					'short_msg'     => isset($nvp_response_array['PAYMENTREQUEST_0_SHORTMESSAGE']) ? $nvp_response_array['PAYMENTREQUEST_0_SHORTMESSAGE'] : '',
					'long_msg'      => isset($nvp_response_array['PAYMENTREQUEST_0_LONGMESSAGE']) ? $nvp_response_array['PAYMENTREQUEST_0_LONGMESSAGE'] : '',
				);

				// Get the correct message
				$error_message = __('PayPal Express Checkout payment failed with message: ', 'subscriben-paypal-ec');
				$error_message .= !empty($paypal_error['long_msg']) ? $paypal_error['long_msg'] : (!empty($paypal_error['short_msg']) ? $paypal_error['short_msg'] : __('Unknown error (check log for more details)', 'subscriben-paypal-ec'));

				// Log error
				$this->wc_logger->log($error_message);

				// Add error
				$order->add_order_note($error_message);
				Simba_Subscriptions_Helper::wc_add_notice($error_message, 'error');

				// Redirect to cart page
				$cart_url = get_permalink(wc_get_page_id('cart'));

				wp_redirect($cart_url);
				exit();
			}
		}


		/**
		 * Handle order with free trial
		 *
		 * @param object $order
		 * @param string $token
		 * @access public
		 * @return array
		 */
		public function handle_trial($order, $token) {
			$woocommerce = WC();

			$this->wc_logger->log(__('Starting process of handling trial subscription from order #', 'subscriben-paypal-ec') . $order->get_id(), 'info');

			// Save payment method
			$order->update_meta_data('_payment_method', $this->id);
			$order->update_meta_data('_payment_method_title', $this->title);

			// Start making the request
			$ba_request = array(
				'METHOD' => 'CreateBillingAgreement',
				'TOKEN'  => urlencode($token),
			);

			// Prepare the NVP string
			$ba_request_nvp = Simba_Subscriptions_PayPal_EC_NVP::create_nvp_from_array($ba_request);

			// Send request
			$nvp_request = $this->get_credentials() . $ba_request_nvp;
			$nvp_response = $this->send_curl_request($nvp_request);
			$nvp_response_array = Simba_Subscriptions_PayPal_EC_NVP::convert_nvp_to_array($nvp_response);

			// Add billing agreement id to user/post meta
			if (isset($nvp_response_array['BILLINGAGREEMENTID'])) {
				$user_id = get_current_user_id();
				$key     = '_subscriben_paypal_ec_billing_agreement';
				$value   = $nvp_response_array['BILLINGAGREEMENTID'];
				
				if (!empty($user_id)) {
					$customer = new WC_Customer($user_id);
					$customer->update_meta_data($key, $value);
					$customer->save();
				}
				
				$order->update_meta_data($key, $value);

				$order->add_order_note(__('PayPal details saved for future use.', 'subscriben-stripe'));
				$this->wc_logger->log(__('Billing agreement id saved', 'subscriben-paypal-ec'), 'info');
			} else {

				$error_message = __('Error: no billing agreement id found', 'subscriben-paypal-ec');

				$order->add_order_note($error_message);
				$this->wc_logger->log($error_message);
			}
			
			$order->save_meta_data();

			// Complete the order
			$order->update_status('processing');
			wc_reduce_stock_levels( $order );

			// Empty cart
			$woocommerce->cart->empty_cart();

			// Redirect user
			wp_redirect($this->get_return_url($order));
			exit();
		}


		/**
		 * Check if order was already paid using this payment method
		 *
		 * @param int $token
		 * @return boolean
		 */
		public static function is_order_paid($token) {
			// Check token
			if (empty($token)) {
				return false;
			}
			
			$hpos_enabled = Simba_Subscriptions::is_hpos_enabled();
			$meta_key     = '_subscriben_paypal_ec_token';
			$args         = array(
				'limit'  => 1,
				'return' => 'objects',
			);
			
			if ($hpos_enabled) {
				// HPOS is enabled; use meta_query.
				$args['meta_query'] = array(
					array(
						'key'     => $meta_key,
						'value'   => $token,
						'compare' => '=',
					),
				);
			} else {
				// HPOS is not enabled; use legacy method.
				$args[$meta_key] = $token;
	
				add_filter( 'woocommerce_order_data_store_cpt_get_orders_query', array( __CLASS__, 'handle_custom_query_var_subscriben_paypal_ec_token' ), 10, 2 );
			}
			
			$order_objects = wc_get_orders($args);
			
			if (!$hpos_enabled) {
				remove_filter( 'woocommerce_order_data_store_cpt_get_orders_query', array( __CLASS__, 'handle_custom_query_var_subscriben_paypal_ec_token' ), 10, 2 );
			}
			
			return !empty($order_objects);
		}

		/**
		 * Process refund manually issued from order page
		 *
		 * @access public
		 * @param int    $order_id
		 * @param float  $amount
		 * @param string $reason
		 * @return bool
		 */
		public function process_refund($order_id, $amount = null, $reason = '') {
			$this->wc_logger->log(__('Processing refund for order #', 'subscriben-paypal-ec') . $order_id, 'info');

			// Load order
			$order = wc_get_order($order_id);

			if (!$order) {
				return;
			}

			// Get transaction id
			$transaction_id = $order->get_meta('_subscriben_paypal_ec_transaction_id');

			if (empty($transaction_id)) {
				return;
			}

			// Get order total
			$refund_type = $amount < $order->get_total() ? 'Partial' : 'Full';
			$reason = esc_html($reason);
			$reason = substr($reason, 0, 255);

			// Start making the request
			$refund_request = array(
				'METHOD'        => 'RefundTransaction',
				'TRANSACTIONID' => $transaction_id,
				'REFUNDTYPE'    => $refund_type,
				'AMT'           => 'Full' == $refund_type ? '' : $amount,
				'CURRENCYCODE'  => strtoupper($order->get_currency()),
				'NOTE'          => $reason,
			);

			// Prepare the NVP string
			$refund_request_nvp = Simba_Subscriptions_PayPal_EC_NVP::create_nvp_from_array($refund_request);

			// Send request
			$nvp_request = $this->get_credentials() . $refund_request_nvp;
		$nvp_response = $this->send_curl_request($nvp_request);
			$nvp_response_array = Simba_Subscriptions_PayPal_EC_NVP::convert_nvp_to_array($nvp_response);

			// Get results
			$result_message = $nvp_response_array['ACK'];
			$refund_transaction_id = $nvp_response_array['REFUNDTRANSACTIONID'];// phpcs:ignore VariableAnalysis.CodeAnalysis.VariableAnalysis.UnusedVariable

			// Request was successful
			if ('Success' == $result_message || 'SuccessWithWarning' == $result_message) {
				$order->add_order_note(sprintf(__('%s of PayPal charge %s refunded.', 'subscriben-paypal-ec'), Simba_Subscriptions::get_formatted_price($amount), $transaction_id));
				$this->wc_logger->log(__('Refund successful', 'subscriben-paypal-ec'), 'info');
				return true;
			} else {// Request failed
				$order->add_order_note(__('PayPal refund failed.', 'subscriben-paypal-ec'));
				$this->wc_logger->log(__('Refund failed', 'subscriben-paypal-ec'));
				return false;
			}
		}


		/**
		 * Get WC currency
		 *
		 * @access public
		 * @param string $currency_code
		 * @return void
		 */
		public static function get_currency() {
			return strtoupper(get_woocommerce_currency());
		}


		/**
		 * Check if currency supports decimals
		 * more details: https://developer.paypal.com/docs/classic/api/currency_codes/
		 *
		 * @access public
		 * @param string $currency_code
		 * @return void
		 */
		public static function currency_supports_decimals($currency_code = '') {
			if (empty($currency_code)) {
				$currency_code = self::get_currency();
			}

			return !in_array($currency_code, array('HUF', 'JPY', 'TWD'));
		}


		/**
		 * Round the amount
		 *
		 * @access public
		 * @param double $amount
		 * @param int    $precision
		 * @return void
		 */
		public static function round($amount, $precision = 2) {
			// Maybe change precision for non-decimal currencies
			$precision = self::currency_supports_decimals() ? $precision : 0;

			// Return rounded amount
			return round($amount, $precision);
		}


		/**
		 * Format the amount
		 *
		 * @access public
		 * @param float $amount
		 * @param int   $decimals
		 * @return float
		 */
		public static function number_format($amount, $decimals = 2) {
			// Maybe change decimals number for non-decimal currencies
			$decimals = self::currency_supports_decimals() ? $decimals : 0;

			// Return formatted amount
			return number_format($amount, $decimals, '.', '');
		}


		/**
		 * Set session variable
		 *
		 * @access public
		 * @param string $key
		 * @param string $value
		 * @return void
		 */
		private function session_set_var($key, $value) {
			$woocommerce = WC();
			$woocommerce->session->$key = $value;
		}


		/**
		 * Get session variable
		 *
		 * @access public
		 * @param string $key
		 * @return void
		 */
		private function session_get_var($key) {
			$woocommerce = WC();
			return $woocommerce->session->$key;
		}


		/**
		 * Erase session variable
		 *
		 * @access public
		 * @param string $key
		 * @return void
		 */
		private function session_erase_var($key) {
			$woocommerce = WC();
			$woocommerce->session->$key = '';
		}


		/**
		 * Get readable pending reason
		 *
		 * @access public
		 * @param string $key
		 * @return void
		 */
		public static function get_pending_reason($key) {
			// Add readable reasons from PayPal documentation
			$pending_reasons = array(
				'none'              => __('No pending reason.', 'subscriben-paypal-ec'),
				'address'           => __('The payment is pending because your buyer did not include a confirmed shipping address and your Payment Receiving Preferences is set such that you want to manually accept or deny each of these payments. To change your preference, go to the Preferences section of your Profile.', 'subscriben-paypal-ec'),
				'authorization'     => __('The payment is pending because it has been authorized but not settled. You must capture the funds first.', 'subscriben-paypal-ec'),
				'echeck'            => __('The payment is pending because it was made by an eCheck that has not yet cleared.', 'subscriben-paypal-ec'),
				'intl'              => __('The payment is pending because you hold a non-U.S. account and do not have a withdrawal mechanism. You must manually accept or deny this payment from your Account Overview.', 'subscriben-paypal-ec'),
				'multi-currency'    => __('You do not have a balance in the currency sent, and you do not have your Payment Receiving Preferences set to automatically convert and accept this payment. You must manually accept or deny this payment.', 'subscriben-paypal-ec'),
				'order'             => __('The payment is pending because it is part of an order that has been authorized but not settled.', 'subscriben-paypal-ec'),
				'payment-review'    => __('The payment is pending while it is being reviewed by PayPal for risk.', 'subscriben-paypal-ec'),
				'regulatory-review' => __('The payment is pending while we make sure it meets regulatory requirements. You will be contacted again in 24-72 hours with the outcome of the review.', 'subscriben-paypal-ec'),
				'unilateral'        => __('The payment is pending because it was made to an email address that is not yet registered or confirmed.', 'subscriben-paypal-ec'),
				'verify'            => __('The payment is pending because you are not yet verified. You must verify your account before you can accept this payment.', 'subscriben-paypal-ec'),
				'other'             => __('The payment is pending for a reason other than those listed above. For more information, contact PayPal customer service.', 'subscriben-paypal-ec'),
			);

			// Also make sure no-hyphens versions supported
			$pending_reasons['multicurrency'] = $pending_reasons['multi-currency'];
			$pending_reasons['paymentreview'] = $pending_reasons['payment-review'];
			$pending_reasons['regulatoryreview'] = $pending_reasons['regulatory-review'];

			return (isset($pending_reasons[$key]) ? $pending_reasons[$key] : $pending_reasons['none']);
		}


		/**
		 * Get order with specific temporal key to use with IPN response
		 *
		 * @access public
		 * @param string $txn_id
		 * @return object|bool
		 */
		public function get_order_from_txnid($txn_id) {
		
			$hpos_enabled = Simba_Subscriptions::is_hpos_enabled();
			
			if (!$hpos_enabled) add_filter('woocommerce_order_data_store_cpt_get_orders_query', array('Simba_Subscriptions_PayPal_EC_Gateway', 'handle_custom_query_var_ec_transaction_id'), 10, 2);
		
			$params = array(
				'limit' => 1,
				'return' => 'objects',
			);
			
			if ($hpos_enabled) {
				$params['meta_query'] = array(
					array(
						'key' => '_subscriben_paypal_ec_transaction_id',
						'value' => $txn_id,
						'compare' => '=',
					),
				);
			} else {
				$params['_subscriben_paypal_ec_transaction_id'] = $txn_id;
			}
			
			$order_objects = wc_get_orders($params);
			
			if (!$hpos_enabled) remove_filter('woocommerce_order_data_store_cpt_get_orders_query', array('Simba_Subscriptions_PayPal_EC_Gateway', 'handle_custom_query_var_ec_transaction_id'), 10, 2);

			return empty($order_objects) ? false : array_pop($order_objects);
		}
		
		/**
		 * Handle a custom '_subscriben_paypal_ec_transaction_id' query var to get orders with the '_subscriben_paypal_ec_transaction_id' meta.
		 *
		 * @param array $query		- Args for WP_Query.
		 * @param array $query_vars - Query vars from WC_Order_Query.
		 * @return array modified $query
		 */
		public static function handle_custom_query_var_ec_transaction_id($query, $query_vars) {
		
			if (!empty($query_vars['_subscriben_paypal_ec_transaction_id'])) {
				$query['meta_query'][] = array(
					'key' => '_subscriben_paypal_ec_transaction_id',
					'value' => esc_attr($query_vars['_subscriben_paypal_ec_transaction_id']),
				);
			}

			return $query;
		}
		
		/**
		 * Handle a custom '_subscriben_paypal_ec_token' query var to get orders with the '_subscriben_paypal_ec_token' meta.
		 *
		 * @param array $query		- Args for WP_Query.
		 * @param array $query_vars - Query vars from WC_Order_Query.
		 * @return array modified $query
		 */
		public static function handle_custom_query_var_subscriben_paypal_ec_token($query, $query_vars) {
		
			if (!empty($query_vars['_subscriben_paypal_ec_token'])) {
				$query['meta_query'][] = array(
					'key' => '_subscriben_paypal_ec_token',
					'value' => esc_attr($query_vars['_subscriben_paypal_ec_token']),
				);
			}

			return $query;
		}
		
		/**
		 * Check and process IPN response from PayPal
		 *
		 * @access public
		 * @return string
		 */
		public function check_and_process_response() {
			$raw_post = file_get_contents("php://input");

			if (!empty($raw_post)) {

				// Validate the request
				if ($this->validate_ipn($raw_post) !== true) {
					wp_die('PayPal IPN Request Failure', 'PayPal IPN', array('response' => 200));
				}

				$posted = $this->parse_paypal_ipn_message($raw_post);
				$this->wc_logger->log(__('Decoded IPN message: ', 'subscriben-paypal-ec'), 'info');
				$this->wc_logger->log($posted, 'info');

				$payment_status = isset($posted['payment_status']) ? $posted['payment_status'] : '';
				$txn_id = isset($posted['txn_id']) ? $posted['txn_id'] : '';
				$custom = isset($posted['custom']) && is_serialized($posted['custom']) ? unserialize($posted['custom'], ['allowed_classes' => false]) : null;
				
				// PayPal IPN events will sent the custom data from the original order; if this is not reliable (e.g. you have migrated data between shops), then this may be undesirable
				if (!empty($custom['order_id']) && apply_filters('subscriben_paypal_ec_identify_order_from_custom', true, $custom)) {
					$order = wc_get_order($custom['order_id']);
				}

				if (empty($order) && !empty($txn_id)) {
					$order = $this->get_order_from_txnid($txn_id);
				}

				// Update only unpaid orders
				if (isset($order) && $order && 'Completed' == $payment_status && Simba_Subscriptions_Order_Handler::order_is_paid($order) === false) {

					// Complete the order
					$order->add_order_note(sprintf(__('PayPal Express Checkout payment completed via IPN (transaction id: %s)', 'subscriben-paypal-ec'), $txn_id));
					$this->wc_logger->log(__('Payment completed via IPN', 'subscriben-paypal-ec'), 'info');
					$order->payment_complete($txn_id);
				}

				exit;
			}
		}

		/**
		 * Validate IPN response with PayPal
		 *
		 * @param string $raw_post
		 * @return bool
		 */
		private function validate_ipn($raw_post) {
			// Combine received input values with validate command
			$raw_post_validate = 'cmd=_notify-validate&' . $raw_post;

			// Compare and maybe change encoding
			if (function_exists('mb_detect_encoding')) {
				$raw_post_enc = mb_detect_encoding($raw_post);
				$raw_post_validate_enc = mb_detect_encoding($raw_post_validate);

				if ($raw_post_enc !== $raw_post_validate_enc && $raw_post_validate_encoded = iconv($raw_post_validate_enc, $raw_post_enc, $raw_post_validate)) {
					$raw_post_validate = $raw_post_validate_encoded;
				}
			}

			// Set url
			$post_url = 'yes' == $this->sandbox ? 'https://www.sandbox.paypal.com/cgi-bin/webscr' : 'https://www.paypal.com/cgi-bin/webscr';

			$curl = curl_init();

			if (defined('WP_DEBUG') && WP_DEBUG) curl_setopt($curl, CURLOPT_VERBOSE, 1);
			curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, Simba_Subscriptions::get_sslverify_value());
			curl_setopt($curl, CURLOPT_TIMEOUT, 60);
			curl_setopt($curl, CURLOPT_URL, $post_url);
			curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($curl, CURLOPT_POSTFIELDS, $raw_post_validate);

			$response = curl_exec($curl);
			$http_code = curl_getinfo($curl, CURLINFO_HTTP_CODE);

			$this->wc_logger->log(__('Incoming IPN message: ', 'subscriben-paypal-ec'), 'info');
			$this->wc_logger->log($raw_post, 'info');
			$this->wc_logger->log(__('IPN validation result: ', 'subscriben-paypal-ec'), 'info');
			$this->wc_logger->log($response, 'info');

			// Check if we received the VERIFIED
			if ($http_code >= 200 && $http_code < 300 && strstr($response, 'VERIFIED')) {
				return true;
			} elseif (false === $response || strstr($response, 'INVALID')) {// If received an error
				return false;
			}

			return null;
		}


		/**
		 * Parse IPN message and return the correctly structured array
		 * (based on a method created by donut2d from PayPal community)
		 *
		 * @access private
		 * @param string $raw_post
		 * @return array
		 */
		private function parse_paypal_ipn_message($raw_post) {

			$post = array();
			$pairs = explode('&', $raw_post);

			foreach ($pairs as $pair) {

				$pair = explode('=', $pair);
				$key = urldecode($pair[0]);
				$value = urldecode($pair[1]);
				$key_parts = array();

				// Look for a key as simple as 'return_url' or as complex as 'somekey[x].property'
				preg_match('/(\w+)(?:\[(\d+)\])?(?:\.(\w+))?/', $key, $key_parts);

				switch (count($key_parts)) {
					case 4:
						// Converting key[x].property to $post[key][x][property]
						if (!isset($post[$key_parts[1]])) {
							$post[$key_parts[1]] = array($key_parts[2] => array($key_parts[3] => $value));
						} elseif (!isset($post[$key_parts[1]][$key_parts[2]])) {
							$post[$key_parts[1]][$key_parts[2]] = array($key_parts[3] => $value);
						} else {
							$post[$key_parts[1]][$key_parts[2]][$key_parts[3]] = $value;
						}
						break;
					case 3:
						// Converting key[x] to $post[key][x]
						if (!isset($post[$key_parts[1]])) {
							$post[$key_parts[1]] = array();
						}

						$post[$key_parts[1]][$key_parts[2]] = $value;
						break;
					default:
						// No special format
						$post[$key] = $value;
						break;
				}
			}

			return $post;
		}
	}
}
