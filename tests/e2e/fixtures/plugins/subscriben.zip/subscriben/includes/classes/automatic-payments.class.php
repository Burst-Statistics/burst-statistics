<?php
/**
 * Exit if accessed directly
 */
if (!defined('ABSPATH')) {
	exit;
}

/**
 * Methods related to automatic payments
 *
 * @class Simba_Subscriptions_Automatic_Payments
 * @package Simba_Subscriptions
 */
if (!class_exists('Simba_Subscriptions_Automatic_Payments')) {

class Simba_Subscriptions_Automatic_Payments {

	/**
	 * Constructor class
	 *
	 * @access public
	 * @return void
	 */
	public function __construct()
	{
		// Check if order is renewal order
		add_filter('woocommerce_stripe_is_renewal_order', array($this, 'is_renewal_order'), 10, 2);

		// Attempt to process automatic payment
		add_filter('subscriben_automatic_payment', array($this, 'process_payment'), 10, 3);
	}

	/**
	 * Check if order is renewal order
	 *
	 * @access public
	 * @param bool   $is_renewal
	 * @param object $order
	 * @return bool
	 */
	public function is_renewal_order($is_renewal, $order)
	{
		return Simba_Subscriptions_Order_Handler::order_is_renewal($order);
	}

	/**
	 * Process automatic payment
	 *
	 * @access public
	 * @param bool   $payment_processed
	 * @param object $order
	 * @param object $subscription
	 * @return bool
	 */
	public function process_payment($payment_processed, $order, $subscription)
	{
		$woocommerce = WC();

		$selected_gateway = null;

		// Load payment methods
		if ($woocommerce->payment_gateways) {
			foreach ($woocommerce->payment_gateways->payment_gateways() as $gateway) {
				if ($gateway->id == $subscription->payment_method) {
					if ($gateway->supports('subscriben') || 'stripe' == $gateway->id) {
						$selected_gateway = $gateway->id;
					}
					break;
				}
			}
		}

		// Gateway is active and supports Simba_Subscriptions
		if ($selected_gateway) {
			// This hook is ran once per subscription by Simba_Subscriptions, but the total we are charging
			// must be based on the subscription, not on the order. An order can contain other products too
			// including other subscriptions
			$amount_to_charge = Simba_Subscriptions_WC_Legacy::order_get_total($order);

			// Trigger the WC subscriptions hook for scheduled payments
			// Due to the change of context from subscription level here, to order level in the following action, we have to use the third
			// parameter of the hook to pass the Simba_Subscriptions subscription ID. It's not used otherwise and we need this back reference
			// to cover cases where orders have multiple subscriptions
			return apply_filters('woocommerce_scheduled_subscription_payment_' . $selected_gateway, $amount_to_charge, $order, $subscription->id);
		}

		return false;
	}
}

new Simba_Subscriptions_Automatic_Payments();
}
