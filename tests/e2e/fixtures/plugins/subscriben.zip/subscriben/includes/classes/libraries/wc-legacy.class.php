<?php
if (!defined('ABSPATH')) die('No direct access.');

// This class contains a compatibility layer to handle WooCommerce API changes. However, much of it does nothing extra, following the removal of pre-WC-3.0 compatibility.

/**
 * Version Control
 *
 * WARNING: Make sure to update version number here as well as in the main class name
 */
$version = '9';

global $subscriben_wc_legacy_version;

if (!$subscriben_wc_legacy_version || $subscriben_wc_legacy_version < $version) {
	$subscriben_wc_legacy_version = $version;
}

/**
 * Proxy Class
 */
if (!class_exists('Simba_Subscriptions_WC_Legacy')) {

	final class Simba_Subscriptions_WC_Legacy {


		/**
		 * Method overload
		 *
		 * @access public
		 * @param string $method_name
		 * @param array  $arguments
		 * @return mixed
		 */
		public static function __callStatic($method_name, $arguments) {
			// Get latest version of the main class
			global $subscriben_wc_legacy_version;

			// Get main class name
			$class_name = 'Simba_Subscriptions_WC_Legacy_' . $subscriben_wc_legacy_version;

			// Call main class
			return call_user_func_array(array($class_name, $method_name), $arguments);
		}
	}
}

/**
 * Handling incompatible changes in WooCommerce core across different versions
 * Simba_Subscriptions_Helper must be loaded for these methods to work properly
 *
 * @class Simba_Subscriptions_WC_Legacy
 */
if (!class_exists('Simba_Subscriptions_WC_Legacy_9')) {

	class Simba_Subscriptions_WC_Legacy_9 {


		/**
		 * Get order id
		 * WC 3.0
		 *
		 * @access public
		 * @param object $order
		 * @return int
		 */
		public static function order_get_id($order) {
			return $order->get_id();
		}

		/**
		 * Get order billing first name
		 * WC 3.0
		 *
		 * @access public
		 * @param object $order
		 * @return string
		 */
		public static function order_get_billing_first_name($order) {
			return $order->get_billing_first_name();
		}

		/**
		 * Get order billing last name
		 * WC 3.0
		 *
		 * @access public
		 * @param object $order
		 * @return string
		 */
		public static function order_get_billing_last_name($order) {
			return $order->get_billing_last_name();
		}

		/**
		 * Get order billing company
		 * WC 3.0
		 *
		 * @access public
		 * @param object $order
		 * @return string
		 */
		public static function order_get_billing_company($order) {
			return $order->get_billing_company();
		}

		/**
		 * Get order billing address 1
		 * WC 3.0
		 *
		 * @access public
		 * @param object $order
		 * @return string
		 */
		public static function order_get_billing_address_1($order) {
			return $order->get_billing_address_1();
		}

		/**
		 * Get order billing address 2
		 * WC 3.0
		 *
		 * @access public
		 * @param object $order
		 * @return string
		 */
		public static function order_get_billing_address_2($order) {
			return $order->get_billing_address_2();
		}

		/**
		 * Get order billing city
		 * WC 3.0
		 *
		 * @access public
		 * @param object $order
		 * @return string
		 */
		public static function order_get_billing_city($order) {
			return $order->get_billing_city();
		}

		/**
		 * Get order billing state
		 * WC 3.0
		 *
		 * @access public
		 * @param object $order
		 * @return string
		 */
		public static function order_get_billing_state($order) {
			return $order->get_billing_state();
		}

		/**
		 * Get order billing postcode
		 * WC 3.0
		 *
		 * @access public
		 * @param object $order
		 * @return string
		 */
		public static function order_get_billing_postcode($order) {
			return $order->get_billing_postcode();
		}

		/**
		 * Get order billing country
		 * WC 3.0
		 *
		 * @access public
		 * @param object $order
		 * @return string
		 */
		public static function order_get_billing_country($order) {
			return $order->get_billing_country();
		}

		/**
		 * Get order shipping first name
		 * WC 3.0
		 *
		 * @access public
		 * @param object $order
		 * @return string
		 */
		public static function order_get_shipping_first_name($order) {
			return $order->get_shipping_first_name();
		}

		/**
		 * Get order shipping last name
		 * WC 3.0
		 *
		 * @access public
		 * @param object $order
		 * @return string
		 */
		public static function order_get_shipping_last_name($order) {
			return $order->get_shipping_last_name();
		}

		/**
		 * Get order shipping company
		 * WC 3.0
		 *
		 * @access public
		 * @param object $order
		 * @return string
		 */
		public static function order_get_shipping_company($order) {
			return $order->get_shipping_company();
		}

		/**
		 * Get order shipping address 1
		 * WC 3.0
		 *
		 * @access public
		 * @param object $order
		 * @return string
		 */
		public static function order_get_shipping_address_1($order) {
			return $order->get_shipping_address_1();
		}

		/**
		 * Get order shipping address 2
		 * WC 3.0
		 *
		 * @access public
		 * @param object $order
		 * @return string
		 */
		public static function order_get_shipping_address_2($order) {
			return $order->get_shipping_address_2();
		}

		/**
		 * Get order shipping city
		 * WC 3.0
		 *
		 * @access public
		 * @param object $order
		 * @return string
		 */
		public static function order_get_shipping_city($order) {
			return $order->get_shipping_city();
		}

		/**
		 * Get order shipping state
		 * WC 3.0
		 *
		 * @access public
		 * @param object $order
		 * @return string
		 */
		public static function order_get_shipping_state($order) {
			return $order->get_shipping_state();
		}

		/**
		 * Get order shipping postcode
		 * WC 3.0
		 *
		 * @access public
		 * @param object $order
		 * @return string
		 */
		public static function order_get_shipping_postcode($order) {
			return $order->get_shipping_postcode();
		}

		/**
		 * Get order shipping country
		 * WC 3.0
		 *
		 * @access public
		 * @param object $order
		 * @return string
		 */
		public static function order_get_shipping_country($order) {
			return $order->get_shipping_country();
		}

		/**
		 * Get order billing phone
		 * WC 3.0
		 *
		 * @access public
		 * @param object $order
		 * @return string
		 */
		public static function order_get_billing_phone($order) {
			return $order->get_billing_phone();
		}

		/**
		 * Get order billing email
		 * WC 3.0
		 *
		 * @access public
		 * @param object $order
		 * @return string
		 */
		public static function order_get_billing_email($order) {
			return $order->get_billing_email();
		}

		/**
		 * Get order payment method
		 * WC 3.0
		 *
		 * @access public
		 * @param object $order
		 * @return string
		 */
		public static function order_get_payment_method($order) {
			return $order->get_payment_method();
		}

		/**
		 * Get order payment method title
		 * WC 3.0
		 *
		 * @access public
		 * @param object $order
		 * @return string
		 */
		public static function order_get_payment_method_title($order) {
			return $order->get_payment_method_title();
		}

		/**
		 * Get order customer note
		 * WC 3.0
		 *
		 * @access public
		 * @param object $order
		 * @return string
		 */
		public static function order_get_customer_note($order) {
			return $order->get_customer_note();
		}

		/**
		 * Get order customer id
		 * WC 3.0
		 *
		 * @access public
		 * @param object $order
		 * @return int
		 */
		public static function order_get_customer_id($order) {
			return $order->get_customer_id();
		}

		/**
		 * Get order customer ip address
		 * WC 3.0
		 *
		 * @access public
		 * @param object $order
		 * @return int
		 */
		public static function order_get_customer_ip_address($order) {
			return $order->get_customer_ip_address();
		}

		/**
		 * Get order customer user agent
		 * WC 3.0
		 *
		 * @access public
		 * @param object $order
		 * @return int
		 */
		public static function order_get_customer_user_agent($order) {
			return $order->get_customer_user_agent();
		}

		/**
		 * Get order prices include tax
		 * WC 3.0
		 *
		 * @access public
		 * @param object $order
		 * @return float
		 */
		public static function order_get_prices_include_tax($order) {
			return $order->get_prices_include_tax();
		}

		/**
		 * Get order total
		 * WC 3.0
		 *
		 * @access public
		 * @param object $order
		 * @return float
		 */
		public static function order_get_total($order) {
			return $order->get_total();
		}

		/**
		 * Get order total discount
		 * WC 3.0
		 *
		 * @access public
		 * @param object $order
		 * @return float
		 */
		public static function order_get_total_discount($order) {
			return $order->get_total_discount();
		}

		/**
		 * Get order discount tax
		 * WC 3.0
		 *
		 * @access public
		 * @param object $order
		 * @return float
		 */
		public static function order_get_discount_tax($order) {
			return $order->get_discount_tax();
		}

		/**
		 * Get order cart tax
		 * WC 3.0
		 *
		 * @access public
		 * @param object $order
		 * @return float
		 */
		public static function order_get_cart_tax($order) {
			return $order->get_cart_tax();
		}

		/**
		 * Get formatted order date created
		 * WC 3.0
		 *
		 * @access public
		 * @param object $order
		 * @param string $format
		 * @return string
		 */
		public static function order_get_formatted_date_created($order, $format = null) {
			$format = (null !== $format ? $format : wc_date_format());
			return wc_format_datetime($order->get_date_created(), $format);
		}

		/**
		 * Get order date created
		 * WC 3.0
		 *
		 * Note: this method returns order date in "Y-m-d H:i:s" format
		 *
		 * @access public
		 * @param object $order
		 * @return string
		 */
		public static function order_get_date_created($order) {
			return gmdate('Y-m-d H:i:s', $order->get_date_created()->getOffsetTimestamp());
		}

		/**
		 * Get order status
		 * WC 3.0
		 *
		 * @access public
		 * @param object $order
		 * @return string
		 */
		public static function order_get_status($order) {
			return $order->get_status();
		}

		/**
		 * Reduce stock levels
		 * WC 3.0
		 *
		 * @access public
		 * @param object $order
		 * @return void
		 */
		public static function order_reduce_stock_levels($order) {
			wc_reduce_stock_levels(Simba_Subscriptions_WC_Legacy::order_get_id($order));
		}

		/**
		 * Get order shipping total
		 * WC 3.0
		 *
		 * @access public
		 * @param object $order
		 * @return float
		 */
		public static function order_get_shipping_total($order) {
			return $order->get_shipping_total();
		}

		/**
		 * Get order item product id
		 * WC 3.0
		 *
		 * @access public
		 * @param mixed $order_item
		 * @return int
		 */
		public static function order_item_get_product_id($order_item) {
			return $order_item->get_product_id();
		}

		/**
		 * Get order item variation id
		 * WC 3.0
		 *
		 * @access public
		 * @param mixed $order_item
		 * @return int
		 */
		public static function order_item_get_variation_id($order_item) {
			return $order_item->get_variation_id();
		}

		/**
		 * Get order item quantity
		 * WC 3.0
		 *
		 * @access public
		 * @param mixed $order_item
		 * @return int
		 */
		public static function order_item_get_quantity($order_item) {
			return $order_item->get_quantity();
		}

		/**
		 * Get order item name
		 * WC 3.0
		 *
		 * @access public
		 * @param mixed $order_item
		 * @return int
		 */
		public static function order_item_get_name($order_item) {
			return $order_item->get_name();
		}

		/**
		 * Get order item tax name
		 * WC 3.0
		 *
		 * @access public
		 * @param mixed $order_item
		 * @return int
		 */
		public static function order_item_tax_get_name($order_item) {
			return $order_item->get_name();
		}

		/**
		 * Get order item tax label
		 * WC 3.0
		 *
		 * @access public
		 * @param mixed $order_item
		 * @return int
		 */
		public static function order_item_tax_get_label($order_item) {
			return $order_item->get_label();
		}

		/**
		 * Get order item tax rate id
		 * WC 3.0
		 *
		 * @access public
		 * @param mixed $order_item
		 * @return int
		 */
		public static function order_item_tax_get_rate_id($order_item) {
			return $order_item->get_rate_id();
		}

		/**
		 * Get order item tax get tax total
		 * WC 3.0
		 *
		 * @access public
		 * @param mixed $order_item
		 * @return int
		 */
		public static function order_item_tax_get_tax_total($order_item) {
			return $order_item->get_tax_total();
		}

		/**
		 * Get order item tax get shipping tax total
		 * WC 3.0
		 *
		 * @access public
		 * @param mixed $order_item
		 * @return int
		 */
		public static function order_item_tax_get_shipping_tax_total($order_item) {
			return $order_item->get_shipping_tax_total();
		}

		/**
		 * Get order item subtotal
		 * WC 3.0
		 *
		 * @access public
		 * @param mixed $order_item
		 * @return int
		 */
		public static function order_item_get_subtotal($order_item) {
			return $order_item->get_subtotal();
		}

		/**
		 * Get order item subtotal tax
		 * WC 3.0
		 *
		 * @access public
		 * @param mixed $order_item
		 * @return int
		 */
		public static function order_item_get_subtotal_tax($order_item) {
			return $order_item->get_subtotal_tax();
		}

		/**
		 * Get order item total
		 * WC 3.0
		 *
		 * @access public
		 * @param mixed $order_item
		 * @return int
		 */
		public static function order_item_get_total($order_item) {
			return $order_item->get_total();
		}

		/**
		 * Get order item total tax
		 * WC 3.0
		 *
		 * @access public
		 * @param mixed $order_item
		 * @return int
		 */
		public static function order_item_get_total_tax($order_item) {
			return $order_item->get_total_tax();
		}

		/**
		 * Get order item tax class
		 * WC 3.0
		 *
		 * @access public
		 * @param mixed $order_item
		 * @return int
		 */
		public static function order_item_get_tax_class($order_item) {
			return $order_item->get_tax_class();
		}

		/**
		 * Get product from order item
		 * WC 3.0
		 *
		 * @access public
		 * @param object $order_item
		 * @param object $order
		 * @return object
		 */
		public static function order_item_get_product($order_item, $order = null) {// phpcs:ignore VariableAnalysis.CodeAnalysis.VariableAnalysis.UnusedVariable
			return $order_item->get_product();
		}

		/**
		 * Check if order meta exists
		 * WC 3.0
		 *
		 * @access public
		 * @param object $order
		 * @param string $key
		 * @return bool
		 */
		public static function order_meta_exists($order, $key) {
			return $order->meta_exists($key);
		}

		/**
		 * Add order meta data
		 * WC 3.0
		 *
		 * @access public
		 * @param object $order
		 * @param string $key
		 * @param mixed  $value
		 * @param bool   $unique
		 * @return void
		 */
		public static function order_add_meta_data($order, $key, $value, $unique = false) {
			$order->add_meta_data($key, $value, $unique);
			$order->save();
		}

		/**
		 * Update order meta data
		 * WC 3.0
		 *
		 * @access public
		 * @param object $order
		 * @param string $key
		 * @param mixed  $value
		 * @param int    $meta_id
		 * @return void
		 */
		public static function order_update_meta_data($order, $key, $value, $meta_id = '') {
			$order->update_meta_data($key, $value, $meta_id);
			$order->save();
		}

		/**
		 * Delete order meta data
		 * WC 3.0
		 *
		 * Note: this does not support deleting meta data by value from a set of meta values with the same key
		 *
		 * @access public
		 * @param object $order
		 * @param string $key
		 * @return void
		 */
		public static function order_delete_meta_data($order, $key) {
			$order->delete_meta_data($key);
			$order->save();
		}

		/**
		 * Get product id
		 * WC 3.0
		 *
		 * @access public
		 * @param object $product
		 * @return int
		 */
		public static function product_get_id($product) {
			return $product->get_id();
		}

		/**
		 * Get product variation parent id
		 * WC 3.0
		 *
		 * @access public
		 * @param object $product_variation
		 * @return int
		 */
		public static function product_variation_get_parent_id($product_variation) {
			return $product_variation->get_parent_id();
		}

		/**
		 * Get product variation parent
		 * WC 3.0
		 *
		 * @access public
		 * @param object $product_variation
		 * @return object
		 */
		public static function product_variation_get_parent($product_variation) {
			return wc_get_product($product_variation->get_parent_id());
		}

		/**
		 * Get product type
		 * WC 3.0
		 *
		 * @access public
		 * @param object $product
		 * @return string
		 */
		public static function product_get_type($product) {
			return $product->get_type();
		}

		/**
		 * Get product price
		 * WC 3.0
		 *
		 * @access public
		 * @param object $product
		 * @return float
		 */
		public static function product_get_price($product) {
			return $product->get_price();
		}

		/**
		 * Get product regular price
		 * WC 3.0
		 *
		 * @access public
		 * @param object $product
		 * @return float
		 */
		public static function product_get_regular_price($product) {
			return $product->get_regular_price();
		}

		/**
		 * Get product sale price
		 * WC 3.0
		 *
		 * @access public
		 * @param object $product
		 * @return float
		 */
		public static function product_get_sale_price($product) {
			return $product->get_sale_price();
		}

		/**
		 * Get product price including tax
		 * WC 3.0
		 *
		 * @access public
		 * @param object $product
		 * @param int    $quantity
		 * @param float  $price
		 * @return float
		 */
		public static function product_get_price_including_tax($product, $quantity = 1, $price = '') {
			return wc_get_price_including_tax($product, array('qty' => $quantity, 'price' => $price));
		}

		/**
		 * Get product price excluding tax
		 * WC 3.0
		 *
		 * @access public
		 * @param object $product
		 * @param int    $quantity
		 * @param float  $price
		 * @return float
		 */
		public static function product_get_price_excluding_tax($product, $quantity = 1, $price = '') {
			return wc_get_price_excluding_tax($product, array('qty' => $quantity, 'price' => $price));
		}

		/**
		 * Get product short description
		 * WC 3.0
		 *
		 * @access public
		 * @param object $product
		 * @return float
		 */
		public static function product_get_short_description($product) {
			return $product->get_short_description();
		}

		/**
		 * Set product price
		 * WC 3.0
		 *
		 * @access public
		 * @param object $product
		 * @param float  $price
		 * @return void
		 */
		public static function product_set_price($product, $price) {
			$product->set_price($price);
		}

		/**
		 * Get product meta by key
		 * WC 3.0
		 *
		 * @access public
		 * @param object $product
		 * @param string $key
		 * @param bool   $single
		 * @param string $context
		 * @return mixed
		 */
		public static function product_get_meta($product, $key, $single = true, $context = 'view') {
			return $product->get_meta($key, $single, $context);
		}

		/**
		 * Check if product meta exists
		 * WC 3.0
		 *
		 * @access public
		 * @param object $product
		 * @param string $key
		 * @return bool
		 */
		public static function product_meta_exists($product, $key) {
			return $product->meta_exists($key);
		}

		/**
		 * Add product meta data
		 * WC 3.0
		 *
		 * @access public
		 * @param object $product
		 * @param string $key
		 * @param mixed  $value
		 * @param bool   $unique
		 * @return void
		 */
		public static function product_add_meta_data($product, $key, $value, $unique = false) {
			$product->add_meta_data($key, $value, $unique);
			$product->save();
		}

		/**
		 * Update product meta data
		 * WC 3.0
		 *
		 * @access public
		 * @param object $product
		 * @param string $key
		 * @param mixed  $value
		 * @param int    $meta_id
		 * @return void
		 */
		public static function product_update_meta_data($product, $key, $value, $meta_id = '') {
			$product->update_meta_data($key, $value, $meta_id);
			$product->save();
		}

		/**
		 * Delete product meta data
		 * WC 3.0
		 *
		 * Note: this does not support deleting meta data by value from a set of meta values with the same key
		 *
		 * @access public
		 * @param object $product
		 * @param string $key
		 * @return void
		 */
		public static function product_delete_meta_data($product, $key) {
			$product->delete_meta_data($key);
			$product->save();
		}

		/**
		 * Get customer billing email
		 * WC 3.0
		 *
		 * @access public
		 * @param int $customer_id
		 * @return string
		 */
		public static function customer_get_billing_email($customer_id) {
			$customer = new WC_Customer($customer_id);
			return $customer->get_billing_email();
		}

		/**
		 * Get customer billing phone
		 * WC 3.0
		 *
		 * @access public
		 * @param int $customer_id
		 * @return string
		 */
		public static function customer_get_billing_phone($customer_id) {
			$customer = new WC_Customer($customer_id);
			return $customer->get_billing_phone();
		}

		/**
		 * Get customer meta by key
		 * WC 3.0
		 *
		 * @access public
		 * @param int    $customer_id
		 * @param string $key
		 * @param bool   $single
		 * @param string $context
		 * @return mixed
		 */
		public static function customer_get_meta($customer_id, $key, $single = true, $context = 'view') {
			$customer = new WC_Customer($customer_id);
			return $customer->get_meta($key, $single, $context);
		}

		/**
		 * Check if customer meta exists
		 * WC 3.0
		 *
		 * @access public
		 * @param int    $customer_id
		 * @param string $key
		 * @return bool
		 */
		public static function customer_meta_exists($customer_id, $key) {
			$customer = new WC_Customer($customer_id);
			return $customer->meta_exists($key);
		}

		/**
		 * Add customer meta data
		 * WC 3.0
		 *
		 * @access public
		 * @param int    $customer_id
		 * @param string $key
		 * @param mixed  $value
		 * @param bool   $unique
		 * @return void
		 */
		public static function customer_add_meta_data($customer_id, $key, $value, $unique = false) {
			$customer = new WC_Customer($customer_id);
			$customer->add_meta_data($key, $value, $unique);
			$customer->save();
		}

		/**
		 * Update customer meta data
		 * WC 3.0
		 *
		 * @access public
		 * @param int    $customer_id
		 * @param string $key
		 * @param mixed  $value
		 * @param int    $meta_id
		 * @return void
		 */
		public static function customer_update_meta_data($customer_id, $key, $value, $meta_id = '') {
			$customer = new WC_Customer($customer_id);
			$customer->update_meta_data($key, $value, $meta_id);
			$customer->save();
		}

		/**
		 * Delete customer meta data
		 * WC 3.0
		 *
		 * Note: this does not support deleting meta data by value from a set of meta values with the same key
		 *
		 * @access public
		 * @param int    $customer_id
		 * @param string $key
		 * @return void
		 */
		public static function customer_delete_meta_data($customer_id, $key) {
			$customer = new WC_Customer($customer_id);
			$customer->delete_meta_data($key);
			$customer->save();
		}

		/**
		 * Get email order items table for display in templates
		 * WC 2.5, WC 3.0
		 *
		 * @access public
		 * @param object $order
		 * @param array  $args
		 * @return string
		 */
		public static function get_email_order_items($order, $args = array()) {
			return wc_get_email_order_items($order, $args);
		}

		/**
		 * Display item meta
		 * WC 3.0
		 *
		 * @access public
		 * @param mixed  $item
		 * @param object $product
		 * @param bool   $flat
		 * @param bool   $return
		 * @param array  $args
		 * @return mixed
		 */
		public static function wc_display_item_meta($item, $product = null, $flat = false, $return = false, $args = array()) {
			// Flat config
			if ($flat) {
				$args = array_merge($args, array(
					'before'    => '',
					'separator' => ', ',
					'after'     => '',
					'autop'     => false,
				));
			}

			// Return vs print flag
			$args['echo'] = !$return;

			// Get display meta and strip tags
			return strip_tags(wc_display_item_meta($item, $args));
		}

		/**
		 * Get shipping method title
		 *
		 * @access public
		 * @param object $shipping_method
		 * @return string
		 */
		public static function shipping_method_get_method_title($shipping_method) {
			return $shipping_method->get_method_title();
		}

		/**
		 * Get WooCommerce shipping zone id
		 *
		 * @access public
		 * @param object $shipping_zone
		 * @return int
		 */
		public static function shipping_zone_get_id($shipping_zone) {
			return $shipping_zone->get_id();
		}

		/**
		 * Display order item downloads
		 *
		 * @access public
		 * @param mixed  $item
		 * @param object $order
		 * @return void
		 */
		public static function display_item_downloads($item, $order = null) {// phpcs:ignore VariableAnalysis.CodeAnalysis.VariableAnalysis.UnusedVariable
			wc_display_item_downloads($item);
		}
	}
}
