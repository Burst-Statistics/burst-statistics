<?php
/**
 * Exit if accessed directly
 */
if (!defined('ABSPATH')) {
	exit;
}

/**
 * Methods related to WooCommerce Orders
 *
 * @class Simba_Subscriptions_Stripe_Order
 * @package Simba_Subscriptions
 */
if (!class_exists('Simba_Subscriptions_Stripe_Order')) {

	class Simba_Subscriptions_Stripe_Order {


		/**
		 * Constructor class
		 *
		 * @access public
		 * @param mixed $id
		 * @return void
		 */
		public function __construct($id = null) {// phpcs:ignore VariableAnalysis.CodeAnalysis.VariableAnalysis.UnusedVariable
			// Capture authorized payments
			add_action('woocommerce_order_status_processing', array($this, 'capture'));
			add_action('woocommerce_order_status_completed', array($this, 'capture'));
		}

		/**
		 * Capture previously authorized payment
		 *
		 * @access public
		 * @param int $order_id
		 * @return void
		 */
		public function capture($order_id) {
			$order = wc_get_order($order_id);

			if (!$order) {
				return;
			}

			// Authorized and not yet charged?
			if (Simba_Subscriptions_WC_Legacy::order_get_payment_method($order) == 'subscriben_stripe' && 'no' === $order->get_meta('_subscriben_stripe_charge_captured')) {

				// Get charge id
				$charge_id = $order->get_meta('_subscriben_stripe_charge_id');

				if (empty($charge_id)) {
					return;
				}

				// Load payment gateway object to access its methods
				$gateway = new Simba_Subscriptions_Stripe_Gateway();

				// Send request to capture payment
				$response = $gateway->send_request('charges', 'capture', array(
					'id'        => $charge_id,
					'amount'    => Simba_Subscriptions_WC_Legacy::order_get_total($order) * Simba_Subscriptions_Stripe_Gateway::get_currency_multiplier($order),
				));

				// Request failed?
				if (!is_object($response)) {
					$order->add_order_note(__('Failed capturing previously authorized Stripe payment.', 'subscriben-stripe') . ' ' . $response);
					return;
				}

				// Received error from Stripe?
				if (!empty($response->error)) {
					$order->add_order_note(__('Failed capturing previously authorized Stripe payment.', 'subscriben-stripe') . ' ' . $response->error->message);
					return;
				}

				// Everything seems to be ok, let's mark order as paid
				$order->add_order_note(sprintf(__('Stripe charge %s captured.', 'subscriben-stripe'), $response->id));
				Simba_Subscriptions_WC_Legacy::order_update_meta_data($order, '_subscriben_stripe_charge_captured', 'yes');
			}
		}

	}

	new Simba_Subscriptions_Stripe_Order();
}
