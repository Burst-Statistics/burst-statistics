<?php

if (!defined('ABSPATH')) die('No direct access.');

/**
 * WC Order related methods (mostly hooks like "do something when new order is placed")
 *
 * @class Simba_Subscriptions_Order_Handler
 * @package Simba_Subscriptions
 */
if (!class_exists('Simba_Subscriptions_Order_Handler')) {

	class Simba_Subscriptions_Order_Handler {
		
		private $renewal_orders = array();
		
		private $temp_shipping_chosen_method = null;

		/**
		 * Class constructor
		 *
		 * @return void
		 */
		public function __construct() {
			// Temporary store renewal order properties
			$this->renewal_orders = array(
				'by_cart_item_key'  => array(),
				'by_line_item_id'   => array(),
			);

			// Calculate renewal taxes etc
			add_filter('woocommerce_create_order', array($this, 'woocommerce_create_order'));
			add_filter('woocommerce_checkout_create_order_line_item_object', array($this, 'checkout_block_create_order'),10,4); // using Checkout Block
			
			// Move renewal order properties from by_cart_item_key to by_line_item_id
			add_action('woocommerce_checkout_create_order_line_item', array($this, 'move_renewal_order_properties'), 10, 4);

			// Create new subscription if order contains subscription products
			add_action('woocommerce_checkout_update_order_meta', array($this, 'new_order_placed'), 99, 1);
			add_action('woocommerce_store_api_checkout_order_processed', array($this, 'checkout_block_new_order_placed'), 99, 1); // using Checkout Block
			
			// Sync subscriptions with order customer (guest users)
			add_action('woocommerce_store_api_checkout_order_processed', array($this, 'sync_order_customer_with_subscriptions'), 100, 1 ); // using Checkout Block

			// Activate subscription or renew existing subscription
			add_action('woocommerce_payment_complete', array($this, 'payment_received'));
			add_action('woocommerce_order_status_processing', array($this, 'payment_received_status'));
			add_action('woocommerce_order_status_completed', array($this, 'payment_received_status'));

			// Cancel subscription, unschedule order & payment if order is cancelled
			add_action('woocommerce_order_status_cancelled', array($this, 'order_cancelled'));
			
			// Cancel subscription if order is refunded
			add_action('woocommerce_order_refunded', array($this, 'order_refunded_then_cancel_subscription'), 10, 1);

			// Cancel subscription if initial order gets refunded and there's another still unpaid
			add_filter('woocommerce_order_status_refunded', array($this, 'order_refunded_maybe_cancel_subscription'));

			// Prevent WooCommerce from cancelling unpaid renewal orders prematurely
			add_filter('woocommerce_cancel_unpaid_order', array($this, 'cancel_unpaid_order'), 10, 2);

			// Handling product downloads
			add_filter('woocommerce_get_item_downloads', array($this, 'filter_download_links'), 10, 1);
			add_filter('woocommerce_customer_get_downloadable_products', array($this, 'filter_downloadable_products'));
			add_action('woocommerce_download_product', array($this, 'maybe_prevent_file_download'), 10, 6);
			
			// Add subscription link and other orders associated with the subscription in order note when subscription renew order created.
			add_action('subscriben_created_renewal_order', array($this, 'add_subscription_link_other_associate_orders_in_order_note'), 10, 2);
			
			// Handle renewal order attribution source
			add_action('subscriben_creating_renewal_order', array($this,'update_renewal_order_attribution_source'), 10, 2);
			add_action('wc_order_attribution_origin_formatted_source', array($this, 'modify_renewal_order_attribution_formatted_source'), 10, 2);
			add_action('wc_order_attribution_origin_label', array($this, 'modify_renewal_order_attribution_label'), 10, 4);
		}

		/**
		 * New order is being created via checkout (this hook if not used elsewhere)
		 *
		 * @access public
		 * @param int $order_id
		 * @return int
		 */
		public function woocommerce_create_order($order_id) {
			// No parameters; the information is in the cart
			$this->new_order();
			return $order_id;
		}
		
		/**
		 * New order is being created via checkout block
		 *
		 * @access public
		 * @param WC_Order_Item_Product $item
		 * @param string $cart_item_key
		 * @param array $values
		 * @param WC_Order $order
		 *
		 * @return WC_Order_Item_Product
		 */
		public function checkout_block_create_order( $item, $cart_item_key, $values, $order ) {
			$this->new_order();
			return $item;
		}
		
		/**
		 * New order is being placed via checkout block
		 *
		 * @access public
		 * @param WC_Order $order
		 *
		 * @return void
		 */
		public function checkout_block_new_order_placed( $order ) {
			if ( ! $order instanceof \WC_Order ) {
				return;
			}
			
			$this->new_order_placed( $order->get_id() );
		}

		/**
		 * At the checkout, prepare recurring amounts, taxes etc for subscription items
		 *
		 * Ultimately, this method adds items to $this->renewal_orders['by_cart_item_key']
		 *
		 * On WC < 3.0, this was called by both of the actions below. They are still present in WC 3.5, but Simba_Subscriptions was not hooking them, but instead the woocommerce_create_order filter (which is called by WC_Checkout::create_order(), which is an opportunity to pre-create the order) is used (indirectly, i.e. via another method, which doesn't actually filter anything).
		 * add_action('woocommerce_new_order', array($this, 'new_order'));
		 * add_action('woocommerce_resume_order', array($this, 'new_order'));
		 *
		 * There are no parameters; the input data is fetched from $woocommerce->cart->cart_contents and from $_POST
		 *
		 * @return void
		 */
		private function new_order() {
			$woocommerce = WC();

			// Check if need to create one subscription for all products
			$multiproduct_subscription = (Simba_Subscriptions::multiproduct_mode() && self::multiproduct_cart_check()) ? true : false;

			// Maybe create new cart and renewal order here...
			if ($multiproduct_subscription) {

				$renewal_cart = new WC_Cart();

				$renewal_order = array(
					'taxes'     => array(),
					'shipping'  => array(),
				);
			}

			// Set item counter for correct taxes adding for multiproduct subscription
			$itemcount = 0;

			// Iterate over real cart and work with subscription products (if any)
			foreach ($woocommerce->cart->cart_contents as $cart_item_key => $cart_item) {

				$itemcount++;
				$id = !empty($cart_item['variation_id']) ? $cart_item['variation_id'] : $cart_item['product_id'];

				if (Simba_Subscriptions_Subscription_Product::is_subscription($id)) {

					// Get the cart item key of first subscription product in cart
					if (!isset($cart_item_key_first)) {// phpcs:ignore VariableAnalysis.CodeAnalysis.VariableAnalysis.UnusedVariable, VariableAnalysis.CodeAnalysis.VariableAnalysis.UndefinedVariable
						$cart_item_key_first = $cart_item_key;
					}

					$product = wc_get_product($id);

					// ... or create them here
					if (!$multiproduct_subscription) {

						// Store all required renewal order fields here
						$renewal_order = array(
							'taxes'     => array(),
							'shipping'  => array(),
						);

						// Create fake cart to mimic renewal order
						$renewal_cart = new WC_Cart();
					}

					// Add product to cart
					$renewal_cart_item_key = $renewal_cart->add_to_cart(
						$cart_item['product_id'],
						$cart_item['quantity'],
						(isset($cart_item['variation_id']) ? $cart_item['variation_id'] : ''),
						(isset($cart_item['variation']) ? $cart_item['variation'] : '')
					);

					// Make sure recurring price is set to regular price in case sale price (and similar programmatic price adjustments) are only applicable to initial orders
					if (Simba_Subscriptions::option('sale_price_handling') === 'initial_order') {
						Simba_Subscriptions_WC_Legacy::product_set_price($renewal_cart->cart_contents[$renewal_cart_item_key]['data'], Simba_Subscriptions_WC_Legacy::product_get_regular_price($renewal_cart->cart_contents[$renewal_cart_item_key]['data']));
					} elseif (($free_trial = Simba_Subscriptions_WC_Legacy::product_get_meta($product, '_subscriben_free_trial_time_value', true)) && is_numeric($free_trial)) {// Also use regular/sale price in case of free trial. Note: Currently this does not support 3rd party price modifications
						if (Simba_Subscriptions::option('sale_price_handling') === 'all_orders' && Simba_Subscriptions_WC_Legacy::product_get_sale_price($renewal_cart->cart_contents[$renewal_cart_item_key]['data'])) {
							Simba_Subscriptions_WC_Legacy::product_set_price($renewal_cart->cart_contents[$renewal_cart_item_key]['data'], Simba_Subscriptions_WC_Legacy::product_get_sale_price($renewal_cart->cart_contents[$renewal_cart_item_key]['data']));
						} else {
							Simba_Subscriptions_WC_Legacy::product_set_price($renewal_cart->cart_contents[$renewal_cart_item_key]['data'], Simba_Subscriptions_WC_Legacy::product_get_regular_price($renewal_cart->cart_contents[$renewal_cart_item_key]['data']));
						}
					} elseif (($signup_fee = Simba_Subscriptions::get_signup_fee_from_product($product, true)) && is_numeric($signup_fee)) {// Use adjusted price but subtract any signup fee
						Simba_Subscriptions_WC_Legacy::product_set_price($renewal_cart->cart_contents[$renewal_cart_item_key]['data'], (Simba_Subscriptions_WC_Legacy::product_get_price($cart_item['data']) - $signup_fee));
					} else {// Otherwise just use price from the original cart to allow sale price and similar price adjustments
						Simba_Subscriptions_WC_Legacy::product_set_price($renewal_cart->cart_contents[$renewal_cart_item_key]['data'], Simba_Subscriptions_WC_Legacy::product_get_price($cart_item['data']));
					}

					// Get fake cart item key
					$renewal_cart_item_keys = array_keys($renewal_cart->cart_contents);

					// Set renewal price(s) and everything else
					foreach ($renewal_cart_item_keys as $renewal_cart_item_key) {

						// Add shipping
						if ($product->needs_shipping() && $renewal_cart->needs_shipping()) {

							// Get instance of checkout object to retrieve shipping options
							$wc_checkout = WC_Checkout::instance();

							// Iterate over shipping packages
							foreach ($woocommerce->shipping->get_packages() as $package_key => $package) {

								// Check if this rate was selected
								if (!isset($package['rates'][$wc_checkout->shipping_methods[$package_key]])) continue;

								// Check if it contains current subscription
								if (!isset($package['contents'][$cart_item_key]) && !isset($package['contents'][$renewal_cart_item_key])) continue;

								// Save shipping details for further calculation
								$shipping_details = array(
									'shipping_method'   => $wc_checkout->shipping_methods[$package_key],
									'destination'       => $package['destination'],
								);

								// On WC 3.0+, accessing WC_Cart->posted gives "WC_Checkout->posted was called incorrectly. Use $_POST directly. ... This message was added in version 3.0.0." Nevertheless, from WC 3.1+, the public method get_posted_data() exists. So, on WC 3.0, there will be a deprecation notice, but not afterwards
								$posted_data = is_callable(array($wc_checkout, 'get_posted_data')) ? $wc_checkout->get_posted_data() : $wc_checkout->posted;
								
								// Save shipping address
								$renewal_order['shipping_address'] = array(
									// First three lines may need to be changed to make this compatible with shipping extensions that allow multiple shipping addresses
									'_shipping_first_name'  => $posted_data['ship_to_different_address'] ? $posted_data['shipping_first_name'] : $posted_data['billing_first_name'],
									'_shipping_last_name'   => $posted_data['ship_to_different_address'] ? $posted_data['shipping_last_name'] : $posted_data['billing_last_name'],
									'_shipping_company'     => ($posted_data['ship_to_different_address'] && !empty($posted_data['shipping_company'])) ? $posted_data['shipping_company'] : ($posted_data['billing_company'] ?? ''),
									'_shipping_address_1'   => $shipping_details['destination']['address'],
									'_shipping_address_2'   => $shipping_details['destination']['address_2'],
									'_shipping_city'        => $shipping_details['destination']['city'],
									'_shipping_state'       => $shipping_details['destination']['state'],
									'_shipping_postcode'    => $shipping_details['destination']['postcode'],
									'_shipping_country'     => $shipping_details['destination']['country'],
								);

								break;
							}

							// Got the shipping method and address for the package that contains current subscription?
							if (!isset($shipping_details)) continue;

							// Get packages based on renewal order details
							$packages = apply_filters('woocommerce_cart_shipping_packages', array(
								0 => array(
									'contents'          => $renewal_cart->get_cart(),
									'contents_cost'     => isset($renewal_cart->cart_contents[$renewal_cart_item_key]['line_total']) ? $renewal_cart->cart_contents[$renewal_cart_item_key]['line_total'] : 0,
									'applied_coupons'   => $renewal_cart->applied_coupons,
									'destination'       => $shipping_details['destination'],
								),
							));

							// Now we need to calculate shipping costs but this requires overwriting session variables
							// In order not to affect real cart, we will overwrite them but then set them back to original values
							$original_session = array(
								'chosen_shipping_methods'   => $woocommerce->session->get('chosen_shipping_methods'),
								'shipping_method_counts'    => $woocommerce->session->get('shipping_method_counts'),
							);

							// Set fake renewal values
							$woocommerce->session->set('chosen_shipping_methods', array($shipping_details['shipping_method']));
							$woocommerce->session->set('shipping_method_counts', array(1));

							// Override chosen shipping method in case there's a mismatch in shipping_method_counts (more than one available)
							add_filter('woocommerce_shipping_chosen_method', array($this, 'set_shipping_chosen_method'));
							$this->temp_shipping_chosen_method = $shipping_details['shipping_method'];

							// Calculate shipping for fake renewal order now
							$woocommerce->shipping->calculate_shipping($packages);

							// Remove filter
							remove_filter('woocommerce_shipping_chosen_method', array($this, 'set_shipping_chosen_method'));
							$this->temp_shipping_chosen_method = null;
						}

						// Recalculate totals
						$renewal_cart->calculate_totals();

						// Get renewal_order_shipping
						$renewal_order['renewal_order_shipping'] = wc_format_decimal($renewal_cart->shipping_total);

						// Get renewal_order_shipping_tax
						$renewal_order['renewal_order_shipping_tax'] = wc_format_decimal($renewal_cart->shipping_tax_total);

						// Get renewal_cart_discount
						$renewal_order['renewal_cart_discount'] = wc_format_decimal($renewal_cart->get_cart_discount_total());

						// Get renewal_order_discount
						$renewal_order['renewal_order_discount'] = wc_format_decimal($renewal_cart->get_total_discount());

						// Get renewal_order_tax
						$renewal_order['renewal_order_tax'] = wc_format_decimal($renewal_cart->tax_total);

						// Get renewal_order_subtotal
						$renewal_order['renewal_order_subtotal'] = wc_format_decimal($renewal_cart->subtotal, get_option('woocommerce_price_num_decimals'));

						// Get renewal_order_total
						$renewal_order['renewal_order_total'] = wc_format_decimal($renewal_cart->total, get_option('woocommerce_price_num_decimals'));

						// Differently add lines totals
						$lines_total = array('line_subtotal', 'line_subtotal_tax', 'line_total', 'line_tax');

						foreach ($lines_total as $line_key) {

							$new_value = wc_format_decimal($renewal_cart->cart_contents[$renewal_cart_item_key][$line_key]);
							$new_key = 'renewal_' . $line_key;

							if ($multiproduct_subscription) {
								$renewal_order[$new_key][$id] = $new_value;
							} else {
								$renewal_order[$new_key] = $new_value;
							}
						}
					}

					// Count the subscriptions
					$all_cart_subscriptions = array();
					foreach ($woocommerce->cart->cart_contents as $cart_item) {

						$id = !empty($cart_item['variation_id']) ? $cart_item['variation_id'] : $cart_item['product_id'];
						if (Simba_Subscriptions_Subscription_Product::is_subscription($id)) {
							$all_cart_subscriptions[] = $id;
						}
					}

					// Add taxes always for regular subscription and only on last subscription item for multiproduct
					if (!$multiproduct_subscription || $multiproduct_subscription && count($all_cart_subscriptions) == $itemcount) {

						// Add filter so that get_tax_totals() returns zero tax rates
						add_filter('woocommerce_cart_hide_zero_taxes', '__return_false');

						// WC_Cart::get_cart_contents_taxes() and get_shipping_taxes() is WC 3.2+
						$taxes = is_callable(array($renewal_cart, 'get_cart_contents_taxes')) ? $renewal_cart->get_cart_contents_taxes() : $renewal_cart->taxes;
						
						$shipping_taxes = is_callable(array($renewal_cart, 'get_shipping_taxes')) ? $renewal_cart->get_shipping_taxes() : $renewal_cart->shipping_taxes;
						
						// Iterate over tax totals
						foreach ($renewal_cart->get_tax_totals() as $rate_key => $rate) {
						
							$renewal_order['taxes'][] = array(
								'name'                  => $rate_key,
								'rate_id'               => $rate->tax_rate_id,
								'label'                 => $rate->label,
								'compound'              => absint($rate->is_compound ? 1 : 0),
								'tax_amount'            => wc_format_decimal(isset($taxes[$rate->tax_rate_id]) ? $taxes[$rate->tax_rate_id] : 0),
								'shipping_tax_amount'   => wc_format_decimal(isset($shipping_taxes[$rate->tax_rate_id]) ? $shipping_taxes[$rate->tax_rate_id] : 0),
							);
						}

						// Remove filter
						remove_filter('woocommerce_cart_hide_zero_taxes', '__return_false');
					}

					// Get shipping details
					if ($product->needs_shipping() && $renewal_cart->needs_shipping()) {

						if (isset($woocommerce->shipping->packages[0]['rates'][$shipping_details['shipping_method']])) {

							$method = $woocommerce->shipping->packages[0]['rates'][$shipping_details['shipping_method']];

							$renewal_order['shipping'] = array(
								'name'      => $method->label,
								'method_id' => $method->id,
								'cost'      => wc_format_decimal($method->cost),
							);
						}

						// Set session variables to original values and recalculate shipping for original order which is being processed now
						$woocommerce->session->set('chosen_shipping_methods', $original_session['chosen_shipping_methods']);
						$woocommerce->session->set('shipping_method_counts', $original_session['shipping_method_counts']);
						$woocommerce->shipping->calculate_shipping($packages);
					}

					// Save to object property so it can be accessed from another method
					if ($multiproduct_subscription) {
						$this->renewal_orders['by_cart_item_key'][$cart_item_key_first] = $renewal_order;
					} else {
						$this->renewal_orders['by_cart_item_key'][$cart_item_key] = $renewal_order;
					}
				}
			}
		}

		/**
		 * Overwrite chosen shipping method if needed when working with fake renewal orders
		 *
		 * @param string $method
		 * @return string
		 */
		public function set_shipping_chosen_method($method) {
			return isset($this->temp_shipping_chosen_method) ? $this->temp_shipping_chosen_method : $method;
		}

		/**
		 * Move renewal order properties so we can pick them by item id
		 * Pre WC 3.0 compatibility
		 *
		 * Called by the WP action woocommerce_checkout_create_order_line_item, which is called by WC_Checkout::create_order_line_items()
		 *
		 * @access public
		 * @param object $item
		 * @param string $cart_item_key
		 * @param array  $values
		 * @param object $order
		 * @return void
		 */
		public function move_renewal_order_properties($item, $cart_item_key, $values, $order) {// phpcs:ignore VariableAnalysis.CodeAnalysis.VariableAnalysis.UnusedVariable
			if (isset($this->renewal_orders['by_cart_item_key'][$cart_item_key])) {
				// WC31: Special temporary handling here, need to rewrite entire subscription setup logic
				$item->update_meta_data('_subscriben_renewal_order_properties', $this->renewal_orders['by_cart_item_key'][$cart_item_key]);
			}
		}

		/**
		 * Get all subscriptions from cart and return if they are compatible
		 *
		 * @access public
		 * @return array
		 */
		public static function multiproduct_cart_check() {
			$woocommerce = WC();

			$all_subs = array();

			foreach ($woocommerce->cart->cart_contents as $cart_item) {

				// Get product id
				$id = !empty($cart_item['variation_id']) ? $cart_item['variation_id'] : $cart_item['product_id'];

				// Load product object
				$product = wc_get_product($id);

				// Check if product is subscription product
				if (Simba_Subscriptions_Subscription_Product::is_subscription($product)) {
					$all_subs[$id] = array(
						'product_id'    => $cart_item['product_id'],
						'variation_id'  => (!empty($cart_item['variation_id']) ? $cart_item['variation_id'] : null),
					);
				}
			}

			return Simba_Subscriptions_Subscription::check_compatibility($all_subs);
		}
		
		/**
		 * Add subscription link and other orders associated with the subscription in order note when a new order is placed.
		 *
		 * @access public
		 * @param object $subscription
		 * @param int    $order_id
		 * @return void
		 */
		public function add_subscription_link_other_associate_orders_in_order_note($subscription, $order_id) {
			$order = wc_get_order($order_id);
			if (self::contains_subscription($order_id)) {
				
				// Iterate over subscriptions from order
				foreach (self::get_subscriptions_from_order_id($order_id) as $subscription) {
					
					// Add subscription link in order note
					$order->add_order_note(Simba_Subscriptions_Helper::get_link_to_post_html($subscription->id, sprintf(__('Subscription ID: %d', 'subscriben'), $subscription->id)), 0, false);
					
					// Add other orders associated with the subscription in order note clickable link
					$orders_associated_subscription  = array();
					foreach ($subscription->all_order_ids as $subscription_order_id) {
						if (false != wc_get_order($subscription_order_id)) {
							$orders_associated_subscription[] = Simba_Subscriptions_Helper::get_link_to_post_html($subscription_order_id);
						} else {
							$orders_associated_subscription[] = '#' . $subscription_order_id . ' (' . __('deleted', 'subscriben') . ')';
						}
					}
					if (count($orders_associated_subscription) > 0) {
						$order->add_order_note(sprintf(__('Orders associated with this subscription %d: %s', 'subscriben'), $subscription->id, implode(', ', $orders_associated_subscription)), 0, false);
					}
				}
			}
		}

		/**
		 * Handle new WooCommerce orders
		 *
		 * @access public
		 * @param int $order_id
		 * @return void
		 */
		public function new_order_placed($order_id) {
			$order = wc_get_order($order_id);
			$order_items = $order->get_items();
			$existing_subscriptions = self::get_subscriptions_from_order_id($order_id);

			// Any existing subscription(s) created for this order? This can be caused by multiple payment attempts or so
			if ($existing_subscriptions) {
				// Starting from WC 2.6 orders are resumed only if no changes were made to cart so we can just keep existing subscription(s)
				// Up to WC 2.6 orders could be resumed even when there were changes made to cart so we needed to delete existing subscription(s) and start fresh
				// Add subscription link and other orders associated with the subscription in order note
				self::add_subscription_link_other_associate_orders_in_order_note('', $order_id);
				return;
			}

			// Array for found subscription products
			$all_subs = array();

			// Iterate over all items and look for subscription products purchased
			foreach ($order_items as $order_item_key => $order_item) {

				// Get appropriate product and variation IDs
				$variation_id = Simba_Subscriptions_WC_Legacy::order_item_get_variation_id($order_item);
				$variation_id = !empty($variation_id) ? $variation_id : null;
				$product_id = Simba_Subscriptions_WC_Legacy::order_item_get_product_id($order_item);
				$id = $variation_id ? $variation_id : $product_id;

				// Load product object
				$product = wc_get_product($id);

				// Proceed only if this product is a subscription
				if (!Simba_Subscriptions_Subscription_Product::is_subscription($product)) {
					continue;
				}

				// Collect all subscription products
				$all_subs[$id] = array(
					'product_id'     => $product_id,
					'variation_id'   => $variation_id,
					'order_item_key' => $order_item_key,
					'order_item'     => $order_item,
				);
			}

			// Proceed only if there's subscriptions found
			if (!empty($all_subs)) {

				// Check if need to create one subscription for all products
				$multiproduct_subscription = (Simba_Subscriptions::multiproduct_mode() && Simba_Subscriptions_Subscription::check_compatibility($all_subs)) ? true : false;

				// Iterate over subscription products
				foreach ($all_subs as $subs_product) {

					// Set variables
					$product_id = $subs_product['product_id'];
					$variation_id = $subs_product['variation_id'];
					$order_item_key = $subs_product['order_item_key'];
					$order_item = $subs_product['order_item'];
					$product = wc_get_product((!empty($subs_product['variation_id']) ? $subs_product['variation_id'] : $subs_product['product_id']));

					// Start logging transaction
					$transaction = new Simba_Subscriptions_Transaction(null, 'new_order', null, $order_id, Simba_Subscriptions_WC_Legacy::order_item_get_product_id($order_item), $variation_id);

					// Check if this subscription product looks ok
					if (!Simba_Subscriptions_Subscription_Product::is_ok($product)) {
						$transaction->update_result('error');
						$transaction->update_note(__('Invalid subscription product configuration.', 'subscriben'));
						continue;
					}

					// Attempt to get renewal order properties
					$renewal_order_properties = (array) $order_item->get_meta('_subscriben_renewal_order_properties', true);
					$order_item->delete_meta_data('_subscriben_renewal_order_properties');

					// Check if we have renewal order properties
					if (empty($renewal_order_properties)) {
						$transaction->update_result('error');
						$transaction->update_note(__('Failed saving subscription properties for renewal orders.', 'subscriben'));
						continue;
					}

					// Everything seems to be ok, lets create a new subscription
					try {
						$subscription = new Simba_Subscriptions_Subscription();

						// Check if multiproduct subscription activated and products are compatible
						if ($multiproduct_subscription) {
							$subscription_id = $subscription->create_from_all_order_items($order, null, $all_subs, $renewal_order_properties);
						} else {// If not, create the usual subscription(s)
							$subscription_id = $subscription->create_from_order_item($order, null, $order_item_key, $order_item, $product, null, $renewal_order_properties);
						}

						$transaction->update_result('success');
						$transaction->add_subscription_id($subscription_id);
						$transaction->update_note(__('Subscription successfully created.', 'subscriben'));
					} catch (Exception $e) {
						$transaction->update_result('error');
						$transaction->update_note($e->getMessage());
					}

					// Break by the end of first iteration if this is a multiproduct subscription
					if ($multiproduct_subscription) {
						break;
					}
				}

				// Reset temporary storage
				$this->renewal_orders = array(
					'by_cart_item_key'  => array(),
					'by_line_item_id'   => array(),
				);
			}
			
			// Add subscription link and other orders associated with the subscription in order note
			self::add_subscription_link_other_associate_orders_in_order_note('', $order_id);
			
		}
		
		/**
		 * When using Checkout Block and the user is not logged in (guest user),
		 * the subscription is created before the user is created.
		 * This function is used to sync the subscriptions with the order user.
		 *
		 * @param \WC_Order $order
		 * @return void
		 */
		public function sync_order_customer_with_subscriptions( $order ) {
			if ( ! $order ) {
				return;
			}
			
			$existing_subscriptions = self::get_subscriptions_from_order_id( $order->get_id() );
			
			if ( empty( $existing_subscriptions ) || ! is_array( $existing_subscriptions ) ) {
				return;
			}
			
			$customer_id   = $order->get_customer_id();
			$customer_name = $order->get_billing_first_name() . ' ' . $order->get_billing_last_name();
			
			foreach ( $existing_subscriptions as $subscription ) {
				$details = array();
				
				if ( empty( $subscription->user_id ) && 0 !== $customer_id ) {
					$details['user_id'] = $customer_id;
				}
				
				if ( empty( $subscription->user_full_name ) && ! empty( $customer_name ) ) {
					$details['user_full_name'] = $customer_name;
				}
				
				if ( ! empty( $details ) ) {
					$subscription->update_subscription_details( $details );
				}
			}
		}

		/**
		 * Check if order has been paid
		 *
		 * @access public
		 * @param int|\WC_Order $order_or_id
		 * @return bool
		 * @throws \InvalidArgumentException If the order is invalid or not found.
		 */
		public static function order_is_paid($order_or_id) {
			// Load order if order id was passed in
			if (!is_object($order_or_id)) {
				$order_or_id = wc_get_order($order_or_id);
			}

			// Check if order exists and is a WC_Order object
			if (!$order_or_id instanceof \WC_Order) {
				throw new \InvalidArgumentException('Invalid order object or ID passed to order_is_paid().');
			}

			return $order_or_id->is_paid();
		}

		/**
		 * Automatic or manual payment received - activate or renew subscription (if this hasn't been done yet)
		 *
		 * @access public
		 * @param int  $order_id
		 * @param bool $manual
		 * @return void
		 * @throws Exception To rollback the transaction.
		 */
		public function payment_received($order_id, $manual = false) {

			// May not actually be a subscription order
			$subscriptions = self::get_subscriptions_from_order_id($order_id);
			if (empty($subscriptions)) return;
			
			wc_transaction_query('start');
			
			try {

				// Iterate over subscriptions and activate or renew
				foreach ($subscriptions as $subscription) {

					// Make sure we don't run this multiple times on status changes
					if (!$subscription->paid_by_order($order_id)) {

						// Log the transaction
						$transaction = new Simba_Subscriptions_Transaction(null, 'payment_received', $subscription->id, $order_id, $subscription->product_id, $subscription->variation_id);

						if ($manual) {
							$transaction->update_note(__('Triggered by status change.', 'subscriben'));
						}

						// Unset any pending reminder, suspension and cancellation events (don't move this below pay_by_order!)
						Simba_Subscriptions_Event_Scheduler::unschedule_multiple(array(
							'payment',
							'reminder',
							'suspension',
							'cancellation',
						), $subscription->id);

						// Apply payment to subscription
						$subscription->pay_by_order($order_id, $transaction);

						// Clear suspended_since property if set
						if (!empty($subscription->suspended_since)) {
							$subscription->clear_subscription_details(array('suspended_since'));
						}
					}
				}

				// Commit transaction, if supported
				wc_transaction_query('commit');

			} catch (Exception $e) {

				// Rollback transaction, if supported
				wc_transaction_query('rollback');

				// Propagate exception
				throw $e;
			}

		}

		/**
		 * Activate or renew subscription after status change (if this hasn't been done yet)
		 *
		 * @access public
		 * @param int $order_id
		 * @return void
		 */
		public function payment_received_status($order_id) {
			$this->payment_received($order_id, true);
		}

		/**
		 * Create renewal order
		 * Since WC 3.0
		 *
		 * This is called via the event scheduler (create_renewal_order event); i.e. it is the creation of the renewal order X days before renewal.
		 *
		 * @access public
		 * @param object $subscription
		 *
		 * @return int
		 */
		public static function create_renewal_order($subscription) {
			return self::create_renewal_order_current($subscription);
		}

		/**
		 *
		 * This is called via the event scheduler (create_renewal_order event); i.e. it is the creation of the renewal order X days before renewal.
		 *
		 * WC 3.0+
		 *
		 * @access public
		 * @param object $subscription
		 *
		 * @return int
		 * @throws Exception To rollback the transaction.
		 */
		public static function create_renewal_order_current($subscription) {
		
			$transaction_begun = false;
			
			try {
				// Subscription renewal order currency
				$renew_order_currency = $subscription->renewal_order_currency;
				// Firstly, create the empty order object
				$order = new WC_Order();

				// Check if need to charge shipping
				$charge_shipping = (Simba_Subscriptions::option('shipping_renewal_charge') == 1) ? true : false;

				$order->set_created_via('subscriptio');
				$order->set_order_key(wc_generate_order_key());
				// $order->set_cart_hash($cart_hash);
				$order->set_customer_id($subscription->user_id);
				$order->set_currency($subscription->renewal_order_currency);
				$order->set_prices_include_tax($subscription->renewal_prices_include_tax);
				$order->set_customer_ip_address($subscription->renewal_customer_ip_address);
				$order->set_customer_user_agent($subscription->renewal_customer_user_agent);
				$order->set_customer_note(empty($subscription->renewal_customer_note) ? __('No customer note.', 'subscriben') : $subscription->renewal_customer_note);
				// The payment method and payment method title are not set because the order is not yet paid

				// Load user meta, and unwrap single-entry arrays (move one level higher)
				$user_meta = Simba_Subscriptions_Helper::unwrap_post_meta(get_user_meta($subscription->user_id));

				// N.B. It may not actually be right to update the billing address from their account. What about any implicit taxation changes? Nevertheless, we're just updating the current code for WC 3.0+ compatibility

				// Insert billing and shipping details
				$billing_shipping_fields = array(
					'billing'  => array(
						'_first_name',
						'_last_name',
						'_company',
						'_address_1',
						'_address_2',
						'_city',
						'_state',
						'_postcode',
						'_country',
						'_email',
						'_phone',
					),
				);

				// Check if subscription needs shipping
				if ($subscription->needs_shipping()) {
					$billing_shipping_fields['shipping'] = array(
						'_first_name',
						'_last_name',
						'_company',
						'_address_1',
						'_address_2',
						'_city',
						'_state',
						'_postcode',
						'_country',
					);
				}

				// Iterate over billing/shipping fields and save them
				foreach ($billing_shipping_fields as $type => $fields) {

					// $type is 'billing' or 'shipping'
					foreach ($fields as $field) {

						// Billing fields
						if ('billing' == $type && isset($user_meta[$type . $field])) {
							$field_value = $user_meta[$type . $field];
						} elseif ('shipping' == $type && isset($subscription->shipping_address['_' . $type . $field])) {// Shipping fields
							$field_value = $subscription->shipping_address['_' . $type . $field];
						} else {// In case some field does not exist
							$field_value = '';
						}

						// $order->update_meta_data('_' . $type . $field, $field_value);
						call_user_func(array($order, 'set_'.$type.$field), $field_value);
					}
				}

				// See in self::new_order() to see where the things we need are getting saved; and in Simba_Subscriptions_Subscription::create_from_order_item() (where you'll basically see that the key names are transferred without change)
				
				// $order->set_discount_total(WC()->cart->get_discount_total());
				// $order->set_discount_tax(WC()->cart->get_discount_tax());
				$order->set_discount_total(0);
				$order->set_discount_tax(0);
				
				// We find and calculate the tax rates from scratch, since the tax rate tables may have changed since the previous order.
				if (empty($subscription->taxable_address) || !is_array($subscription->taxable_address)) {
					if ('shipping' == get_option('woocommerce_tax_based_on') && $order->get_shipping_country()) {
						$rate_country = $order->get_shipping_country();
						$rate_state = $order->get_shipping_state();
						$rate_city = $order->get_shipping_city();
						$rate_postcode = $order->get_shipping_postcode();
					} else {
						$rate_country = $order->get_billing_country();
						$rate_state = $order->get_billing_state();
						$rate_city = $order->get_billing_city();
						$rate_postcode = $order->get_billing_postcode();
					}
				} else {
					$rate_country = $subscription->taxable_address[0];
					$rate_state = $subscription->taxable_address[1];
					$rate_city = $subscription->taxable_address[2];
					$rate_postcode = $subscription->taxable_address[3];
				}
				
				if (isset($subscription->renewal_tax_class)) {
					$rate_tax_classes = is_array($subscription->renewal_tax_class) ? array_unique($subscription->renewal_tax_class) : array($subscription->renewal_tax_class);
				} else {
					$rate_tax_classes = array('');
				}
				
				$tax_rates = array();
				
				$add_taxes = true;
				// If the original order was VAT-exempt, then make that the default for future orders. This may not be correct, of course; the reasons that made the customer/order previously exempt may no longer apply (e.g. perhaps they de-registered their VAT number since); but such things require special handling from a compatible plugin (hence the filter below).
				if (isset($subscription->renewal_all_order_meta['is_vat_exempt'])) {
					if ('yes' === $subscription->renewal_all_order_meta['is_vat_exempt']) $add_taxes = false;
				}
				
				// Users of this filter should note that the $order object has not yet been saved, and thus may not behave like a conventional WC_Order object obtained with wc_get_order().
				$add_taxes = apply_filters('subscriben_creating_renewal_order_add_taxes', $add_taxes, $subscription, $order);
				
				if ($add_taxes) {
					// If this array is not populated (i.e. $add_taxes is false), then everything cascades from there: there will be no taxes.
					// We leave $subscription->renewal_tax_class alone; perhaps it will be wanted for use again on a future renewal
					foreach ($rate_tax_classes as $rate_tax_class) {
						$tax_rates_single_class = WC_Tax::find_rates(array(
							'country' => $rate_country,
							'state' => $rate_state,
							'city' => $rate_city,
							'postcode' => $rate_postcode,
							'tax_class' => $rate_tax_class,
						));
						// Merge to get a master list of all applicable rates
						$tax_rates = $tax_rates + $tax_rates_single_class;
					}
				}

				// Recalculate total cart tax. This returns an array with total and individual amounts
				$recalculated_order_tax = self::recalculate_total_order_tax($subscription, $tax_rates);
				$renewal_order_tax = $recalculated_order_tax['total'];
				// Value in WC Checkout: WC()->cart->get_cart_contents_tax() + WC()->cart->get_fee_tax()
				// N.B. The label "cart" tax is a bit confusing. It means the taxes on items (in distinction to shipping taxes). This call sets the 'cart_tax' order property and internally calls set_total_tax() which sets the 'total_tax' order property.
				$order->set_cart_tax($renewal_order_tax);
				
				/*
				// Add the lines, order item lines, fee lines, shipping lines, tax lines, coupon lines
				$this->create_order_line_items($order, WC()->cart);
				$this->create_order_fee_lines($order, WC()->cart);
				$this->create_order_shipping_lines($order, WC()->session->get('chosen_shipping_methods'), WC()->shipping->get_packages());
				$this->create_order_tax_lines($order, WC()->cart);
				$this->create_order_coupon_lines($order, WC()->cart);
				*/
				
				/*
				"If they are looking for a way to trigger the calculations in the Currency Switcher, I believe that they would have to call the following before WC_Order::save():"

				WC_Order::set_total()
				WC_Order::set_discount_total()
				WC_Order::set_shipping_total()
				WC_Order::set_cart_tax()
				WC_Order::set_shipping_tax()
				WC_Order::set_discount_tax()
				*/
				
				$renewal_shipping_tax = 0;
				
				$recalculated_shipping_tax = array();
				if ($charge_shipping) {
					// Setting shipping tax
					$recalculated_shipping_tax = self::recalculate_order_shipping_tax($subscription, $tax_rates);
					$renewal_shipping_tax = $recalculated_shipping_tax['total'];
				}
				
				// This sets the shipping_tax and total_tax order properties
				$order->set_shipping_tax($renewal_shipping_tax);
				
				// Change order total based on new tax

				// Subtotal and total need to include tax. Total needs to include shipping
				$total_ex_old_tax = $subscription->renewal_order_subtotal - $subscription->renewal_order_tax;
				$total_inc_new_tax = $total_ex_old_tax + $renewal_order_tax;
				
				$totals_params = array(
					// "subtotal" is line items; it does not yet include shipping or fees
					'renewal_order_subtotal' => $total_inc_new_tax,
					'renewal_order_total' => $total_inc_new_tax,
					'renewal_order_tax' => $renewal_order_tax,
				);
				
				if ($charge_shipping) {
					$shipping_ex_old_tax = $subscription->renewal_order_shipping;
					$shipping_inc_new_tax = $shipping_ex_old_tax + $renewal_shipping_tax;
					
					$totals_params['renewal_order_shipping'] = $shipping_ex_old_tax;
					$totals_params['renewal_order_shipping_tax'] = $renewal_shipping_tax;
					$totals_params['renewal_order_total'] += $shipping_inc_new_tax;
				}
				
				// Save recalculated totals - this saves as subscription meta
				$subscription->update_subscription_details($totals_params);
				
				// Setting shipping - sets the 'shipping_total' order property
				$order->set_shipping_total($charge_shipping ? $subscription->renewal_order_shipping : 0);
				
				// The next two are temporary solutions for developers who need to change prices in renewal orders
				// Which of these gets used depends upon whether the option to charge shipping on renewals is set, or not
				$renewal_order_subtotal = apply_filters('subscriben_renewal_order_subtotal', $subscription->renewal_order_subtotal, $subscription);
				$renewal_order_total = apply_filters('subscriben_renewal_order_total', $subscription->renewal_order_total, $subscription);
				
				// At the checkout, this is: WC()->cart->get_total('edit') . So, this is the "cart" total, i.e. line-items subtotal
				$order->set_total($charge_shipping ? $renewal_order_total : $renewal_order_subtotal);
				
				$order->update_meta_data('_subscriben_renewal', 'yes');
				$order->update_meta_data('_subscriben_subscription_id', $subscription->id);

				$order->update_meta_data('is_vat_exempt', $add_taxes ? 'no' : 'yes');
				
				// Exclude meta keys already set via direct methods above (those direct methods internally use WC_Order::update_meta_data() and result in duplicate row entries).
				$meta_keys_already_set = array('_order_currency', '_customer_ip_address', '_customer_user_agent', '_created_via', '_order_key', '_prices_include_tax', '_order_version', '_order_tax', '_order_total', '_customer_user', '_subscriben_renewal', '_subscriben_subscription_id', 'is_vat_exempt');
				
				// Add any other possible custom data for order
				
				foreach ($subscription->renewal_all_order_meta as $meta_key => $meta_value) {
					if (
						!in_array($meta_key, $meta_keys_already_set) && 
						!preg_match('/_((shipp|bill)ing|discount)/', $meta_key) && 
						!preg_match('/_base_currency/', $meta_key) && 
						apply_filters('subscriben_copy_meta_field_to_renewal_order', true, $order, $meta_key, $meta_value, $subscription)
					) {
						$order->update_meta_data($meta_key, $meta_value);
					}
				}

				// The product handling start

				// Check if can create one subscription for all products
				$multiproduct_subscription = (Simba_Subscriptions::multiproduct_mode() && is_array($subscription->products_multiple)) ? true : false;

				// Set how many subscription products we need to add (if multiple - add as many as needed)
				$iterations = $multiproduct_subscription ? count($subscription->products_multiple) : 1;

				// Set variable
				$all_subs = $subscription->products_multiple;
				
				$subscription_line_tax_parameters = array();
				
				// Start iterations
				for ($i = 0; $i < $iterations; $i++) {

					// Get product ids
					if (!empty($all_subs)) {
						$product_id     = !empty($all_subs[$i]['product_id']) ? $all_subs[$i]['product_id'] : '';
						$variation_id   = !empty($all_subs[$i]['variation_id']) ? $all_subs[$i]['variation_id'] : '';
						$quantity       = !empty($all_subs[$i]['quantity']) ? $all_subs[$i]['quantity'] : 1;
					} else {
						$product_id     = !empty($subscription->product_id) ? $subscription->product_id : '';
						$variation_id   = !empty($subscription->variation_id) ? $subscription->variation_id : '';
						$quantity       = !empty($subscription->quantity) ? $subscription->quantity : 1;
					}

					// Set the current product id
					$product_id_to_use = empty($variation_id) ? $product_id : $variation_id;

					// Check if product still exists
					if (false != ($product = wc_get_product($product_id_to_use))) {

						// Get product name
						$product_title = $product->get_title();

						// Get product variation data
						$item_variation_data = array();
						$item_variation_data['variation_data']    = isset($product->variation_id) ? $product->get_variation_attributes() : '';

						// Update product name on subscription if it was changed
						if ($product_title != $subscription->product_name) {
							$subscription->update_subscription_details(array(
								'product_name'  => $product_title,
							));
						}
					} else {// Product no longer exists; use product information saved when the subscription was created
						$product_title = $subscription->product_name;
					}
					
					$transaction_begun = true;
					wc_transaction_query('start');
					
					// In order to add order items, we first need to get the order_id. WC_Checkout does it a bit differently.
					$order_id = $order->save();

					// Add line item (product) to order
					$item_id = wc_add_order_item($order_id, array(
						'order_item_name'   => $product_title,
						'order_item_type'   => 'line_item',
					));

					if (!$item_id) {
						throw new Exception(__('Unable to add product to renewal order.', 'subscriben'));
					}
					
					// Add line item meta
					$tax_class = $subscription->renewal_tax_class[$product_id_to_use] ?? '';
					
					// Get totals. Filters are temporary solution for developers who need to change prices in renewal orders
					$renewal_line_subtotal      = apply_filters('subscriben_renewal_order_line_subtotal', $subscription->renewal_line_subtotal, $subscription, $i);
					$renewal_line_total         = apply_filters('subscriben_renewal_order_line_total', $subscription->renewal_line_total, $subscription, $i);

					$item_meta = array(
						'_qty'                  => $quantity,
						'_tax_class'            => $tax_class, // We still store this even if there was no actual tax
						'_product_id'           => $product_id,
						'_variation_id'         => $variation_id,
						'_line_subtotal'        => is_array($renewal_line_subtotal) ? wc_format_decimal($renewal_line_subtotal[$product_id_to_use]) : wc_format_decimal($renewal_line_subtotal),
						'_line_total'           => is_array($renewal_line_total) ? wc_format_decimal($renewal_line_total[$product_id_to_use]) : wc_format_decimal($renewal_line_total),
					);

					// Recalculate tax - we can't assume that a tax class will be set
					if ($add_taxes && (!empty($tax_rates) || $subscription->renewal_line_subtotal_tax)) {
						$line_item_taxes = self::recalculate_line_tax($subscription, $product_id_to_use, $tax_class, $tax_rates, $i);

						$item_meta['_line_subtotal_tax'] = $line_item_taxes['subtotal']['sum'];
						$item_meta['_line_tax'] = $line_item_taxes['total']['sum'];
						$item_meta['_line_tax_data'] = array(
							'total' => $line_item_taxes['total']['breakdown'],
							'subtotal' => $line_item_taxes['subtotal']['breakdown']
						);

					}

					foreach ($item_meta as $item_meta_key => $item_meta_value) {
						wc_add_order_item_meta($item_id, $item_meta_key, $item_meta_value);
					}

					// Add any possible custom data for item
					if (isset($subscription->renewal_all_items_meta[$product_id]) && is_array($subscription->renewal_all_items_meta[$product_id])) {
						foreach ($subscription->renewal_all_items_meta[$product_id]['item_meta'] as $item_meta_key => $item_meta_value) {
							if (!isset($item_meta[$item_meta_key]) && is_array($item_meta_value)) {
								wc_add_order_item_meta($item_id, $item_meta_key, maybe_unserialize($meta_value));
							}
						}
					}

					// Store variation data in meta
					if (is_array($item_variation_data['variation_data'])) {
						foreach ($item_variation_data['variation_data'] as $key => $value) {
							wc_add_order_item_meta($item_id, str_replace('attribute_', '', $key), $value);
						}
					}

					// Save shipping info (if any)
					if (!empty($subscription->shipping)) {
						$shipping_item_id = wc_add_order_item($order_id, array(
							'order_item_name'   => $subscription->shipping['name'],
							'order_item_type'   => 'shipping',
						));

						wc_add_order_item_meta($shipping_item_id, 'method_id', $subscription->shipping['method_id']);

						// Maybe change shipping cost
						$shipping_cost = $charge_shipping ? $subscription->shipping['cost'] : 0;
						wc_add_order_item_meta($shipping_item_id, 'cost', wc_format_decimal($shipping_cost));
						wc_add_order_item_meta($shipping_item_id, 'total_tax', wc_format_decimal($renewal_shipping_tax));
						wc_add_order_item_meta($shipping_item_id, 'taxes', array('total' => $recalculated_shipping_tax['individual']));
					}
					
					// Save item tax for use later
					if (isset($subscription->products_multiple) && !empty($subscription->products_multiple)) {
						$subscription_line_tax_parameters[$i] = array(
							'product_id' => $product_id,
							'product_name' => $product_title,
							'variation_id' => $variation_id,
							'quantity' => $quantity,
							'total' => $item_meta['_line_total'],
						);

						if (!isset($item_line_tax_amount)) $item_line_tax_amount = array();
						
						if (isset($item_meta['_line_tax'])) {
							$subscription_line_tax_parameters[$i]['tax'] = $item_meta['_line_tax'];
							$item_line_tax_amount[$i] = $item_meta['_line_tax'];
						}
						
					} else {
						$item_line_tax_amount = isset($item_meta['_line_tax']) ? $item_meta['_line_tax'] : 0;
					}
				} // Product handling end
				
				// Update the subscription taxes array
				$tax_info_container_array = array();
				
				// Reformat the recalculated order tax to what we want to store
				if (isset($recalculated_order_tax['individual'])) {
					foreach ($recalculated_order_tax['individual'] as $rate_id => $rot) {
						$rate_array = array(
							'name' => $tax_rates[$rate_id]['label'],
							'rate_id' => $rate_id,
							'label' => $tax_rates[$rate_id]['label'],
							'compound' => ('yes' === $tax_rates[$rate_id]['compound']),
							'tax_amount' => $rot,
						);
					
						if (isset($recalculated_shipping_tax['individual'][$rate_id])) {
							$rate_array['shipping_tax_amount'] = $recalculated_shipping_tax['individual'][$rate_id];
						}
						
						$tax_info_container_array[] = $rate_array;
					}
				}
					
				// Update the 'taxes' array in the subscription
				if (empty($tax_info_container_array)) {
					$subscription->clear_subscription_details(array(
						'taxes',
						'renewal_order_shipping_tax',
						'renewal_order_tax',
						'renewal_line_subtotal_tax',
						'renewal_line_tax',
					));
				} else {
					$params = array(
						'taxes' => $tax_info_container_array,
						'renewal_order_shipping_tax' => $renewal_shipping_tax,
						'renewal_order_tax' => $renewal_order_tax,
					);
					
					if (is_array($item_line_tax_amount)) {
						$params['renewal_line_subtotal_tax'] = $item_line_tax_amount;
						$params['renewal_line_tax'] = $item_line_tax_amount;
					} else {
						$params['renewal_line_subtotal_tax'] = $item_line_tax_amount;
						$params['renewal_line_tax'] = $item_line_tax_amount;
					}
					
					$params['products_multiple'] = $subscription_line_tax_parameters;
					
					$subscription->update_subscription_details($params);
				}
				
				// Save taxes (if any). N.B. The 'taxes' property was set in the immediately preceding block
				if (is_array($subscription->taxes)) {
					foreach ($subscription->taxes as $tax) {
						$tax_item_id = wc_add_order_item($order_id, array(
							'order_item_name'   => $tax['name'],
							'order_item_type'   => 'tax',
						));

						wc_add_order_item_meta($tax_item_id, 'rate_id', $tax['rate_id']);
						wc_add_order_item_meta($tax_item_id, 'label', $tax['label']);
						wc_add_order_item_meta($tax_item_id, 'compound', $tax['compound']);
						wc_add_order_item_meta($tax_item_id, 'tax_amount', wc_format_decimal($tax['tax_amount'], 4));

						// Maybe change shipping tax
						$shipping_tax = $charge_shipping ? $tax['shipping_tax_amount'] : 0;
						wc_add_order_item_meta($tax_item_id, 'shipping_tax_amount', wc_format_decimal($shipping_tax, 4));
					}
				}
				
				// apply renewal coupon if applicable
				$last_order = wc_get_order($subscription->last_order_id);
				if ($last_order) {
					if ($last_order->get_coupon_codes()) {
						$used_coupon_code = reset($last_order->get_coupon_codes());
						$used_coupon = new WC_Coupon($used_coupon_code);
						if ($used_coupon) {
							if ('yes' == $used_coupon->get_meta('subscription_order_renew_coupon', true)) {
								// Override the active currency temporarily for this renewal order. This will ensure that the conversion functions will return coupon discount price in the renewal order currency
								add_filter('wc_aelia_cs_selected_currency', $selected_currency_filter = function($selected_currency) use ($renew_order_currency) {// phpcs:ignore VariableAnalysis.CodeAnalysis.VariableAnalysis.UnusedVariable
									return $renew_order_currency;
								}, 999);
								$order->apply_coupon($used_coupon_code);
								// Remove the filter for the active currency, restoring the original one
								remove_filter('wc_aelia_cs_selected_currency', $selected_currency_filter, 999);
							}
						}
					}
				}

				// Try to get scheduled payment timestamp
				$payment_due_timestamp = Simba_Subscriptions_Event_Scheduler::get_scheduled_event_timestamp('payment', $subscription->id);

				// If set, schedule payment due reminders
				if ($payment_due_timestamp) {
					foreach ($subscription->get_reminders('pre_payment_due', $payment_due_timestamp) as $timestamp) {
						Simba_Subscriptions_Event_Scheduler::schedule_reminder($subscription->id, $timestamp);
					}
				}

				// Update appropriate subscription fields with new order id
				$subscription->update_subscription_details(array(
					'last_order_id' => $order_id,
					'all_order_ids' => $order_id,
				));

				do_action('subscriben_creating_renewal_order', $subscription, $order);
				
				$order->save();
				
				// Commit transaction, if supported
				wc_transaction_query('commit');
				$transaction_begun = false;
				
				// See: https://github.com/woocommerce/woocommerce/issues/57204 (the current $order object does not behave as previously, when under HPOS). However; it seems likely to me that the pre-HPOS behaviour, whereby the item meta lines added with wc_add_order_item_meta() took effect in the WC_Order object immediately, was undocumented/unofficial.
				$order = wc_get_order($order_id);
				
				do_action('subscriben_created_renewal_order', $subscription, $order_id, $order);

				// Send New Order email
				Simba_Subscriptions_Mailer::send('new_order', $order);

				// If renewal order's total is zero or the site is demo - change status to processing
				if (Simba_Subscriptions_WC_Legacy::order_get_total($order) == 0) {
					$order->update_status('processing');
				}
				
				return $order_id;
			} catch (Exception $e) {

				// Rollback transaction, if supported
				if ($transaction_begun) wc_transaction_query('rollback');

				// Propagate exception
				throw $e;
			}

		}
		
		/**
		 *
		 * Recalculate the 'cart' tax for a subscription. This does not update the subscription data
		 *
		 * WC 3.0+
		 *
		 * @access private
		 * @param object $subscription
		 * @param array  $tax_rates
		 * @return array
		 */
		private static function recalculate_total_order_tax($subscription, $tax_rates) {
			$renewal_order_new_tax = array();
			
			if (wc_tax_enabled() && !empty($tax_rates)) {
				// Grab the total without tax
				$renewal_order_total = $subscription->renewal_order_subtotal;
				$renewal_order_tax = $subscription->renewal_order_tax;
				$renewal_order_ex_tax_total = $renewal_order_total-$renewal_order_tax;
				
				// Pass that to WC tax functions
				// Use the exclusive price calculation here, as we can't guarantee older subscriptions have the correct tax information
				$renewal_order_new_tax = WC_tax::calc_exclusive_tax($renewal_order_ex_tax_total, $tax_rates);
				$renewal_order_new_total_tax = WC_tax::get_tax_total($renewal_order_new_tax);
				
			} else {
				// Tax rate has been removed
				$renewal_order_new_total_tax = WC_Tax::round(0);
			}
			
			// Filter the result and return
			$renewal_order_new_total_tax = apply_filters('subscriben_renewal_order_tax', $renewal_order_new_total_tax, $subscription);
			
			// The individual values here is an array of 'rate_id'=>'amount'. used to update the subscription details
			return array('total' => $renewal_order_new_total_tax, 'individual' => $renewal_order_new_tax);
		}
		
		/**
		 *
		 * Recalculate the shipping tax for a subscription. This does not update the subscription data
		 *
		 * WC 3.0+
		 *
		 * @access private
		 * @param object $subscription
		 * @param array  $tax_rates
		 * @return array
		 */
		private static function recalculate_order_shipping_tax($subscription, $tax_rates) {
			if (wc_tax_enabled() && !empty($tax_rates)) {
				$renewal_shipping_total = $subscription->renewal_order_shipping;
				// Check that the tax rates passed apply to shipping
				foreach ($tax_rates as $key => $rate) {
					if (!isset($rate['shipping']) || 'yes' !== $rate['shipping']) {
						unset($tax_rates[$key]);
					}
				}
				// Pass that to WC tax functions
				// Use the exclusive price calculation here, as we can't guarantee older subscriptions have the correct tax information
				$renewal_shipping_new_tax = WC_tax::calc_shipping_tax($renewal_shipping_total, $tax_rates);
				$renewal_shipping_new_total_tax = WC_tax::get_tax_total($renewal_shipping_new_tax);
			} else {
				// Tax rate has been removed, so remove tax from the order
				$renewal_shipping_new_total_tax = WC_Tax::round(0);
				$renewal_shipping_new_tax = array();
			}
			
			// Filter the result and return
			$renewal_shipping_new_total_tax = apply_filters('subscriben_renewal_shipping_tax', $renewal_shipping_new_total_tax, $subscription);
			// The individual values here is an array of 'rate_id'=>'amount'. used to update the subscription details
			return array('total' => $renewal_shipping_new_total_tax, 'individual' => $renewal_shipping_new_tax);
		}
		
		/**
		 *
		 * Recalculate the line tax for a subscription item. This does not update the subscription data
		 *
		 * WC 3.0+
		 *
		 * @access private
		 * @param object     $subscription The subscription
		 * @param int|string $product_id   The product for the line item
		 * @param int|string $tax_class    The tax class of the product
		 * @param array      $tax_rates    An array of tax rates to use if the tax class is not available
		 * @param int        $i            The iteration we are on through the line items
		 * @return array
		 */
		private static function recalculate_line_tax($subscription, $product_id, $tax_class, $tax_rates, $i) {
			// Check if the tax rate still exists
			if (wc_tax_enabled() && !empty($tax_class)) {
				$tax_rates = get_rates_for_tax_class($tax_class);
			}
			
			if (wc_tax_enabled() && !empty($tax_rates)) {
				$line_subtotal_raw = $subscription->renewal_line_subtotal;
				$line_total_raw = $subscription->renewal_line_total;
				
				// Extract the correct value if subscription contains an array of items
				$line_subtotal = is_array($line_subtotal_raw) ? $line_subtotal_raw[$product_id] : $line_subtotal_raw;
				$line_total = is_array($line_total_raw) ? $line_total_raw[$product_id] : $line_total_raw;
				
				// Pass that to WC tax functions
				$line_new_subtotal_tax = WC_Tax::calc_tax($line_subtotal, $tax_rates);
				$line_new_total_tax = WC_Tax::calc_tax($line_total, $tax_rates);
				
				$subtotal_tax = array('sum' => wc_format_decimal(WC_Tax::get_tax_total($line_new_subtotal_tax)), 'breakdown' => $line_new_subtotal_tax);
				$total_tax = array('sum' => wc_format_decimal(WC_Tax::get_tax_total($line_new_total_tax)), 'breakdown' => $line_new_subtotal_tax);
			} else {
				// Tax rate has been removed, so remove tax from line item
				$subtotal_tax = array('sum' => wc_format_decimal(0), 'breakdown' => array());
				$total_tax = array('sum' => wc_format_decimal(0), 'breakdown' => array());
			}
			
			$subtotal_tax = apply_filters('subscriben_renewal_order_line_subtotal_tax', $subtotal_tax, $subscription, $i);
			$total_tax = apply_filters('subscriben_renewal_order_line_tax', $total_tax, $subscription, $i);
			return array('subtotal' => $subtotal_tax, 'total' => $total_tax);
		}
		
		/**
		 * Cancel subscriptions when orders are cancelled
		 *
		 * @access public
		 * @param int $order_id
		 * @return void
		 * @throws Exception To rollback the transaction.
		 */
		public function order_cancelled($order_id) {
			
			wc_transaction_query('start');

			try {
				
				// Iterate over subscriptions and cancel if they are still pending
				foreach (self::get_subscriptions_from_order_id($order_id) as $subscription) {
					if ('cancelled' != $subscription->status) {
						// Get all current events timestamps
						$scheduled_events = array(
							'renewal_order' => Simba_Subscriptions_Event_Scheduler::get_scheduled_event_timestamp('order', $subscription->id),
							'payment' => Simba_Subscriptions_Event_Scheduler::get_scheduled_event_timestamp('payment', $subscription->id),
						);
						// Write transaction
						$transaction = new Simba_Subscriptions_Transaction(null, 'order_cancellation');
						$transaction->add_subscription_id($subscription->id);
						$transaction->add_order_id($order_id);
						$transaction->add_product_id($subscription->product_id);
						$transaction->add_variation_id($subscription->variation_id);

						try {
							// Cancel subscription
							$subscription->cancel();

							// Update transaction
							$transaction->update_result('success');
							$transaction->update_note(__('Subscription cancelled due to cancelled order.', 'subscriben'), true);
							
							// Unschedule order and payment
							Simba_Subscriptions_Event_Scheduler::unschedule_order($subscription->id, $scheduled_events['renewal_order']);
							Simba_Subscriptions_Event_Scheduler::unschedule_payment($subscription->id, $scheduled_events['payment']);
						} catch (Exception $e) {
							$transaction->update_result('error');
							$transaction->update_note($e->getMessage());
						}
					}
				}
				
				// Commit transaction, if supported
				wc_transaction_query('commit');
				
			} catch (Exception $e) {
	
				// Rollback transaction, if supported
				wc_transaction_query('rollback');
	
				// Propagate exception
				throw $e;
			}
		}
		
		/**
		 * Cancel associated subscription when order gets refunded in full
		 *
		 * @access public
		 * @param int $order_id
		 * @param int $refund_id
		 * @return void
		 * @throws Exception To rollback the transaction.
		 */
		public function order_refunded_then_cancel_subscription($order_id) {
			
			wc_transaction_query('start');

			try {
				// Iterate over subscriptions from order
				foreach (self::get_subscriptions_from_order_id($order_id) as $subscription) {
					
					if (!empty($_POST['subscriptions_cancel']) && in_array($subscription->id, $_POST['subscriptions_cancel'], true)) {
	
						// Write transaction
						$transaction = new Simba_Subscriptions_Transaction(null, 'order_refund');
						$transaction->add_subscription_id($subscription->id);
						$transaction->add_order_id($order_id);
						$transaction->add_product_id($subscription->product_id);
						$transaction->add_variation_id($subscription->variation_id);
		
						try {
							// Cancel subscription
							$subscription->cancel();
		
							// Update transaction
							$transaction->update_result('success');
							$transaction->update_note(__('Subscription cancelled due to refunded order.', 'subscriben'), true);
						} catch (Exception $e) {
							$transaction->update_result('error');
							$transaction->update_note($e->getMessage());
						}
					}
				}
				
				// Commit transaction, if supported
				wc_transaction_query('commit');
				
			} catch (Exception $e) {
	
				// Rollback transaction, if supported
				wc_transaction_query('rollback');
	
				// Propagate exception
				throw $e;
			}
		}

		/**
		 * Maybe cancel subscription when order gets refunded in full
		 *
		 * @access public
		 * @param int $refunded_order_id
		 * @return void
		 * @throws Exception To rollback the transaction.
		 */
		public function order_refunded_maybe_cancel_subscription($refunded_order_id) {
			
			wc_transaction_query('start');

			try {
				// Iterate over subscriptions from order
				foreach (self::get_subscriptions_from_order_id($refunded_order_id) as $subscription) {
	
					// Iterate over order ids related to one subscription
					foreach ($subscription->all_order_ids as $subscription_order_id) {
	
						$order = wc_get_order($subscription_order_id);
	
						// If there's still pending renewal order found, cancel the subscription
						if ($order && (Simba_Subscriptions_WC_Legacy::order_get_status($order) == 'pending' || !$subscription->paid_by_order(Simba_Subscriptions_WC_Legacy::order_get_id($order))) && self::order_is_renewal($order)) {
	
							// Write transaction
							$transaction = new Simba_Subscriptions_Transaction(null, 'order_refund');
							$transaction->add_subscription_id($subscription->id);
							$transaction->add_order_id(Simba_Subscriptions_WC_Legacy::order_get_id($order));
	
							try {
								// Cancel subscription
								$subscription->cancel();
	
								// Update transaction
								$transaction->update_result('success');
								$transaction->update_note(__('Subscription cancelled due to refunded order.', 'subscriben'), true);
							} catch (Exception $e) {
								$transaction->update_result('error');
								$transaction->update_note($e->getMessage());
							}
						}
					}
				}
				
				// Commit transaction, if supported
				wc_transaction_query('commit');
				
			} catch (Exception $e) {
	
				// Rollback transaction, if supported
				wc_transaction_query('rollback');
	
				// Propagate exception
				throw $e;
			}
		}

		/**
		 * Get related Simba_Subscriptions from Order ID
		 *
		 * @access public
		 * @param int $order_id
		 * @return array
		 */
		public static function get_subscriptions_from_order_id($order_id) {
			$subscriptions = array();

			// Search for related subscriptions
			$subscriptions = Simba_Subscriptions_Subscription::get_by_order_id($order_id);

			return $subscriptions;
		}

		/**
		 * Check if order contains subscription products
		 *
		 * @access public
		 * @param int $order_id
		 * @return bool
		 */
		public static function contains_subscription($order_id) {
			$subscriptions = self::get_subscriptions_from_order_id($order_id);
			return !empty($subscriptions);
		}

		/**
		 * Check if order is Simba_Subscriptions renewal order
		 *
		 * @access public
		 * @param mixed $order
		 * @return bool
		 */
		public static function order_is_renewal($order) {
			// Load order object
			if (!is_object($order)) {
				$order = wc_get_order($order);
				if (!is_object($order)) return false;
			}
			
			// Check if order is renewal order
			
			return ('yes' === $order->get_meta('_subscriben_renewal'));
		}

		/**
		 * Prevent WooCommerce from cancelling unpaid renewal orders prematurely
		 *
		 * @access public
		 * @param bool   $old_value
		 * @param string $order
		 * @return bool
		 */
		public function cancel_unpaid_order($old_value, $order) {
			// Try to find subscriptions
			$subscriptions = self::get_subscriptions_from_order_id(Simba_Subscriptions_WC_Legacy::order_get_id($order));

			// If no subscriptions found, allow to proceed
			if (!empty($subscriptions) && self::order_is_renewal($order)) {
				return false;
			}

			return $old_value;
		}
		
		/**
		 * Updates the renewal order source
		 *
		 * @param \WC_Subscription $subscription
		 * @param \WC_Order $renewal_order
		 * @return void
		 */
		public function update_renewal_order_attribution_source( $subscription, $renewal_order ) {
			$renewal_order->update_meta_data( '_wc_order_attribution_source_type', 'utm' );
			$renewal_order->update_meta_data( '_wc_order_attribution_utm_source', 'subscriben_renewal' );
		}
		
		/**
		 * Modify the renewal order attribution label
		 *
		 * @param string $label
		 * @param string $source_type
		 * @param string $source
		 * @param string $formatted_source
		 * @return string
		 */
		public function modify_renewal_order_attribution_label( $label, $source_type, $source, $formatted_source ) {
			if ( 'subscriben_renewal' === $source ) {
				$label = __( 'Subscription %s', 'subscriben' );
			}
			return $label;
		}
		
		/**
		 * Modify the renewal order attribution formatted source.
		 *
		 * WooCommerce applies `ucfirst()` to the `$formatted_source` by default, capitalizing the first letter.
		 * For example, 'subscriben_renewal' becomes 'Subscriben_renewal'.
		 *
		 * @param string $formatted_source
		 * @param string $source
		 * @return string
		 */
		public function modify_renewal_order_attribution_formatted_source( $formatted_source, $source ) {
			if ( false !== strpos( $formatted_source, 'Subscriben_renewal' ) ) {
				$formatted_source = __( 'renewal', 'subscriben' );
			}
			return $formatted_source;
		}

		/**
		 * Filter download links on Order page
		 *
		 * @access public
		 * @param array $files
		 * @return array
		 */
		public function filter_download_links($files) {
			// Iterate over files
			foreach ($files as $file_key => $file) {

				// Parse product id from file download url
				$parts = parse_url($file['download_url']);
				parse_str($parts['query'], $query);
				$product_id = $query['download_file'];

				// Check if user has access to this product
				if (!Simba_Subscriptions_User::has_access_to_product_downloads($product_id)) {
					unset($files[$file_key]);
				}
			}

			return $files;
		}

		/**
		 * Filter download links on My Account page
		 *
		 * @access public
		 * @param array $downloads
		 * @return array
		 */
		public function filter_downloadable_products($downloads) {
			// Iterate over downloads and check if user has access to them
			foreach ($downloads as $download_key => $download) {
				if (!Simba_Subscriptions_User::has_access_to_product_downloads($download['product_id'])) {
					unset($downloads[$download_key]);
				}
			}

			return $downloads;
		}

		/**
		 * Maybe prevent actual file download
		 *
		 * @access public
		 * @param string $email
		 * @param string $order_key
		 * @param int    $product_id
		 * @param int    $user_id
		 * @param int    $download_id
		 * @param int    $order_id
		 * @return void
		 */
		public function maybe_prevent_file_download($email, $order_key, $product_id, $user_id, $download_id, $order_id) {// phpcs:ignore VariableAnalysis.CodeAnalysis.VariableAnalysis.UnusedVariable
			// Check if user has access to this product files
			if (!Simba_Subscriptions_User::has_access_to_product_downloads($product_id)) {

				// Add notice
				Simba_Subscriptions_Helper::wc_add_notice(__('You no longer have access to this file.', 'subscriben'), 'error');

				// Redirect to My Account
				wp_redirect(get_permalink(wc_get_page_id('myaccount')));
				exit;
			}
		}

	}
	new Simba_Subscriptions_Order_Handler();
}
