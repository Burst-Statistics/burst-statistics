<?php
/**
 * Description: This class handle version updates.
 */

// Basic security, prevents file from being loaded directly.
if (!defined('ABSPATH')) die('No direct access.');

class Simba_Subscriptions_Version_Update {
	
	/**
	 * A array of method that handle table structure upgrades
	 *
	 * @access private
	 * @var array $db_updates
	 */
	private static $db_updates = array(
		'0.10.1' => array(
			'update_0101_possible_legacy_data',
		),
		'0.12.4' => array(
			'update_0124_possible_legacy_data',
		),
	);


	/**
	 * Simba_Subscriptions_Version_Update constructor.
	 * check updates
	 */
	public function __construct() {
		// can't really request orders before the order custom post type is registered, need hooked in init
		add_action('init', array($this, 'check_updates'));

	}
	
	/**
	 * Compares installed and available version and takes necessary action
	 *
	 * @return void
	 */
	public static function check_updates() {
		
		$our_version = SUBSCRIBEN_VERSION;
		$db_version = get_option('subscriben_dbversion', '0');
		if (version_compare($our_version, $db_version, '<=')) return;
		
		$logger = new Simba_Subscriptions_Semaphore_Logger();
		$semaphore = new Updraft_Semaphore_3_0('subscriben_version_update', 300, array($logger));

		if (!$semaphore->lock()) {
			error_log("Subscriben version update: Failed to gain semaphore lock");
			return;
		}
		
		foreach (self::$db_updates as $version => $updates) {
			if (version_compare($version, $db_version, '>')) {
				foreach ($updates as $update) {
					call_user_func(array(__CLASS__, $update));
				}
			}
		}
		update_option('subscriben_dbversion', $our_version);

		$semaphore->release();
	}
	
	/**
	 * update possible legacy data so that no subscriptions have the legacy format
	 *
	 * @return void
	 */
	public static function update_0101_possible_legacy_data() {
		$query_args = array(
			'post_type'      => 'subscription',
			'posts_per_page' => -1,
			'post_status'    => 'publish',
			'fields'    => 'ids',
			'meta_key'     => 'all_order_ids',
		);
		$the_query = new WP_Query($query_args);
		$subscription_ids = $the_query->posts;
		wp_reset_postdata();
		if (count($subscription_ids) > 0) {
			foreach ($subscription_ids as $subscription_id) {
				$subscription_order_ids = get_post_meta($subscription_id, 'all_order_ids', false);
				if (count($subscription_order_ids) > 0) {
					$orders = wc_get_orders(array(
						'limit' => -1,
						'post__in' => $subscription_order_ids,
						'meta_key'     => '_subscriben_subscription_id',
						'meta_compare' => 'NOT EXISTS',
					));
					if (count($orders) > 0) {
						foreach ($orders as $order) {
							Simba_Subscriptions_WC_Legacy::order_add_meta_data($order, '_subscriben_subscription_id', $subscription_id);
						}
					}
					
				}
			
			}
		}
	}

	/**
	 * update possible legacy data so that each transaction has parent subscription id.
	 *
	 * @return void
	 */
	public static function update_0124_possible_legacy_data() {
		global $wpdb;
		$no_of_records = 10000;
		$last_meta_id = get_option('subscriben_0124_update_last_subscription_id', 0);
		do {
			
			$subscriptions = array();
					
			$results = $wpdb->get_results($wpdb->prepare("SELECT pm.meta_id, pm.post_id, pm.meta_value FROM $wpdb->postmeta AS pm, $wpdb->posts AS p WHERE pm.meta_id > %d AND pm.meta_key ='subscription_id' AND pm.post_id = p.ID AND p.post_type='sub_transaction' ORDER BY pm.meta_id ASC LIMIT %d", $last_meta_id, $no_of_records));

			if (null === $results) {
				error_log("update_0124_possible_legacy_data: failed: database error.");
				return;
			}

			if ($results) {
				foreach ($results as $subscription) {
					$subscription_id = $subscription->meta_value;
					$subscriptions[$subscription_id]['meta_id'] = $subscription->meta_id;
					$subscriptions[$subscription_id]['sub'][] = $subscription->post_id;
				}
							
				$last_meta_id = $subscription->meta_id;
				$counter = 0;

				foreach ($subscriptions as $sub_id => $subscription) {

					$trans_ids = implode(',', $subscription['sub']);
					$sql = $wpdb->prepare("UPDATE $wpdb->posts SET post_parent = %d WHERE ID IN ($trans_ids)", $sub_id);
					if (defined('SUBSCRIBEN_DB_UPDATE_DEBUG_LOG') && SUBSCRIBEN_DB_UPDATE_DEBUG_LOG) error_log("update_0124_possible_legacy_data: ".substr($sql, 0, 256));
					$wpdb->query($sql);
					$counter++;
					if (100 == $counter) {
						$counter = 0;
						update_option('subscriben_0124_update_last_subscription_id', $subscription['meta_id']);
					}
				}
			}
			
		} while ($results);
	}

}
// Instantiate version update class
new Simba_Subscriptions_Version_Update();
