<?php

if (!defined('ABSPATH')) die('No direct access.');

/**
 * WC Coupons data related methods (mostly hooks like "add new meta data in coupons and all coupon related tweaks")
 *
 * @class Simba_Subscriptions_Order_Coupon_Handler
 * @package Simba_Subscriptions
 */
if (!class_exists('Simba_Subscriptions_Order_Coupon_Handler')) {

	class Simba_Subscriptions_Order_Coupon_Handler {

		/**
		 * Class constructor
		 *
		 * @return void
		 */
		public function __construct() {
			
			// Coupons UI
			add_action('woocommerce_coupon_data_tabs', array($this, 'woocommerce_coupon_data_tabs'), 10);
			add_action('woocommerce_coupon_data_panels', array($this, 'woocommerce_coupon_data_panels'), 10);

			// Save our coupon options when the user saves the coupon
			add_action('woocommerce_coupon_options_save', array($this, 'woocommerce_coupon_options_save'), 10, 2);

		}

		/**
		 * Adds a new tab to the Edit Coupon page. The tab will allow to set
		 * subscription order parameters for a coupon.
		 *
		 * @param array tabs The tabs passed by WooCommerce.
		 * @return array The array of tabs, with the additional one.
		 */
		public function woocommerce_coupon_data_tabs($tabs) {
			$tabs['subscription_order'] = array(
				'label' => __('Subscription', 'subscriben'),
				'target' => 'subscription_order_coupon_data',
				'class' => 'subscription_order_coupon_data',
			);

			return $tabs;
		}

		/**
		 * Renders the new tab in Edit Coupon page. The tab will allow to set
		 * subscription order parameters for a coupon.
		 */
		public function woocommerce_coupon_data_panels() {
			include SUBSCRIBEN_PLUGIN_PATH . 'includes/views/backend/coupon/coupon-subscription-order.php';
		}

		/**
		 * Saves the multi-currency data for a coupon.
		 *
		 * @param int coupon_id The coupon ID.
		 */
		public function woocommerce_coupon_options_save($coupon_id, $coupon) {
			$subscription_order_renew_coupon = !empty($_POST['subscription_order_renew_coupon']) ? 'yes' : 'no';
			$coupon->update_meta_data('subscription_order_renew_coupon', $subscription_order_renew_coupon);
			$coupon->save();
		}

	}
	new Simba_Subscriptions_Order_Coupon_Handler();
}
