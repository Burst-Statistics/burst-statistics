<?php
/**
 * Exit if accessed directly
 */
if (!defined('ABSPATH')) {
	exit;
}

/**
 * Main Simba_Subscriptions Stripe payment gateway class
 *
 * @class Simba_Subscriptions_Stripe_Gateway
 * @package Simba_Subscriptions
 */
if (!class_exists('Simba_Subscriptions_Stripe_Gateway') && class_exists('WC_Payment_Gateway')) {

	class Simba_Subscriptions_Stripe_Gateway extends WC_Payment_Gateway {
		
		/**
		 * Stripe API endpoint URL
		 *
		 * @var string
		 */
		private $endpoint_url;
		
		/**
		 * Debug mode
		 *
		 * @var string
		 */
		public $debug;
		
		/**
		 * Only existing cards
		 *
		 * @var bool
		 */
		private $only_existing;
		
		/**
		 * Capture payment
		 *
		 * @var bool
		 */
		private $capture;
		
		/**
		 * Stripe secret key
		 *
		 * @var string
		 */
		private $secret_key;
		
		/**
		 * Stripe publishable key
		 *
		 * @var string
		 */
		public $publishable_key;
		
		/**
		 * Checkout style
		 *
		 * @var string
		 */
		public $checkout_style;
		
		/**
		 * Checkout image
		 *
		 * @var string
		 */
		public $checkout_image;
		
		/**
		 * Enable logging
		 *
		 * @var bool
		 */
		private $enable_log;
		
		/**
		 * WC Logger
		 *
		 * @var \Simba_Subscriptions_WC_Logger
		 */
		public $wc_logger;
		
		/**
		 * Notices
		 *
		 * @var array
		 */
		private $notices = array();

		/**
		 * Constructor class
		 *
		 * @access public
		 * @param mixed $id
		 * @return void
		 */
		public function __construct($id = null) {// phpcs:ignore VariableAnalysis.CodeAnalysis.VariableAnalysis.UnusedVariable
			$woocommerce = WC();

			// Gateway configuration
			$this->id                  = 'subscriben_stripe';
			$this->icon                = apply_filters('subscriben_stripe_logo_url', set_url_scheme(SUBSCRIBEN_PLUGIN_URL) . '/assets/gateways/stripe/images/subscriben_stripe_' . ($woocommerce->countries->get_base_country() === 'US' ? 'us' : 'worldwide') . '.png');
			$this->has_fields          = true;
			$this->endpoint_url        = 'https://api.stripe.com/';
			$this->supports            = array('products', 'refunds', 'subscriben');
			$this->method_title        = __('Stripe by Subscriben', 'subscriben-stripe');
			$this->method_description  = sprintf(wp_kses(__('Stripe requires all communications to be secured with TLS 1.2+; make sure that your server <a href="%s">supports it</a>.', 'subscriben-stripe'), array('a' => array('href' => array()), 'br' => array())), 'https://subscribenplugin.com/faqs/tls-support/');

			// Load settings fields
			$this->init_form_fields();
			$this->init_settings();

			// Define properties
			$this->enabled             = apply_filters('subscriben_stripe_enabled', $this->get_option('enabled'));
			$this->debug               = apply_filters('subscriben_stripe_debug', $this->get_option('debug'));
			$this->only_existing       = apply_filters('subscriben_stripe_only_existing', $this->get_option('only_existing')) === 'yes' ? true : false;
			$this->capture             = apply_filters('subscriben_stripe_capture', $this->get_option('capture')) === 'yes' ? true : false;
			$this->title               = $this->get_option('title');
			$this->description         = $this->get_option('description');
			$this->secret_key          = wc_string_to_bool( $this->debug ) ? $this->get_option('test_secret_key') : $this->get_option('live_secret_key');
			$this->publishable_key     = wc_string_to_bool( $this->debug ) ? $this->get_option('test_publishable_key') : $this->get_option('live_publishable_key');
			$this->checkout_style      = $this->get_option('checkout_style');
			$this->checkout_image      = $this->get_option('checkout_image');
			
			// Log
			$this->enable_log          = wc_string_to_bool( $this->get_option('enable_log') );
			$this->wc_logger           = new \Simba_Subscriptions_WC_Logger( $this->id );
			
			// Disable logging
			if (!$this->enable_log) {
				$this->wc_logger->disable();
			}

			// Save gateway settings
			add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));

			// Add support for WC subscriptions recurring payments
			add_filter('woocommerce_scheduled_subscription_payment_' . $this->id, array($this, 'process_recurring_payment'), 10, 3);

			// Enqueue Stripe scripts
			add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts_on_checkout'));

			// Maybe hide on checkout
			add_filter('woocommerce_available_payment_gateways', array($this, 'maybe_hide_on_checkout'), 10000);

			// Get admin notices and disable payment gateway if any
			$this->notices = $this->get_notices();

			// Disable payments and show admin notices if something is wrong with settings
			if (wc_string_to_bool($this->enabled) && !empty($this->notices)) {

				// Show admin notices
				if ('POST' !== $_SERVER['REQUEST_METHOD'] || !isset($_POST['subscriben_stripe_test_secret_key'])) {
					add_action('admin_notices', array($this, 'show_admin_notices'));
				}

				// Disable payments
				if (count($this->notices) > 1 || !isset($this->notices['ssl'])) {
					$this->enabled = 'no';
				}
			}
		}

		/**
		 * Get notices for admin
		 *
		 * @access public
		 * @param bool $return_error
		 * @return array|bool
		 */
		public function get_notices() {
			$notices = array();

			// Check for SSL support
			if (get_option('woocommerce_force_ssl_checkout') != 'yes' && !class_exists('WordPressHTTPS') && !is_ssl()) {
				$notices['ssl'] = __('Subscriben Stripe payment gateway requires full SSL support and enforcement during Checkout. Only test mode will work until this is solved.', 'subscriben-stripe');
			}

			// Check secret key
			if (empty($this->secret_key)) {
				$notices['secret'] = __('Subscriben Stripe payment gateway requires Stripe Secret Key to be set.', 'subscriben-stripe');
			}

			// Check publishable key
			if (empty($this->publishable_key)) {
				$notices['publishable'] = __('Subscriben Stripe payment gateway requires Stripe Publishable Key to be set.', 'subscriben-stripe');
			}

			return $notices;
		}

		/**
		 * Show admin notices
		 *
		 * @access public
		 * @return void
		 */
		public function show_admin_notices() {
			foreach ($this->notices as $notice) {
				echo '<div class="error"><p>' . __($notice, 'subscriben-stripe') . '</p></div>';
			}
		}

		/**
		 * Check if this gateway is available for use
		 *
		 * @access public
		 * @return bool
		 */
		public function is_available() {
			return wc_string_to_bool( $this->enabled );
		}

		/**
		 * Process payment
		 *
		 * @access public
		 * @param int $order_id
		 * @return array
		 */
		public function process_payment($order_id) {
			$woocommerce = WC();
			$order       = wc_get_order($order_id);

			if (!$order) {
				$message = __('Order not found.', 'subscriben-stripe') . ' ' . __('We have not charged your card. Please try again.', 'subscriben-stripe');
				Simba_Subscriptions_Helper::wc_add_notice($message, 'error');
				$this->wc_logger->log( $message );
				return array();
			}
			
			$token_key   = Simba_Subscriptions::is_checkout_block() ? 'token' : 'subscriben_stripe_token';
			$card_id_key = Simba_Subscriptions::is_checkout_block() ? 'card_id' : 'subscriben_stripe_card_id';
			
			// Get token and selected card
			$token         = isset($_POST[$token_key]) ? sanitize_text_field($_POST[$token_key]) : '';
			$selected_card = isset($_POST[$card_id_key]) ? sanitize_text_field($_POST[$card_id_key]) : '';
			
			// Make sure we received card id
			if (empty($selected_card)) {
				$message = __('Card is not selected.', 'subscriben-stripe') . ' ' . __('We have not charged your card. Please try again.', 'subscriben-stripe');
				Simba_Subscriptions_Helper::wc_add_notice($message, 'error');
				$this->wc_logger->log( $message );
				return array();
			}

			// Make sure we received Stripe token if it's not an existing card
			if ('none' === $selected_card && empty($token)) {
				$message = __('Authorization token not set.', 'subscriben-stripe') . ' ' . __('We have not charged your card. Please try again.', 'subscriben-stripe');
				Simba_Subscriptions_Helper::wc_add_notice($message, 'error');
				$this->wc_logger->log( $message );
				return array();
			}

			// Data to send to Stripe
			$charge_details = array(
				'amount'        => Simba_Subscriptions_WC_Legacy::order_get_total($order) * Simba_Subscriptions_Stripe_Gateway::get_currency_multiplier($order),
				'currency'      => strtolower($order->get_currency()),
				'description'   => apply_filters('subscriben_stripe_payment_description', esc_html(get_bloginfo('name')) . ' - ' . __('Order', 'subscriben-stripe') . ' ' . $order->get_order_number(), $order),
				'metadata'      => array(
					'order_id'  => Simba_Subscriptions_WC_Legacy::order_get_id($order),
					'email'     => Simba_Subscriptions_WC_Legacy::order_get_billing_email($order),
				),
			);

			// Additional statement description
			$statement_descriptor = apply_filters('subscriben_stripe_payment_statement_description', '', $order);

			if ('' !== $statement_descriptor) {
				$charge_details['statement_descriptor'] = $statement_descriptor;
			}

			// Get user id from order
			$order_user_id = Simba_Subscriptions_WC_Legacy::order_get_customer_id($order);

			// Try to get user id
			if (!empty($order_user_id)) {
				$user_id = $order_user_id;
			} elseif (is_user_logged_in()) {
				$user_id = get_current_user_id();
			} else {
				$user_id = 0;
			}

			// User is known - charge by sending a customer id / card id pair
			if ($user_id) {

				// Get (and possibly create) user and card details
				$user_card_details = $this->get_card($order, $user_id, $token, $selected_card);

				if (!is_array($user_card_details)) {
					$message = $user_card_details . ' ' . __('We have not charged your card. Please try again.', 'subscriben-stripe');
					Simba_Subscriptions_Helper::wc_add_notice($message, 'error');
					$this->wc_logger->log( $message );
					return array();
				}

				// Handle free trial order
				if (0 == $charge_details['amount']) {
					return $this->handle_trial($order);
				}

				// Charge card
				$charge_details['customer'] = $user_card_details['customer_id'];
				$charge_details['source'] = $user_card_details['card_id'];
				$response = $this->charge($charge_details);
			} else {// User is not known - charge guest users directly by token

				$charge_details['source'] = $token;
				$response = $this->charge($charge_details);
			}

			// Error charging card?
			if (is_string($response)) {
				$order->add_order_note($response);
				Simba_Subscriptions_Helper::wc_add_notice($response, 'error');
				$this->wc_logger->log( $response );
				return array();
			}

			// Save charge id
			Simba_Subscriptions_WC_Legacy::order_update_meta_data($order, '_subscriben_stripe_charge_id', $response->id);

			// Save capture status
			Simba_Subscriptions_WC_Legacy::order_update_meta_data($order, '_subscriben_stripe_charge_captured', ($response->captured ? 'yes' : 'no'));

			// Charge captured?
			if ($response->captured) {
				$order->add_order_note(sprintf(__('Stripe charge %s captured.', 'subscriben-stripe'), $response->id));
				$order->payment_complete();
			} else {// Only authorized
				$order->add_order_note(sprintf(__('Stripe charge %s authorized and will be charged as soon as you start processing this order. Authorization will expire in 7 days.', 'subscriben-stripe'), $response->id));
				$order->update_status('on-hold');
				Simba_Subscriptions_WC_Legacy::order_reduce_stock_levels($order);
			}

			// Empty cart
			$woocommerce->cart->empty_cart();

			// Redirect user
			return array(
				'result'   => 'success',
				'redirect' => $this->get_return_url($order),
			);
		}

		/**
		 * Add support for automated payments via WC Simba_Subscriptions API
		 *
		 * @access public
		 * @param float   $amount_to_charge
		 * @param object  $order
		 * @param integer $subscription_id
		 * @return bool
		 */
		public function process_recurring_payment($amount_to_charge, $order, $subscription_id) {
			$subscription = new Simba_Subscriptions_Subscription($subscription_id);

			$customer_id = Simba_Subscriptions_WC_Legacy::customer_get_meta($subscription->user_id, '_subscriben_stripe_customer_id', true);
			$default_card = Simba_Subscriptions_WC_Legacy::customer_get_meta($subscription->user_id, '_subscriben_stripe_customer_default_card', true);

			if (empty($customer_id) || empty($default_card)) {
				$subscription->add_note(__('The customer has no card to charge.', 'subscriben-stripe'), 'error', $order->id);
				$order->add_order_note(__('The customer has no card to charge.', 'subscriben-stripe'));
				return false;
			}

			// Send request
			$response = $this->charge(array(
				'amount'        => $amount_to_charge * Simba_Subscriptions_Stripe_Gateway::get_currency_multiplier($order),
				'currency'      => strtolower($order->get_currency()),
				'description'   => apply_filters('subscriben_stripe_payment_description', esc_html(get_bloginfo('name')) . ' - ' . __('Order', 'subscriben-stripe') . ' ' . $order->get_order_number() . ' (' . __('Subscription', 'subscriben-stripe') . ' ' . $subscription->get_subscription_number() . ')', $order),
				'metadata'      => array(
					'order_id'          => Simba_Subscriptions_WC_Legacy::order_get_id($order),
					'subscription_id'   => $subscription->id,
					'email'             => Simba_Subscriptions_WC_Legacy::order_get_billing_email($order),
				),
				'statement_descriptor' => substr(sprintf(__('Subscr %s', 'subscriben-stripe'), $subscription->get_subscription_number()), 0, 15),
				'customer'      => $customer_id,
				'source'          => $default_card,
			));

			// Received error?
			if (is_string($response)) {
				$order->add_order_note(__('Automatic subscription payment failed (Stripe).', 'subscriben-stripe') . ' ' . $this->get_localized_error_message_from_response($response));
				$subscription->add_note(__('Failed repeat payment response from gateway:', 'subscriben-stripe').' '.$this->get_localized_error_message_from_response($response), 'error', $order->id);
				return false;
			}

			// Add payment method
			Simba_Subscriptions_WC_Legacy::order_update_meta_data($order, '_payment_method', 'subscriben_stripe');

			// Save charge id
			Simba_Subscriptions_WC_Legacy::order_update_meta_data($order, '_subscriben_stripe_charge_id', $response->id);

			// Save capture status
			Simba_Subscriptions_WC_Legacy::order_update_meta_data($order, '_subscriben_stripe_charge_captured', ($response->captured ? 'yes' : 'no'));

			// Charge captured?
			if ($response->captured) {
				$order->add_order_note(sprintf(__('Stripe charge %s captured.', 'subscriben-stripe'), $response->id));
				$order->payment_complete();
				$subscription->add_note(__('Repeat payment captured:', 'subscriben-stripe').' '.$response->id, 'success', $order->id);
			} else {// Only authorized
				$order->add_order_note(sprintf(__('Stripe charge %s authorized and will be charged as soon as you start processing this order. Authorization will expire in 7 days.', 'subscriben-stripe'), $response->id));
				$order->update_status('on-hold');
				Simba_Subscriptions_WC_Legacy::order_reduce_stock_levels($order);
				$subscription->add_note(__('Repeat payment authorised:', 'subscriben-stripe').' '.$response->id, 'success', $order->id);
			}

			return true;
		}

		

		/**
		 * Handle order with free trial
		 *
		 * @access public
		 * @param object $order
		 * @return array
		 */
		public function handle_trial($order) {
			$woocommerce = WC();

			// Complete the order
			$order->add_order_note(__('Stripe details saved for future use.', 'subscriben-stripe'));
			$order->update_status('processing');
			Simba_Subscriptions_WC_Legacy::order_reduce_stock_levels($order);

			// Empty cart
			$woocommerce->cart->empty_cart();

			// Redirect user
			return array(
				'result'   => 'success',
				'redirect' => $this->get_return_url($order),
			);
		}

		/**
		 * Get (and possibly save) card
		 *
		 * @access public
		 * @param object $order
		 * @param int    $user_id
		 * @param string $token
		 * @param string $selected_card
		 * @return array|bool
		 */
		public function get_card($order, $user_id, $token, $selected_card) {
			// Does Stripe already know this user?
			$customer_id = Simba_Subscriptions_WC_Legacy::customer_get_meta($user_id, '_subscriben_stripe_customer_id', true);

			// No customer? Create both customer and card
			if (empty($customer_id)) {

				// Send request to add a new customer
				$response = $this->send_request('customers', 'create', array(
					'source'          => $token,
					'description'   => apply_filters('subscriben_stripe_customer_description', esc_html(get_bloginfo('name')) . ' - ' . Simba_Subscriptions_WC_Legacy::order_get_billing_first_name($order) . ' ' . Simba_Subscriptions_WC_Legacy::order_get_billing_last_name($order), $order),
					'email'         => Simba_Subscriptions_WC_Legacy::order_get_billing_email($order),
				));

				// Errors?
				if (!empty($response->error)) {
					if (Simba_Subscriptions_Helper::string_contains_phrase($response->error->message, 'Stripe no longer supports API requests made with TLS')) {
						$order->add_order_note(__('Connection error.', 'subscriben-stripe') . ' ' . $response->error->message);
						return __('Connection error.', 'subscriben-stripe');
					}
					$response_localized_error_message = $this->get_localized_error_message_from_response($response);
					$order->add_order_note(__('Payment gateway error:', 'subscriben-stripe') . ' ' . $response_localized_error_message);
					return __('Payment gateway error:', 'subscriben-stripe') . ' ' . $response_localized_error_message;
				} elseif (!is_object($response) || !isset($response->id) || !isset($response->default_source)) {
					return __('Unable to add a new card.', 'subscriben-stripe');
				}

				// Save user id
				Simba_Subscriptions_WC_Legacy::customer_update_meta_data($user_id, '_subscriben_stripe_customer_id', $response->id);

				// Check the type of new card before adding
				if (!$this->is_funding_type_allowed($response->sources->data[0]->funding)) {
					return sprintf(__('Unable to use a card with "%s" funding type. ', 'subscriben-stripe'), $response->sources->data[0]->funding);
				}

				// Save card details
				if (!empty($response->sources->data[0])) {
					Simba_Subscriptions_WC_Legacy::customer_update_meta_data($user_id, '_subscriben_stripe_customer_cards', array(
						$response->default_source => array(
							'brand'     => $response->sources->data[0]->brand,
							'funding'   => $response->sources->data[0]->funding,
							'exp_month' => $response->sources->data[0]->exp_month,
							'exp_year'  => $response->sources->data[0]->exp_year,
							'last4'     => $response->sources->data[0]->last4,
						),
					));
				}

				// Set card as default
				Simba_Subscriptions_WC_Legacy::customer_update_meta_data($user_id, '_subscriben_stripe_customer_default_card', $response->default_source);

				// Return customer and card ids to charge
				return array(
					'customer_id'  => $response->id,
					'card_id'      => $response->default_source,
				);
			} elseif ('none' == $selected_card) {// Customer exists - we need to add a new card to its profile

				// Send request to add a new card
				$response = $this->send_request('cards', 'create', array(
					'id'     => $customer_id,
					'source' => $token,
				));

				// Errors?
				if (!empty($response->error)) {
					if (Simba_Subscriptions_Helper::string_contains_phrase($response->error->message, 'Stripe no longer supports API requests made with TLS')) {
						$order->add_order_note(__('Connection error.', 'subscriben-stripe') . ' ' . $response->error->message);
						return __('Connection error.', 'subscriben-stripe');
					}
					$response_localized_error_message = $this->get_localized_error_message_from_response($response);
					$order->add_order_note(__('Payment gateway error:', 'subscriben-stripe') . ' ' . $response_localized_error_message);
					return __('Payment gateway error:', 'subscriben-stripe') . ' ' . $response_localized_error_message;
				} elseif (!is_object($response) || !isset($response->id)) {
					return __('Unable to add a new card.', 'subscriben-stripe');
				}

				// Maybe update other cards with funding type
				$this->maybe_add_funding_type(get_current_user_id());

				// Check the type of new card before adding
				if (!$this->is_funding_type_allowed($response->funding)) {
					return sprintf(__('Unable to use a card with "%s" funding type. ', 'subscriben-stripe'), $response->funding);
				}

				// Save card details
				$existing_cards = Simba_Subscriptions_WC_Legacy::customer_get_meta($user_id, '_subscriben_stripe_customer_cards', true);
				$existing_cards = !empty($existing_cards) ? maybe_unserialize($existing_cards) : array();

				Simba_Subscriptions_WC_Legacy::customer_update_meta_data($user_id, '_subscriben_stripe_customer_cards', array_merge($existing_cards, array(
					$response->id => array(
						'brand'     => $response->brand,
						'funding'   => $response->funding,
						'exp_month' => $response->exp_month,
						'exp_year'  => $response->exp_year,
						'last4'     => $response->last4,
					),
				)));

				// Set card as default
				Simba_Subscriptions_WC_Legacy::customer_update_meta_data($user_id, '_subscriben_stripe_customer_default_card', $response->id);

				// Set card as default in Stripe
				$this->send_request('customers', 'update', array(
					'id'            => $customer_id,
					'default_source'  => $response->id,
				));

				// Return customer and card ids to charge
				return array(
					'customer_id'  => $customer_id,
					'card_id'      => $response->id,
				);
			} else {// Existing card selected by customer

				// Maybe update cards with funding type
				$this->maybe_add_funding_type(get_current_user_id());

				// Get all customer's cards
				$cards = Simba_Subscriptions_WC_Legacy::customer_get_meta($user_id, '_subscriben_stripe_customer_cards', true);

				if (empty($cards)) {
					return __('Such card does not exist.', 'subscriben-stripe');
				}

				$cards = maybe_unserialize($cards);

				// Check if selected card exists in user's card list
				if (empty($cards) || !is_array($cards) || !isset($cards[$selected_card])) {
					return __('Such card does not exist.', 'subscriben-stripe');
				}

				// Check the type of card
				if (!$this->is_funding_type_allowed($cards[$selected_card]['funding'])) {
					return sprintf(__('Unable to use a card with "%s" funding type. ', 'subscriben-stripe'), $cards[$selected_card]['funding']);
				}

				// Return customer and card ids to charge
				return array(
					'customer_id'  => $customer_id,
					'card_id'      => $selected_card,
				);
			}
		}

		/**
		 * Maybe update existing user cards with funding type value
		 *
		 * @access public
		 * @param int $user_id
		 * @return void
		 */
		public function maybe_add_funding_type($user_id) {
			// Get customer id and existing cards
			$customer_id = Simba_Subscriptions_WC_Legacy::customer_get_meta($user_id, '_subscriben_stripe_customer_id', true);
			$existing_cards = Simba_Subscriptions_WC_Legacy::customer_get_meta($user_id, '_subscriben_stripe_customer_cards', true);
			$existing_cards = !empty($existing_cards) ? maybe_unserialize($existing_cards) : array();

			// Build new array
			$updated_cards = $existing_cards;
			$updated = false;

			// Iterate and check all cards
			foreach ($existing_cards as $card_id => $card_data) {

				// Update funding if not set
				if (!isset($card_data['funding'])) {

					// Get card details
					$response = $this->send_request('cards', 'retrieve', array(
						'id'            => $customer_id,
						'secondary_id'  => $card_id,
					));

					$updated_cards = array_merge($updated_cards, array(
						$response->id => array(
							'brand'     => $response->brand,
							'funding'   => $response->funding,
							'exp_month' => $response->exp_month,
							'exp_year'  => $response->exp_year,
							'last4'     => $response->last4,
						),
					));

					$updated = true;
				}
			}

			// Update if needed
			if (true === $updated) {
				Simba_Subscriptions_WC_Legacy::customer_update_meta_data($user_id, '_subscriben_stripe_customer_cards', $updated_cards);
			}
		}

		/**
		 * Check if funding type of card is allowed
		 *
		 * @access public
		 * @param string $type
		 * @return bool
		 */
		public function is_funding_type_allowed($type) {
			// Don't check if not needed
			if ($this->get_option('restricted_funding_type') == 'none') {
				return true;
			}

			// Allow to add more types by using the filter
			$restricted_funding_types = apply_filters('subscriben_stripe_restricted_funding_types', array($this->get_option('restricted_funding_type')));

			// Empty type allowed by default
			return !empty($type) ? !in_array($type, $restricted_funding_types) : true;
		}

		/**
		 * Localize Stripe messages based on code
		 *
		 * @access public
		 * @return array
		 */
		public function get_localized_messages() {
			return apply_filters('subscriben_stripe_localized_messages', array(
				'invalid_number'           => __('The card number is not a valid credit card number.', 'subscriben-stripe'),
				'invalid_expiry_month'     => __('The card\'s expiration month is invalid.', 'subscriben-stripe'),
				'invalid_expiry_year'      => __('The card\'s expiration year is invalid.', 'subscriben-stripe'),
				'invalid_cvc'              => __('The card\'s security code is invalid.', 'subscriben-stripe'),
				'incorrect_number'         => __('The card number is incorrect.', 'subscriben-stripe'),
				'incomplete_number'        => __('The card number is incomplete.', 'subscriben-stripe'),
				'incomplete_cvc'           => __('The card\'s security code is incomplete.', 'subscriben-stripe'),
				'incomplete_expiry'        => __('The card\'s expiration date is incomplete.', 'subscriben-stripe'),
				'expired_card'             => __('The card has expired.', 'subscriben-stripe'),
				'incorrect_cvc'            => __('The card\'s security code is incorrect.', 'subscriben-stripe'),
				'incorrect_zip'            => __('The card\'s zip code failed validation.', 'subscriben-stripe'),
				'postal_code_invalid'      => __('Invalid zip code, please correct and try again', 'subscriben-stripe'),
				'invalid_expiry_year_past' => __('The card\'s expiration year is in the past', 'subscriben-stripe'),
				'card_declined'            => __('The card was declined.', 'subscriben-stripe'),
				'missing'                  => __('There is no card on a customer that is being charged.', 'subscriben-stripe'),
				'processing_error'         => __('An error occurred while processing the card.', 'subscriben-stripe'),
				'invalid_sofort_country'   => __('The billing country is not accepted by SOFORT. Please try another country.', 'subscriben-stripe'),
				'email_invalid'            => __('Invalid email address, please correct and try again.', 'subscriben-stripe'),
				'invalid_request_error'    => __('Unable to process this payment, please try again or use alternative method.', 'subscriben-stripe'),
				'amount_too_large'         => __('The order total is too high for this payment method', 'subscriben-stripe'),
				'amount_too_small'         => __('The order total is too low for this payment method', 'subscriben-stripe'),
				'country_code_invalid'     => __('Invalid country code, please try again with a valid country code', 'subscriben-stripe'),
				'tax_id_invalid'           => __('Invalid Tax Id, please try again with a valid tax id', 'subscriben-stripe'),
			));
		}

		/**
		 * Generates a localized message for an error from a response.
		 *
		 * @param stdClass $response The response from the Stripe API.
		 * @return string The localized error message.
		 */
		public function get_localized_error_message_from_response($response) {
			$localized_messages = $this->get_localized_messages();

			if ('card_error' === $response->error->type) {
				$localized_message = isset($localized_messages[$response->error->code]) ? $localized_messages[$response->error->code] : $response->error->message;
			} else {
				$localized_message = isset($localized_messages[$response->error->type]) ? $localized_messages[$response->error->type] : $response->error->message;
			}

			return $localized_message;
		}


		/**
		 * Charge the card (or token) or ask for an authorization
		 *
		 * @access public
		 * @param array $params
		 * @return object|string
		 */
		public function charge($params) {
			// Add defaults
			$params = array_merge(array(
				'capture' => $this->capture ? 'true' : 'false',
			), $params);

			// Send request
			$result = $this->send_request('charges', 'create', $params);

			if (!is_object($result)) {
				return __('We were not able to connect to the payment gateway. Please try again.', 'subscriben-stripe');
			}

			// Received error?
			if (!empty($result->error)) {

				if (Simba_Subscriptions_Helper::string_contains_phrase($result->error->message, 'Stripe no longer supports API requests made with TLS')) {
					return __('Connection error.', 'subscriben-stripe');
				}

				return __('Payment gateway error:', 'subscriben-stripe') . ' ' . $this->get_localized_error_message_from_response($result);
			}

			return $result;
		}

		/**
		 * Send request to Stripe
		 *
		 * @access public
		 * @param string $context
		 * @param string $action
		 * @param array  $params
		 * @return object|string
		 */
		public function send_request($context, $action, $params) {
			// Special case for customer's cards
			if ('cards' === $context) {
				$context = 'customers/' . $params['id'] . '/cards';
				unset($params['id']);
			}

			// Different actions require different endpoint URL
			switch ($action) {
				case 'update':
					$context = $context . '/' . $params['id'];
					unset($params['id']);
					break;
				case 'capture':
					$context = $context . '/' . $params['id'] . '/capture';
					unset($params['id']);
					break;
				case 'refund':
					$context = $context . '/' . $params['id'] . '/refund';
					unset($params['id']);
					break;
				case 'delete':
					$context = $context . '/' . $params['secondary_id'];
					unset($params['secondary_id']);
					break;
				case 'retrieve':
					$context = $context . '/' . $params['secondary_id'];
					unset($params['secondary_id']);
					break;
			}

			$result = wp_remote_post(
				$this->endpoint_url . 'v1/' . $context,
				array(
					'method'    => 'delete' !== $action ? 'POST' : 'DELETE',
					'headers'   => array(
						'Authorization'     => 'Basic ' . base64_encode($this->secret_key . ':'),// phpcs:ignore VariableAnalysis.CodeAnalysis.VariableAnalysis.UnusedVariable
						'Stripe-Version'    => '2018-09-24',
					),
					'body'      => $params,
					'sslverify' => Simba_Subscriptions::get_sslverify_value(),
					'timeout'   => 100,
				)
			);

			return is_wp_error($result) ? $result->get_error_message() : (empty($result['body']) ? __('Response body empty.', 'subscriben-stripe') : json_decode($result['body']));
		}

		/**
		 * Enqueue scripts on Checkout
		 *
		 * @access public
		 * @return void
		 */
		public function enqueue_scripts_on_checkout() {
			// Scripts only needed on the Checkout page
			if (!is_checkout() || Simba_Subscriptions::is_checkout_block()) {
				return;
			}

			// Different scripts for different Checkout styles
			if ('inline' == $this->checkout_style) {

				// External Stripe script
				wp_register_script('subscriben_stripe_js', 'https://js.stripe.com/v2/');

				// jQuery Payment Plugin
				if (!wp_script_is('jquery-payment', 'registered')) {
					wp_register_script('jquery-payment', SUBSCRIBEN_PLUGIN_URL . '/assets/gateways/stripe/js/jquery.payment.min.js', array('jquery'), '1.1.2');
				}

				// Plugin's script
				wp_register_script('subscriben_stripe_inline', SUBSCRIBEN_PLUGIN_URL . '/assets/gateways/stripe/js/frontend_inline.js', array('jquery'), SUBSCRIBEN_VERSION);

				// Pass Stripe config to frontend
				$this->add_stripe_config('subscriben_stripe_inline');

				// Add billing details if payment is being made
				if (function_exists('is_checkout_pay_page') ? is_checkout_pay_page() : is_page(wc_get_page_id('pay'))) {
					$this->add_billing_details('subscriben_stripe_inline');
				}

				// Enqueue scripts
				wp_enqueue_script('subscriben_stripe_js');
				wp_enqueue_script('jquery-payment');
				wp_enqueue_script('subscriben_stripe_inline');
			} else {

				// External Stripe script
				wp_register_script('subscriben_stripe_checkout_js', 'https://checkout.stripe.com/checkout.js');

				// Plugin's script
				wp_register_script('subscriben_stripe_modal', SUBSCRIBEN_PLUGIN_URL . '/assets/gateways/stripe/js/frontend_modal.js', array('jquery'), SUBSCRIBEN_VERSION);

				// Pass Stripe config to frontend
				$this->add_stripe_config('subscriben_stripe_modal');

				// Add billing details if payment is being made
				if (function_exists('is_checkout_pay_page') ? is_checkout_pay_page() : is_page(wc_get_page_id('pay'))) {
					$this->add_billing_details('subscriben_stripe_modal');
				}

				// Enqueue scripts
				wp_enqueue_script('subscriben_stripe_checkout_js');
				wp_enqueue_script('subscriben_stripe_modal');
			}
		}

		/**
		 * Pass Stripe config to frontend
		 *
		 * @access public
		 * @param string $handle
		 * @return void
		 */
		public function add_stripe_config($handle) {
			$woocommerce = WC();

			// Payment for existing order?
			if ('GET' === $_SERVER['REQUEST_METHOD'] && !empty($_GET['order_id'])) {
				$order = wc_get_order((int) $_GET['order_id']);
			}

			wp_localize_script($handle, 'subscriben_stripe_config', array(
				'checkout_name'                 => apply_filters('subscriben_stripe_checkout_modal_name', get_bloginfo('name')),
				'checkout_description'          => apply_filters('subscriben_stripe_checkout_modal_description', ''),
				'checkout_label'                => apply_filters('subscriben_stripe_checkout_modal_button_title', __('Pay Now', 'subscriben-stripe')),
				'checkout_image'                => apply_filters('subscriben_stripe_checkout_modal_image_url', $this->checkout_image),
				'checkout_amount'               => $woocommerce->cart->total * Simba_Subscriptions_Stripe_Gateway::get_currency_multiplier(),
				'checkout_currency'             => strtolower(get_woocommerce_currency()),
				'checkout_email'                => isset($order) && gettype($order) == 'object' && isset($order->billing_method) ? Simba_Subscriptions_WC_Legacy::order_get_billing_email($order) : '',
				'publishable_key'               => $this->publishable_key,
				'error_incorrect_number'        => __('The card number is incorrect.', 'subscriben-stripe'),
				'error_invalid_number'          => __('The card number is not a valid credit card number.', 'subscriben-stripe'),
				'error_invalid_expiry_month'    => __("The card's expiration month is invalid.", 'subscriben-stripe'),
				'error_invalid_expiry_year'     => __("The card's expiration year is invalid.", 'subscriben-stripe'),
				'error_invalid_cvc'             => __("The card's security code is invalid.", 'subscriben-stripe'),
				'error_expired_card'            => __('The card has expired.', 'subscriben-stripe'),
				'error_incorrect_cvc'           => __("The card's security code is incorrect.", 'subscriben-stripe'),
				'error_incorrect_zip'           => __("The card's zip code failed validation.", 'subscriben-stripe'),
				'error_card_declined'           => __('The card was declined.', 'subscriben-stripe'),
				'error_missing'                 => __('The customer has no card to charge.', 'subscriben-stripe'),
				'error_processing_error'        => __('An error occurred while processing the card.', 'subscriben-stripe'),
				'error_rate_limit'              => __("An error occurred due to requests hitting the API too quickly. Please let us know if you're consistently running into this error.", 'subscriben-stripe'),
			));
		}

		/**
		 * Pass buyer details to Stripe scripts
		 *
		 * @access public
		 * @param string $handle
		 * @return void
		 */
		public function add_billing_details($handle) {
			// Payment for existing order?
			if ('GET' === $_SERVER['REQUEST_METHOD'] && !empty($_GET['order_id'])) {
				$order = wc_get_order((int) $_GET['order_id']);
			}

			// Check if order payment keys match
			if (isset($order) && 'object' === gettype($order) && isset($order->order_key) && urldecode($_GET['order']) == $order->order_key) {
				wp_localize_script($handle, 'subscriben_stripe_billing_details', array(
					'billing_first_name'    => Simba_Subscriptions_WC_Legacy::order_get_billing_first_name($order),
					'billing_last_name'     => Simba_Subscriptions_WC_Legacy::order_get_billing_last_name($order),
					'billing_full_name'     => Simba_Subscriptions_WC_Legacy::order_get_billing_first_name($order) . ' ' . Simba_Subscriptions_WC_Legacy::order_get_billing_last_name($order),
					'billing_address_1'     => Simba_Subscriptions_WC_Legacy::order_get_billing_address_1($order),
					'billing_address_2'     => Simba_Subscriptions_WC_Legacy::order_get_billing_address_2($order),
					'billing_state'         => Simba_Subscriptions_WC_Legacy::order_get_billing_state($order),
					'billing_city'          => Simba_Subscriptions_WC_Legacy::order_get_billing_city($order),
					'billing_postcode'      => Simba_Subscriptions_WC_Legacy::order_get_billing_postcode($order),
					'billing_country'       => Simba_Subscriptions_WC_Legacy::order_get_billing_country($order),
				));
			}
		}

		/**
		 * Initialize form fields
		 *
		 * @access public
		 * @return void
		 */
		public function init_form_fields() {
			$this->form_fields = array(
				'enabled' => array(
					'title'   => __('Enable/Disable', 'subscriben-stripe'),
					'type'    => 'checkbox',
					'label'   => __('Enable Stripe payment gateway', 'subscriben-stripe'),
					'default' => 'no',
				),
				'debug' => array(
					'title'   => __('Test Mode', 'subscriben-stripe'),
					'type'    => 'checkbox',
					'label'   => __('Enable test & debug mode', 'subscriben-stripe'),
					'default' => 'no',
				),
				'enable_log' => array(
					'title'   => __('Enable Log', 'subscriben-stripe'),
					'type'    => 'checkbox',
					'label'   => __('Enable logging of Stripe operations', 'subscriben-stripe'),
					'default' => 'yes',
				),
				'only_existing' => array(
					'title'         => __('Only Existing Subscriptions', 'subscriben-stripe'),
					'type'          => 'checkbox',
					'label'         => __('Only available for existing subscriptions, not new orders', 'subscriben-stripe'),
					'description'   => __('If checked, this payment gateway will be hidden on the checkout, and will only be used to process existing subscriptions that used this payment gateway.', 'subscriben-stripe'),
					'default'       => 'no',
				),
				'capture' => array(
					'title'         => __('Capture Immediately', 'subscriben-stripe'),
					'type'          => 'checkbox',
					'label'         => __('Capture the charge immediately', 'subscriben-stripe'),
					'description'   => __('If unchecked, an authorization is issued at the time of purchase but the charge itself is captured when you start processing the order. Uncaptured charges expire in 7 days.', 'subscriben-stripe'),
					'default'       => 'yes',
				),
				'title' => array(
					'title'       => __('Title', 'subscriben-stripe'),
					'type'        => 'text',
					'description' => __('The title which the user sees during checkout.', 'subscriben-stripe'),
					'default'     => __('Credit Card - Stripe', 'subscriben-stripe'),
				),
				'description' => array(
					'title'       => __('Description', 'subscriben-stripe'),
					'type'        => 'textarea',
					'description' => __('The description which the user sees during checkout.', 'subscriben-stripe'),
					'default'     => __('Pay Securely via Stripe', 'subscriben-stripe'),
				),
				'checkout_style' => array(
					'title'       => __('Checkout Style', 'subscriben-stripe'),
					'type'        => 'select',
					'description' => __('Control how credit card details fields appear on your page.', 'subscriben-stripe'),
					'default'     => 'inline',
					'options'     => array(
						'inline'    => __('Inline', 'subscriben-stripe'),
						'modal'     => __('Modal', 'subscriben-stripe'),
					),
				),
				'restricted_funding_type' => array(
					'title'       => __('Restricted type of cards', 'subscriben-stripe'),
					'type'        => 'select',
					'description' => __('Restrict the use of some card funding type.', 'subscriben-stripe'),
					'default'     => 'none',
					'options'     => array(
						'none'    => __('None', 'subscriben-stripe'),
						'debit'    => __('Debit', 'subscriben-stripe'),
						'credit'     => __('Credit', 'subscriben-stripe'),
						'prepaid'     => __('Prepaid', 'subscriben-stripe'),
						'unknown'     => __('Unknown', 'subscriben-stripe'),
					),
				),
				'checkout_image' => array(
					'title'       => __('Checkout Image', 'subscriben-stripe'),
					'type'        => 'text',
					'description' => __('Stripe Checkout modal allows custom seller image to be displayed. Enter your custom 128x128 px image URL here (should be hosted on a secure location).', 'subscriben-stripe'),
					'default'     => '',
				),
				'test_secret_key' => array(
					'title'       => __('Test Secret Key', 'subscriben-stripe'),
					'type'        => 'text',
					'description' => __('Test Secret Key from your Stripe Account (under Account Settings > API Keys).', 'subscriben-stripe'),
					'default'     => '',
				),
				'test_publishable_key' => array(
					'title'       => __('Test Publishable Key', 'subscriben-stripe'),
					'type'        => 'text',
					'description' => __('Test Publishable Key from your Stripe Account.', 'subscriben-stripe'),
					'default'     => '',
				),
				'live_secret_key' => array(
					'title'       => __('Live Secret Key', 'subscriben-stripe'),
					'type'        => 'text',
					'description' => __('Live Secret Key from your Stripe Account.', 'subscriben-stripe'),
					'default'     => '',
				),
				'live_publishable_key' => array(
					'title'       => __('Live Publishable Key', 'subscriben-stripe'),
					'type'        => 'text',
					'description' => __('Live Publishable Key from your Stripe Account.', 'subscriben-stripe'),
					'default'     => '',
				),
			);
		}

		/**
		 * Credit card details form on Checkout
		 *
		 * @access public
		 * @return void
		 */
		public function payment_fields() {
			// Get user cards
			extract($this->get_user_cards());

			Simba_Subscriptions::include_template('gateways/stripe/credit-card-form', array(
				'id'              => $this->id,
				'description'     => $this->description,
				'cards'           => $cards,
				'default_card'    => $default_card,
				'is_debug'        => 'yes' == $this->debug ? true : false,
				'is_inline'       => 'inline' == $this->checkout_style ? true : false,
				'checkout_amount' => $this->get_checkout_amount(),
			));
		}
		
		/**
		 * Get user cards
		 *
		 * @access public
		 * @return array
		 */
		public function get_user_cards() {			
			// User logged in?
			if (is_user_logged_in()) {

				$user_id = get_current_user_id();

				// Get customer's cards
				$cards = Simba_Subscriptions_WC_Legacy::customer_get_meta($user_id, '_subscriben_stripe_customer_cards', true);

				if (!empty($cards)) {
					$cards = maybe_unserialize($cards);

					// Format card names
					foreach ($cards as $card_id => $card) {
						$brand = 'Unknown' != $card['brand'] ? $card['brand'] : __('Card', 'subscriben-stripe');
						$exp = Simba_Subscriptions_Stripe::format_expiration_date($card['exp_month'], $card['exp_year']);
						$cards[$card_id] = $brand . ' ' . __('ending with', 'subscriben-stripe') . ' ' . $card['last4'] . ' (' . __('expires', 'subscriben-stripe') . ' ' . $exp . ')';
					}

					$cards['none'] = __('New Credit Card', 'subscriben-stripe');
				} else {
					$cards = array();
				}

				// Get customer's default card
				$default_card = Simba_Subscriptions_WC_Legacy::customer_get_meta($user_id, '_subscriben_stripe_customer_default_card', true);
				$default_card = !empty($default_card) ? $default_card : 'none';
			} else {
				$cards = array();
				$default_card = 'none';
			}
			
			return compact('cards', 'default_card');
		}
		
		/**
		 * Get checkout amount
		 *
		 * @return float
		 */
		public function get_checkout_amount() {
			$woocommerce = WC();
			$cart_total  = ! is_null( $woocommerce->cart ) ? $woocommerce->cart->total : 0;
			
			return $cart_total * Simba_Subscriptions_Stripe_Gateway::get_currency_multiplier();
		} 

		/**
		 * Process refund manually issued from order page
		 *
		 * @access public
		 * @param int   $order_id
		 * @param float $amount
		 * @return bool
		 */
		public function process_refund($order_id, $amount = null, $reason = '') {// phpcs:ignore VariableAnalysis.CodeAnalysis.VariableAnalysis.UnusedVariable -- $reason PHP 8 required overloaded methods to have matching signatures
			// Load order
			$order = wc_get_order($order_id);

			if (!$order) {
				return;
			}

			// Get charge id
			$charge_id = $order->get_meta('_subscriben_stripe_charge_id');

			if (empty($charge_id)) {
				return;
			}

			// Send request to refund payment
			$response = $this->send_request('charges', 'refund', array(
				'id'        => $charge_id,
				'amount'    => $amount * Simba_Subscriptions_Stripe_Gateway::get_currency_multiplier($order),
			));

			// Request failed?
			if (!is_object($response)) {
				$order->add_order_note(__('Stripe refund failed.', 'subscriben-stripe') . ' ' . $response);
				return false;
			}

			// Received error from Stripe?
			if (!empty($response->error)) {
				$order->add_order_note(__('Stripe refund failed.', 'subscriben-stripe') . ' ' . $this->get_localized_error_message_from_response($response));
				return false;
			}

			// Request was successful
			$order->add_order_note(sprintf(__('%s of Stripe charge %s refunded.', 'subscriben-stripe'), Simba_Subscriptions::get_formatted_price($amount), $response->id));
			return true;
		}

		/**
		 * Get currency multiplier
		 *
		 * @access public
		 * @param object $order
		 * @return int
		 */
		public static function get_currency_multiplier($order = null) {
			// Define currencies with no decimals
			$currencies_with_no_decimals = array('BIF', 'CLP', 'DJF', 'GNF', 'JPY', 'KMF', 'KRW', 'MGA', 'PYG', 'RWF', 'VND', 'VUV', 'XAF', 'XOF', 'XPF');

			// Get currency
			$currency = (null !== $order ? $order->get_currency() : get_woocommerce_currency());

			// Get multiplier by currency
			$multiplier = in_array($currency, $currencies_with_no_decimals, true) ? 1 : 100;

			// Allow developers to override
			return absint(apply_filters('subscriben_stripe_decimals_in_currency', $multiplier, $order));
		}

		/**
		 * Maybe hide on checkout
		 *
		 * @access public
		 * @param array $gateways
		 * @return void
		 */
		public function maybe_hide_on_checkout($gateways) {
			if (is_checkout() && true === $this->only_existing && isset($gateways['subscriben_stripe'])) {
				unset($gateways['subscriben_stripe']);
			}

			return $gateways;
		}
	}
}
