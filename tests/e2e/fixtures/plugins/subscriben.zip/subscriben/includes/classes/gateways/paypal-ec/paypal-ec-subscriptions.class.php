<?php
if (!defined('ABSPATH')) die('No direct access.');

/**
 * Methods related to subscriptions
 *
 * @class Simba_Subscriptions_PayPal_EC_Subscriptions
 * @package Simba_Subscriptions
 */
if (!class_exists('Simba_Subscriptions_PayPal_EC_Subscriptions')) {

	class Simba_Subscriptions_PayPal_EC_Subscriptions {


		/**
		 * Constructor class
		 *
		 * @access public
		 * @return void
		 */
		public function __construct() {
			// Process payment
			add_filter('subscriben_automatic_payment_subscriben_paypal_ec', array($this, 'process_payment'), 10, 3);

			// Save billing agreement id
			add_action('woocommerce_order_status_processing', array($this, 'save_billing_agreement_id'));
			add_action('woocommerce_order_status_completed', array($this, 'save_billing_agreement_id'));
		}


		/**
		 * Get billing agreement ID
		 *
		 * @access public
		 * @param obj $order
		 * @param obj $subscription
		 * @return bool|string
		 */
		public static function get_billing_agreement_id($order = null, $subscription = null) {
			// Get billing agreement ID from anywhere (redundancy is fine)
			$billing_agreement_id = '';

			if (!is_null($subscription)) {
				$billing_agreement_user = Simba_Subscriptions_WC_Legacy::customer_get_meta($subscription->user_id, '_subscriben_paypal_ec_billing_agreement', true);
				$billing_agreement_subscription = get_post_meta($subscription->id, '_subscriben_paypal_ec_billing_agreement', true);

				$billing_agreement_id = !empty($billing_agreement_subscription) ? $billing_agreement_subscription : $billing_agreement_user;
			} elseif (!is_null($order)) {
				$billing_agreement_order = $order->get_meta('_subscriben_paypal_ec_billing_agreement');
				$billing_agreement_order_user = Simba_Subscriptions_WC_Legacy::customer_get_meta(Simba_Subscriptions_WC_Legacy::order_get_customer_id($order), '_subscriben_paypal_ec_billing_agreement', true);

				$billing_agreement_id = !empty($billing_agreement_order) ? $billing_agreement_order : $billing_agreement_order_user;
			}

			return !empty($billing_agreement_id) ? $billing_agreement_id : false;
		}


		/**
		 * Save billing agreement id to subscription(s)
		 *
		 * @access public
		 * @param int $order_id
		 * @return void
		 */
		public function save_billing_agreement_id($order_id) {
			
			$order = wc_get_order($order_id);
			if ('subscriben_paypal_ec' != $order->get_payment_method()) return;
			
			// Get subscriptions from order
			$subscriptions = Simba_Subscriptions_Order_Handler::get_subscriptions_from_order_id($order_id);

			if (empty($subscriptions)) return;
			
			// And set preapproval keys for those subscriptions
			foreach ($subscriptions as $subscription) {

				$billing_agreement_id = Simba_Subscriptions_WC_Legacy::customer_get_meta($subscription->user_id, '_subscriben_paypal_ec_billing_agreement', true);
				$post_meta_billing_agreement_id = get_post_meta($subscription->id, '_subscriben_paypal_ec_billing_agreement', true);

				if (empty($post_meta_billing_agreement_id)) {
					update_post_meta($subscription->id, '_subscriben_paypal_ec_billing_agreement', $billing_agreement_id);
				}
			}
		}


		/**
		 * Process the result of subscription payment
		 *
		 * @access public
		 * @param string $billing_agreement_id
		 * @param obj    $order
		 * @param float  $amount_to_charge     Optional amount to charge in the transaciton. If false defaults to order total
		 * @return bool|string
		 */
		public static function do_reference_transaction($billing_agreement_id, $order, $amount_to_charge = false) {
			// Load payment gateway object to access its methods
			$gateway = new Simba_Subscriptions_PayPal_EC_Gateway(null, false);
			
			$total_amount = (false === $amount_to_charge) ? Simba_Subscriptions_WC_Legacy::order_get_total($order) : $amount_to_charge;
			
			/**
			 * Local debugging: attempt to catch and debug the issue of occasional 1 unit additional charges
			 */
			if (1 == $total_amount && DB_NAME == 'updraftpluscom') {
				error_log("Subscriben charge of 1 unit (".serialize($total_amount).", amount_to_charge=".serialize($amount_to_charge)."): ".wp_debug_backtrace_summary());
			}

			// Create payment_request fields
			$payment_request_object = new Simba_Subscriptions_PayPal_EC_Payment_Request($order);
			$payment_request = $payment_request_object->get_payment_array();
			
			$request = array(
				'METHOD'        => 'DoReferenceTransaction',
				'REFERENCEID'   => $billing_agreement_id,
				'AMT'           => $total_amount,
				'PAYMENTACTION' => 'Sale',
				'CURRENCYCODE'  => strtoupper($order->get_currency()),
				'NOTIFYURL'     => WC()->api_request_url('Simba_Subscriptions_PayPal_EC_Gateway'),
				'CUSTOM'        => maybe_serialize(array('order_id' => Simba_Subscriptions_WC_Legacy::order_get_id($order))),
			);

			// Pass order items to paypal request
			$items = self::get_items($payment_request);
			$request = array_merge($request, $items);

			// Prepare the NVP string
			$nvp_request = $gateway->get_credentials() . Simba_Subscriptions_PayPal_EC_NVP::create_nvp_from_array($request);

			$nvp_response = $gateway->send_curl_request($nvp_request);

			return Simba_Subscriptions_PayPal_EC_NVP::convert_nvp_to_array($nvp_response);
		}

		/**
		 * Get order items
		 *
		 * @access public
		 * @param array $payment_request
		 * @return array
		 */
		public static function get_items($payment_request) {

			$items_arr = array();
			foreach ($payment_request as $field_key => $value) {

				if ('_items' != $field_key) continue;
				
				$item_num = 0;
				foreach ($value as $item) {
					foreach ($item as $item_field => $item_value) {
						$item_name_key='L_' . $item_field . $item_num;
						$items_arr[$item_name_key] = $item_value;
					}
					$item_num++;
				}
			}
			return $items_arr;
		}

		/**
		 * Process the result of subscription payment
		 *
		 * @access public
		 * @param obj     $order
		 * @param array   $response
		 * @param boolean $auto
		 * @return bool|string
		 */
		public static function process_result($order, $response, $auto = true) {
			// Load payment gateway object to write the log
			$gateway = new Simba_Subscriptions_PayPal_EC_Gateway(null, false);

			// Check for cURL error
			if (isset($response['error'])) {
				$error_message = __('Error connecting to PayPal (Subscription payment): ', 'subscriben-paypal-ec') . $response['error'];
				$order->add_order_note($error_message);
				$gateway->wc_logger->log($error_message);
				return false;
			}

			// Get results
			$transaction_id = isset($response['TRANSACTIONID']) ? $response['TRANSACTIONID'] : '';
			$result_message = isset($response['ACK']) ? $response['ACK'] : '';
			$payment_status = isset($response['PAYMENTSTATUS']) ? $response['PAYMENTSTATUS'] : '';

			// Request was successful
			if (in_array($result_message, array('Success', 'SuccessWithWarning'))) {

				// Create notes
				$payment_type = $auto ? __('Automatic', 'subscriben-paypal-ec') : __('Manual', 'subscriben-paypal-ec');
				$order_note = sprintf(__('%s PayPal Express Checkout subscription payment operation completed (payment status: %s, transaction id: %s)', 'subscriben-paypal-ec'), $payment_type, $payment_status, $transaction_id);
				$log_entry = sprintf(__('%s subscription payment operation completed (payment status: %s, transaction id: %s)', 'subscriben-paypal-ec'), $payment_type, $payment_status, $transaction_id);

				// Payment completed
				if (in_array($payment_status, array('Completed', 'Processed'))) {

					// Complete the order
					$order->payment_complete($transaction_id);
				} else {// Pending and other statuses
					if ('Pending' == $payment_status && isset($response['PENDINGREASON'])) {
						$pending_reason_key = $response['PENDINGREASON'];
						$pending_reason = Simba_Subscriptions_PayPal_EC_Gateway::get_pending_reason($pending_reason_key);
						$log_entry .= sprintf(__(' Pending reason: %s (%s)', 'subscriben-paypal-ec'), $pending_reason_key, $pending_reason);
					}
				}

				// Write notes
				$order->add_order_note($order_note);
				$gateway->wc_logger->log($log_entry, 'info');

				// Create transaction url notes
				$transaction_url = $gateway->get_transaction_url($order);
				if ($transaction_url) {
					$payment_via = ' (<a href="' . esc_url($transaction_url) . '" target="_blank">' . esc_html($transaction_id) . '</a>)';
					$order_transaction_url_note = sprintf(__('PayPal Express Checkout Transaction URL: %s', 'subscriben-paypal-ec'), $payment_via);
					$order->add_order_note($order_transaction_url_note);
				}

				// Save transaction id
				Simba_Subscriptions_WC_Legacy::order_update_meta_data($order, '_subscriben_paypal_ec_transaction_id', $transaction_id);

				// Add payment method
				Simba_Subscriptions_WC_Legacy::order_update_meta_data($order, '_payment_method', $gateway->id);
				Simba_Subscriptions_WC_Legacy::order_update_meta_data($order, '_payment_method_title', $gateway->title);

				// Save transaction id
				Simba_Subscriptions_WC_Legacy::order_update_meta_data($order, '_subscriben_paypal_ec_transaction_id', $transaction_id);

				return true;
			} else {
				$paypal_error = array(
					'full_response' => $response,
					'error_code'    => isset($response['L_ERRORCODE0']) ? $response['L_ERRORCODE0'] : '',
					'severity_code' => isset($response['L_SEVERITYCODE0']) ? $response['L_SEVERITYCODE0'] : '',
					'short_msg'     => isset($response['L_SHORTMESSAGE0']) ? $response['L_SHORTMESSAGE0'] : '',
					'long_msg'      => isset($response['L_LONGMESSAGE0']) ? $response['L_LONGMESSAGE0'] : '',
				);

				// Log error
				$gateway->wc_logger->log(__('Subscription payment request failed with error: ', 'subscriben-paypal-ec') . $paypal_error['long_msg']);

				// Get the correct message
				$error_message = !empty($paypal_error['long_msg']) ? $paypal_error['long_msg'] : $paypal_error['short_msg'];
				$error_message = __(($auto ? 'Automatic ' : '') . 'PayPal Express Checkout subscription payment failed with message: ', 'subscriben-paypal-ec') . $error_message;

				$order->add_order_note($error_message);
				$gateway->wc_logger->log($error_message);

				return false;
			}
		}

		/**
		 * Process automatic subscription payment
		 *
		 * @access public
		 * @param bool  $payment_successful
		 * @param array $order
		 * @param array $subscription
		 * @return bool
		 */
		public function process_payment($payment_successful, $order, $subscription) {
			// Get billing agreement ID
			$billing_agreement_id = self::get_billing_agreement_id($order, $subscription);

			if (false === $billing_agreement_id) {

				$error_message = __('Automatic subscription payment failed: billing agreement ID not found (PayPal)', 'subscriben-paypal-ec');
				$order->add_order_note($error_message);

				// Add to log
				$gateway = new Simba_Subscriptions_PayPal_EC_Gateway(null, true);
				$gateway->wc_logger->log($error_message);

				return false;
			}

			$response = self::do_reference_transaction($billing_agreement_id, $order);

			return self::process_result($order, $response, true);
		}

		/**
		 * Process renewal order payment
		 *
		 * We have to add $amount_to_charge here, due to support for the WC Simba_Subscriptions API.
		 * This is because Simba_Subscriptions processes automated payments on a subscription level, but the
		 * WC hooks are fired within the scope of an order. But an order can technically contain other products
		 * so the order total isn't necessarily what we want to be charging.
		 *
		 * @access public
		 * @param array $order
		 * @param float $amount_to_charge
		 * @return bool
		 */
		public static function process_renewal_order_payment($order, $amount_to_charge = false) {
			// Get billing agreement ID
			$billing_agreement_id = self::get_billing_agreement_id($order);

			if (false === $billing_agreement_id) {
				return false;
			}

			$response = self::do_reference_transaction($billing_agreement_id, $order, $amount_to_charge);

			return self::process_result($order, $response, false);
		}
	}
	new Simba_Subscriptions_PayPal_EC_Subscriptions();
}
