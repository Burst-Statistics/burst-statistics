<?php
/**
 * Exit if accessed directly
 */
if (!defined('ABSPATH')) die('No direct access.');

/**
 * Integration with affiliate wp plugins
 *
 * @class Simba_Subscriptions_Affiwp
 * @package Simba_Subscriptions
 */
if (!class_exists('Simba_Subscriptions_Affiwp')) {

	class Simba_Subscriptions_Affiwp extends Affiliate_WP_WooCommerce {

		/**
		 * Constructor class
		 *
		 * @access public
		 * @return void
		 */
		public function __construct() {

			add_filter('affwp_settings_tabs', array($this, 'subscriben_referral_tab'));
			add_filter('affwp_settings', array($this, 'subscriben_referral_tab_settings_fields'));

			$enable_recurring_referrals = affiliate_wp()->settings->get('enable_recurring_referrals');
			if (1 == $enable_recurring_referrals) {
				add_action('subscriben_created_renewal_order', array($this, 'create_pending_referral_for_recurring_order'), 10, 3);
				add_filter('affwp_referral_table_columns', array($this, 'add_referral_type_column'), 10, 1);
				add_filter('affwp_referral_table_referral_type', array($this, 'display_referral_type_value'), 10, 2);
			}
		}

		/**
		 * Create referral for subscription renewal order.
		 *
		 * @access public
		 * @param object $subscription Subscription object.
		 * @param int 	 $order_id     renewal order id
		 * @param object $order        renewal order object
		 * @return void
		 */
		public function create_pending_referral_for_recurring_order($subscription, $order_id, $order) {

			$all_subscription_orders = $subscription->all_order_ids;
			if (count($all_subscription_orders) > 1) {
				sort($all_subscription_orders, SORT_NUMERIC);
			}
			
			$first_order = $all_subscription_orders[0];
			
			$parent_order_referral = $this->was_parent_order_referred($first_order);
			// Check if it was either referred or a coupon.
			if (!$parent_order_referral) {
				return false;
			}
			
			$affiliate_id = $parent_order_referral->affiliate_id;
			
			$eligible_affiliates = affiliate_wp()->settings->get('eligible_affiliates');
			
			$affiliate_name = affwp_get_affiliate_username($affiliate_id);

			if (is_array($eligible_affiliates) && !in_array($affiliate_name, $eligible_affiliates)) {
				return;
			}

			$args = array(
				'status'       => 'draft',
				'reference'    => $order_id,
				'description'  => $parent_order_referral->description,
				'campaign'     => affiliate_wp()->tracking->get_campaign(),
				'affiliate_id' => $affiliate_id,
				'visit_id'     => 1,
				'type'         => 'sale',
				'context'      => 'woocommerce',
				'customer'     => $this->get_customer($order_id),
			);
			if (affiliate_wp()->settings->get('disable_ip_logging')) {
				$args['customer']['ip'] = '';
			}
			
			$referral_id = affiliate_wp()->referrals->add($args);
			if (! $referral_id) {
				$this->log('Draft referral creation failed.');
				return false;
			}
			
			if ($this->is_affiliate_email($this->email, $affiliate_id)) {
				$this->log('Draft referral rejected because affiliate\'s own account was used.');
				$this->mark_referral_failed($referral_id);
				return false;
			}

			$cart_shipping = (float) $order->get_total_shipping();

			if (! affiliate_wp()->settings->get('exclude_tax')) {
				$cart_shipping += (float) $order->get_shipping_tax();
			}

			if (affwp_is_per_order_rate($affiliate_id)) {

				$amount = $this->calculate_referral_amount();

			} else {

				$items = $order->get_items();

				// Calculate the referral amount based on product prices.
				$amount = 0.00;

				foreach ($items as $product) {
					$product_obj = wc_get_product($product['product_id']);
					if ($product_obj->get_meta('_affwp_woocommerce_referrals_disabled', true)) {
						continue;
					}

					if (! empty($product['variation_id'])) {
						$product_obj = wc_get_product($product['variation_id']);
						if ($product_obj->get_meta('_affwp_woocommerce_referrals_disabled', true)) {
							continue;
						}
					}

					// Get the categories associated with the download.
					$categories = get_the_terms($product['product_id'], 'product_cat');

					// Get the first category ID for the product.
					$category_id = $categories && ! is_wp_error($categories) ? $categories[0]->term_id : 0;

					// The order discount has to be divided across the items.
					$product_total = $product['line_total'];
					$shipping      = 0;

					if ($cart_shipping > 0 && ! affiliate_wp()->settings->get('exclude_shipping')) {
						$shipping       = $cart_shipping / count($items);
						$product_total += $shipping;
					}

					if (! affiliate_wp()->settings->get('exclude_tax')) {
						$product_total += $product['line_tax'];
					}

					if ($product_total <= 0 && 'flat' !== affwp_get_affiliate_rate_type($affiliate_id)) {
						continue;
					}

					$product_id_for_rate = $product['product_id'];

					if (! empty($product['variation_id']) && $this->get_product_rate($product['variation_id'])) {
						$product_id_for_rate = $product['variation_id'];
					}

					$amount += $this->calculate_referral_amount($product_total, $order_id, $product_id_for_rate, $affiliate_id, $category_id);
				}
			}

			$amount = apply_filters('affwp_woocommerce_add_pending_referral_amount', $amount, $order_id, $affiliate_id);

			if (0 == $amount && affiliate_wp()->settings->get('ignore_zero_referrals')) {
				$this->log('Draft referral failed due to 0.00 amount and ignore_zero_referrals setting.');
				$this->mark_referral_failed($referral_id);
				return false;
			}

			$order_total = $order instanceof WC_Order ? $order->get_total() : 0;
			$products = $order instanceof WC_Order ? $this->get_order_products($order, $order_id) : '';
			
			$this->hydrate_referral(
				$referral_id,
				array(
					'status'      => 'pending',
					'amount'      => $amount,
					'order_total' => $order_total,
					'products'    => $products,
				)
			);
			affiliate_wp()->referral_meta->add_meta($referral_id, 'referral_type', 'Referral - renewal');
			$this->log(sprintf('WooCommerce referral #%d updated successfully.', $referral_id));
			
		}

		/**
		 * Check whether parent order was referred. If yes, then return reeferral object.
		 *
		 * @param int $parent_order_id Parent order id
		 * @return boolean|object
		 */
		public function was_parent_order_referred($parent_order_id) {
			
			$referral = affwp_get_referral_by('reference', $parent_order_id, 'woocommerce');
			if (!is_wp_error($referral)) {
				return $referral;
			}
			return false;
		}

		/**
		 * Get referral products of order.
		 *
		 * @access public
		 * @param object $order    Order object
		 * @param int    $order_id order id
		 * @return array
		 */
		public function get_order_products($order, $order_id) {

			$products  = array();
			$items     = $order->get_items();
			foreach ($items as $product) {
				$product_obj = wc_get_product($product['product_id']);

				if ($product_obj->get_meta('_affwp_woocommerce_referrals_disabled', true)) {
					continue;
				}

				if (! empty($product['variation_id'])) {
					$product_obj = wc_get_product($product['variation_id']);
					if ($product_obj->get_meta('_affwp_woocommerce_referrals_disabled', true)) {
						continue;
					}
				}

				if (! affiliate_wp()->settings->get('exclude_tax')) {
					$amount = $product['line_total'] + $product['line_tax'];
				} else {
					$amount = $product['line_total'];
				}

				if (! empty($product['variation_id'])) {
					$product['name'] .= ' ' . sprintf(__('(Variation ID %d)', 'subscriben'), $product['variation_id']);
				}

				$products[] = apply_filters('affwp_woocommerce_get_products_line', array(
					'name'            => $product['name'],
					'id'              => $product['product_id'],
					'price'           => $amount,
					'referral_amount' => $this->calculate_referral_amount($amount, $order_id, $product['product_id'])
				), $product, $order_id);

			}

			return $products;

		}

		/**
		 * Settings tab for Subscriben recurring refferals.
		 *
		 * @access public
		 * @param array $tabs array of tabs.
		 * @return array
		 */
		public function subscriben_referral_tab($tabs) {
			return array_merge(
				$tabs,
				array_filter(
					array(
						'subscriben_referrals' => __('Subscriben Recurring Referrals', 'subscriben')
					)
				)
			);
		}

		/**
		 * Settings tab for Subscriben recurring refferals.
		 *
		 * @access public
		 * @param array $settings settings fields.
		 * @return array
		 */
		public function subscriben_referral_tab_settings_fields($settings) {
			
			$settings['subscriben_referrals'] = array(
				'enable_recurring_referrals' => array(
					'name' => __('Enable Recurring Referrals', 'subscriben'),
					'desc' => __('New referral will created on each subscription renewal', 'subscriben'),
					'type' => 'checkbox',
					'std'  => '0'
				),
				'eligible_affiliates' => array(
					'name' => __('Enable Reccurring Referrals For', 'subscriben'),
					'desc' => __('Recurring referrals will be created only for selected Affilliates.', 'subscriben'),
					'type' => 'multicheck',
					'options' => $this->get_affiliates_list()
				),

			);
			
			return $settings;
		}

		/**
		 * Get list of affiliates.
		 *
		 * @access public
		 * @return array
		 */
		public function get_affiliates_list() {
			$affiliates = affiliate_wp()->affiliates->get_affiliates(
				array(
					'number' => -1,
					//'fields' => 'ids'
					'fields' => array('affiliate_id', 'payment_email')
				)
			);
			
			$data = array();
			if (!empty($affiliates)) {
				foreach ($affiliates as $affid) {
					// This adds a database query per affiliate on every wp-admin page load
					// $data[$affid] = affwp_get_affiliate_username($affid);
					
					// Below is a stopgap while Subscriben team makes a better solution
					$data[$affid->affiliate_id] = 'ID: '.$affid->affiliate_id.' - '.$affid->payment_email;
				}
			}
			return $data;
		}

		/**
		 * Add referral type column on referrals list table.
		 *
		 * @access public
		 * @param array $columns array of columns.
		 * @return array
		 */
		public function add_referral_type_column($columns) {
			$columns = array_merge($columns, array('referral_type' => __('Referral Type', 'subscriben')));
			return $columns;
		}

		/**
		 * Display referral type
		 * 		- Referral - new New order referral
		 * 		- Referral - renewal Reweal order referral
		 *
		 * @access public
		 * @param string $value    column value.
		 * @param object $referral referral object.
		 * @return string
		 */
		public function display_referral_type_value($value, $referral) {
			
			$referral_type = affiliate_wp()->referral_meta->get_meta($referral->referral_id, 'referral_type', true);

			$value = $referral_type;
			if ('' == $referral_type) {
				$value = __('Referral - new', 'subscriben');
			}
			return $value;
		}
		
	}
	new Simba_Subscriptions_Affiwp();
}
