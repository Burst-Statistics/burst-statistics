<?php
/**
 * Exit if accessed directly
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * WC Logger class
 *
 * @package Subscriptions
 */
if ( ! class_exists( 'Simba_Subscriptions_WC_Logger' ) ) {

	class Simba_Subscriptions_WC_Logger {

		/**
		 * The WooCommerce logger instance.
		 *
		 * @var WC_Logger|null
		 */
		protected $wc_logger = null;

		/**
		 * The context or source of the log entries.
		 *
		 * @var array
		 */
		protected $context = array();
		
		/**
		 * Whether logging is enabled.
		 *
		 * @var bool
		 */
		protected $is_enabled = true;

		/**
		 * Available logging levels.
		 *
		 * @var array
		 */
		protected $levels = array( 'debug', 'info', 'notice', 'warning', 'error', 'critical', 'alert', 'emergency' );

		/**
		 * Constructor.
		 *
		 * @param string $context The context or source of the log entries.
		 */
		public function __construct( $context = 'subscriben' ) {
			$this->context   = array( 'source' => sanitize_text_field( $context ) );
			$this->wc_logger = wc_get_logger();
		}
		
		/**
		 * Disable logging.
		 *
		 * @return void
		 */
		public function disable() {
			$this->is_enabled = false;
		}

		/**
		 * Logs a message or data entry.
		 *
		 * @param mixed  $entry The message or data to log, can be a string or an array.
		 * @param string $level The log level: 'debug', 'info', 'notice', 'warning', 'error', 'critical', 'alert', 'emergency'.
		 *
		 * @return void
		 */
		public function log( $entry, $level = 'info' ) {
			if ( ! $this->wc_logger || ! $this->is_enabled || empty( $entry ) || ! in_array( $level, $this->levels, true ) ) {
				return;
			}

			// If entry is an array, process it
			if ( is_array( $entry ) ) {
				// Hide credentials from the array
				foreach ( array( 'USER', 'PWD', 'SIGNATURE' ) as $key ) {
					if ( isset( $entry[ $key ] ) ) {
						$entry[ $key ] = '***';
					}
				}
				
				$entry = print_r( $entry, true );
			}
			
			$this->wc_logger->log( $level, $entry, $this->context );
		}

		/**
		 * Erase the log file associated with the current context.
		 *
		 * @return void
		 */
		public function log_erase() {
			if ( ! $this->wc_logger || ! class_exists( 'WC_Log_Handler_File' ) ) {
				return;
			}

			$handler = new \WC_Log_Handler_File();
			$handler->remove( $this->context['source'] );
		}
		
	}
	
}
