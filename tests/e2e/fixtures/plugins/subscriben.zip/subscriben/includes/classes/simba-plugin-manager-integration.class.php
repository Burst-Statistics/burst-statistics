<?php

/**
 * Exit if accessed directly
 */
if (!defined('ABSPATH')) {
	exit;
}

/**
 * Integration with Simba Plugin Manager
 *
 * @class Simba_Subscriptions_SPM_Integration
 * @package Simba_Subscriptions
 */
if (!class_exists('Simba_Subscriptions_SPM_Integration')) {
	
	class Simba_Subscriptions_SPM_Integration {
		
		public function __construct() {
			add_action('updraftmanager_manage_user_page_before_entitlements', array($this, 'updraftmanager_manage_user_page_before_entitlements'), 9);
		}
		
		public function updraftmanager_manage_user_page_before_entitlements($user_id) {	
			if (!$user_id || !class_exists('Simba_Subscriptions_User')) return;
			
			// Fetch an array of subscription objects
			$subscriptions = Simba_Subscriptions_User::find_subscriptions(false, $user_id);
			
			if (count($subscriptions) > 0) {
				
				usort($subscriptions, function($a, $b) {
					return version_compare($a->started, $b->started);
				});
				
				
				echo "<p><strong>".__('Subscriptions:', 'simba-plugin-updates-manager').'</strong> ';
				$first = true;
				foreach ($subscriptions as $info) {
					$subscription_id = $info->id;
					$url = Simba_Subscriptions_Helper::get_link_to_post_html($subscription_id, (string)$subscription_id);
					$date = $info->started_readable ? substr($info->started_readable, 0, strpos($info->started_readable, ' ')) : __('never begun', 'subscriben');
					if ($first) { $first = false; } else { echo " | "; }
					echo $url.' ('.htmlspecialchars($date).', '.htmlspecialchars($info->status_title).')';
				}
				echo '</p>';
			}
			
		}
	}
}

new Simba_Subscriptions_SPM_Integration();
