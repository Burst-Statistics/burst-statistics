<?php
/**
 * Returns settings for this plugin
 *
 * @return array
 */
if (!function_exists('simba_subscriptions_plugin_settings')) :
function simba_subscriptions_plugin_settings() {
	return array(
		'general' => array(
			'title' => __('General', 'subscriben'),
			'children' => array(
				'general' => array(
					'title' => __('General', 'subscriben'),
					'children' => array(
						'add_to_cart' => array(
							'title' => __('Add To Cart button label', 'subscriben'),
							'type' => 'text',
							'default' => '',
							'placeholder' => __('No change', 'subscriben'),
							'validation' => array(
								'rule' => 'default',
								'empty' => true
							),
							'hint' => '<p></p>',
						),
						'multiproduct_subscription' => array(
							'title' => __('Enable multi-product subscriptions', 'subscriben'),
							'type' => 'checkbox',
							'default' => 0,
							'validation' => array(
								'rule' => 'bool',
								'empty' => false
							),
							'hint' => __('<p>If checked, will create one subscription with multiple products, if not - will create separate subscription for each product.</p>', 'subscriben'),
						),
					),
				),
				'pricing' => array(
					'title' => __('Pricing', 'subscriben'),
					'children' => array(
						'cheapest_price_method' => array(
							'title' => __('Cheapest product is one with', 'subscriben'),
							'type' => 'dropdown',
							'default' => 0,
							'validation' => array(
								'rule' => 'option',
								'empty' => false
							),
							'values' => array(
								'0' => __('Lowest calculated per-day price', 'subscriben'),
								'1' => __('Lowest price as set in product settings', 'subscriben'),
							),
							'hint' => __('<p>How to display the price in variable/grouped subscription products (i.e. after "From:" text).</p>', 'subscriben'),
						),
						'sale_price_handling' => array(
							'title' => __('Product sale price applies to', 'subscriben'),
							'type' => 'dropdown',
							'default' => 'all_orders',
							'validation' => array(
								'rule' => 'option',
								'empty' => false
							),
							'values' => array(
								'all_orders'      => __('Initial and renewal orders', 'subscriben'),
								'initial_order'   => __('Initial order only', 'subscriben'),
							),
						),
						'shipping_renewal_charge' => array(
							'title' => __('Charge shipping for renewal orders', 'subscriben'),
							'type' => 'checkbox',
							'default' => 1,
							'validation' => array(
								'rule' => 'bool',
								'empty' => false
							),
							'hint' => '<p></p>',
						),
					),
				),
				'limits' => array(
					'title' => __('Limits', 'subscriben'),
					'children' => array(
						'limit_subscriptions' => array(
							'title' => __('Subscription limit', 'subscriben'),
							'type' => 'dropdown',
							'default' => 0,
							'validation' => array(
								'rule' => 'option',
								'empty' => false
							),
							'values' => array(
								'0' => __('Do not limit subscriptions', 'subscriben'),
								'1' => __('One active subscription of specific product per customer', 'subscriben'),
								'2' => __('One active subscription per customer', 'subscriben'),
							),
							'hint' => '<p>'.__('How to limit the amount of subscriptions.', 'subscriben').'</p>',
						),
						'limit_trials' => array(
							'title' => __('Trial limit', 'subscriben'),
							'type' => 'dropdown',
							'default' => 0,
							'validation' => array(
								'rule' => 'option',
								'empty' => false
							),
							'values' => array(
								'0' => __('Do not limit trials', 'subscriben'),
								'1' => __('One trial per product per customer', 'subscriben'),
								'2' => __('One trial per site per customer', 'subscriben'),
							),
							'hint' => '<p>'.__('How to limit the amount of trials.', 'subscriben').'</p>',
						),
					),
				),
			),
		),
		'capabilities' => array(
			'title' => __('Capabilities', 'subscriben'),
			'children' => array(
				'pause_resume' => array(
					'title' => __('Pausing & Resuming', 'subscriben'),
					'children' => array(
						'customer_pausing_allowed' => array(
							'title' => __('Allow customers to pause subscriptions', 'subscriben'),
							'type' => 'checkbox',
							'default' => 0,
							'validation' => array(
								'rule' => 'bool',
								'empty' => false
							),
							'hint' => '<p></p>',
						),
						'max_pauses' => array(
							'title' => __('Max number of pauses', 'subscriben'),
							'type' => 'text',
							'default' => 0,
							'validation' => array(
								'rule' => 'number',
								'empty' => false
							),
							'hint' => '<p></p>',
						),
						'max_pause_duration' => array(
							'title' => __('Max duration of a pause', 'subscriben'),
							'after' => __('day(s)', 'subscriben'),
							'type' => 'text',
							'default' => 0,
							'validation' => array(
								'rule' => 'number',
								'empty' => false
							),
							'hint' => '<p></p>',
						),
					),
				),
				'cancel' => array(
					'title' => __('Cancelling', 'subscriben'),
					'children' => array(
						'customer_cancelling_allowed' => array(
							'title' => __('Allow customers to cancel subscriptions', 'subscriben'),
							'type' => 'checkbox',
							'default' => 0,
							'validation' => array(
								'rule' => 'bool',
								'empty' => false
							),
							'hint' => '<p></p>',
						),
					),
				),
			),
		),
		'flow' => array(
			'title' => __('Flow', 'subscriben'),
			'children' => array(
				'subscription_flow' => array(
					'title' => __('Subscription Flow', 'subscriben'),
					'children' => array(),
				),
				'renewal_orders' => array(
					'title' => __('Renewal Orders', 'subscriben'),
					'children' => array(
						'renewal_order_day_offset' => array(
							'title' => __('Generate renewal orders', 'subscriben'),
							'after' => __('day(s) before payment due date', 'subscriben'),
							'type' => 'text',
							'default' => 1,
							'validation' => array(
								'rule' => 'number',
								'empty' => false
							),
							'hint' => '<p></p>',
						),
					),
				),
				'reminders' => array(
					'title' => __('Payment Reminders', 'subscriben'),
					'children' => array(
						'reminders_enabled' => array(
							'title' => __('Enable payment reminders', 'subscriben'),
							'type' => 'checkbox',
							'default' => 0,
							'validation' => array(
								'rule' => 'bool',
								'empty' => false
							),
							'hint' => '<p></p>',
						),
						'reminders_days' => array(
							'title' => __('Send reminders before', 'subscriben'),
							'after' => __('day(s) (separate values by comma)', 'subscriben'),
							'type' => 'text',
							'default' => '',
							'validation' => array(
								'rule' => 'number',
								'empty' => true
							),
							'hint' => '<p></p>',
						),
					),
				),
				'overdue' => array(
					'title' => __('Overdue Period', 'subscriben'),
					'children' => array(
						'overdue_enabled' => array(
							'title' => __('Enable overdue period', 'subscriben'),
							'type' => 'checkbox',
							'default' => 0,
							'validation' => array(
								'rule' => 'bool',
								'empty' => false
							),
							'hint' => '<p></p>',
						),
						'overdue_length' => array(
							'title' => __('Overdue period length', 'subscriben'),
							'after' => __('day(s)', 'subscriben'),
							'type' => 'text',
							'default' => '',
							'validation' => array(
								'rule' => 'number',
								'empty' => true
							),
							'hint' => '<p></p>',
						),
					),
				),
				'suspensions' => array(
					'title' => __('Suspensions', 'subscriben'),
					'children' => array(
						'suspensions_enabled' => array(
							'title' => __('Enable suspensions', 'subscriben'),
							'type' => 'checkbox',
							'default' => 0,
							'validation' => array(
								'rule' => 'bool',
								'empty' => false
							),
							'hint' => '<p></p>',
						),
						'suspensions_length' => array(
							'title' => __('Suspension period length', 'subscriben'),
							'after' => __('day(s)', 'subscriben'),
							'type' => 'text',
							'default' => '',
							'validation' => array(
								'rule' => 'number',
								'empty' => true
							),
							'hint' => '<p></p>',
						),
					),
				),
				'cancellations' => array(
					'title' => __('Cancellations', 'subscriben'),
					'children' => array(
						'downloads_when_cancelled' => array(
							'title' => __('Allow downloads whilst a subscription is cancelled', 'subscriben'),
							'type' => 'checkbox',
							'default' => 0,
							'validation' => array(
								'rule' => 'bool',
								'empty' => false
							),
							'hint' => '<p></p>',
						),
					),
				),
				'pausing' => array(
					'title' => __('Pausing', 'subscriben'),
					'children' => array(
						'downloads_when_paused' => array(
							'title' => __('Allow downloads whilst a subscription is paused', 'subscriben'),
							'type' => 'checkbox',
							'default' => 0,
							'validation' => array(
								'rule' => 'bool',
								'empty' => false
							),
							'hint' => '<p></p>',
						),
					),
				),
			),
		),
		'gateways' => array(
			'title' => __('Gateways', 'subscriben'),
			'children' => array(
				'stripe_gateway' => array(
					'title' => __('Stripe', 'subscriben'),
					'children' => array(
						'stripe_enabled' => array(
							'title' => __('Enable Stripe', 'subscriben'),
							'type' => 'stripe_info',
							'default' => 0,
							'validation' => array(
								'rule' => 'bool',
								'empty' => false,
							),
							'hint' => '<p></p>',
						),
					),
				),
				'paypal_ec_gateway' => array(
					'title' => __('PayPal Express Checkout', 'subscriben'),
					'children' => array(
						'paypal_ec_enabled' => array(
							'title' => __('Enable PayPal Express Checkout', 'subscriben'),
							'type' => 'checkbox',
							'default' => 0,
							'validation' => array(
								'rule' => 'bool',
								'empty' => false,
							),
							'hint' => '<p></p>',
						),
					),
				),
			),
		),
	);
}
endif;
