<?php
/**
 * View for subscriptionEdit page Simba_Subscriptions Transactions block
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
	exit;
}

?>

<ul class="subscriben_subscription_transactions">
	<?php if (!empty($transactions)) : ?>
		<?php foreach ($transactions as $transaction) : ?>
			<li>
				<div class="subscriben_transaction_<?php echo $transaction->result; ?>">
					<div class="subscriben_transaction_heading">
						<?php echo '<strong>' . $transaction->action_title . '</strong> - ' . $transaction->result_title . ''; ?>
					</div>
					<?php if ($transaction->note) : ?>
						<div class="subscriben_transaction_note">
							<?php echo $transaction->note; ?>
						</div>
					<?php endif; ?>
				</div>
				<div class="subscriben_transaction_meta">
					<?php echo Simba_Subscriptions::get_adjusted_datetime($transaction->time, null, 'subscription_edit_started'); ?>
				</div>
			</li>
		<?php endforeach; ?>
	<?php else : ?>
		<p class="subscriben_nothing_to_display"><?php _e('No transactions found.', 'subscriben'); ?></p>
	<?php endif; ?>
</ul>
