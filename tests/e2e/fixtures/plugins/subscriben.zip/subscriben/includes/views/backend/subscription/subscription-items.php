<?php
/**
 * View for subscriptionEdit page Simba_Subscriptions Items block
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
	exit;
}

?>
<div id="subscriben_subscription_items_container">
<table class="subscriben_subscription_items_list">
	<thead>
		<tr>
			<th class="subscriben_subscription_items_list_item"><?php _e('Item', 'subscriben'); ?></th>
			<th class="subscriben_subscription_items_list_quantity"><?php _e('Qty', 'subscriben'); ?></th>
			<th class="subscriben_subscription_items_list_total"><?php _e('Total', 'subscriben'); ?></th>
			<th class="subscriben_subscription_items_list_tax"><?php _e('Tax', 'subscriben'); ?></th>
		</tr>
	</thead>

	<tbody>
		<?php foreach ($subscription->get_items() as $item) : ?>
			<tr>
				<td class="subscriben_subscription_items_list_item">
					<?php if (!$item['deleted']) : ?>
						<?php /* WC31: Products will no longer be posts */ ?>
						<?php Simba_Subscriptions_Helper::print_link_to_product($item['product_id'], $item['name'], '', ($item['quantity'] > 1 ? 'x ' . $item['quantity'] : '')); ?>
					<?php else : ?>
						<?php echo $item['name']; ?>
					<?php endif; ?>
				</td>
				<td class="subscriben_subscription_items_list_quantity"><?php echo $item['quantity']; ?></td>
				<td class="subscriben_subscription_items_list_total"><?php echo $subscription->get_formatted_price($item['total']); ?></td>
				<td class="subscriben_subscription_items_list_tax"><?php echo $subscription->get_formatted_price($item['tax']); ?></td>
			</tr>
		<?php endforeach; ?>

		<?php if ($subscription->needs_shipping()) : ?>
			<tr>
				<td class="subscriben_subscription_items_list_item"><?php echo $subscription->shipping['name']; ?></td>
				<td class="subscriben_subscription_items_list_quantity"><?php echo '1'; ?></td>
				<td class="subscriben_subscription_items_list_total"><?php echo $subscription->get_formatted_price($subscription->renewal_order_shipping); ?></td>
				<td class="subscriben_subscription_items_list_tax"><?php echo $subscription->get_formatted_price($subscription->renewal_order_shipping_tax); ?></td>
			</tr>
		<?php endif; ?>
	</tbody>
</table>
<input type="button" class="button" id="subscriben_subscription_items_update" value="<?php _e('Edit', 'subscriben'); ?>">
</div>

<!-- Additional inputs to allow item quantity and price to be altered -->
<div id="subscriben_subscription_items_edit_container">
<input type="hidden" class="subscriben_subscription_items_edit" id="sub_user_id" value="<?php echo $subscription->user_id; ?>">
<input type="hidden" class="subscriben_subscription_items_edit" id="sub_id" value="<?php echo $subscription->id; ?>">

<table class="subscriben_subscription_items_list">
	<thead>
		<tr>
			<th class="subscriben_subscription_items_list_item"><?php _e('Item', 'subscriben'); ?></th>
			<th class="subscriben_subscription_items_list_quantity"><?php _e('Qty', 'subscriben'); ?></th>
			<th class="subscriben_subscription_items_list_total"><?php _e('Total', 'subscriben'); ?></th>
			<th class="subscriben_subscription_items_list_tax"><?php _e('Tax', 'subscriben'); ?></th>
		</tr>
	</thead>
	
	<tbody>
		<?php foreach ($subscription->get_items() as $item) :
				$item_suf = $item['product_id'].'-'.$item['variation_id'];
		?>
			<tr>
				<td class="subscriben_subscription_items_list_item"><?php echo $item['name']; ?></td>
				<td class="subscriben_subscription_items_list_quantity"><input type="number" class="subscriben_subscription_items_edit" id="subitem_quantity_<?php echo $item_suf; ?>" value="<?php echo $item['quantity']; ?>"></td> 
				<td class="subscriben_subscription_items_list_total"><input type="number" class="subscriben_subscription_items_edit" id="subitem_total_<?php echo $item_suf; ?>" value="<?php echo $item['total']; ?>" singleVal="<?php echo $item['total']/$item['quantity']; ?>"></td>
				<td class="subscriben_subscription_items_list_tax"><input type="number" class="subscriben_subscription_items_edit" id="subitem_tax_<?php echo $item_suf; ?>" value="<?php echo $item['tax']; ?>" singleVal="<?php echo $item['tax']/$item['quantity']; ?>"></td>
				<input type="hidden" class="subscriben_subscription_items_edit" id="subitem_id_<?php echo $item_suf; ?>" value="<?php echo $item['product_id']; ?>">
				<input type="hidden" class="subscriben_subscription_items_edit" id="subitem_var_<?php echo $item_suf; ?>" value="<?php echo $item['variation_id']; ?>">
				<input type="hidden" class="subscriben_subscription_items_edit" id="subitem_name_<?php echo $item_suf; ?>" value="<?php echo $item['name']; ?>">
			</tr>
		<?php endforeach; ?>
		
		<?php if ($subscription->needs_shipping()) : ?>
			<tr>
				<td class="subscriben_subscription_items_list_item"><?php echo $subscription->shipping['name']; ?></td>
				<td class="subscriben_subscription_items_list_quantity"><?php echo '1'; ?></td>
				<td class="subscriben_subscription_items_list_total"><input type="number" class="subscriben_subscription_items_edit" id="sub_shipping_total" value="<?php echo $subscription->renewal_order_shipping; ?>"></td>
				<td class="subscriben_subscription_items_list_tax"><input type="number" class="subscriben_subscription_items_edit" id="sub_shipping_tax" value="<?php echo $subscription->renewal_order_shipping_tax; ?>"></td>
			</tr>
		<?php endif; ?>
	</tbody>
</table>
<input type="button" class="button" id="subscriben_subscription_items_submit" value="<?php _e('Save', 'subscriben'); ?>">
</div>

