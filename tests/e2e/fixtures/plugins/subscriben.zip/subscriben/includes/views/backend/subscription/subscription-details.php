
<?php
/**
 * View for subscriptionEdit page main subscription details block
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
	exit;
}

?>

<style type="text/css">
	#post-body-content,
	#submitdiv {
		display: none;
	}
</style>

<div id="subscription_data">
	<h2>
		<?php echo __('Subscription', 'subscriben') . ' ' . $subscription->get_subscription_number(); ?>
		<span class="subscription_edit_page_status subscription_status_<?php echo $subscription_statuses[$subscription->status]['title']; ?>"><?php echo $subscription_statuses[$subscription->status]['title']; ?></span>
	</h2>

	<p class="subscription_subheading">
		<?php echo $subscription->get_formatted_recurring_amount(); ?>
	</p>

	<div class="subscription_data_container">
		<div class="subscription_data_content">
			<h4><?php _e('General Details', 'subscriben'); ?></h4>

			<p>
				<strong><?php _e('Started:', 'subscriben'); ?></strong>
				<?php if ($subscription->started) : ?>
					<?php echo Simba_Subscriptions::get_adjusted_datetime($subscription->started, null, 'subscription_edit_started'); ?>
				<?php else : ?>
					<span class="subscriben_nothing_to_display">
						<?php _e('Not started yet.', 'subscriben'); ?>
					</span>
				<?php endif; ?>
			</p>

			<?php if ($subscription->overdue_since) : ?>
				<p>
					<strong><?php _e('Overdue Since:', 'subscriben'); ?></strong>
					<?php echo Simba_Subscriptions::get_adjusted_datetime($subscription->overdue_since, null, 'subscription_edit_overdue_since'); ?>
				</p>
			<?php endif; ?>

			<?php if ($subscription->paused_since) : ?>
				<p>
					<strong><?php _e('Paused Since:', 'subscriben'); ?></strong>
					<?php echo Simba_Subscriptions::get_adjusted_datetime($subscription->paused_since, null, 'subscription_edit_paused_since'); ?>
				</p>
			<?php endif; ?>

			<?php if ($subscription->suspended_since) : ?>
				<p>
					<strong><?php _e('Suspended Since:', 'subscriben'); ?></strong>
					<?php echo Simba_Subscriptions::get_adjusted_datetime($subscription->suspended_since, null, 'subscription_edit_suspended_since'); ?>
				</p>
			<?php endif; ?>

			<?php if ($subscription->cancelled_since) : ?>
				<p>
					<strong><?php _e('Cancelled Since:', 'subscriben'); ?></strong>
					<?php echo Simba_Subscriptions::get_adjusted_datetime($subscription->cancelled_since, null, 'subscription_edit_cancelled_since'); ?>
				</p>
			<?php endif; ?>

			<?php if ($subscription->expired_since) : ?>
				<p>
					<strong><?php _e('Expired Since:', 'subscriben'); ?></strong>
					<?php echo Simba_Subscriptions::get_adjusted_datetime($subscription->expired_since, null, 'subscription_edit_expired_since'); ?>
				</p>
			<?php endif; ?>

			<?php if ($subscription->payment_method_title) : ?>
				<p>
					<strong><?php _e('Payment Method:', 'subscriben'); ?></strong>
					<?php echo $subscription->payment_method_title; ?>
				</p>
			<?php endif; ?>

			<?php if ($subscription->needs_shipping()) : ?>
				<p>
					<strong><?php _e('Shipping Method:', 'subscriben'); ?></strong>
					<?php echo $subscription->shipping['name']; ?>
				</p>
			<?php endif; ?>

			<p>
				<strong><?php _e('Related Orders:', 'subscriben'); ?></strong>
				<?php foreach ($subscription->all_order_ids as $order_id) : ?>
					<?php if (false != wc_get_order($order_id)) : ?>
						<?php Simba_Subscriptions_Helper::print_link_to_order($order_id); ?>
					<?php else : ?>
						<?php echo '#' . $order_id . ' (' . __('deleted', 'subscriben') . ')'; ?>
					<?php endif; ?>
					<?php echo end($subscription->all_order_ids) != $order_id ? ', ' : ''; ?>
				<?php endforeach; ?>
			</p>

		</div>
		<div class="subscription_data_content">
			<h4><?php _e('Customer Details', 'subscriben'); ?></h4>

			<p>
				<strong><?php _e('Name:', 'subscriben'); ?></strong>
				<?php echo Simba_Subscriptions::get_user_full_name_link($subscription->user_id, $subscription->user_full_name); ?>
			</p>

			<?php if ($user_email = Simba_Subscriptions_WC_Legacy::customer_get_billing_email($subscription->user_id)) : ?>
				<p>
					<strong><?php _e('Email:', 'subscriben'); ?></strong>
					<a href="mailto:<?php echo $user_email; ?>"><?php echo $user_email; ?></a>
				</p>
			<?php endif; ?>

			<?php if ($user_phone = Simba_Subscriptions_WC_Legacy::customer_get_billing_phone($subscription->user_id)) : ?>
				<p>
					<strong><?php _e('Phone:', 'subscriben'); ?></strong>
					<?php echo $user_phone; ?>
				</p>
			<?php endif; ?>

			<?php if (is_array($subscription->shipping_address) && !empty($subscription->shipping_address)) : ?>
				<p class="subscriben_admin_address_paragraph">
					<strong><?php _e('Shipping Address:', 'subscriben'); ?>
						<?php if (!$subscription->is_inactive()) : ?>
							&nbsp;&nbsp;<a id="subscriben_admin_edit_address" href="#"><?php _e('[edit]', 'subscriben'); ?></a>
						<?php endif; ?>
					</strong>
					<span class="subscriben_admin_address"><?php echo wp_kses(Simba_Subscriptions::get_formatted_shipping_address($subscription->shipping_address), array('br' => array())); ?></span>
				</p>
				<?php if (!$subscription->is_inactive()) : ?>
					<div class="subscriben_admin_address_fields">
						<?php foreach (Simba_Subscriptions_Subscription::get_admin_shipping_fields() as $key => $field) : ?>
							<?php if ('select' == $field['type']) : ?>
								<?php woocommerce_wp_select(array('id' => $key, 'value' => $subscription->shipping_address[$key], 'label' => $field['title'], 'options' => $field['values'])); ?>
							<?php else : ?>
								<?php woocommerce_wp_text_input(array('id' => $key, 'value' => $subscription->shipping_address[$key], 'label' => $field['title'])); ?>
							<?php endif; ?>
						<?php endforeach; ?>
						<div class="subscriben_admin_address_save">
							<button type="submit" class="button subscriben_save_address" name="subscriben_subscription_button" value="address" title="<?php _e('Save Address', 'subscriben'); ?>"><?php _e('Save Address', 'subscriben'); ?></button>
							<button class="button" id="subscriben_cancel_address_edit" title="<?php _e('Cancel', 'subscriben'); ?>"><?php _e('Cancel', 'subscriben'); ?></button>
						</div>
					</div>
				<?php endif; ?>
			<?php endif; ?>

		</div>
		<div class="subscription_data_content">
			<h4><?php _e('Scheduled Events', 'subscriben'); ?></h4>

			<?php $scheduled_events = false; ?>

			<?php if ($scheduled_order = Simba_Subscriptions_Event_Scheduler::get_scheduled_event_timestamp('order', $subscription->id)) : ?>
				<p>
					<strong><?php _e('Renewal Order:', 'subscriben'); ?></strong>
					<a class="subscriben_date_change_link" href="" title="<?php _e('Change renewal order date', 'subscriben'); ?>">
						<?php echo Simba_Subscriptions::get_adjusted_datetime($scheduled_order);
						$scheduled_events = true;
						?>
					</a>
					<?php echo $subscription->get_date_change_fields($scheduled_order, 'renewal_order'); ?>
				</p>
			<?php endif; ?>

			<?php if ($scheduled_reminder = Simba_Subscriptions_Event_Scheduler::get_scheduled_event_timestamp('reminder', $subscription->id)) : ?>
				<p>
					<strong><?php _e('Payment Reminder:', 'subscriben'); ?></strong>
					<a class="subscriben_date_change_link" href="" title="<?php _e('Change reminder date', 'subscriben'); ?>">
						<?php echo Simba_Subscriptions::get_adjusted_datetime($scheduled_reminder);
						$scheduled_events = true;
						?>
					</a>
					<?php echo $subscription->get_date_change_fields($scheduled_reminder, 'reminder'); ?>
				</p>
			<?php endif; ?>

			<?php if ($scheduled_payment = Simba_Subscriptions_Event_Scheduler::get_scheduled_event_timestamp('payment', $subscription->id)) : ?>
				<p>
					<strong><?php _e('Payment Due:', 'subscriben'); ?></strong>
					<a class="subscriben_date_change_link" href="" title="<?php _e('Change payment date', 'subscriben'); ?>">
						<?php echo Simba_Subscriptions::get_adjusted_datetime($scheduled_payment);
						$scheduled_events = true;
						?>
					</a>
					<?php echo $subscription->get_date_change_fields($scheduled_payment, 'payment'); ?>
				</p>
			<?php endif; ?>

			<?php if ($scheduled_suspension = Simba_Subscriptions_Event_Scheduler::get_scheduled_event_timestamp('suspension', $subscription->id)) : ?>
				<p>
					<strong><?php _e('Suspension:', 'subscriben'); ?></strong>
					<a class="subscriben_date_change_link" href="" title="<?php _e('Change suspension date', 'subscriben'); ?>">
						<?php echo Simba_Subscriptions::get_adjusted_datetime($scheduled_suspension);
						$scheduled_events = true;
						?>
					</a>
					<?php echo $subscription->get_date_change_fields($scheduled_suspension, 'suspension'); ?>
				</p>
			<?php endif; ?>

			<?php if ($scheduled_cancellation = Simba_Subscriptions_Event_Scheduler::get_scheduled_event_timestamp('cancellation', $subscription->id)) : ?>
				<p>
					<strong><?php _e('Cancellation:', 'subscriben'); ?></strong>
					<a class="subscriben_date_change_link" href="" title="<?php _e('Change cancellation date', 'subscriben'); ?>">
						<?php echo Simba_Subscriptions::get_adjusted_datetime($scheduled_cancellation);
						$scheduled_events = true;
						?>
					</a>
					<?php echo $subscription->get_date_change_fields($scheduled_cancellation, 'cancellation'); ?>
				</p>
			<?php endif; ?>

			<?php if ($scheduled_expiration = Simba_Subscriptions_Event_Scheduler::get_scheduled_event_timestamp('expiration', $subscription->id)) : ?>
				<p>
					<strong><?php _e('Expiration:', 'subscriben'); ?></strong>
					<a class="subscriben_date_change_link" href="" title="<?php _e('Change expiration date', 'subscriben'); ?>">
						<?php echo Simba_Subscriptions::get_adjusted_datetime($scheduled_expiration);
						$scheduled_events = true;
						?>
					</a>
					<?php echo $subscription->get_date_change_fields($scheduled_expiration, 'expiration'); ?>
				</p>
			<?php endif; ?>

			<?php if (!$scheduled_events) : ?>
				<p class="subscriben_nothing_to_display">
					<?php _e('No events scheduled.', 'subscriben'); ?>
				</p>
			<?php endif; ?>

		</div>
		
		<div style="clear:both;">
			<h4><?php _e('Debugging details', 'subscriben'); ?></h4>
			
			<a href="#" class="subscription-debug-details-show-hide" data-subscription-id="<?php echo $subscription->id; ?>"><?php _e('Show / hide ...', 'subscriben');?></a>
			
			<?php
			
				echo '<div class="subscription-debug-details-'.$subscription->id.'" style="display:none;"><pre>'.htmlspecialchars(print_r($subscription, true)).'</pre></div>';
			
			?>
			
		</div>
		
	</div>
	
	

</div>
