<?php
/**
 * View for site URL mismatch notification
 * Displayed on development/staging websites or when user changes main website URL
 */

if (!defined('ABSPATH')) die('No direct access.');

?>

<div id="message" class="error subscriben_url_mismatch">
	<p>
		<strong><?php _e('Subscriben URL mismatch', 'subscriben'); ?></strong>
	</p>
	<p>
		<?php _e('Your website URL has recently been changed. Automatic payments and customer emails have been disabled to prevent live transactions originating from development or staging servers.', 'subscriben'); ?><br />
		<?php _e('If you have moved this website permanently and would like to re-enable these features, select appropriate action below.', 'subscriben'); ?>
	</p>
	<form action="" method="post">
		<button class="button-primary" name="subscriben_url_mismatch_action" value="ignore"><?php _e('Hide this warning', 'subscriben'); ?></button>
		<button class="button" name="subscriben_url_mismatch_action" value="change"><?php _e('Make current URL primary', 'subscriben'); ?></button>
	</form>
</div>
