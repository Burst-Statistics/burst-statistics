<?php
/**
 * View for subscription edit page actions block
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
	exit;
}

?>

<div class="subscription_actions">
	<select name="subscriben_subscription_actions">

		<option value=""><?php _e('Actions', 'subscriben'); ?></option>

		<?php if ($subscription->can_be_paused()) : ?>
			<option value="pause"><?php _e('Pause Subscription', 'subscriben'); ?></option>
		<?php endif; ?>

		<?php if ($subscription->can_be_resumed()) : ?>
			<option value="resume"><?php _e('Resume Subscription', 'subscriben'); ?></option>
		<?php endif; ?>

		<?php if ($subscription->can_be_cancelled()) : ?>
			<option value="cancel"><?php _e('Cancel Subscription', 'subscriben'); ?></option>
		<?php endif; ?>

		<?php if (in_array($subscription->status, array('cancelled', 'expired', 'failed'))) : ?>
			<option value="" disabled="disabled"><?php _e('- No actions available -', 'subscriben'); ?></option>
		<?php endif; ?>

	</select>
</div>
<div class="subscription_actions_footer submitbox">
	<div class="subscriben_subscription_delete">
		<?php if (current_user_can('delete_post', $subscription->id)) : ?>
			<a class="submitdelete deletion" href="<?php echo esc_url(get_delete_post_link($subscription->id)); ?>"><?php echo !EMPTY_TRASH_DAYS ? __('Delete Permanently', 'subscriben') : __('Move to Trash', 'subscriben'); ?></a>
		<?php endif; ?>
	</div>

	<button type="submit" class="button button-primary" title="<?php _e('Process', 'subscriben'); ?>" name="subscriben_subscription_button" value="actions"><?php _e('Process', 'subscriben'); ?></button>
</div>
<div style="clear: both;"></div>
