<?php
/**
 * View for WooCommerce product page subscription settings (simple product)
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
	exit;
}

?>

<div class="options_group show_if_subscriben_simple" style="display: none;">

	<p class="form-field _subscriben_price_time_field">
		<label for="_subscriben_price_time_value"><?php _e('Price is per', 'subscriben'); ?></label>
		<input type="text" class="input-text subscriben_product_page_half_width" id="_subscriben_price_time_value" name="_subscriben_price_time_value" placeholder="<?php _e('e.g. 7', 'subscriben'); ?>" value="<?php echo $_subscriben_price_time_value; ?>">
		<select id="_subscriben_price_time_unit" name="_subscriben_price_time_unit" class="select subscriben_product_page_half_width" style="margin-left: 3px;">
			<?php foreach (Simba_Subscriptions::get_time_units() as $unit_key => $unit) : ?>
				<option value="<?php echo $unit_key; ?>" <?php echo $_subscriben_price_time_unit == $unit_key ? 'selected="selected"' : ''; ?>><?php echo call_user_func($unit['translation_callback'], $unit_key, 2); ?></option>
			<?php endforeach; ?>
		</select>
	</p>

	<p class="form-field _subscriben_free_trial_field">
		<label for="_subscriben_free_trial_time_value"><?php _e('Free trial', 'subscriben'); ?></label>
		<input type="text" class="input-text subscriben_product_page_half_width" id="_subscriben_free_trial_time_value" name="_subscriben_free_trial_time_value" placeholder="<?php _e('e.g. 3', 'subscriben'); ?>" value="<?php echo $_subscriben_free_trial_time_value; ?>">
		<select id="_subscriben_free_trial_time_unit" name="_subscriben_free_trial_time_unit" class="select subscriben_product_page_half_width" style="margin-left: 3px;">
			<?php foreach (Simba_Subscriptions::get_time_units() as $unit_key => $unit) : ?>
				<option value="<?php echo $unit_key; ?>" <?php echo $_subscriben_free_trial_time_unit == $unit_key ? 'selected="selected"' : ''; ?>><?php echo call_user_func($unit['translation_callback'], $unit_key, 2); ?></option>
			<?php endforeach; ?>
		</select>
	</p>

	<p class="form-field _subscriben_signup_fee_field">
		<label for="_subscriben_signup_fee"><?php _e('Sign-up fee', 'subscriben'); ?> <?php echo '(' . get_option('woocommerce_currency'). ', ' . get_woocommerce_currency_symbol() . ')'; ?></label>
		<input type="text" class="short" name="_subscriben_signup_fee" id="_subscriben_signup_fee" placeholder="<?php _e('e.g. 9.99', 'subscriben'); ?>" value="<?php echo $_subscriben_signup_fee; ?>">
	</p>

		<?php
		
		foreach ($currencies as $currency) {
		
			// Already printed
			if (get_option('woocommerce_currency') == $currency) continue;
		
			?><p class="form-field _subscriben_signup_fee_field">
			
			<label for="_subscriben_signup_fee_<?php echo $currency; ?>"><?php _e('Sign-up fee', 'subscriben'); ?> <?php echo " ($currency, " . get_woocommerce_currency_symbol($currency) . ')'; ?></label>
			<input type="text" class="wc_input_price" name="_subscriben_signup_fee_<?php echo $currency; ?>" placeholder="<?php _e('e.g. 9.99', 'subscriben'); ?>" value="<?php echo empty($_subscriben_signup_fees[$currency]) ? '' : esc_attr($_subscriben_signup_fees[$currency]); ?>">
		
			</p><?php
		}
		
	?>
	
	<p class="form-field _subscriben_max_length_field">
		<label for="_subscriben_max_length_time_value"><?php _e('Max length', 'subscriben'); ?></label>
		<input type="text" class="input-text subscriben_product_page_half_width" id="_subscriben_max_length_time_value" name="_subscriben_max_length_time_value" placeholder="<?php _e('e.g. 90', 'subscriben'); ?>" value="<?php echo $_subscriben_max_length_time_value; ?>">
		<select id="_subscriben_max_length_time_unit" name="_subscriben_max_length_time_unit" class="select subscriben_product_page_half_width" style="margin-left: 3px;">
			<?php foreach (Simba_Subscriptions::get_time_units() as $unit_key => $unit) : ?>
				<option value="<?php echo $unit_key; ?>" <?php echo $_subscriben_max_length_time_unit == $unit_key ? 'selected="selected"' : ''; ?>><?php echo call_user_func($unit['translation_callback'], $unit_key, 2); ?></option>
			<?php endforeach; ?>
		</select>
	</p>

</div>
