<?php
/**
 * View settings/option for subscription order on wc create/edit Coupon page.
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
	exit;
}

global $post;
if (!empty($post->ID)) {
	$coupon = new WC_Coupon($post->ID);
	if ($coupon && 'yes' == $coupon->get_meta('subscription_order_renew_coupon', true)) {
		$subscription_order_renew_coupon = 'yes';
	} else {
		$subscription_order_renew_coupon = 'no';
	}
} else {
	$subscription_order_renew_coupon = 'no';
}
?>

<div id="subscription_order_coupon_data" class="panel woocommerce_options_panel">
	<p><?php
		echo __('Here you can configure the coupon parameters for subscription order', 'subscriben');
	?></p>
	<?php
		woocommerce_wp_checkbox(array(
			'id' => 'subscription_order_renew_coupon',
			'label' => __('Subscription renewal', 'subscriben'),
			'description' => __('Tick this box if the coupon should be applied to every subscription renewal order; otherwise it will only apply to the initial order.', 'subscriben'),
			'value' => $subscription_order_renew_coupon,
		));
	?>
</div>
