<?php
/**
 * View for WooCommerce product page subscription settings (variable product)
 */

// Exit if accessed directly
if (!defined('ABSPATH')) die('No direct access.');

?>

<div class="show_if_subscriben_variable">
	<div>
		<p class="form-row form-row-first">
			<label for="_subscriben_price_time_value"><?php _e('Price is per', 'subscriben'); ?></label>
			<input type="text" class="input-text subscriben_product_page_half_width" name="_subscriben_price_time_value[<?php echo $loop; ?>]" placeholder="<?php _e('e.g. 7', 'subscriben'); ?>" value="<?php echo $_subscriben_price_time_value; ?>">
			<select name="_subscriben_price_time_unit[<?php echo $loop; ?>]" class="select subscriben_product_page_half_width" style="margin-left: 0.5%;">
				<?php foreach (Simba_Subscriptions::get_time_units() as $unit_key => $unit) : ?>
					<option value="<?php echo $unit_key; ?>" <?php echo $_subscriben_price_time_unit == $unit_key ? 'selected="selected"' : ''; ?>><?php echo call_user_func($unit['translation_callback'], $unit_key, 2); ?></option>
				<?php endforeach; ?>
			</select>
		</p>
		<p class="form-row form-row-last">
			<label for="_subscriben_signup_fee"><?php _e('Sign-up fee', 'subscriben'); ?> <?php echo '(' . get_option('woocommerce_currency') . ', ' . get_woocommerce_currency_symbol() . ')'; ?></label>
			<input type="text" class="wc_input_price" name="_subscriben_signup_fee[<?php echo $loop; ?>]" placeholder="<?php _e('e.g. 9.99', 'subscriben'); ?>" value="<?php echo $_subscriben_signup_fee; ?>">
		</p>
		
	</div>
	<?php
	
		$i = 0;
	
		foreach ($currencies as $currency) {
		
			// Already printed
			if (get_option('woocommerce_currency') == $currency) continue;
		
			if (0 == $i % 2) {
				if ($i > 0) echo '</div>';
				echo '<div>';
			}
		
			?><p class="form-row form-row-<?php echo (0 == $i %2 ? 'first' : 'last'); ?>">
			
			<label for="_subscriben_signup_fee_<?php echo $currency; ?>"><?php _e('Sign-up fee', 'subscriben'); ?> <?php echo " ($currency, " . get_woocommerce_currency_symbol($currency) . ')'; ?></label>
			<input type="text" class="wc_input_price" name="_subscriben_signup_fee_<?php echo $currency.'['.$loop.']'; ?>" placeholder="<?php _e('e.g. 9.99', 'subscriben'); ?>" value="<?php echo empty($_subscriben_signup_fees[$currency]) ? '' : esc_attr($_subscriben_signup_fees[$currency]); ?>">
		
			</p><?php
			$i++;
		}
		
		if ($i > 1) echo '</div>';
	
	?>
	<div>
		<p class="form-row form-row-first">
			<label for="_subscriben_free_trial_time_value"><?php _e('Free trial', 'subscriben'); ?></label>
			<input type="text" class="input-text subscriben_product_page_half_width" name="_subscriben_free_trial_time_value[<?php echo $loop; ?>]" placeholder="<?php _e('e.g. 3', 'subscriben'); ?>" value="<?php echo $_subscriben_free_trial_time_value; ?>">
			<select name="_subscriben_free_trial_time_unit[<?php echo $loop; ?>]" class="select subscriben_product_page_half_width" style="margin-left: 0.5%;">
				<?php foreach (Simba_Subscriptions::get_time_units() as $unit_key => $unit) : ?>
					<option value="<?php echo $unit_key; ?>" <?php echo $_subscriben_free_trial_time_unit == $unit_key ? 'selected="selected"' : ''; ?>><?php echo call_user_func($unit['translation_callback'], $unit_key, 2); ?></option>
				<?php endforeach; ?>
			</select>
		</p>
		<p class="form-row form-row-last">
			<label for="_subscriben_max_length_time_value"><?php _e('Max length', 'subscriben'); ?></label>
			<input type="text" class="input-text subscriben_product_page_half_width" name="_subscriben_max_length_time_value[<?php echo $loop; ?>]" placeholder="<?php _e('e.g. 90', 'subscriben'); ?>" value="<?php echo $_subscriben_max_length_time_value; ?>">
			<select name="_subscriben_max_length_time_unit[<?php echo $loop; ?>]" class="select subscriben_product_page_half_width" style="margin-left: 0.5%;">
				<?php foreach (Simba_Subscriptions::get_time_units() as $unit_key => $unit) : ?>
					<option value="<?php echo $unit_key; ?>" <?php echo $_subscriben_max_length_time_unit == $unit_key ? 'selected="selected"' : ''; ?>><?php echo call_user_func($unit['translation_callback'], $unit_key, 2); ?></option>
				<?php endforeach; ?>
			</select>
		</p>
	</div>
</div>
