<?php
/**
 * View for subscription settings page header (tabs)
 */

if (!defined('ABSPATH')) die('No direct access.');

?>

<h2 class="subscriben_tabs_container nav-tab-wrapper">
	<?php foreach ($this->settings as $tab_key => $tab) : ?>
		<a class="nav-tab <?php echo $tab_key == $current_tab ? 'nav-tab-active' : ''; ?>" href="?post_type=subscription&page=subscriben_settings&tab=<?php echo $tab_key; ?>"><?php echo (!empty($tab['icon']) ? $tab['icon'] . '&nbsp;' : '') . $tab['title']; ?></a>
	<?php endforeach; ?>
</h2>
