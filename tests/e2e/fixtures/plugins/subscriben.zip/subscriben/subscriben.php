<?php
/**
 * Plugin Name:          Subscriben
 * Requires Plugins:     woocommerce
 * Plugin URI:           https://subscribenplugin.com
 * Description:          A powerful WooCommerce plugin for managing subscriptions with ease.
 * Version:              0.12.11
 * Author:               Team Updraft (Updraft WP Software Ltd.) - based off work up until April 2017 by RightPress (http://rightpress.net)
 * Author URI:           https://subscribenplugin.com
 * Requires at least:    5.0
 * Tested up to:         6.8
 * WC requires at least: 3.9
 * WC tested up to:      9.7
 * License:              GPLv3
 * License URI:          License URI: http://www.gnu.org/licenses/gpl-3.0.html
 * Text Domain:          subscriben
 * Domain Path:          /languages
 */


if (!defined('ABSPATH')) die('No direct access.');

// Define Constants
define('SUBSCRIBEN_PLUGIN_PATH', plugin_dir_path(__FILE__));
define('SUBSCRIBEN_PLUGIN_URL', plugins_url(basename(plugin_dir_path(__FILE__)), basename(__FILE__)));
define('SUBSCRIBEN_VERSION', '0.12.11');
define('SUBSCRIBEN_SUPPORT_PHP', '7.1');
define('SUBSCRIBEN_SUPPORT_WP', '5.0');
define('SUBSCRIBEN_SUPPORT_WC', '3.9');
define('SUBSCRIBEN_SUPPORT_WC_STRIPE_VERSION', '8.8.0');
define('SUBSCRIBEN_OPTIONS_VERSION', '1');

if (!class_exists('Simba_Subscriptions')) {

/**
 * Main plugin class
 *
 * @package Simba_Subscriptions
 */
class Simba_Subscriptions {

	/***************************************************************************
	 * WARNING WARNING WARNING
	 * Never enable debug mode on live system! Only enable debug mode if you
	 * will be able to DELETE all subscriptions and give it a fresh start!
	 **************************************************************************/ // phpcs:ignore Squiz.Commenting.VariableComment.MissingVar
	public static $debug = false;

	/***************************************************************************
	 * WARNING WARNING WARNING
	 * Never enable debug mode on live system! Only enable debug mode if you
	 * will be able to DELETE all subscriptions and give it a fresh start!
	 **************************************************************************/

	// Singleton instance
	private static $instance = false;

	// Query variables for frontend navigation
	private static $query_vars = array(
		'subscriptions',
		'view-subscription',
		'subscription-address',
		'pause-subscription',
		'resume-subscription',
		'cancel-subscription',
	);

	private $cache = array();
	
	private $settings = array();
	
	public $opt = array();
	
	/**
	 * Singleton control
	 */
	public static function get_instance() {
		if (!self::$instance) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Class constructor
	 *
	 * @access public
	 * @return void
	 */
	public function __construct() {
		add_action('before_woocommerce_init', array($this, 'subscriben_hpos_compatibility'));
		
		// Hook to WordPress 'init' action
		if (did_action('init')) {
			$this->load_translations();
			$this->on_init();
			$this->on_init_pre();
			$this->on_init_post();
		} else {
			add_action('init', array($this, 'load_translations'), -1);
			add_action('init', array($this, 'on_init'), 0);
			add_action('init', array($this, 'on_init_pre'), 1);
			add_action('init', array($this, 'on_init_post'), 99);
		}
		
		$this->load_updater();
	}
	
	/**
	 * Load the updater
	 * 
	 * @return void
	 */
	private function load_updater(): void {
		if (!class_exists('Updraft_Manager_Updater_1_9')) {
			$updater_path = SUBSCRIBEN_PLUGIN_PATH.'vendor/davidanderson684/simba-plugin-manager-updater/class-udm-updater.php';
			if (file_exists($updater_path)) {
				require_once $updater_path;
			} else {
				error_log('Subscriben Updater Error: Updater file not found at '.$updater_path);
				return;
			}
		}
		
		if (class_exists('Updraft_Manager_Updater_1_9')) {
			try {
				new Updraft_Manager_Updater_1_9('https://subscribenplugin.com/plugin-info/', 1, 'subscriben/subscriben.php', array('require_login' => false));
			} catch (Exception $e) {
				error_log(sprintf('Subscriben Updater Error: %s in %s on line %d', $e->getMessage(), $e->getFile(), $e->getLine()));
			}
		} else {
			error_log('Subscriben Updater Error: Class still not found after attempting to load updater.');
		}
	}

	/**
	 *  Define compatibility with High performance order storage.
	 */
	public function subscriben_hpos_compatibility() {
		// phpcs:ignore PHPCompatibility.Constants.NewMagicClassConstant.Found
		if (class_exists(\Automattic\WooCommerce\Utilities\FeaturesUtil::class)) {
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('custom_order_tables', __FILE__, true);
			
			// Cart & Checkout Blocks compatibility
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'cart_checkout_blocks', __FILE__, true );
		}
	}
	
	/**
	 * Load block payment methods
	 *
	 * @return void
	 */
	public function on_blocks_loaded() {
		if ( class_exists( 'Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType' ) ) {
			add_action(
				'woocommerce_blocks_payment_method_type_registration',
				function ( $registry ) {
					require_once SUBSCRIBEN_PLUGIN_PATH . 'includes/classes/gateways/paypal-ec/paypal-ec-blocks-payment.class.php';
					$registry->register( new Simba_Subscriptions_PayPal_EC_Payment() );
					
					require_once SUBSCRIBEN_PLUGIN_PATH . 'includes/classes/gateways/stripe/stripe-blocks-payment.class.php';
					$registry->register( new Simba_Subscriptions_Stripe_Payment() );
				}
			);
		}
	}

	/**
	 * Code executed on WordPress 'init' action
	 *
	 * @access public
	 * @return void
	 */
	public function on_init() {
		// Load helper class
		include_once SUBSCRIBEN_PLUGIN_PATH . 'includes/classes/libraries/helper.class.php';
		include_once SUBSCRIBEN_PLUGIN_PATH . 'includes/classes/libraries/wc-legacy.class.php';
		
		if (!class_exists('Updraft_Semaphore_3_0')) {
			include_once SUBSCRIBEN_PLUGIN_PATH . 'includes/classes/libraries/updraft-semaphore.class.php';
		}

		// Additional Plugins page links
		add_filter('plugin_action_links_'.plugin_basename(__FILE__), array($this, 'plugins_page_links'));

		// Check environment
		if (!self::check_environment()) return;
		
		// Load includes
		foreach (glob(SUBSCRIBEN_PLUGIN_PATH . 'includes/*.inc.php') as $filename) {
			include $filename;
		}

		// Load classes
		foreach (glob(SUBSCRIBEN_PLUGIN_PATH . 'includes/classes/*.class.php') as $filename) {
			include $filename;
		}

		// Load WC Simba_Subscriptions compatibility classes
		foreach (glob(SUBSCRIBEN_PLUGIN_PATH . 'includes/classes/woocommerce/*.class.php') as $filename) {
			include $filename;
		}

		// Load Affiliate WP compatibility class
		if (did_action('affwp_plugins_loaded') && function_exists('affiliate_wp')) {
			$integrations = affiliate_wp()->integrations->get_enabled_integrations();

			if (array_key_exists('woocommerce', $integrations)) {
				include SUBSCRIBEN_PLUGIN_PATH . 'includes/classes/affiliate-wp/affiwp.class.php';
			}
		}

		// Initialize automatic updates
		if (file_exists(__DIR__.'/updater.php')) include __DIR__.'/updater.php';

		// Initialize plugin configuration
		$this->settings = simba_subscriptions_plugin_settings();

		// Load/parse plugin settings
		$this->opt = $this->get_options();

		// Load payment gateway classes
		$this->load_payment_gateways();

		// Cache objects in admin list view
		$this->cache = array(
			'subscriptions' => array(),
			'transactions'  => array(),
		);

		// Admin-only hooks
		if (is_admin() && !defined('DOING_AJAX')) {

			// Add settings page menu link
			add_action('admin_menu', array($this, 'add_admin_menu'));
			add_action('admin_init', array($this, 'plugin_options_setup'));

			// Use correct capability for settings page
			add_filter('option_page_capability_subscriben_opt_group_general', array($this, 'custom_options_capability'));
			add_filter('option_page_capability_subscriben_opt_group_capabilities', array($this, 'custom_options_capability'));
			add_filter('option_page_capability_subscriben_opt_group_flow', array($this, 'custom_options_capability'));
			add_filter('option_page_capability_subscriben_opt_group_gateways', array($this, 'custom_options_capability'));

			// Load backend assets conditionally
			if (self::is_subscriben_page()) {
				add_action('admin_enqueue_scripts', array($this, 'enqueue_backend_assets'));
			}

			// ... and load some assets on all pages
			add_action('admin_enqueue_scripts', array($this, 'enqueue_backend_assets_all'));
		} else { // Frontend-only hooks

			if (!(defined('DOING_AJAX') && DOING_AJAX)) {
				add_action('wp_enqueue_scripts', array($this, 'enqueue_frontend_css_assets'));
			}
		}

		// Add payment gateways
		add_filter('woocommerce_payment_gateways', array($this, 'add_payment_gateways'), 20);

		// Customer My Account hooks
		add_filter('woocommerce_my_account_my_orders_query', array($this, 'woocommerce_my_orders_query'));
		add_filter('woocommerce_my_account_my_orders_title', array($this, 'woocommerce_my_orders_title'));
		add_filter('query_vars', array($this, 'add_query_vars'));
		add_action('wp_loaded', array($this, 'maybe_flush_rewrite_rules'));
		add_filter('rewrite_rules_array', array($this, 'insert_rewrite_rules'));

		add_action('woocommerce_before_my_account', array($this, 'display_customer_subscription_list'), 1);

		// Other hooks
		add_action('restrict_manage_posts', array($this, 'add_list_filters'));
		add_action('manage_subscription_posts_columns', array($this, 'manage_subscription_list_columns'));
		add_action('manage_sub_transaction_posts_columns', array($this, 'manage_transaction_list_columns'));
		add_action('manage_subscription_posts_custom_column', array($this, 'manage_subscription_list_column_values'), 10, 2);
		add_action('manage_sub_transaction_posts_custom_column', array($this, 'manage_transaction_list_column_values'), 10, 2);
		add_filter('parse_query', array($this, 'handle_list_filter_queries'));
		add_filter('bulk_actions-edit-subscription', array($this, 'manage_subscription_list_bulk_actions'));
		add_filter('bulk_actions-edit-sub_transaction', array($this, 'manage_transaction_list_bulk_actions'));
		add_filter('views_edit-subscription', array($this, 'manage_subscription_list_views'));
		add_filter('views_edit-sub_transaction', array($this, 'manage_transaction_list_views'));
		add_filter('posts_join', array($this, 'expand_list_search_context_join'));
		add_filter('posts_where', array($this, 'expand_list_search_context_where'));
		add_filter('posts_groupby', array($this, 'expand_list_search_context_group_by'));
		add_action('woocommerce_before_checkout_form', array($this, 'enforce_registration'), 99);
		add_action('woocommerce_checkout_process', array($this, 'enforce_createaccount_option'), 99);
		add_action('woocommerce_store_api_checkout_update_customer_from_request', array($this, 'checkout_block_force_registration'), 99, 2); // using Checkout Block
		add_action('woocommerce_store_api_checkout_order_processed', array($this, 'remove_checkout_block_force_registration'), 101); // using Checkout Block
		add_filter('wc_checkout_params', array($this, 'enforce_registration_js'), 99);
		add_action('before_delete_post', array($this, 'post_deleted_event'));
		add_action('save_post', array($this, 'save_subscription_meta_box'), 9, 2);
		add_action('init', array($this, 'maybe_save_main_site_url'), 1);
		add_action('admin_notices', array($this, 'url_mismatch_notification'));
		add_action('add_meta_boxes', array($this, 'remove_meta_boxes'), 99, 2);
		add_action('admin_init', array($this, 'admin_redirect'));
		add_action('admin_head', array($this, 'admin_remove_new_post_links'));
		add_action('woocommerce_blocks_loaded', array($this, 'on_blocks_loaded' ));

		// Add shortcode to display customer's subscription list
		add_shortcode('subscriben_customer_subscriptions', array($this, 'shortcode_customer_subscriptions'));

		// AJAX handler for subscription date change
		add_action('wp_ajax_change_scheduled_date', array('Simba_Subscriptions_Subscription', 'ajax_change_scheduled_date'));
		add_action('wp_ajax_update_renewal_quantity_and_price', array('Simba_Subscriptions_Subscription', 'ajax_update_renewal_quantity_and_price'));
		
		// Add checkbox to also cancel linked subscription if the order is part of a subscription
		add_action('woocommerce_order_item_add_action_buttons', array($this, 'add_subscription_cancel_option'));
		
		// Debug class
		if (self::$debug) add_action('init', array($this, 'debug'));

		// Intercept PayPal's response
		add_action('parse_request', array($this, 'paypal_express_return_page'), 10);
	}
	
	/**
	 * Load plugin translations
	 *
	 * @return void
	 */
	public function load_translations() {
		load_textdomain('subscriben', WP_LANG_DIR . '/subscriben/subscriben-' . apply_filters('plugin_locale', get_locale(), 'subscriben') . '.mo');
		load_plugin_textdomain('subscriben', false, dirname(plugin_basename(__FILE__)) . '/languages/');
	}

	/**
	 * Debug function run on WordPress init action - do your testing here
	 *
	 * @access public
	 * @return void
	 */
	public function debug() {

	}

	/**
	 * Add settings link on plugins page
	 *
	 * @access public
	 * @param array $links
	 * @return void
	 */
	public function plugins_page_links($links) {
		// Support
		$settings_link = '<a href="https://subscribenplugin.com/support" target="_blank">'.__('Support', 'subscriben').'</a>';
		array_unshift($links, $settings_link);

		// Settings
		if (self::check_environment()) {
			$settings_link = '<a href="edit.php?post_type=subscription&page=subscriben_settings">'.__('Settings', 'subscriben').'</a>';
			array_unshift($links, $settings_link);
		}

		return $links;
	}

	/**
	 * WordPress 'init' @ position 1
	 *
	 * @access public
	 * @return void
	 */
	public function on_init_pre() {
		// Register new post type to store subscriptions
		$this->add_custom_post_types();

		// Register endpoints
		foreach (self::$query_vars as $var) {
			add_rewrite_endpoint($var, EP_ROOT | EP_PAGES);
		}
	}

	/**
	 * WordPress 'init' @ position 99
	 *
	 * @access public
	 * @return void
	 */
	public function on_init_post() {
		// Add menu item to tabbed navigation (works starting from WooCommerce 2.6)
		add_filter('woocommerce_account_menu_items', array($this, 'my_account_menu_items'));
		add_action('woocommerce_account_subscriptions_endpoint', array($this, 'display_customer_subscription_list'));
		add_filter('the_title', array($this, 'subscriptions_endpoint_title'));

		// Replace woocommerce_my_account shortcode with our own
		if (function_exists('shortcode_exists') && shortcode_exists('woocommerce_my_account')) {
			remove_shortcode('woocommerce_my_account');
			include SUBSCRIBEN_PLUGIN_PATH . 'includes/classes/lazy/my-account.class.php';
			add_shortcode(apply_filters('woocommerce_my_account_shortcode_tag', 'woocommerce_my_account'), array($this, 'intercept_woocommerce_my_account_shortcode'));
		}

		// Display related subscriptions on frontend single order view page
		add_action(
			apply_filters('subscriben_order_view_hook', 'woocommerce_order_details_after_order_table'),
			array($this, 'display_frontend_order_related_subscriptions'),
			apply_filters('subscriben_order_view_position', 9)
		);
	}

	/**
	 * Check if current user has admin capability
	 *
	 * @access public
	 * @return bool
	 */
	public static function is_admin() {
		return current_user_can(Simba_Subscriptions::get_admin_capability());
	}

	/**
	 * Get admin capability
	 *
	 * @access public
	 * @return string
	 */
	public static function get_admin_capability() {
		return apply_filters('subscriben_capability', 'manage_woocommerce');
	}

	/**
	 * Custom capability for options
	 *
	 * @access public
	 * @return string
	 */
	public function custom_options_capability() {
		return Simba_Subscriptions::get_admin_capability();
	}

	/**
	 * Add menu item to tabbed navigation
	 *
	 * @access public
	 * @param array $items
	 * @return array
	 */
	public function my_account_menu_items($items) {
		// Check if subscription list needs to be displayed
		if (self::display_frontend_subscriptions_list()) {

			$menu_item = array('subscriptions' => __('Subscriptions', 'subscriben'));

			// Insert after dashboard or after orders
			if (isset($items['dashboard']) || isset($items['orders'])) {
				$where = isset($items['dashboard']) ? 'dashboard' : 'orders';
				$items = Simba_Subscriptions_Helper::insert_to_array_after_key($items, $where, $menu_item);
			} else {// ... or at the beginning of the list
				$items = array_merge($menu_item, $items);
			}
		}

		return $items;
	}

	/**
	 * Change subscriptions endpoint title
	 *
	 * @access public
	 * @param string $title
	 * @return string
	 */
	public function subscriptions_endpoint_title($title) {
		global $wp_query;

		// Check if we are in My Account
		if (!is_null($wp_query) && !is_admin() && is_main_query() && in_the_loop() && is_account_page()) {

			// Subscriptions
			if (isset($wp_query->query_vars['subscriptions'])) {
				$title = __('Subscriptions', 'subscriben');
			} elseif (isset($wp_query->query_vars['subscription-address'])) {// Shipping address
				$title = __('Shipping Address', 'subscriben');
			} else {// Single subscription
				foreach (array('view-subscription', 'pause-subscription', 'resume-subscription', 'cancel-subscription') as $var) {
					if (isset($wp_query->query_vars[$var])) {
						$subscription = Simba_Subscriptions_Subscription::get_by_id($wp_query->query_vars[$var]);
						$title = is_object($subscription) ? __('Subscription', 'subscriben') . ' ' . $subscription->get_subscription_number() : __('Subscription', 'subscriben');
						break;
					}
				}
			}

			// Remove filter so that no further changes can be made to the page title
			remove_filter('the_title', array($this, 'subscriptions_endpoint_title'));
		}

		return $title;
	}

	/**
	 * Extract some options from plugin settings array
	 *
	 * @access public
	 * @param string $name
	 * @param bool   $split_by_page
	 * @return array
	 */
	public function options($name, $split_by_page = false) {
		$results = array();

		// Iterate over settings array and extract values
		foreach ($this->settings as $page => $page_value) {
			$page_options = array();

			foreach ($page_value['children'] as $section_value) {
				foreach ($section_value['children'] as $field => $field_value) {
					if (isset($field_value[$name])) {
						$page_options['subscriben_' . $field] = $field_value[$name];
					}
				}
			}

			$results[preg_replace('/_/', '-', $page)] = $page_options;
		}

		$final_results = array();

		if (!$split_by_page) {
			foreach ($results as $value) {
				$final_results = array_merge($final_results, $value);
			}
		} else {
			$final_results = $results;
		}

		return $final_results;
	}

	/**
	 * Get options saved to database or default options if no options saved
	 *
	 * @access public
	 * @return array
	 */
	public function get_options() {
		// Get options from database
		$saved_options = get_option('subscriben_options', array());

		// Get current version (for major updates in future)
		if (!empty($saved_options)) {
			if (isset($saved_options[SUBSCRIBEN_OPTIONS_VERSION])) {
				$saved_options = $saved_options[SUBSCRIBEN_OPTIONS_VERSION];
			} else { // phpcs:ignore Generic.CodeAnalysis.EmptyStatement.DetectedElse
				// Migrate options here if needed...
			}
		}

		if (is_array($saved_options)) {
			return array_merge($this->options('default'), $saved_options);
		} else {
			return $this->options('default');
		}
	}

	/**
	 * Update single option
	 *
	 * @param array  $key
	 * @param string $value
	 * @return bool
	 */
	public function update_option($key, $value) {
		$this->opt[$key] = $value;
		return update_option('subscriben_options', $this->opt);
	}

	/**
	 * Add custom post types
	 *
	 * @access public
	 * @return void
	 */
	public function add_custom_post_types() {
		/**
		 * SUBSCRIPTION
		 */

		// Define labels
		$labels = array(
			'name'               => __('Subscriptions', 'subscriben'),
			'singular_name'      => __('Subscription', 'subscriben'),
			'add_new'            => __('Add Subscription', 'subscriben'),
			'add_new_item'       => __('Add New Subscription', 'subscriben'),
			'edit_item'          => __('Edit Subscription', 'subscriben'),
			'new_item'           => __('New Subscription', 'subscriben'),
			'all_items'          => __('Subscriptions', 'subscriben'),
			'view_item'          => __('View Subscriptions', 'subscriben'),
			'search_items'       => __('Search Subscriptions', 'subscriben'),
			'not_found'          => __('No Subscriptions Found', 'subscriben'),
			'not_found_in_trash' => __('No Subscriptions Found In Trash', 'subscriben'),
			'parent_item_colon'  => '',
			'menu_name'          => __('Subscriptions', 'subscriben'),
		);

		// Define settings
		$args = array(
			'labels'               => $labels,
			'description'          => __('WooCommerce Subscriptions', 'subscriben'),
			'public'               => false,
			'show_ui'              => true,
			'menu_position'        => 56,
			'capability_type'      => 'post',
			'capabilities'         => array(
				'create_posts'     => 'do_not_allow',
				'edit_posts'         => $this->get_admin_capability(),
				'edit_others_posts'  => $this->get_admin_capability(),
				'delete_posts'       => $this->get_admin_capability(),
				'publish_posts'      => $this->get_admin_capability(),
				'read_private_posts' => $this->get_admin_capability(),
			),
			'map_meta_cap'         => true,
			'supports'             => array(''),
			'register_meta_box_cb' => array($this, 'add_subscription_meta_box'),
		);

		// Register new post type
		register_post_type('subscription', $args);

		// Register custom taxonomy (subscription status)
		register_taxonomy('subscription_status', 'subscription', array(
			'label'             => __('Status', 'subscriben'),
			'labels'            => array(
				'name'          => __('Status', 'subscriben'),
				'singular_name' => __('Status', 'subscriben'),
			),
			'public'            => false,
			'show_admin_column' => true,
			'query_var'         => true,
		));

		// Register custom terms - subscription status
		foreach (Simba_Subscriptions_Subscription::get_statuses() as $status_key => $status) {
			if (!term_exists($status_key, 'subscription_status')) {
				wp_insert_term($status['title'], 'subscription_status', array(
					'slug' => $status_key,
				));
			}
		}

		/**
		 * SUBSCRIPTION TRANSACTION
		 */

		// Define labels
		$labels = array(
			'name'               => __('Transactions', 'subscriben'),
			'singular_name'      => __('Transaction', 'subscriben'),
			'add_new'            => __('Add Transaction', 'subscriben'),
			'add_new_item'       => __('Add New Transaction', 'subscriben'),
			'edit_item'          => __('Edit Transaction', 'subscriben'),
			'new_item'           => __('New Transaction', 'subscriben'),
			'all_items'          => __('Transactions', 'subscriben'),
			'view_item'          => __('View Transaction', 'subscriben'),
			'search_items'       => __('Search Transactions', 'subscriben'),
			'not_found'          => __('No Transactions Found', 'subscriben'),
			'not_found_in_trash' => __('No Transactions Found In Trash', 'subscriben'),
			'parent_item_colon'  => '',
			'menu_name'          => __('Transactions', 'subscriben'),
		);

		// Define settings
		$args = array(
			'labels'                 => $labels,
			'description'            => __('WooCommerce Subscriptions', 'subscriben'),
			'public'                 => false,
			'show_ui'                => true,
			'show_in_menu'           => 'edit.php?post_type=subscription',
			'menu_position'          => 59,
			'capability_type'        => 'post',
			'capabilities'           => array(
				'create_posts'       => 'do_not_allow',
				'edit_posts'         => $this->get_admin_capability(),
				'edit_others_posts'  => $this->get_admin_capability(),
				'delete_posts'       => $this->get_admin_capability(),
				'publish_posts'      => $this->get_admin_capability(),
				'read_private_posts' => $this->get_admin_capability(),
			),
			'map_meta_cap'           => true,
			'supports'               => array('title'),
		);

		// Register new post type
		register_post_type('sub_transaction', $args);

		// Edit this custom post type a bit
		add_filter('post_row_actions', array($this, 'sub_transaction_remove_actions'));

		// Register custom taxonomy (transaction action)
		register_taxonomy('sub_transaction_action', 'sub_transaction', array(
			'label'             => __('Action', 'subscriben'),
			'labels'            => array(
				'name'          => __('Action', 'subscriben'),
				'singular_name' => __('Action', 'subscriben'),
			),
			'public'            => false,
			'show_admin_column' => true,
			'query_var'         => true,
		));

		// Register custom taxonomy (transaction result)
		register_taxonomy('sub_transaction_result', 'sub_transaction', array(
			'label'             => __('Result', 'subscriben'),
			'labels'            => array(
				'name'          => __('Result', 'subscriben'),
				'singular_name' => __('Result', 'subscriben'),
			),
			'public'            => false,
			'show_admin_column' => true,
			'query_var'         => true,
		));

		// Register custom terms - action
		foreach (Simba_Subscriptions_Transaction::get_actions() as $action_key => $action) {
			if (!term_exists($action_key, 'sub_transaction_action')) {
				wp_insert_term($action['title'], 'sub_transaction_action', array(
					'slug' => $action_key,
				));
			}
		}

		// Register custom terms - result
		foreach (Simba_Subscriptions_Transaction::get_results() as $result_key => $result) {
			if (!term_exists($result_key, 'sub_transaction_result')) {
				wp_insert_term($result['title'], 'sub_transaction_result', array(
					'slug' => $result_key,
				));
			}
		}
	}

	/**
	 * Add filtering capabilities to custom taxonomies for custom post types
	 *
	 * @access public
	 * @return void
	 */
	public function add_list_filters() {
		global $typenow;
		global $wp_query;

		// Extract selected filter options
		$selected = array();

		foreach (array('subscription_status', 'sub_transaction_action', 'sub_transaction_result') as $taxonomy) {
			if (!empty($wp_query->query[$taxonomy]) && is_numeric($wp_query->query[$taxonomy])) {
				$selected[$taxonomy] = $wp_query->query[$taxonomy];
			} elseif (!empty($wp_query->query[$taxonomy])) {
				$term = get_term_by('slug', $wp_query->query[$taxonomy], $taxonomy);
				$selected[$taxonomy] = $term ? $term->term_id : 0;
			} else {
				$selected[$taxonomy] = 0;
			}
		}

		if ('subscription' == $typenow) {

			// Statuses
			wp_dropdown_categories(array(
				'show_option_all'   => __('All statuses', 'subscriben'),
				'taxonomy'          => 'subscription_status',
				'name'              => 'subscription_status',
				'selected'          => $selected['subscription_status'],
				'show_count'        => true,
				'hide_empty'        => false,
			));
		} elseif ('sub_transaction' == $typenow) {

			// Actions
			if (!empty($wp_query->query['sub_transaction_action'])) {
				$term = get_term_by('slug', $wp_query->query['sub_transaction_action'], 'sub_transaction_action');
			}
			wp_dropdown_categories(array(
				'show_option_all'   => __('All actions', 'subscriben'),
				'taxonomy'          => 'sub_transaction_action',
				'name'              => 'sub_transaction_action',
				'selected'          => $selected['sub_transaction_action'],
				'show_count'        => true,
				'hide_empty'        => false,
			));

			// Results
			wp_dropdown_categories(array(
				'show_option_all'   => __('All results', 'subscriben'),
				'taxonomy'          => 'sub_transaction_result',
				'name'              => 'sub_transaction_result',
				'selected'          => $selected['sub_transaction_result'],
				'show_count'        => true,
				'hide_empty'        => false,
			));
		}
	}

	/**
	 * Handle list filter queries
	 *
	 * @access public
	 * @param object $query
	 * @return void
	 */
	public function handle_list_filter_queries($query) {
		global $pagenow;

		$qv = &$query->query_vars;

		if ('edit.php' == $pagenow && isset($qv['post_type'])) {

			$taxonomies = array(
				'subscription' => array('subscription_status'),
				'sub_transaction' => array('sub_transaction_action', 'sub_transaction_result'),
			);

			if (!is_array($qv['post_type']) && isset($taxonomies[$qv['post_type']])) {
				foreach ($taxonomies[$qv['post_type']] as $taxonomy) {
					if (isset($qv[$taxonomy]) && is_numeric($qv[$taxonomy]) && 0 != $qv[$taxonomy]) {
						$term = get_term_by('id', $qv[$taxonomy], $taxonomy);
						$qv[$taxonomy] = $term->slug;
					}
				}
			}
		}
	}

	/**
	 * Manage subscription list columns
	 *
	 * @access public
	 * @param array $columns
	 * @return array
	 */
	public function manage_subscription_list_columns($columns) {
		$new_columns = array();

		foreach ($columns as $column_key => $column) {
			$allowed_columns = array(
				'cb',
			);

			if (in_array($column_key, $allowed_columns)) {
				$new_columns[$column_key] = $column;
			}
		}

		$new_columns['id'] = __('ID', 'subscriben');
		$new_columns['status'] = __('Status', 'subscriben');
		$new_columns['subscriben_product'] = __('Product', 'subscriben');
		$new_columns['subscriben_user'] = __('User', 'subscriben');
		$new_columns['recurring_amount'] = __('Recurring', 'subscriben');
		$new_columns['first_last_orders'] = __('1st/Last Orders', 'subscriben');
		$new_columns['started'] = __('Started', 'subscriben');
		$new_columns['payment_due'] = __('Payment Due', 'subscriben');
		$new_columns['expires'] = __('Expires', 'subscriben');

		return $new_columns;
	}

	/**
	 * Manage transaction list columns
	 *
	 * @access public
	 * @param array $columns
	 * @return array
	 */
	public function manage_transaction_list_columns($columns) {
		$new_columns = array();

		foreach ($columns as $column_key => $column) {
			$allowed_columns = array(
				'cb',
			);

			if (in_array($column_key, $allowed_columns)) {
				$new_columns[$column_key] = $column;
			}
		}

		$new_columns['time'] = __('Timestamp', 'subscriben');
		$new_columns['action'] = __('Action', 'subscriben');
		$new_columns['result'] = __('Result', 'subscriben');
		$new_columns['subscription'] = __('Subscription', 'subscriben');
		$new_columns['order'] = __('Order', 'subscriben');
		$new_columns['product'] = __('Product', 'subscriben');
		$new_columns['subscriben_note'] = __('Note', 'subscriben');

		return $new_columns;
	}

	/**
	 * Manage subscription list column values
	 *
	 * @access public
	 * @param array $column
	 * @param int   $post_id
	 * @return void
	 */
	public function manage_subscription_list_column_values($column, $post_id) {
		$subscription = $this->load_from_cache('subscriptions', $post_id);

		switch ($column) {
			case 'id':
				Simba_Subscriptions_Helper::print_link_to_post($subscription->id);
				break;

			case 'status':
				echo '<a class="subscription_status_' . $subscription->status . '" href="edit.php?post_type=subscription&amp;subscription_status=' . $subscription->status . '">' . $subscription->status_title . '</a>';
				break;

			case 'subscriben_product':
				$products = array();

				foreach (Simba_Subscriptions_Subscription::get_subscription_items($subscription->id) as $item) {
					if (!$item['deleted']) {
						// WC31: Products will no longer be posts
						$products[] = Simba_Subscriptions_Helper::get_link_to_post_html($item['product_id'], $item['name'], '', ($item['quantity'] > 1 ? 'x ' . $item['quantity'] : ''));
					} else {
						$products[] = $item['name'];
					}
				}

				echo implode('<br>', $products);
				break;
			case 'subscriben_user':
				echo Simba_Subscriptions::get_user_full_name_link($subscription->user_id, $subscription->user_full_name);
				break;

			case 'recurring_amount':
				echo $subscription->get_formatted_price($subscription->renewal_order_total);
				break;
			case 'first_last_orders':
				$all_orders = $subscription->all_order_ids;
				
				if (count($all_orders) > 1) {
			
					sort($all_orders, SORT_NUMERIC);
			
					if (false != wc_get_order($all_orders[0])) {
						Simba_Subscriptions_Helper::print_link_to_order($all_orders[0]);
					} else {
						echo '#' . $all_orders[0] . ' (' . __('deleted', 'subscriben') . ')';
					}
					
					echo ' / ';
				}
			
				if (false != wc_get_order($subscription->last_order_id)) {
					Simba_Subscriptions_Helper::print_link_to_order($subscription->last_order_id);
				} else {
					echo '#' . $subscription->last_order_id . ' (' . __('deleted', 'subscriben') . ')';
				}
				break;
			case 'started':
				if ($subscription->started) {
						$date_format = apply_filters('subscriben_date_format', get_option('date_format'), 'subscription_list_started');
						$date = Simba_Subscriptions::get_adjusted_datetime($subscription->started, $date_format);
						$date_time = Simba_Subscriptions::get_adjusted_datetime($subscription->started, null, 'subscription_list_started');
						echo '<span title="' . $date_time . '">' . $date . '</span>';
				} else {
					echo '—';
				}
				break;
			case 'payment_due':
				if ($subscription->payment_due) {
					$date_format = apply_filters('subscriben_date_format', get_option('date_format'), 'subscription_list_payment_due');
					$date = Simba_Subscriptions::get_adjusted_datetime($subscription->payment_due, $date_format);
					$date_time = Simba_Subscriptions::get_adjusted_datetime($subscription->payment_due, null, 'subscription_list_payment_due');
					echo '<span title="' . $date_time . '">' . $date . '</span>';
				} else {
					echo '—';
				}
				break;
			case 'expires':
				if ($subscription->expires) {
					$date_format = apply_filters('subscriben_date_format', get_option('date_format'), 'subscription_list_expires');
					$date = Simba_Subscriptions::get_adjusted_datetime($subscription->expires, $date_format);
					$date_time = Simba_Subscriptions::get_adjusted_datetime($subscription->expires, null, 'subscription_list_expires');
					echo '<span title="' . $date_time . '">' . $date . '</span>';
				} else {
					echo '—';
				}
				break;
			default:
				break;
		}
	}

	/**
	 * Manage transaction list column values
	 *
	 * @access public
	 * @param array $column
	 * @param int   $post_id
	 * @return void
	 */
	public function manage_transaction_list_column_values($column, $post_id) {
		$transaction = $this->load_from_cache('transactions', $post_id);

		switch ($column) {
			case 'time':
				echo Simba_Subscriptions::get_adjusted_datetime($transaction->time, null, 'subscription_edit_started');
				break;

			case 'subscription':
				if ($transaction->subscription_id) {
					if (Simba_Subscriptions_Helper::post_is_active($transaction->subscription_id)) {
						Simba_Subscriptions_Helper::print_link_to_post($transaction->subscription_id);
					} else {
						echo '#' . $transaction->subscription_id . ' (' . __('deleted', 'subscriben') . ')';
					}
				}
				break;
			case 'order':
				if ($transaction->order_id) {
					if (false != wc_get_order($transaction->order_id)) {
						Simba_Subscriptions_Helper::print_link_to_order($transaction->order_id);
					} else {
						echo '#' . $transaction->order_id . ' (' . __('deleted', 'subscriben') . ')';
					}
				}
				break;
			case 'product':
				if ($transaction->product_id) {

					// Is this a variable product?
					$title = $transaction->variation_id ? sprintf(__('Variation #%1$s of', 'subscriben'), $transaction->variation_id) . ' #' . $transaction->product_id : '#' . $transaction->product_id;

					// Is this product still active?
					if (false != wc_get_product($transaction->product_id)) {
						Simba_Subscriptions_Helper::print_link_to_product($transaction->product_id, $title);
					} else {
						echo $title . ' (' . __('deleted', 'subscriben') . ')';
					}
				}
				break;
			case 'action':
				echo '<a href="edit.php?post_type=sub_transaction&amp;sub_transaction_action=' . $transaction->action . '">' . $transaction->action_title . '</a>';
				break;
			case 'result':
				echo '<a class="sub_transaction_result_' . $transaction->result . '" href="edit.php?post_type=sub_transaction&amp;sub_transaction_result=' . $transaction->result . '">' . $transaction->result_title . '</a>';
				break;
			case 'subscriben_note':
				echo $transaction->note;
				break;
			default:
				break;
		}
	}

	/**
	 * Load object from cache
	 *
	 * @access public
	 * @param string $type
	 * @param int    $id
	 * @return object
	 */
	public function load_from_cache($type, $id) {
		if (!isset($this->cache[$type][$id])) {
			$object = 'subscriptions' == $type ? Simba_Subscriptions_Subscription::get_by_id($id) : new Simba_Subscriptions_Transaction($id);
			if (!$object) {
				return false;
			}
			$this->cache[$type][$id] = $object;
		}
		return $this->cache[$type][$id];
	}

	/**
	 * Remove some post actions for custom post type sub_transaction
	 *
	 * @access public
	 * @param array $actions
	 * @return array
	 */
	public function sub_transaction_remove_actions($actions) {
		global $post;

		if ('sub_transaction' == $post->post_type) {
			unset($actions['edit']);
			unset($actions['inline hide-if-no-js']);
			unset($actions['trash']);
		}

		return $actions;
	}

	/**
	 * Manage subscription list bulk actions
	 *
	 * @access public
	 * @param array $actions
	 * @return array
	 */
	public function manage_subscription_list_bulk_actions($actions) {
		$new_actions = array();

		foreach ($actions as $action_key => $action) {
			if (in_array($action_key, array('trash', 'untrash', 'delete'))) {
				$new_actions[$action_key] = $action;
			}
		}

		return $new_actions;
	}

	/**
	 * Manage transaction list bulk actions
	 *
	 * @access public
	 * @param array $actions
	 * @return array
	 */
	public function manage_transaction_list_bulk_actions($actions) {
		$new_actions = array();

		foreach ($actions as $action_key => $action) {
			if (in_array($action_key, array('trash', 'untrash', 'delete'))) {
				$new_actions[$action_key] = $action;
			}
		}

		return $new_actions;
	}

	/**
	 * Manage subscription list views (All, Trash ...)
	 *
	 * @access public
	 * @param array $views
	 * @return array
	 */
	public function manage_subscription_list_views($views) {
		$new_views = array();

		foreach ($views as $view_key => $view) {
			if (in_array($view_key, array('all', 'trash'))) {
				$new_views[$view_key] = $view;
			}
		}

		return $new_views;
	}

	/**
	 * Manage transaction list views (All, Trash ...)
	 *
	 * @access public
	 * @param array $views
	 * @return array
	 */
	public function manage_transaction_list_views($views) {
		$new_views = array();

		foreach ($views as $view_key => $view) {
			if (in_array($view_key, array('all', 'trash'))) {
				$new_views[$view_key] = $view;
			}
		}

		return $new_views;
	}

	/**
	 * Expand list search context with more fields
	 *
	 * @access public
	 * @param string $join
	 * @return string
	 */
	public function expand_list_search_context_join($join) {
		global $pagenow;
		global $wpdb;

		$post_types = array('subscription', 'sub_transaction');

		if ('edit.php' == $pagenow && isset($_GET['post_type']) && in_array($_GET['post_type'], $post_types) && isset($_GET['s']) && '' != $_GET['s']) {
			$join .= 'LEFT JOIN ' . $wpdb->postmeta . ' pm ON ' . $wpdb->posts . '.ID = pm.post_id ';
		}

		return $join;
	}

	/**
	 * Expand list search context with more fields
	 *
	 * @access public
	 * @param string $where
	 * @return string
	 */
	public function expand_list_search_context_where($where) {
		global $pagenow;
		global $wpdb;

		// Define post types with search contexts, meta field whitelist (searchable meta fields) etc
		$post_types = array(
			'subscription' => array(
				'contexts' => array(
					'subscription'  => 'ID',
					'user'          => 'user_id',
					'name'          => 'user_full_name',
					'order'         => 'all_order_ids',
					'product'       => 'product_id',
					'variation'     => 'variation_id',
				),
				'meta_whitelist' => array(
					'product_name',
					'user_full_name',
					'all_order_ids',
					'product_id',
					'variation_id',
				),
			),
			'sub_transaction' => array(
				'contexts' => array(
					'order'         => 'order_id',
					'product'       => 'product_id',
					'variation'     => 'variation_id',
					'subscription'  => 'subscription_id',
				),
				'meta_whitelist' => array(
					'order_id',
					'product_id',
					'variation_id',
					'subscription_id',
				),
			),
		);

		if ('edit.php' == $pagenow && isset($_GET['post_type']) && isset($post_types[$_GET['post_type']]) && !empty($_GET['s'])) {

			$search_phrase = trim($_GET['s']);
			$exact_match = false;
			$context = null;

			// Exact match?
			if (preg_match('/^\".+\"$/', $search_phrase) || preg_match('/^\'.+\'$/', $search_phrase)) {
				$exact_match = true;
				$search_phrase = substr($search_phrase, 1, -1);
			} elseif (preg_match('/^\\\\\".+\\\\\"$/', $search_phrase) || preg_match('/^\\\\\'.+\\\\\'$/', $search_phrase)) {
				$exact_match = true;
				$search_phrase = substr($search_phrase, 2, -2);
			} else {// Or search with context?
				foreach ($post_types[$_GET['post_type']]['contexts'] as $context_key => $context_value) {
					if (preg_match('/^' . $context_key . '\:/i', $search_phrase)) {
						$context = $context_value;
						$search_phrase = trim(preg_replace('/^' . $context_key . '\:/i', '', $search_phrase));
						break;
					}
				}
			}

			// Search by ID?
			if ('ID' == $context) {
				$replacement = $wpdb->prepare(
					'(' . $wpdb->posts . '.ID LIKE %s)',
					$search_phrase
				);
			} elseif ($context) {// Search within other context
				$replacement = $wpdb->prepare(
					'(pm.meta_key LIKE %s) AND (pm.meta_value LIKE %s)',
					$context,
					$search_phrase
				);
			} else {// Regular search
				$whitelist = 'pm.meta_key IN (\'' . join('\', \'', $post_types[$_GET['post_type']]['meta_whitelist']) . '\')';

				// Exact match?
				if ($exact_match) {
					$replacement = $wpdb->prepare(
						'(' . $wpdb->posts . '.ID LIKE %s) OR (pm.meta_value LIKE %s)',
						$search_phrase,
						$search_phrase
					);
					$replacement = '(' . $whitelist . ' AND ' . $replacement . ')';
				} else { // Regular match
					$replacement = '(' . $whitelist . ' AND ((' . $wpdb->posts . '.ID LIKE $1) OR (pm.meta_value LIKE $1)))';
				}
			}
			$where = preg_replace('/\(\s*' . $wpdb->posts . '.post_title\s+LIKE\s*(\'[^\']+\')\s*\)/', $replacement, $where);
		}

		return $where;
	}

	/**
	 * Expand list search context with more fields - group results by id
	 *
	 * @access public
	 * @param string $groupby
	 * @return string
	 */
	public function expand_list_search_context_group_by($groupby) {
		global $pagenow;
		global $wpdb;

		$post_types = array('subscription', 'sub_transaction');

		if ('edit.php' == $pagenow && isset($_GET['post_type']) && in_array($_GET['post_type'], $post_types) && isset($_GET['s']) && '' != $_GET['s']) {
			$groupby = $wpdb->posts . '.ID';
		}

		return $groupby;
	}

	/**
	 * Maybe display URL mismatch notification
	 *
	 * @access public
	 * @return void
	 */
	public function url_mismatch_notification() {
		if (!Simba_Subscriptions::is_admin()) {
			return;
		}

		$current_url = $this->get_main_site_url();

		if (!empty($_POST['subscriben_url_mismatch_action'])) {
			if ('change' == $_POST['subscriben_url_mismatch_action']) {
				$this->save_main_site_url($this->get_main_site_url());
			} elseif ('ignore' == $_POST['subscriben_url_mismatch_action']) {
				$this->update_option('subscriben_ignore_url_mismatch', $current_url);
			}
		} elseif (!self::is_main_site() && (empty($this->opt['subscriben_ignore_url_mismatch']) || $this->opt['subscriben_ignore_url_mismatch'] != $current_url)) {
			include SUBSCRIBEN_PLUGIN_PATH . 'includes/views/backend/admin/url-mismatch-notification.php';
		}
	}

	/**
	 * Maybe save main site URL
	 *
	 * @access public
	 * @return void
	 */
	public function maybe_save_main_site_url() {
		if (empty($this->opt['subscriben_main_site_url'])) {
			$this->save_main_site_url($this->get_main_site_url());
		}
	}

	/**
	 * Save main site URL so we can disable some actions on development/staging websites
	 *
	 * @access public
	 * @param string $url
	 * @return void
	 */
	public function save_main_site_url($url) {
		$this->update_option('subscriben_main_site_url', $url);
	}

	/**
	 * Get main site URL with placeholder in the middle
	 *
	 * @access public
	 * @return string
	 */
	public function get_main_site_url() {
		$current_site_url = get_site_url();
		return substr_replace($current_site_url, '%%%SUBSCRIPTIO%%%', (int) (strlen($current_site_url) / 2), 0);
	}

	/**
	 * Check if this is main site - some actions must be cancelled on development/staging websites
	 *
	 * @access public
	 * @return bool
	 */
	public static function is_main_site() {
		$is_main_site = false;

		$subscriben = self::get_instance();
		$current_site_url = get_site_url();

		// Make sure we have saved original URL, otherwise treat as duplicate site
		if (!empty($subscriben->opt['subscriben_main_site_url'])) {
			$main_site_url = set_url_scheme(str_replace('%%%SUBSCRIPTIO%%%', '', $subscriben->opt['subscriben_main_site_url']));
			$is_main_site = apply_filters('subscriben_site_url', $main_site_url) == $current_site_url ? true : false;
		}

		return apply_filters('subscriben_is_main_site', $is_main_site);
	}

	/**
	 * Add subscription edit page meta box
	 *
	 * @access public
	 * @param mixed $post
	 * @return void
	 */
	public function add_subscription_meta_box($post) {
		if (in_array($post->post_type, array('subscription'))) {

			// General subscription details block
			add_meta_box(
				'subscriben_subscription_details',
				__('Subscription Details', 'subscriben'),
				array($this, 'render_subscription_meta_box_details'),
				'subscription',
				'normal',
				'high'
			);

			// Subscription items
			add_meta_box(
				'subscriben_subscription_items',
				__('Subscription Items', 'subscriben'),
				array($this, 'render_subscription_meta_box_items'),
				'subscription',
				'normal',
				'high'
			);

			// Subscription actions
			add_meta_box(
				'subscriben_subscription_actions',
				__('Subscription Actions', 'subscriben'),
				array($this, 'render_subscription_meta_box_actions'),
				'subscription',
				'side',
				'default'
			);

			// Subscription transactions
			add_meta_box(
				'subscriben_subscription_transactions',
				__('Transactions', 'subscriben'),
				array($this, 'render_subscription_meta_box_transactions'),
				'subscription',
				'side',
				'default'
			);
		}
	}

	/**
	 * Save subscription custom fields from edit page
	 *
	 * @access public
	 * @param int    $post_id
	 * @param object $post
	 * @return void
	 */
	public function save_subscription_meta_box($post_id, $post) {
		// Check if required properties were passed in
		if (empty($post_id) || empty($post)) {
			return;
		}

		// Make sure user has permissions to edit this post
		if (!current_user_can('edit_post', $post_id)) {
			return;
		}

		// Make sure the correct post ID was passed from form
		if (empty($_POST['post_ID']) || $_POST['post_ID'] != $post_id) {
			return;
		}

		// Make sure it is not a draft save action
		if (defined('DOING_AUTOSAVE') || is_int(wp_is_post_autosave($post)) || is_int(wp_is_post_revision($post))) {
			return;
		}

		// Proceed only if post type is subscription
		if ('subscription' != $post->post_type) {
			return;
		}

		$subscription = $this->load_from_cache('subscriptions', $post_id);

		if (!$subscription) {
			return;
		}

		// Actions
		if (!empty($_POST['subscriben_subscription_button']) && 'actions' == $_POST['subscriben_subscription_button'] && !empty($_POST['subscriben_subscription_actions'])) {
			switch ($_POST['subscriben_subscription_actions']) {
				// Cancel
				case 'cancel':
					if ($subscription->can_be_cancelled()) {
						// Write transaction
						$transaction = new Simba_Subscriptions_Transaction(null, 'manual_cancellation');
						$transaction->add_subscription_id($subscription->id);
						$transaction->add_product_id($subscription->product_id);
						$transaction->add_variation_id($subscription->variation_id);

						try {
							// Cancel subscription
							$subscription->cancel();

							// Update transaction
							$transaction->update_result('success');
							$transaction->update_note(__('Subscription cancelled manually by administrator.', 'subscriben'), true);
						} catch (Exception $e) {
							$transaction->update_result('error');
							$transaction->update_note($e->getMessage());
						}
					}
					break;
				// Pause
				case 'pause':
					// Make sure that subscription can be paused
					if ($subscription->can_be_paused()) {
						// Write transaction
						$transaction = new Simba_Subscriptions_Transaction(null, 'subscription_pause');
						$transaction->add_subscription_id($subscription->id);
						$transaction->add_product_id($subscription->product_id);
						$transaction->add_variation_id($subscription->variation_id);

						try {
							// Pause subscription
							$subscription->pause();

							// Update transaction
							$transaction->update_result('success');
							$transaction->update_note(__('Subscription paused by administrator.', 'subscriben'), true);
						} catch (Exception $e) {
							$transaction->update_result('error');
							$transaction->update_note($e->getMessage());
						}
					}
					break;
				// Resume
				case 'resume':
					// Make sure that subscription can be resumed (was paused)
					if ($subscription->can_be_resumed()) {
						// Write transaction
						$transaction = new Simba_Subscriptions_Transaction(null, 'subscription_resume');
						$transaction->add_subscription_id($subscription->id);
						$transaction->add_product_id($subscription->product_id);
						$transaction->add_variation_id($subscription->variation_id);

						try {
							// Resume subscription
							$subscription->resume();

							// Update transaction
							$transaction->update_result('success');
							$transaction->update_note(__('Subscription resumed by administrator.', 'subscriben'), true);
						} catch (Exception $e) {
							$transaction->update_result('error');
							$transaction->update_note($e->getMessage());
						}
					}
					break;
				default:
					break;
			}
		} elseif (!empty($_POST['subscriben_subscription_button']) && 'address' == $_POST['subscriben_subscription_button']) { // Address update
			$subscription->update_shipping_address($_POST);
		}
	}

	/**
	 * Render subscription edit page meta box Subscription Details content
	 *
	 * @access public
	 * @param mixed $post
	 * @return void
	 */
	public function render_subscription_meta_box_details($post) {
		$subscription = $this->load_from_cache('subscriptions', $post->ID);

		if (!$subscription) return;

		// Get subscription statuses
		$subscription_statuses = Simba_Subscriptions_Subscription::get_statuses();// phpcs:disable VariableAnalysis.CodeAnalysis.VariableAnalysis.UnusedVariable  -- Actually used in the included template

		// Load view
		include SUBSCRIBEN_PLUGIN_PATH . 'includes/views/backend/subscription/subscription-details.php';
	}

	/**
	 * Render subscription edit page meta box Subscription Items content
	 *
	 * @access public
	 * @param mixed $post
	 * @return void
	 */
	public function render_subscription_meta_box_items($post) {
		$subscription = $this->load_from_cache('subscriptions', $post->ID);

		if (!$subscription) {
			return;
		}

		// Load view
		include SUBSCRIBEN_PLUGIN_PATH . 'includes/views/backend/subscription/subscription-items.php';
	}

	/**
	 * Render subscription edit page meta box Subscription Actions content
	 *
	 * @access public
	 * @param mixed $post
	 * @return void
	 */
	public function render_subscription_meta_box_actions($post) {
		$subscription = $this->load_from_cache('subscriptions', $post->ID);

		if (!$subscription) {
			return;
		}

		// Load view
		include SUBSCRIBEN_PLUGIN_PATH . 'includes/views/backend/subscription/subscription-actions.php';
	}

	/**
	 * Render subscription edit page meta box Subscription Transactions content
	 *
	 * @access public
	 * @param mixed $post
	 * @return void
	 */
	public function render_subscription_meta_box_transactions($post) {
		$subscription = $this->load_from_cache('subscriptions', $post->ID);

		if (!$subscription) {
			return;
		}

		$transactions = array();
		// This database version filled in the "post parent" field, removing the need to row-scan meta_value values.
		$subscriben_db_version = get_option('subscriben_dbversion');
		// Get all transaction IDs
		if (version_compare($subscriben_db_version, '0.12.4', '<')) {
			$query = new WP_Query(array(
				'post_type'     => 'sub_transaction',
				'fields'        => 'ids',
				'posts_per_page' => -1,
				'meta_query'    => array(
					array(
						'key'       => 'subscription_id',
						'value'     => $subscription->id,
						'compare'   => '=',
					),
				),
			));
		} else {
			$query = new WP_Query(array(
				'post_type'      => 'sub_transaction',
				'fields'         => 'ids',
				'posts_per_page' => -1,
				'post_parent'    => $subscription->id,
				'orderby'        => array( 'ID' => 'DESC' ),
			));
		}
		
		// Populate list of transactions
		foreach ($query->posts as $transaction_id) {
			$transactions[] = new Simba_Subscriptions_Transaction($transaction_id);
		}

		// Load view
		include SUBSCRIBEN_PLUGIN_PATH . 'includes/views/backend/subscription/subscription-transactions.php';
	}

	/**
	 * Add admin menu items
	 *
	 * @access public
	 * @return void
	 */
	public function add_admin_menu() {
		// Add submenu links
		add_submenu_page(
			'edit.php?post_type=subscription',
			__('Settings', 'subscriben'),
			__('Settings', 'subscriben'),
			Simba_Subscriptions::get_admin_capability(),
			'subscriben_settings',
			array($this, 'set_up_settings_pages')
		);
		
		add_submenu_page(
			'edit.php?post_type=subscription',
			__('Scheduled events', 'subscriben'),
			__('Scheduled events', 'subscriben'),
			Simba_Subscriptions::get_admin_capability(),
			'subscriben_events',
			array($this, 'events_admin_page')
		);

		add_submenu_page(
			'edit.php?post_type=subscription',
			__('Logs', 'subscriben'),
			__('Logs', 'subscriben'),
			Simba_Subscriptions::get_admin_capability(),
			'subscriben_logs',
			array($this, 'logs_admin_page')
		);

		// Remove Add Subscriptions if other plugins have set it back
		global $submenu;

		if (isset($submenu['edit.php?post_type=subscription'])) {
			foreach ($submenu['edit.php?post_type=subscription'] as $item_key => $item) {
				if (in_array('post-new.php?post_type=subscription', $item)) {
					unset($submenu['edit.php?post_type=subscription'][$item_key]);
				}
			}
		}
	}

	/**
	 * Paint the contents of the scheduled events page
	 */
	public function events_admin_page() {
	
		global $wpdb;
		$table_name = Simba_Subscriptions_Event_Scheduler::table_name();
		
		$page_size = 100;
		
		$events = $wpdb->get_results($wpdb->prepare("SELECT * FROM ".$table_name." ORDER BY event_timestamp ASC LIMIT %d", $page_size));
	
		?><h1><?php esc_html_e('Scheduled events', 'subscriben'); ?></h1>
		
		<p>
			<?php esc_html_e('This is a debugging aid, allowing you to see what future events have been scheduled, and which subscription each relates to.', 'subscriben');?>
			<?php printf(esc_html__('If, as a developer, you wish to run an event manually, then you can do so by deleting the entry from the SQL table (%s) (to prevent duplicate events), and then running code like %s, which will run the (create renewal) \'order\' event for the subscription 123456.', 'subscriben'), $table_name, '<code>Simba_Subscriptions_Event_Scheduler::scheduled_order(123456);</code>'); ?>
		</p>
		
		<?php

		if (!is_array($events) || 0 == count($events)) {
			esc_html_e('There are no scheduled events.', 'subscriben');
			return;
		}
		
		if (count($events) >= $page_size) {
			echo '<p><em>'.sprintf(__('Showing the soonest %d events.', 'subscriben'), count($events)).'<em></p>';
		}
		
		// Other attributes: event_meta, attempt_count, last_attempt_timestamp, processing
		
		?><table class="widefat striped">
			<thead>
			<tr>
				<th><?php esc_html_e('Time', 'subscriben');?></th>
				<th><?php esc_html_e('Subscription', 'subscriben');?></th>
				<th><?php esc_html_e('Event', 'subscriben');?></th>
			</tr>
			</thead>
			<tbody>
			<?php

		$time_now = time();
			
		foreach ($events as $event) {
		
			$seconds_from_now = $event->event_timestamp - $time_now;
		
			if ($seconds_from_now < 60) {
				$time_from_now = sprintf(__('%d seconds', 'subscriben'), $seconds_from_now);
			} elseif ($seconds_from_now < 3600) {
				$time_from_now = sprintf(__('%d minutes, %d seconds', 'subscriben'), (int) ($seconds_from_now/60), $seconds_from_now % 60);
			} elseif ($seconds_from_now < 86400) {
			
				$hours = (int) ($seconds_from_now/3600);
				$minutes = (int) (($seconds_from_now-$hours*3600)/60);
			
				$time_from_now = sprintf(__('%d hours, %d minutes, %d seconds', 'subscriben'), $hours, $minutes, $seconds_from_now % 60);
			} else {
				$days = (int) floor(($seconds_from_now/86400));
				$hours = (int) floor(($seconds_from_now-($days*86400))/3600);
				$minutes = (int) floor(($seconds_from_now-($days*86400)-($hours*3600))/60);
				$seconds = (int) floor($seconds_from_now-($days*86400)-($hours*3600)-($minutes*60));
			
				$time_from_now = sprintf(__('%d days, %d hours, %d minutes, %d seconds', 'subscriben'), $days, $hours, $minutes, $seconds);
			}
		
			?>
			<tr data-event-id="<?php echo esc_attr($event->event_id); ?>">
				<td><?php echo htmlspecialchars(date_i18n(get_option('date_format').' '.get_option('time_format'), $event->event_timestamp), ENT_COMPAT, 'UTF-8').' - '.$time_from_now; ?></td>
				<td><?php Simba_Subscriptions_Helper::print_link_to_post($event->subscription_id); ?></td>
				<td><?php echo htmlspecialchars($event->event_key, ENT_COMPAT, 'UTF-8'); ?></td>
			</tr>
			<?php
		}
		echo '</tbody></table>';

	}

	/**
	 * Paint the contents of the subscriben logs page
	 */
	public function logs_admin_page() {

		?><h1><?php _e('Logs', 'subscriben'); ?></h1>
		
		<p><?php _e('Subscriben also creates some WooCommerce logs, mainly for the Subscriben payment gateways.', 'subscriben');?> <?php _e('You can view these Subscriben logs from Subscriben itself, rather than going through the WooCommerce menu.', 'subscriben');?></p>
		
		<?php

		$logs = WC_Admin_Status::scan_log_files();
		$subscriben_logs = array_filter(array_keys($logs), function($key) {
			return 0 === strpos($key, 'subscriben');
		});
		$subscriben_logs = array_intersect_key($logs, array_flip($subscriben_logs));
		if (0 == count($subscriben_logs)) {
			_e('There are no subscriben payment gateways logs.', 'subscriben');
			return;
		}
		add_action('admin_footer', array($this, 'admin_footer_subscriben_logs_js'));
		?><table class="widefat striped">
			<thead>
			<tr>
				<th><?php _e('Log File', 'subscriben');?></th>
				<th><?php echo htmlspecialchars(__('Date & Time', 'subscriben'), ENT_QUOTES, 'UTF-8');?></th>
				<th><?php _e('Action', 'subscriben');?></th>
			</tr>
			</thead>
			<tbody>
			<form action="<?php echo esc_url(admin_url('admin.php?page=wc-status&tab=logs')); ?>" method="post" id="subscribenlogsform">
			<input type="hidden" name="log_file" id="log_file" value="">
			<?php
			$log = 0;
		foreach ($subscriben_logs as $log_key => $log_file) :

			$timestamp = filemtime(WC_LOG_DIR . $log_file);
			$date = sprintf(__('%1$s at %2$s %3$s', 'subscriben'), wp_date(wc_date_format(), $timestamp), wp_date(wc_time_format(), $timestamp), wp_date('T', $timestamp));
			$log++;
			?>
			<tr>
				<td><?php echo esc_html($log_file); ?></td>
				<td><?php echo esc_html($date); ?></td>
				<td><button type="button" id="viewlog_<?php echo esc_attr($log); ?>" class="button view-logs-btn" value="<?php echo esc_attr($log_key); ?>"><?php _e('View', 'subscriben');?></button></td>
			</tr>
			</form>
			<?php
		endforeach;
		echo '</tbody></table>';

	}

	/**
	 * This function will output any needed js for subscriben logs.
	 *
	 * @return void
	 */
	public function admin_footer_subscriben_logs_js() {
		?>
		<script>
			jQuery(function($) {
				$('.view-logs-btn').on('click', function(e) {
					e.preventDefault();
					document.getElementById('log_file').value = $(this).val();
					$('#subscribenlogsform').submit();
				});
			});
		</script>
		<?php
	}
	
	/**
	 * Register our settings fields with WordPress
	 *
	 * @access public
	 * @return void
	 */
	public function plugin_options_setup() {
		// Check if current user can manage Subscription options
		if (Simba_Subscriptions::is_admin()) {

			// Iterate over tabs
			foreach ($this->settings as $tab_key => $tab) {

				register_setting(
					'subscriben_opt_group_' . $tab_key,
					'subscriben_options',
					array($this, 'options_validate')
				);

				// Iterate over sections
				foreach ($tab['children'] as $section_key => $section) {
					
					// Add section
					add_settings_section(
						$section_key,
						$section['title'],
						array($this, 'render_section_info'),
						'subscriben-admin-' . str_replace('_', '-', $tab_key)
					);

					// Iterate over fields
					foreach ($section['children'] as $field_key => $field) {

								// Add text to display after a field
								if (in_array($field_key, array('stripe_enabled', 'paypal_enabled', 'paypal_ec_enabled')) && $this->option($field_key)) {
						$payment_gateway_section = 'subscriben_' . str_replace('_enabled', '', $field_key);
						$after = '<a style="padding-left: 20px;" href="admin.php?page=wc-settings&tab=checkout&section=' . $payment_gateway_section . '">'.__('Settings', 'subscriben').'</a>';
								} else {
							$after = isset($field['after']) ? $field['after'] : '';
								}

						// Add field
						add_settings_field(
							'subscriben_' . $field_key,
							$field['title'],
							array($this, 'render_field_' . $field['type']),
							'subscriben-admin-' . str_replace('_', '-', $tab_key),
							$section_key,
							array(
								'name'        => 'subscriben_' . $field_key,
								'options'     => $this->opt,
								'values'      => isset($field['values']) ? $field['values'] : '',
								'placeholder' => isset($field['placeholder']) ? $field['placeholder'] : '',
								'after'       => $after,
							)
						);
					}
				}
			}
		}
	}

	/**
	 * Render section info
	 *
	 * @access public
	 * @param array $section
	 * @return void
	 */
	public function render_section_info($section) {
		// Subscription Flow
		if ('subscription_flow' === $section['id']) {
			echo '<img src="' . SUBSCRIBEN_PLUGIN_URL . '/assets/img/subscription_flow.png' . '" style="margin: 20px 110px 20px 110px;">';
			echo '<p style="margin: 25px;">' . __('Payment reminders, overdue period and suspensions are optional.<br>Not displayed in illustration are trial periods, expiration dates and subscription pausing and resuming capability.', 'subscriben') . '</p>';
			echo '<p style="margin: 25px;">' . sprintf(__('You can enable/disable email notifications on the <a href="%s">Emails</a> page.', 'subscriben'), 'admin.php?page=wc-settings&tab=email') . '</p>';
		}
	}

	/**
	 * Render checkbox field
	 *
	 * @param array $args
	 * @return void
	 */
	public function render_field_checkbox($args = array()) {
		printf(
			'<input type="checkbox" id="%s" name="subscriben_options[%s]" value="1" %s />%s',
			$args['name'],
			$args['name'],
			checked($args['options'][$args['name']], true, false),
			!empty($args['after']) ? '&nbsp;&nbsp;' . $args['after'] : ''
		);
	}

	/**
	 * Render checkbox field
	 *
	 * @param array $args
	 * @return void
	 */
	public function render_field_text($args = array()) {
		if (in_array($args['name'], array('subscriben_renewal_order_day_offset', 'subscriben_reminders_days', 'subscriben_overdue_length', 'subscriben_suspensions_length', 'subscriben_max_pauses', 'subscriben_max_pause_duration'))) {
			$field_width_class = 'subscriben_field_width_third';
		} else {
			$field_width_class = 'subscriben_field_width';
		}

		printf(
			'<input type="text" id="%s" name="subscriben_options[%s]" value="%s" class="' . $field_width_class . '" placeholder="%s" />%s',
			$args['name'],
			$args['name'],
			$args['options'][$args['name']],
			$args['placeholder'],
			!empty($args['after']) ? '&nbsp;&nbsp;' . $args['after'] : ''
		);
	}

	/**
	 * Render a dropdown
	 *
	 * @access public
	 * @param array $args
	 * @return void
	 */
	public function render_field_dropdown($args = array()) {
		printf(
			'<select id="%s" name="subscriben_options[%s]" class="subscriben_field_width">',
			$args['name'],
			$args['name']
		);

		foreach ($args['values'] as $key => $name) {
			printf(
				'<option value="%s" %s>%s</option>',
				$key,
				selected($key, $args['options'][$args['name']], false),
				$name
			);
		}

		echo '</select>';
	}
	
	/**
	 * Render Stripe field section
	 *
	 * Display a link to the WooCommerce Stripe Gateway plugin settings page if its active
	 *
	 * @param array $args
	 * @return void
	 */
	public function render_field_stripe_info($args = array()) {
		if (is_plugin_active('woocommerce-gateway-stripe/woocommerce-gateway-stripe.php')) {
			$stripe_link_text = __('Go here to manage your Stripe settings', 'subscriben');
			echo '<a href="admin.php?page=wc-settings&tab=checkout&section=stripe">'.$stripe_link_text.'</a>';
		} else {
			printf(__('To use Stripe with Subscriben, install and activate %s.', 'subscriben'), '<a href="https://wordpress.org/plugins/woocommerce-gateway-stripe/">'.__('the WooCommerce Stripe Gateway plugin', 'subscriben').'</a>');
		}

	}

	/**
	 * Validate saved options
	 *
	 * @access public
	 * @param array $input
	 * @return void
	 */
	public function options_validate($input) {
		$output = $this->opt;

		if (empty($_POST['current_tab']) || !isset($this->settings[$_POST['current_tab']])) {
			return $output;
		}

		$errors = array();

		// Iterate over fields and validate new values
		foreach ($this->settings[$_POST['current_tab']]['children'] as $section_key => $section) {
			foreach ($section['children'] as $field_key => $field) {

				$current_field_key = 'subscriben_' . $field_key;

				switch ($field['validation']['rule']) {
					// Checkbox
					case 'bool':
						$input[$current_field_key] = (!isset($input[$current_field_key]) || '' == $input[$current_field_key]) ? '0' : $input[$current_field_key];
						if (in_array($input[$current_field_key], array('0', '1')) || ('' == $input[$current_field_key] && true == $field['validation']['empty'])) {
								$output[$current_field_key] = $input[$current_field_key];
						} else {
											array_push($errors, array('setting' => $current_field_key, 'code' => 'bool', 'title' => $field['title']));
						}
						break;
					// Number
					case 'number':
						if (is_numeric($input[$current_field_key]) || ('' == $input[$current_field_key] && true == $field['validation']['empty'])) {
								$output[$current_field_key] = $input[$current_field_key];
						} elseif ('subscriben_reminders_days' == $current_field_key) {
							$reminder_days = explode(',', trim($input[$current_field_key], ','));

							$is_ok = true;

							foreach ($reminder_days as $reminder_day) {
								if (!is_numeric($reminder_day)) {
								$is_ok = false;
								break;
								}
							}

							if ($is_ok) {
								$output[$current_field_key] = trim($input[$current_field_key], ',');
							} else {
								array_push($errors, array('setting' => $current_field_key, 'code' => 'number', 'title' => $field['title']));
							}
						} else {
							array_push($errors, array('setting' => $current_field_key, 'code' => 'number', 'title' => $field['title']));
						}
						break;
					// Option
					case 'option':
						if (isset($input[$current_field_key]) && (isset($field['values'][$input[$current_field_key]]) || ('' == $input[$current_field_key] && true == $field['validation']['empty']))) {
								$output[$current_field_key] = $input[$current_field_key];
						} elseif (!isset($input[$current_field_key])) {
											$output[$current_field_key] = '';
						} else {
															array_push($errors, array('setting' => $current_field_key, 'code' => 'option', 'title' => $field['title']));
						}
						break;
					// Text input and others - default validation rule
					default:
						// Make sure the field is set
						$input[$current_field_key] = (isset($input[$current_field_key])) ? $input[$current_field_key] : '';

						if ('' == $input[$current_field_key] && false === $field['validation']['empty']) {
								array_push($errors, array('setting' => $current_field_key, 'code' => 'string', 'title' => $field['title']));
						} else {
							$output[$current_field_key] = esc_attr(trim($input[$current_field_key]));
						}
						break;
				}
			}
		}

		// Display settings updated message
		add_settings_error(
			'subscriben',
			'subscriben_' . 'settings_updated',
			__('Your settings have been saved.', 'subscriben'),
			'updated'
		);

		// Display errors
		foreach ($errors as $error) {
			$reverted = __('Reverted to a previous value.', 'subscriben');

			$messages = array(
				'number' => __('must be numeric', 'subscriben') . '. ' . $reverted,
				'bool' => __('must be either 0 or 1', 'subscriben') . '. ' . $reverted,
				'option' => __('is not allowed', 'subscriben') . '. ' . $reverted,
				'email' => __('is not a valid email address', 'subscriben') . '. ' . $reverted,
				'url' => __('is not a valid URL', 'subscriben') . '. ' . $reverted,
				'string' => __('is not a valid text string', 'subscriben') . '. ' . $reverted,
			);

			add_settings_error(
				'subscriben',
				$error['code'],
				__('Value of', 'subscriben') . ' "' . $error['title'] . '" ' . $messages[$error['code']]
			);
		}

		return $output;
	}

	/**
	 * Set up settings pages
	 *
	 * @access public
	 * @return void
	 */
	public function set_up_settings_pages() {
		// Get current page & tab ids
		$current_tab = $this->get_current_settings_tab();// phpcs:disable VariableAnalysis.CodeAnalysis.VariableAnalysis.UnusedVariable  -- Actually used in the following included templates

		// Open form container
		echo '<div class="wrap woocommerce"><form method="post" action="options.php" enctype="multipart/form-data">';

		// Print notices
		settings_errors('subscriben');

		// Print header
		include SUBSCRIBEN_PLUGIN_PATH . 'includes/views/backend/settings/header.php';

		// Print settings page content
		include SUBSCRIBEN_PLUGIN_PATH . 'includes/views/backend/settings/fields.php';

		// Print footer
		include SUBSCRIBEN_PLUGIN_PATH . 'includes/views/backend/settings/footer.php';

		// Close form container
		echo '</form></div>';
	}

	/**
	 * Get current settings tab
	 *
	 * @access public
	 * @return string
	 */
	public function get_current_settings_tab() {
		// Check if we know tab identifier
		if (isset($_GET['tab']) && isset($this->settings[$_GET['tab']])) {
			$tab = $_GET['tab'];
		} else {
			$keys = array_keys($this->settings);
			$tab = array_shift($keys);
		}

		return $tab;
	}

	/**
	 * Check if it's Subscription page and whether to load scripts for backend
	 *
	 * @access public
	 * @return void
	 */
	public static function is_subscriben_page() {
		// Check the query string
		if (!isset($_SERVER['QUERY_STRING'])) {
			return false;
		}

		$query = $_SERVER['QUERY_STRING'];

		if (preg_match('/post_type=(subscription|sub_transaction)/i', $query)) {
			return true;
		} elseif (!empty($_REQUEST['post']) && is_numeric($_REQUEST['post'])) { // And also check post edit page
			$post = get_post($_REQUEST['post']);

			if (is_a($post, 'WP_Post') && in_array($post->post_type, array('subscription', 'sub_transaction'))) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Load backend assets conditionally
	 *
	 * @access public
	 * @return bool
	 */
	public function enqueue_backend_assets() {
		// Our own scripts and styles
		wp_register_script('subscriben-backend-scripts', SUBSCRIBEN_PLUGIN_URL . '/assets/js/backend.js', array('jquery'), SUBSCRIBEN_VERSION);
		wp_register_style('subscriben-backend-styles', SUBSCRIBEN_PLUGIN_URL . '/assets/css/backend.css', array(), SUBSCRIBEN_VERSION);

		// Scripts
		wp_enqueue_script('subscriben-backend-scripts');

		// Styles
		wp_enqueue_style('subscriben-backend-styles');

		// Datepicker
		wp_enqueue_script('jquery-ui-datepicker');

		// Datepicker styles
		wp_register_style('subscriben-jquery-ui', SUBSCRIBEN_PLUGIN_URL . '/assets/jquery-ui/jquery-ui.min.css', array(), SUBSCRIBEN_VERSION);
		wp_enqueue_style('subscriben-jquery-ui');
	}

	/**
	 * Load backend assets unconditionally
	 *
	 * @access public
	 * @return bool
	 */
	public function enqueue_backend_assets_all() {
		// Our own scripts and styles
		wp_register_script('subscriben-backend-scripts-all', SUBSCRIBEN_PLUGIN_URL . '/assets/js/backend-all.js', array('jquery'), SUBSCRIBEN_VERSION);
		wp_register_style('subscriben-backend-styles-all', SUBSCRIBEN_PLUGIN_URL . '/assets/css/backend-all.css', array(), SUBSCRIBEN_VERSION);

		// Localize script
		wp_localize_script('subscriben-backend-scripts-all', 'subscriben_vars', array(
			'title_subscription_product' => __('Subscription product', 'subscriben'),
			'current_text'               => __('Today', 'subscriben'),
			'close_text'                 => __('Close', 'subscriben'),
			'date_change_alert'          => __('Error! The selected date is incorrect!', 'subscriben'),
			'price_change_fail_alert'    => __('Error! Unable to update the subscription.', 'subscriben'),
		));

		// Font awesome (icons)
		wp_register_style('subscriben-font-awesome', SUBSCRIBEN_PLUGIN_URL . '/assets/font-awesome/css/font-awesome.min.css', array(), '4.1');

		// Scripts
		wp_enqueue_script('subscriben-backend-scripts-all');

		// Styles
		wp_enqueue_style('subscriben-backend-styles-all');
		wp_enqueue_style('subscriben-font-awesome');

		// RTL support
		if (is_rtl()) {
			wp_register_style('subscriben-backend-rtl-styles', SUBSCRIBEN_PLUGIN_URL . '/assets/css/backend-rtl.css', array(), SUBSCRIBEN_VERSION);
			wp_enqueue_style('subscriben-backend-rtl-styles');
		}
	}

	/**
	 * Load frontend JS assets
	 *
	 * @access public
	 * @return bool
	 */
	public static function enqueue_frontend_js_assets() {
		// Frontend scripts
		wp_register_script('subscriben_frontend', SUBSCRIBEN_PLUGIN_URL . '/assets/js/frontend.js', array('jquery'), SUBSCRIBEN_VERSION);
		wp_localize_script('subscriben_frontend', 'subscriben_vars', array(
			'confirm_pause'     => __('Are you sure you want to pause this subscription?', 'subscriben'),
			'confirm_resume'    => __('Are you sure you want to resume this subscription?', 'subscriben'),
			'confirm_cancel'    => __('Are you sure you want to cancel this subscription?', 'subscriben'),
		));
		wp_enqueue_script('subscriben_frontend');
	}
	
	/**
	 * Load frontend CSS assets
	 *
	 * @access public
	 * @return bool
	 */
	public function enqueue_frontend_css_assets() {
		// Frontend styles
		wp_register_style('subscriben_frontend', SUBSCRIBEN_PLUGIN_URL . '/assets/css/frontend.css', array(), SUBSCRIBEN_VERSION);
		wp_enqueue_style('subscriben_frontend');

		// RTL support
		if (is_rtl()) {
			wp_register_style('subscriben-frontend-rtl-styles', SUBSCRIBEN_PLUGIN_URL . '/assets/css/frontend-rtl.css', array(), SUBSCRIBEN_VERSION);
			wp_enqueue_style('subscriben-frontend-rtl-styles');
		}
	}

	/**
	 * Allow no guest checkout
	 *
	 * @access public
	 * @param object $checkout
	 * @return void
	 */
	public function enforce_registration($checkout) {
		// User already registered?
		if (is_user_logged_in()) {
			return;
		}

		// Only proceed if cart contains subscription
		if (self::cart_contains_subscription()) {

			// Enable registration
			if (!$checkout->enable_signup) {
				$checkout->enable_signup = true;
			}

			// Enforce registration
			if ($checkout->enable_guest_checkout) {
				$checkout->enable_guest_checkout = false;
				$checkout->must_create_account = true;
			}
		}
	}

	/**
	 * Enforce create new account option
	 *
	 * @access public
	 * @param array $params
	 * @return void
	 */
	public function enforce_createaccount_option() {
		// User already registered?
		if (is_user_logged_in()) {
			return;
		}

		// Only proceed if cart contains subscription
		if (self::cart_contains_subscription()) {
			$_POST['createaccount'] = 1;
		}
	}
	
	/**
	 * Force registration on checkout block (guest users)
	 *
	 * @param \WC_Customer $customer
	 * @param \WP_REST_Request $request
	 * @return void
	 */
	public function checkout_block_force_registration( $customer, $request ) {
		// User already registered?
		if (is_user_logged_in()) {
			return;
		}

		// Only proceed if cart contains subscription
		if (!self::cart_contains_subscription()) {
			return;
		}
		
		// Only proceed if checkout block
		if (!self::is_checkout_block()) {
			return;
		}
		
		if ( 0 === $customer->get_id() ) {
			add_filter( 'woocommerce_checkout_registration_enabled', '__return_true', 99 );
			add_filter( 'woocommerce_checkout_registration_required', '__return_true', 99 );
		}
	}
	
	/**
	 * Remove forcing registration filters on checkout block (guest users)
	 *
	 * @param \WC_Order $order
	 * @return bool
	 */
	public function remove_checkout_block_force_registration( $order ) {
		remove_filter( 'woocommerce_checkout_registration_enabled', '__return_true', 99 );
		remove_filter( 'woocommerce_checkout_registration_required', '__return_true', 99 );
	}

	/**
	 * Allow no guest checkout (Javascript part)
	 *
	 * @access public
	 * @param array $properties
	 * @return array
	 */
	public function enforce_registration_js($properties) {
		// User already registered?
		if (is_user_logged_in()) {
			return $properties;
		}

		// No subscription in cart?
		if (!self::cart_contains_subscription()) {
			return $properties;
		}

		$properties['option_guest_checkout'] = 'no';

		return $properties;
	}

	/**
	 * Check if cart contains subscription product
	 *
	 * @access public
	 * @return bool
	 */
	public static function cart_contains_subscription() {
		$woocommerce = WC();

		if (!empty($woocommerce->cart->cart_contents)) {
			foreach ($woocommerce->cart->cart_contents as $item) {
				if (Simba_Subscriptions_Subscription_Product::is_subscription($item['variation_id'] ? $item['variation_id'] : $item['product_id'])) {
					return true;
				}
			}
		}

		return false;
	}

	/**
	 * Sanitize float (treats as a string)
	 *
	 * @access public
	 * @param string $input
	 * @return string
	 */
	public static function sanitize_float($input) {
		return preg_replace('/[^0-9\.]/', '', $input);
	}

	/**
	 * Sanitize integer (treats as a string)
	 *
	 * @access public
	 * @param string $input
	 * @return string
	 */
	public static function sanitize_integer($input) {
		return preg_replace('/[^0-9]/', '', $input);
	}

	/**
	 * Get natural number from anything
	 *
	 * @access public
	 * @param string $input
	 * @return int
	 */
	public static function get_natural_number($input) {
		if (!isset($input)) {
			return 1;
		}

		$input = (int) self::sanitize_integer($input);

		return $input < 1 ? 1 : $input;
	}

	/**
	 * Get floating point number from anything (but return as string)
	 * Returns zero (0) if input variable is not properly defined
	 *
	 * @access public
	 * @param string $input
	 * @return string
	 */
	public static function get_float_number_as_string($input) {
		if (!isset($input)) {
			return '0';
		}

		return (string) (float) self::sanitize_float($input);
	}

	/**
	 * Get timezone-adjusted formatted date/time string
	 *
	 * @access public
	 * @param int    $timestamp
	 * @param string $format
	 * @param string $context
	 * @return string
	 */
	public static function get_adjusted_datetime($timestamp, $format = null, $context = null) {
		// Fix possible issues
		if (empty($timestamp)) {
			return false;
		}

		// No format passed? Get it from WordPress settings and allow developers to override it
		if (null === $format) {
			$date_format = apply_filters('subscriben_date_format', get_option('date_format'), $context);
			$time_format = apply_filters('subscriben_time_format', get_option('time_format'), $context);
			$format = $date_format . (apply_filters('subscriben_display_event_time', true) ? ' ' . $time_format : '');
		}

		// Get adjusted datetime
		return Simba_Subscriptions_Helper::get_adjusted_datetime($timestamp, $format);
	}

	/**
	 * Get user full name from database with link to user profile or revert to provided name
	 *
	 * @access public
	 * @param int    $user_id
	 * @param string $default
	 * @return string
	 */
	public static function get_user_full_name_link($user_id, $default) {
		// User still exists?
		if ($user = get_userdata($user_id)) {
			$first_name = get_the_author_meta('first_name', $user_id);
			$last_name = get_the_author_meta('last_name', $user_id);

			if ($first_name || $last_name) {
				$display_name = join(' ', array($first_name, $last_name));
			} else {
				$display_name = $user->display_name;
			}

			return '<a href="user-edit.php?user_id=' . $user_id . '">' . $display_name . '</a>';
		}

		return $default . ' (' . __('deleted', 'subscriben') . ')';
	}

	/**
	 * Get formatted shipping address
	 *
	 * @access public
	 * @param array $input
	 * @return string
	 */
	public static function get_formatted_shipping_address($input) {
		if (!is_array($input) || empty($input)) {
			return '';
		}

		$address = array();

		foreach ($input as $key => $value) {
			$address[str_replace('_shipping_', '', $key)] = $value;
		}

		$address = apply_filters('woocommerce_order_formatted_shipping_address', $address);

		return WC()->countries->get_formatted_address($address);
	}

	/**
	 * Get formatted price
	 *
	 * @access public
	 * @param float		 $price
	 * @param string	 $currency
	 * @param bool		 $sale_price
	 * @param bool		 $display_price_suffix
	 * @param WC_Product $product			   - associated product; should be used if $display_price_suffix is set to avoid obsolete/wrong code
	 * @return string
	 */
	public static function get_formatted_price($price, $currency = '', $sale_price = false, $display_price_suffix = true, $product = null) {
	
		// Both prices are only needed on shop/product pages, not for cart and checkout; and should not be shown if they match already
		$show_both_prices = (is_cart() || is_checkout() || $price === $sale_price) ? false : true;

		// Format price
		if ($sale_price && $show_both_prices && !defined('DOING_AJAX')) {
			$formatted_price = '<del>' . wc_price($price, array('currency' => $currency)) . '</del> <ins>' . wc_price($sale_price, array('currency' => $currency)) . '</ins>';
		} elseif ($sale_price && (!$show_both_prices || ($show_both_prices && defined('DOING_AJAX')))) {
			$formatted_price = wc_price($sale_price, array('currency' => $currency));
		} else {
			$formatted_price = wc_price($price, array('currency' => $currency));
		}

		// Optionally append price suffix
		if ($display_price_suffix) {
			// April 2019: saw a fatal error in another extension caused by the 'null' product, so we avoid that; and, in the absence of a product context, there's almost certainly not going to be a suffix
			if (null !== $product) $formatted_price .= $product->get_price_suffix($price);
		}

		return $formatted_price;
	}

	/**
	 * Handle post deleted event
	 *
	 * @access public
	 * @param int $post_id
	 * @return void
	 */
	public function post_deleted_event($post_id) {
		global $post_type;

		if ('subscription' !== $post_type) {
			return;
		}

		self::post_deleted($post_id);
	}

	/**
	 * Post deleted
	 *
	 * @access public
	 * @param int    $post_id
	 * @param string $note
	 * @return void
	 */
	public static function post_deleted($post_id, $note = null) {
		// Unschedule all events
		Simba_Subscriptions_Event_Scheduler::unschedule_all($post_id);

		// Write to transaction log
		$transaction = new Simba_Subscriptions_Transaction(null, 'subscription_deleted', $post_id);
		$transaction->update_result('success');

		// Add note
		$note = $note ? $note : __('Subscription manually deleted by administrator.', 'subscriben');
		$transaction->update_note($note);
	}

	/**
	 * Define and return time units
	 *
	 * @access public
	 * @return array
	 */
	public static function get_time_units() {
		// This design decision is suboptimal. Up to the old-series 2.3.8 release, a month was hard-coded as 30 days, a discrepancy which then adds up if you have (e.g.) quarterly subscriptions
		return apply_filters('subscriben_subscription_time_units', array(
			'day'   => array(
				'seconds'               => 86400,
				'translation_callback'  => array('Simba_Subscriptions', 'translate_time_unit'),
			),
			'week'  => array(
				'seconds'               => 604800,
				'translation_callback'  => array('Simba_Subscriptions', 'translate_time_unit'),
			),
			'month' => array(
				'seconds'               => 2629800,
				'translation_callback'  => array('Simba_Subscriptions', 'translate_time_unit'),
			),
			'year'  => array(
				'seconds'               => 31557600, // 1 year = 365.25 days
				'translation_callback'  => array('Simba_Subscriptions', 'translate_time_unit'),
			),
		));
	}

	/**
	 * Translate time unit (doing this way to allow developers
	 * to use their own time units AND to translate them to
	 * exoting languages that have complex plurals)
	 *
	 * @access public
	 * @param string $unit
	 * @param int    $value
	 * @return string
	 */
	public static function translate_time_unit($unit, $value) {
		switch ($unit) {
			case 'day':
				return _n('day', 'days', $value, 'subscriben');
			break;
			case 'week':
				return _n('week', 'weeks', $value, 'subscriben');
			break;
			case 'month':
				return _n('month', 'months', $value, 'subscriben');
			break;
			case 'year':
				return _n('year', 'years', $value, 'subscriben');
			break;
			default:
				break;
		}
	}

	/**
	 * Display customer subscription list under My Account
	 *
	 * @access public
	 * @param string $context
	 * @param bool   $return_html
	 * @return string|void
	 */
	public function display_customer_subscription_list($context = 'myaccount', $return_html = false) {
		// Check if subscription list needs to be displayed
		if (!self::display_frontend_subscriptions_list($context) && !$return_html) {
			return;
		}

		if ($return_html) {
			ob_start();

			// Adding this div for standard WooCommerce table formatting
			echo '<div class="woocommerce">';
		}

		Simba_Subscriptions::include_template('myaccount/subscription-list', array(
			'subscriptions' => Simba_Subscriptions_User::find_subscriptions(),
			'title'         => __('My Subscriptions', 'subscriben'),
			'display_title' => false,
		));

		if ($return_html) {
			echo '</div>';
			return ob_get_clean();
		}
	}

	/**
	 * Check if subscriptions list needs to be displayed in My Account
	 *
	 * @access public
	 * @param string $context
	 * @return bool
	 */
	public static function display_frontend_subscriptions_list($context = 'myaccount') {
		return (Simba_Subscriptions_User::find_subscriptions() || apply_filters('subscriben_display_empty_subscription_list', false, $context));
	}

	/**
	 * Intercept and replace woocommerce_my_account shortcode
	 *
	 * @access public
	 * @param array $atts
	 * @return void
	 */
	public function intercept_woocommerce_my_account_shortcode($atts) {
		return WC_Shortcodes::shortcode_wrapper(array('Simba_Subscriptions_My_Account', 'output'), $atts);
	}

	/**
	 * Add query vars to WP query vars array
	 *
	 * @access public
	 * @param array $vars
	 * @return array
	 */
	public function add_query_vars($vars) {
		foreach (self::$query_vars as $var) {
			$vars[] = $var;
		}

		return $vars;
	}

	/**
	 * Maybe flush rewrite rules if ours are not present
	 *
	 * @access public
	 * @return void
	 */
	public function maybe_flush_rewrite_rules() {
		$rules = get_option('rewrite_rules');

		foreach (self::$query_vars as $var) {
			if (!isset($rules['(.?.+?)/' . $var . '(/(.*))?/?$'])) {
				global $wp_rewrite;
				$wp_rewrite->flush_rules();
				break;
			}
		}
	}

	/**
	 * Insert our rewrite rules
	 *
	 * @access public
	 * @param array $rules
	 * @return array
	 */
	public function insert_rewrite_rules($rules) {
		foreach (self::$query_vars as $var) {
			$rules['(.?.+?)/' . $var . '(/(.*))?/?$'] = 'index.php?pagename=$matches[1]&' . $var . '=$matches[3]';
		}

		return $rules;
	}

	/**
	 * Maybe change WooCommerce My Orders query
	 *
	 * @access public
	 * @param array $params
	 * @return array
	 */
	public function woocommerce_my_orders_query($params) {
		if (defined('SUBSCRIBEN_PRINTING_RELATED_ORDERS')) {
			$subscription = Simba_Subscriptions_Subscription::get_by_id(SUBSCRIBEN_PRINTING_RELATED_ORDERS);

			if ($subscription) {
				$params['post__in'] = $subscription->all_order_ids;
			}
		}

		return $params;
	}

	/**
	 * Maybe change WooCommerce My Orders title
	 *
	 * @access public
	 * @param string $title
	 * @return string
	 */
	public function woocommerce_my_orders_title($title) {
		if (defined('SUBSCRIBEN_PRINTING_RELATED_ORDERS')) {
			return __('Related Orders', 'subscriben');
		}

		return $title;
	}

	/**
	 * Display related subscriptions on single order view page
	 *
	 * @access public
	 * @param object $order
	 * @return void
	 */
	public function display_frontend_order_related_subscriptions($order) {
		$subscriptions = Simba_Subscriptions_Order_Handler::get_subscriptions_from_order_id(Simba_Subscriptions_WC_Legacy::order_get_id($order));

		// Check if order contains any subscriptions
		if (!empty($subscriptions)) {

			// Allow developers to hide subscriptions list
			if (apply_filters('subscriben_display_order_related_subscriptions', true)) {
				Simba_Subscriptions::include_template('myaccount/subscription-list', array(
					'subscriptions' => $subscriptions,
					'title'         => __('Related Subscriptions', 'subscriben'),
					'display_title' => true,
				));
			}

			// Disable order again functionality for renewal orders
			if (Simba_Subscriptions_Order_Handler::order_is_renewal($order)) {
				remove_action('woocommerce_order_details_after_order_table', 'woocommerce_order_again_button');
			}
		}
	}

	/**
	 * Return option
	 * Warning: do not use in Simba_Subscriptions class constructor!
	 *
	 * @access public
	 * @param string $key
	 * @return string|bool
	 */
	public static function option($key) {
		$subscriben = Simba_Subscriptions::get_instance();
		return isset($subscriben->opt['subscriben_' . $key]) ? $subscriben->opt['subscriben_' . $key] : false;
	}

	/**
	 * Display customer subscriptions via shortcode
	 *
	 * @access public
	 * @return string - the output
	 */
	public function shortcode_customer_subscriptions() {
		if (is_home() || is_archive() || is_search() || is_feed()) return '';

		return $this->display_customer_subscription_list('shortcode', true);
	}
	
	/**
	 * Add checkbox to edit order page for cancel linked subscription
	 *
	 * @param WC_Order $order
	 *
	 * @return void
	 */
	public function add_subscription_cancel_option($order)
	{
		$subscriptions = Simba_Subscriptions_Subscription::get_by_order_id($order->get_id());
		
		if (false == $subscriptions) return;
		
		foreach ($subscriptions as $subscription) {
			printf('<p><input class="cancel-meta" type="checkbox" name="subscription_%s" value="%s" id="subscription_%s" />' . __('Also cancel the associated subscription (%s)', 'subscriben'). '</p>', $subscription->id, $subscription->id, $subscription->id, Simba_Subscriptions_Helper::get_link_to_post_html($subscription->id));
		}
	}
	
	/**
	 * Remove third party meta boxes from custom post type
	 *
	 * @access public
	 * @param string $post_type
	 * @param object $post
	 * @return void
	 */
	public function remove_meta_boxes($post_type, $post) {
		if (in_array($post_type, array('subscription', 'sub_transaction'))) {
			$meta_boxes_to_leave = apply_filters('subscriben_third_party_meta_boxes_to_leave', array());

			foreach (self::get_meta_boxes() as $context => $meta_boxes_by_context) {
				foreach ($meta_boxes_by_context as $subcontext => $meta_boxes_by_subcontext) {
					foreach ($meta_boxes_by_subcontext as $meta_box_id => $meta_box) {
						if (!in_array($meta_box_id, $meta_boxes_to_leave)) {
							remove_meta_box($meta_box_id, $post_type, $context);
						}
					}
				}
			}
		}
	}

	/**
	 * Get list of meta boxes for current screent
	 *
	 * @access public
	 * @return array
	 */
	public static function get_meta_boxes() {
		global $wp_meta_boxes;

		$screen = get_current_screen();
		$page = $screen->id;

		return $wp_meta_boxes[$page];
	}

	/**
	 * Don't allow to create new subscriptions manually (doing this in case some plugin overridden our custom post type settings)
	 *
	 * @access public
	 * @return void
	 */
	public function admin_redirect() {
		if (is_admin() && is_user_logged_in()) {
			global $typenow;
			global $pagenow;

			if (in_array($typenow, array('subscription', 'sub_transaction')) && in_array($pagenow, array('post-new.php'))) {
				wp_redirect(admin_url('/edit.php?post_type=' . $typenow));
				exit;
			}
		}
	}

	/**
	 * Remove New Subscriptions and New Transaction links
	 *
	 * @access public
	 * @return void
	 */
	public function admin_remove_new_post_links() {
		global $typenow;

		if (in_array($typenow, array('subscription', 'sub_transaction'))) {
			echo '<style>#favorite-actions{display:none;}.add-new-h2{display:none;}.groups-capabilities-container{display:none!important;}</style>';
		}
	}

	/**
	 * Add payment gateways
	 *
	 * @access public
	 * @param array $gateways
	 * @return void
	 */
	public function add_payment_gateways($gateways) {
		// Stripe
		if (isset($this->opt['subscriben_stripe_enabled']) && 1 === absint($this->opt['subscriben_stripe_enabled'])) {
			$gateways[] = 'Simba_Subscriptions_Stripe_Gateway';
			load_textdomain('subscriben-stripe', WP_LANG_DIR . '/subscriben/subscriben-stripe-' . apply_filters('plugin_locale', get_locale(), 'subscriben') . '.mo');
			load_plugin_textdomain('subscriben-stripe', false, dirname(plugin_basename(__FILE__)) . '/languages/');
		}

		// PayPal EC
		if (isset($this->opt['subscriben_paypal_ec_enabled']) && 1 === absint($this->opt['subscriben_paypal_ec_enabled'])) {
			$gateways[] = 'Simba_Subscriptions_PayPal_EC_Gateway';
			load_textdomain('subscriben-paypal-ec', WP_LANG_DIR . '/subscriben/subscriben-paypal-ec-' . apply_filters('plugin_locale', get_locale(), 'subscriben') . '.mo');
			load_plugin_textdomain('subscriben-paypal-ec', false, dirname(plugin_basename(__FILE__)) . '/languages/');
		}

		// If the official WC Stripe gateway is enabled, replace with our own version of the official class
		if (class_exists('WC_Gateway_Stripe')) {
			// Check if the version of the official WC Stripe gateway is compatible with Subscriben
			if (!Simba_Subscriptions_Helper::wc_stripe_version_gte(SUBSCRIBEN_SUPPORT_WC_STRIPE_VERSION)) {
				add_action('admin_notices', array('Simba_Subscriptions', 'wc_stripe_version_notice'));
				return $gateways;
			}
			
			if (in_array('WC_Gateway_Stripe', $gateways)) {
				unset($gateways[array_search('WC_Gateway_Stripe', $gateways)]);
			} else {
				foreach ($gateways as $gateway) {
					if (is_a($gateway, 'WC_Gateway_Stripe')) {
						unset($gateways[array_search($gateway, $gateways)]);
					}
				}
			}
			unset($gateways[array_search('WC_Gateway_Stripe_Sepa', $gateways)]);

			// include our version
			foreach (glob(SUBSCRIBEN_PLUGIN_PATH . 'includes/classes/woocommerce/stripe/*.class.php') as $filename) {
				include_once $filename;
			}

			$gateways[] = 'Simba_Subscriptions_WC_Stripe_Subs_Compat';
		}

		return $gateways;
	}

	/**
	 * Load payment gateway classes
	 *
	 * @access public
	 * @param array $gateways
	 * @return void
	 */
	public function load_payment_gateways() {
		// Stripe
		if (isset($this->opt['subscriben_stripe_enabled'])) {
			foreach (glob(SUBSCRIBEN_PLUGIN_PATH . 'includes/classes/gateways/stripe/*.class.php') as $filename) {
				if (false !== strstr($filename, 'blocks-payment')) {
					if (class_exists('WooCommerce')) {
						include $filename;
					}
				} else {
					include $filename;
				}
			}
		}
		// PayPal EC
		if ($this->opt['subscriben_paypal_ec_enabled']) {
			foreach (glob(SUBSCRIBEN_PLUGIN_PATH . 'includes/classes/gateways/paypal-ec/*.class.php') as $filename) {
				if (false !== strstr($filename, 'blocks-payment')) {
					if (class_exists('WooCommerce')) {
						include $filename;
					}
				} else {
					include $filename;
				}
			}
		}
	}

	/**
	 * Intercept PayPal's response and process the payment
	 *
	 * @access public
	 * @return void
	 */
	public function paypal_express_return_page() {
		if (!empty($_GET['subscriben_ppec_action']) && ('do_payment' == $_GET['subscriben_ppec_action'])) {
			/**
			 * We're setting the second parameter of this class to true, so that the recurring payments hook
			 * is subscribed to and repeat payments are enabled
			 */
			$Simba_Subscriptions_PayPal_EC_Gateway = new Simba_Subscriptions_PayPal_EC_Gateway(null, true);
			$Simba_Subscriptions_PayPal_EC_Gateway->do_express_checkout_payment();
		}
	}

	/**
	 * Check if multiproduct subscription mode is active
	 *
	 * @access public
	 * @return bool
	 */
	public static function multiproduct_mode() {
		return Simba_Subscriptions::option('multiproduct_subscription') == 1;
	}

	/**
	 * Check if environment meets requirements
	 *
	 * @access public
	 * @return bool
	 */
	public static function check_environment() {
		$is_ok = true;

		// Check PHP version
		if (!version_compare(PHP_VERSION, SUBSCRIBEN_SUPPORT_PHP, '>=')) {

			// Add notice
			add_action('admin_notices', array('Simba_Subscriptions', 'php_version_notice'));

			// Do not proceed as Subscriben Helper requires PHP 5.3 for itself
			return false;
		}

		// Check WordPress version
		if (!Simba_Subscriptions_Helper::wp_version_gte(SUBSCRIBEN_SUPPORT_WP)) {
			add_action('admin_notices', array('Simba_Subscriptions', 'wp_version_notice'));
			$is_ok = false;
		}

		// This will allow Subscriben to load, even if WooCommerce is absent. May be useful for bare bones subscription access, but not recommended
		if (!defined('SUBSCRIBEN_SKIP_WC_ENVIRONMENT_CHECK') || !SUBSCRIBEN_SKIP_WC_ENVIRONMENT_CHECK) {
			// Check if WooCommerce is enabled
			if (!class_exists('WooCommerce')) {
				add_action('admin_notices', array('Simba_Subscriptions', 'wc_disabled_notice'));
				$is_ok = false;
			} elseif (!Simba_Subscriptions_Helper::wc_version_gte(SUBSCRIBEN_SUPPORT_WC)) {
				add_action('admin_notices', array('Simba_Subscriptions', 'wc_version_notice'));
				$is_ok = false;
			}
		}

		return $is_ok;
	}

	/**
	 * Display PHP version notice
	 *
	 * @access public
	 * @return void
	 */
	public static function php_version_notice() {
		echo '<div class="error"><p>' . sprintf(__('<strong>Subscriben</strong> requires PHP %s or later. Please update PHP on your server to use this plugin.', 'subscriben'), SUBSCRIBEN_SUPPORT_PHP) . ' ' . sprintf(__('If you have any questions, please contact %s.', 'subscriben'), '<a href="https://subscribenplugin.com/support">' . __('Subscriben Support', 'subscriben') . '</a>') . '</p></div>';
	}

	/**
	 * Display WP version notice
	 *
	 * @access public
	 * @return void
	 */
	public static function wp_version_notice() {
		echo '<div class="error"><p>' . sprintf(__('<strong>Subscriben</strong> requires WordPress version %s or later. Please update WordPress to use this plugin.', 'subscriben'), SUBSCRIBEN_SUPPORT_PHP) . ' ' . sprintf(__('If you have any questions, please contact %s.', 'subscriben'), '<a href="https://subscribenplugin.com/support">' . __('Subscriben Support', 'subscriben') . '</a>') . '</p></div>';
	}

	/**
	 * Display WC disabled notice
	 *
	 * @access public
	 * @return void
	 */
	public static function wc_disabled_notice() {
		echo '<div class="error"><p>' . sprintf(__('<strong>Subscriben</strong> requires WooCommerce to be active. You can download WooCommerce %s.', 'subscriben'), '<a href="https://wordpress.org/plugins/woocommerce">' . __('here', 'subscriben') . '</a>') . ' ' . sprintf(__('If you have any questions, please contact %s.', 'subscriben'), '<a href="https://subscribenplugin.com/support">' . __('Subscriben Support', 'subscriben') . '</a>') . '</p></div>';
	}

	/**
	 * Display WC version notice
	 *
	 * @access public
	 * @return void
	 */
	public static function wc_version_notice() {
		echo '<div class="error"><p>' . sprintf(__('<strong>Subscriben</strong> requires WooCommerce version %s or later. Please update WooCommerce to use this plugin.', 'subscriben'), SUBSCRIBEN_SUPPORT_WC) . ' ' . sprintf(__('If you have any questions, please contact %s.', 'subscriben'), '<a href="https://subscribenplugin.com/support">' . __('Subscriben Support', 'subscriben') . '</a>') . '</p></div>';
	}
	
	/**
	 * Display WC Stripe Gateway version notice
	 *
	 * @access public
	 * @return void
	 */
	public static function wc_stripe_version_notice() {
		echo '<div class="error"><p>' . sprintf(__('<strong>Subscriben</strong> requires WooCommerce Stripe Gateway version %s or later. Please update WooCommerce Stripe Gateway to use this plugin.', 'subscriben'), SUBSCRIBEN_SUPPORT_WC_STRIPE_VERSION) . ' ' . sprintf(__('If you have any questions, please contact %s.', 'subscriben'), '<a href="https://subscribenplugin.com/support">' . __('Subscriben Support', 'subscriben') . '</a>') . '</p></div>';
	}

	/**
	 * Get sslverify value (defaults to true)
	 *
	 * @access public
	 * @return bool
	 */
	public static function get_sslverify_value() {
		return apply_filters('subscriben_sslverify', true);
	}

	/**
	 * Get SSL version value (defaults to 6 (TLV 1.2))
	 *
	 * @access public
	 * @return bool
	 */
	public static function get_sslversion_value() {
		return apply_filters('subscriben_sslversion', 6);
	}

	/**
	 * Include template
	 *
	 * @access public
	 * @param string $template
	 * @param array  $args
	 * @return string
	 */
	public static function include_template($template, $args = array()) {
		// Front-end JavaScript for the the buttons
		if ('myaccount/view-subscription' === $template || 'myaccount/subscription-list' === $template) {
			self::enqueue_frontend_js_assets();
		}
		Simba_Subscriptions_Helper::include_template($template, SUBSCRIBEN_PLUGIN_PATH, 'subscriben', $args);
	}

	/**
	 * Print frontend link to post; no known callers
	 * Legacy compatibility for template files
	 *
	 * @access public
	 * @param int    $id
	 * @param string $title
	 * @param string $pre
	 * @param string $post
	 * @return void
	 */
	public static function print_frontend_link_to_post($id, $title = '', $pre = '', $post = '') {
		error_log("Deprecated: call to Simba_Subscriptions::print_frontend_link_to_post() - may be removed in future, so change your code");
		Simba_Subscriptions_Helper::print_frontend_link_to_post($id, $title, $pre, $post);
	}

	/**
	 * Fetch the signup fee for a product.
	 * Optionally, attempt to convert the signup fee to the current currency
	 *
	 * @access public
	 * @param numeric	  $product
	 * @param string|bool $currency - currency to get the sign-up fee in; if empty, then use the default
	 * @return numeric
	 */
	public static function get_signup_fee_from_product($product, $currency = false) {
	
		$default_currency = get_option('woocommerce_currency');
	
		if (false == $currency) $currency = Simba_Subscriptions_Helper::get_current_frontend_currency();
	
		$meta_key_default = '_subscriben_signup_fee';
	
		$meta_key = ($currency == $default_currency) ? $meta_key_default : $meta_key_default.'_'.$currency;
	
		$price = Simba_Subscriptions_WC_Legacy::product_get_meta($product, $meta_key, true);

		if ($currency != $default_currency) {
		
			$price_default_currency = Simba_Subscriptions_WC_Legacy::product_get_meta($product, $meta_key_default, true);

			if ('' == $price) {
				// This is a legacy filter from a previous, different logic flow; recommended not to use - may soon disappear
				$price = apply_filters('subscriben_convert_signup_fee_currency', $price_default_currency, $product, $currency, $price);
			
				if ($price == $price_default_currency) {
					$price = Simba_Subscriptions_Helper::get_amount_in_currency($price_default_currency, $currency, $default_currency);
				}
			}
		}
		return apply_filters('subscriben_get_signup_fee_from_product', $price, $product, $currency);
	}
	
	/**
	 * Abstraction function for fetching subscription records, allowing for arbitrary query parameters
	 * Additional arguments available as part of array:
	 * 'before'     Only fetch subscriptions created before this date
	 * 'after'      Only fetch subscriptions created after this date
	 * 'orderby'    Field by which to order the results by (e.g. 'post_date')
	 * 'order'      Order ASC or DESC
	 * 'status'     Post status of the subscriptions to fetch
	 * 'meta_query' Array containing meta query parameters to apply to search
	 *
	 * @access public
	 * @param int   $user_id         ID of the user to restrict the list to
	 * @param bool  $ids             Return only the subscription id, or full post objects
	 * @param int   $limit           Limit the number of subscriptions to fetch
	 * @param array $additional_args Array of additional arguments. See above for details.
	 * @return array
	 */
	public static function get_subscription_posts($user_id = null, $ids = true, $limit = -1, $additional_args = array()) {
		
		$args = array(
			'post_type' => 'subscription',
			'posts_per_page' => $limit,
		);
		
		if ($ids) $args['fields'] = 'ids';
		if ($user_id) $args['author'] = $user_id;
		
		foreach ($additional_args as $key => $value) {
			if ('meta_query' == $key && !is_array($value)) continue;
			$args[$key] = $value;
		}
		
		// Use WP_Query rather than get_posts() as its slightly more flexible
		$query = new WP_Query;
		return $query->query($args);
	}
	
	/**
	 * Checks if High-Performance Order Storage (HPOS) is enabled in WooCommerce.
	 *
	 * This function determines whether HPOS is enabled by verifying:
	 * - WooCommerce version is 6.8.0 or higher.
	 * - The `OrderUtil` class exists within the WooCommerce Utilities namespace.
	 * - The `custom_orders_table_usage_is_enabled()` method exists within the `OrderUtil` class.
	 * - HPOS is actually enabled via the `OrderUtil::custom_orders_table_usage_is_enabled()` method.
	 *
	 * **Note:** Starting from WooCommerce version 6.8.0, with HPOS enabled, you can directly use
	 * the 'meta_query' argument in `wc_get_orders()` without needing the
	 * `woocommerce_order_data_store_cpt_get_orders_query` filter.
	 *
	 * @return bool True if HPOS is enabled, false otherwise.
	 */
	public static function is_hpos_enabled() {
		return Simba_Subscriptions_Helper::wc_version_gte('6.8.0') &&
			class_exists( '\\Automattic\\WooCommerce\\Utilities\\OrderUtil' ) &&
			method_exists( '\\Automattic\\WooCommerce\\Utilities\\OrderUtil', 'custom_orders_table_usage_is_enabled' ) &&
			\Automattic\WooCommerce\Utilities\OrderUtil::custom_orders_table_usage_is_enabled();
	}
	
	/**
	 * Get the taxable address for the specified or current customer
	 *
	 * @param WC_Customer|Boolean $customer - false to get the current customer
	 *
	 * @return Array of 4 elements (country, state, city, postcode)
	 */
	public static function get_customer_taxable_address($customer = false) {
		
		$wc = WC();
		
		$tax = new WC_Tax();
		
		if (false === $customer && !empty($wc->customer)) $customer = $wc->customer;

		if (method_exists($tax, 'get_tax_location')) {
			return $tax->get_tax_location('', $customer);
		}
		
		if (method_exists($customer, 'get_taxable_address')) {
			return $customer->get_taxable_address();
		}
		
		return array();
	}
	
	/**
	 * Determines if the WooCommerce default checkout page is using the Checkout block.
	 *
	 * This function checks if the active checkout page in WooCommerce is leveraging the
	 * newer Checkout block, rather than the legacy shortcode-based checkout.
	 *
	 * @return bool True if the WooCommerce checkout page is using the Checkout block, false otherwise.
	 */
	public static function is_checkout_block() {
		$checkout_page_id = wc_get_page_id( 'checkout' );
	
		$is_block = $checkout_page_id &&
			function_exists( 'has_block' ) &&
			has_block( 'woocommerce/checkout', $checkout_page_id );
	
		if ( ! $is_block ) {
			$is_block = class_exists( '\\WC_Blocks_Utils' ) &&
				count( \WC_Blocks_Utils::get_blocks_from_page( 'woocommerce/checkout', 'checkout' ) ) > 0;
		}
	
		if ( ! $is_block ) {
			$is_block = class_exists( '\\Automattic\\WooCommerce\\Blocks\\Utils\\CartCheckoutUtils' ) &&
				is_callable( array( '\\Automattic\\WooCommerce\\Blocks\\Utils\\CartCheckoutUtils', 'is_checkout_block_default' ) ) &&
				\Automattic\WooCommerce\Blocks\Utils\CartCheckoutUtils::is_checkout_block_default();
		}
	
		return $is_block;
	}
}

Simba_Subscriptions::get_instance();
}
