<?php
/**
 * This script removes taxes from subscriptions as VAT won't be 
 * chargeable to EU countries post-brexit
 * 
 * php remove-subscription-taxes.php --id=377
 * php remove-subscription-taxes.php --c=GB,FR
 * php remove-subscription-taxes.php --c=GB,FR --dry-run
 * 
 * --id - pass in a subscription ID for the taxes to be removed
 * --c  - pass in country codes to return a list of subscriptions from those countries
 *        based on pre-calculated tax rules
 * --dry-run - feed back what *would* have been updated, if this switch wasn't passed
 */

/**
 * Include WordPress
 */
$root = dirname(dirname(dirname(dirname(dirname(__FILE__)))));
if (file_exists($root.'/wp-load.php')) {
	require_once $root.'/wp-load.php';
} else {
	die('Can\'t find wp-load.php, looked in '.$root);
}

$countries = '';
$subscription_id = '';
$options = getopt(null, ['id:', 'c:', 'dry-run']);

$dryrun = isset($options['dry-run']);
$countries = isset($options['c']) ? $options['c'] : false;
$subscription_id =  isset($options['id']) ? $options['id'] : false;

if (!$subscription_id && !$countries) {
	
	echo PHP_EOL. 'Subscription ID or Countries parameter missing. E.G. php remove-subscription-taxes.php --id=377 --c=GB,FR'. PHP_EOL;
	return false;
	
} elseif ($countries) {
	
	$countries = explode(',', $countries);
	global $wpdb;
	
	foreach ($countries as $country) {
		$query = "SELECT
			p.meta_value AS `subscription_id`, 
			v.meta_value AS `vat_compliance_country_info` 
			FROM 
				`ud_postmeta` AS p
			JOIN 
				`ud_postmeta` AS v ON p.post_id = v.post_id
			WHERE 
				p.meta_key = '_subscriben_subscription_id' && 
				v.meta_key = 'vat_compliance_country_info' && 
				v.meta_value LIKE '%$country%'
			GROUP BY subscription_id;";			  
	
		$subscriptions = $wpdb->get_results($query);
		foreach ($subscriptions as $subscription) {
			echo PHP_EOL .'Removing taxes from subscription with ID '.$subscription->subscription_id.' and country: '.$country.PHP_EOL;
			remove_subscription_taxes($subscription->subscription_id, $dryrun);
		}
		unset($subscriptions);
	}

} elseif ($subscription_id && !$countries) {
	remove_subscription_taxes($subscription_id, $dryrun);
}

function remove_subscription_taxes($subscription_id, $dryrun) {
	// Get all order meta
	$renewal_all_order_meta = get_post_meta($subscription_id, 'renewal_all_order_meta', true);
	$renewal_order_currency = get_post_meta($subscription_id, 'renewal_order_currency', true);
	
	if (isset($renewal_all_order_meta['is_vat_exempt']) && 'no' == $renewal_all_order_meta['is_vat_exempt']) {
		
		$subscription_taxes = get_post_meta($subscription_id, 'taxes', true);
		
		if (isset($subscription_taxes[0])) {
			$tax = $subscription_taxes[0];
			$pos = strpos($tax['name'], 'VAT');
			$tax_amount_to_deduct = wc_format_decimal($tax['tax_amount']);
			$user_id = get_post_meta($subscription_id, 'user_id', true);
			
			if ($pos !== false) {
				
				// taxes meta
				$subscription_taxes[0]['tax_amount'] = 0;
				if ($dryrun) {
					echo PHP_EOL."DRY-RUN: update_post_meta($subscription_id, 'taxes', $subscription_taxes)".PHP_EOL;
					print_r($subscription_taxes); echo PHP_EOL;
				} else {
					update_post_meta($subscription_id, 'taxes', $subscription_taxes);
				}
				
				
				// renewal_line_tax meta
				$renewal_line_tax = get_post_meta($subscription_id, 'renewal_line_tax', true);
				if (is_array($renewal_line_tax)) {
					$renewal_line_tax = wc_format_decimal(array_pop($renewal_line_tax));
					if ($renewal_line_tax > 0) {
						$renewal_line_tax_updated = $renewal_line_tax - $tax_amount_to_deduct;
						if ($dryrun) {
							echo PHP_EOL."DRY-RUN: update_post_meta($subscription_id, 'renewal_line_tax', $renewal_line_tax_updated)".PHP_EOL;
						} else {
							update_post_meta($subscription_id, 'renewal_line_tax', $renewal_line_tax_updated);
						}
					}
				} else {
					$renewal_line_tax = wc_format_decimal($renewal_line_tax);
					if ($renewal_line_tax > 0) {
						$renewal_line_tax_updated = $renewal_line_tax - $tax_amount_to_deduct;
						if ($dryrun) {
							echo PHP_EOL."DRY-RUN: update_post_meta($subscription_id, 'renewal_line_tax', $renewal_line_tax_updated)".PHP_EOL;
						} else {
							update_post_meta($subscription_id, 'renewal_line_tax', $renewal_line_tax_updated);
						}
					}
				}
				
				// renewal_line_subtotal_tax meta
				$renewal_line_subtotal_tax = get_post_meta($subscription_id, 'renewal_line_subtotal_tax', true);
				if(is_array($renewal_line_subtotal_tax)){
					$renewal_line_subtotal_tax = wc_format_decimal(array_pop($renewal_line_subtotal_tax));
					if ($renewal_line_subtotal_tax > 0) {
						$renewal_line_subtotal_tax_updated = $renewal_line_subtotal_tax - $tax_amount_to_deduct;
						if ($dryrun) {
							echo PHP_EOL."DRY-RUN: update_post_meta($subscription_id, 'renewal_line_subtotal_tax', $renewal_line_subtotal_tax_updated)".PHP_EOL;
						} else {
							update_post_meta($subscription_id, 'renewal_line_subtotal_tax', $renewal_line_subtotal_tax_updated);
						}
					}
				} else {
					$renewal_line_subtotal_tax = wc_format_decimal($renewal_line_subtotal_tax);
					if ($renewal_line_subtotal_tax > 0) {
						$renewal_line_subtotal_tax_updated = $renewal_line_subtotal_tax - $tax_amount_to_deduct;
						if ($dryrun) {
							echo PHP_EOL."DRY-RUN: update_post_meta($subscription_id, 'renewal_line_subtotal_tax', $renewal_line_subtotal_tax_updated)".PHP_EOL;
						} else {
							update_post_meta($subscription_id, 'renewal_line_subtotal_tax', $renewal_line_subtotal_tax_updated);
						}
					}
				}
				
				// renewal_order_subtotal meta
				$renewal_order_subtotal = wc_format_decimal(get_post_meta($subscription_id, 'renewal_order_subtotal', true));
				if ($renewal_order_subtotal > 0) {
					$renewal_order_subtotal_updated = $renewal_order_subtotal - $tax_amount_to_deduct;	
					if ($dryrun) {
						echo PHP_EOL."DRY-RUN: update_post_meta($subscription_id, 'renewal_order_subtotal', $renewal_order_subtotal_updated)".PHP_EOL;
					} else {
						update_post_meta($subscription_id, 'renewal_order_subtotal', $renewal_order_subtotal_updated);
					}
				}
				
				// renewal_order_total meta
				$renewal_order_total = wc_format_decimal(get_post_meta($subscription_id, 'renewal_order_total', true));
				if ($renewal_order_total > 0) {
					$renewal_order_total_updated = $renewal_order_total-$tax_amount_to_deduct;
					if ($dryrun) {
						echo PHP_EOL."DRY-RUN: update_post_meta($subscription_id, 'renewal_order_total', $renewal_order_total_updated)".PHP_EOL;
					} else {
						update_post_meta($subscription_id, 'renewal_order_total', $renewal_order_total_updated);
					}
				}
				
				// renewal_order_tax meta
				$renewal_order_tax = wc_format_decimal(get_post_meta($subscription_id, 'renewal_order_tax', true));
				if ($renewal_order_tax > 0) {
					$renewal_order_tax_updated = $renewal_order_tax-$tax_amount_to_deduct;
					if ($dryrun) {
						echo PHP_EOL."DRY-RUN: update_post_meta($subscription_id, 'renewal_order_tax', $renewal_order_tax_updated)".PHP_EOL;
					} else {
						update_post_meta($subscription_id, 'renewal_order_tax', $renewal_order_tax_updated);
					}
				}
			}
		}
	}
}
echo PHP_EOL.'Removal of taxes from subscription completed.'.PHP_EOL;
exit;
