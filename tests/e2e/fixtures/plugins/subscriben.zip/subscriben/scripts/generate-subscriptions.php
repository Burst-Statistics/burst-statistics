<?php
/**
 * This script will create number of subscriptions and renewal orders
 * For testing future issues and the effect on a large site
 * 
 * php generate-subscriptions.php --nosub=20 --pid=2814 --vid=304879 --noorder=20 --cuid=234 --old-data-set=true
 * php generate-subscriptions.php --delete-data=true
 * https://yourdomain.com/generate_subscriptions.php?nosub=2&pid=2814&vid=304879&noorder=2&cuid=30446
 * https://hsb.updraftplus.com/generate_subscriptions.php?delete-data=true
 * 
 * --nosub - number of subscriptions you want to generate
 * --pid  - subscription product id
 * --vid  - subscription product variation id
 * --noorder  - number of renewal orders you want to generate for each subscription
 * --cuid  - customer id for generate subscriptoins and renewal orders
 * --old-data-set - optional flag to generate old data set of renewal orders
 */

/**
 * Include WordPress
 */
if (!defined('ABSPATH')) {
	define('ABSPATH', $_SERVER['DOCUMENT_ROOT'].'/');
}
require_once ABSPATH.'wp-load.php';

if ($_GET) {
	$sub_gen_script_url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
	$script_parse_url = parse_url($sub_gen_script_url, PHP_URL_QUERY);
	parse_str($script_parse_url, $options);
} else {
	$options = getopt(null, ['nosub:', 'pid:', 'vid:', 'noorder:', 'cuid:', 'old-data-set', 'delete-data']);
}

$old_data_set = isset($options['old-data-set']) ? $options['old-data-set'] : false;
$delete_data = isset($options['delete-data'])  ? $options['delete-data'] : false;
$number_subscriptions = isset($options['nosub']) ? $options['nosub'] : false;
$product_id =  isset($options['pid']) ? $options['pid'] : false;
$variation_id = isset($options['vid']) ? $options['vid'] : false;
$number_renewal_orders =  isset($options['noorder']) ? $options['noorder'] : false;
$customer_id =  isset($options['cuid']) ? $options['cuid'] : false;

// Remove the default WooCommerce emails
add_action('woocommerce_email', 'unhook_woo_order_emails', 12);
add_filter('woocommerce_email_recipient_new_order', 'filter_woocommerce_email_recipient', 10, 3);
add_filter('woocommerce_email_recipient_customer_on_hold_order', 'filter_woocommerce_email_recipient', 10, 3);
add_filter('woocommerce_email_recipient_customer_processing_order', 'filter_woocommerce_email_recipient', 10, 3);
add_filter('woocommerce_email_recipient_customer_pending_order', 'filter_woocommerce_email_recipient', 10, 3);
add_filter('woocommerce_email_recipient_customer_completed_order', 'filter_woocommerce_email_recipient', 10, 3);

if ($delete_data) {

	$query_args = array(
		'post_type'      =>  array('subscription', 'shop_order'),
		'posts_per_page' => -1,
		'post_status'    => 'any',
		'fields'    => 'ids',
		'meta_key'     => '_script_generate',
	);
	$the_query = new WP_Query($query_args);
	$subscription_order_ids = $the_query->posts;
	wp_reset_postdata();
	if (count($subscription_order_ids) > 0) {
		foreach ($subscription_order_ids as $id) {
			wp_delete_post($id, true);
		}
	}
	echo PHP_EOL .count($subscription_order_ids).' Subscriptions & orders are deleted.';

} elseif (!$number_subscriptions || !$product_id || !$variation_id || !$number_renewal_orders || !$customer_id) {
	if ($_GET) {
		echo PHP_EOL. 'Number of Subscriptions or Product ID or Variation ID or Number of Renewal Orders or Customer ID parameter missing. E.G. php http://yourdomain.com/generate-subscriptions.php?nosub=20&pid=2814&vid=304879&noorder=20&cuid=234'. PHP_EOL;
	} else {
		echo PHP_EOL. 'Number of Subscriptions or Product ID or Variation ID or Number of Renewal Orders or Customer ID parameter missing. E.G. php generate-subscriptions.php --nosub=20 --pid=2814 --vid=304879 --noorder=20 --cuid=234'. PHP_EOL;
	}
	return false;
	
} else {
	generate_initial_subscription_order($number_subscriptions, $product_id, $variation_id, $number_renewal_orders, $customer_id, $old_data_set);
}

function generate_initial_subscription_order($number_subscriptions, $product_id, $variation_id, $number_renewal_orders, $customer_id, $old_data_set) {
	
	for ($x = 1; $x <= $number_subscriptions; $x++) {
		$address = array(
			'first_name' => 'Alex ' . rand(1,200),
			'last_name'  => 'Njenga',
			'company'    => 'updraft',
			'email'      => 'apothiyawala+subtest@updraftplus.com',
			'phone'      => '894-672-780',
			'address_1'  => '123 Main st.',
			'address_2'  => '100',
			'city'       => 'Nairobi',
			'state'      => 'Nairobi',
			'postcode'   => '00100',
			'country'    => 'KE'
		);
		$Subscriptions_Checkout = new Simba_Subscriptions_Checkout();
		$Order_Handler = new Simba_Subscriptions_Order_Handler();
		WC()->cart->empty_cart();
		$cart_item_key = WC()->cart->add_to_cart($product_id, 1, $variation_id); // Create fake cart to generate cart item key to mimic renewal order 
		$Subscriptions_Checkout->change_prices(WC()->cart); // update product price with signup fee need it because renewal order need it
		$Order_Handler->woocommerce_create_order(0); // Fill renewal_orders array property by calling this method 
		$product_variation = new WC_Product_Variation($variation_id);
		$args=array();
		
		// Get new product price and set product price
		$new_price = Simba_Subscriptions_Subscription_Product::get_new_price($variation_id, $product_variation->get_price());
		//if($new_price > $product_variation->get_price())
		$product_variation->set_price($new_price);
		foreach($product_variation->get_variation_attributes() as $attribute=>$attribute_value){
				$args['variation'][$attribute]=$attribute_value;
		}
		$order = wc_create_order(array('customer_id'=>$customer_id));
		$order->add_product($product_variation, 1, $args);
		$order->set_address( $address, 'billing' );
		foreach( $order->get_items() as $item_id => $item ){
			// save renewal_orders array property as order item meta
			$item->update_meta_data('_subscriben_renewal_order_properties', $Order_Handler->renewal_orders['by_cart_item_key'][$cart_item_key]);
		}
		$order->calculate_totals();
		$order->update_status("completed", 'Generated order through script', TRUE);
		$order->update_meta_data('_script_generate', 'yes');
		$order->save();
		$subscription = generate_subscription($order->get_id());
		echo PHP_EOL .$x.' Subscription is created ID '.Simba_Subscriptions_Helper::get_link_to_post_html($subscription->id).' with initial order ID  '.Simba_Subscriptions_Helper::get_link_to_post_html($order->get_id()).' &  '.$number_renewal_orders.' renewal orders.<br>'.PHP_EOL;
		generate_subscription_renewal_orders($subscription, $number_renewal_orders, $old_data_set);
	}
}

function generate_subscription($order_id) {
	$Order_Handler = new Simba_Subscriptions_Order_Handler();
	$Order_Handler->new_order_placed($order_id);
	$Order_Handler->payment_received_status($order_id);
	$subscriptions = Simba_Subscriptions_Order_Handler::get_subscriptions_from_order_id($order_id);
	$subscription = reset($subscriptions);
	update_post_meta($subscription->id, '_script_generate', 'yes');
	return $subscription;
}

function generate_subscription_renewal_orders($subscription, $number_renewal_orders, $old_data_set) {
	for ($x = 1; $x <= $number_renewal_orders; $x++) {
		$renewal_order_id = Simba_Subscriptions_Order_Handler::create_renewal_order($subscription);
		$renewal_order = wc_get_order($renewal_order_id);
		$renewal_order->update_status("completed", 'Generated order through script', TRUE);
		$renewal_order->update_meta_data('_script_generate', 'yes');
		if ($old_data_set) {
			$renewal_order->delete_meta_data('_subscriben_subscription_id');
		}
		$renewal_order->save();
	}
	Simba_Subscriptions_Event_Scheduler::unschedule_all($subscription->id);
}

function unhook_woo_order_emails($email_class) {

	// New order emails
	remove_action('woocommerce_order_status_pending_to_processing_notification', array($email_class->emails['WC_Email_New_Order'], 'trigger'));
	remove_action('woocommerce_order_status_pending_to_completed_notification', array($email_class->emails['WC_Email_New_Order'], 'trigger'));
	remove_action('woocommerce_order_status_pending_to_on-hold_notification', array($email_class->emails['WC_Email_New_Order'], 'trigger'));
	remove_action('woocommerce_order_status_failed_to_processing_notification', array($email_class->emails['WC_Email_New_Order'], 'trigger'));
	remove_action('woocommerce_order_status_failed_to_completed_notification', array($email_class->emails['WC_Email_New_Order'], 'trigger'));
	remove_action('woocommerce_order_status_failed_to_on-hold_notification', array($email_class->emails['WC_Email_New_Order'], 'trigger'));

	// Processing order emails
	remove_action('woocommerce_order_status_pending_to_processing_notification', array($email_class->emails['WC_Email_Customer_Processing_Order'], 'trigger'));
	remove_action('woocommerce_order_status_pending_to_on-hold_notification', array($email_class->emails['WC_Email_Customer_Processing_Order'], 'trigger'));

	// Completed order emails
	remove_action('woocommerce_order_status_completed_notification', array($email_class->emails['WC_Email_Customer_Completed_Order'], 'trigger'));
	remove_action('woocommerce_order_status_pending_to_processing_notification', array($email_class->emails['WC_Email_New_Order'], 'trigger')); // cancels automatic email of new order placed (when defined to procession status)
	remove_action('woocommerce_order_status_pending_to_processing_notification', array($email_class->emails['WC_Email_Customer_Processing_Order'], 'trigger')); // cancels automatic email of status update to processing.

}

function filter_woocommerce_email_recipient( $recipient, $order, $email ) { 
    if ( ! $order || ! is_a( $order, 'WC_Order' ) ) return $recipient;
    
    return '';
}