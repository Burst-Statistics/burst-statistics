<?php
/**
 * This script migrates uncaptured orders and saved card tokens
 * from the legacy bundled Subscriptio Stripe payment gateway to the
 * official Woocommerce Stripe payment gateway
 * 
 * php legacy-stripe-migration.php --dry-run
 * --dry-run - feed back what *would* have been updated, if this switch wasn't passed
 */

$dry_run = false;

if ($argc > 1) {
	foreach ( $argv as $key => $value) {
		if (0 == $key) continue;
		if ('-?' == $value || '--help' == $value) { print_usage(); exit;}
		elseif ('--dry-run' == $value) { $dry_run = true; }
		elseif (preg_match('/^--abspath=(.*)$/', $value, $matches)) { define('ABSPATH', $matches[1]); }
		else { print_usage(); trigger_error("ABORT: Unknown parameter: ".$value , E_USER_ERROR); exit; }
	}
}

/**
 * Include WordPress
 */
if (!defined('ABSPATH')) {
	if (!empty($_SERVER['DOCUMENT_ROOT'])) {
		define('ABSPATH', $_SERVER['DOCUMENT_ROOT'].'/');
	} else {
		define('ABSPATH', getcwd().'/');
	} 
}

require_once ABSPATH.'/wp-load.php';

if (defined('LEGACY_STRIPE_MIGRATION_DRY_RUN') && LEGACY_STRIPE_MIGRATION_DRY_RUN) $dry_run = true;
$dry_run = $dry_run ? true : false;

/**
 * Make sure that the official Stripe gateway is installed
 */
$payment_gateway = null;

if (WC()->payment_gateways()) {

	$payment_gateways = WC()->payment_gateways()->payment_gateways();

	if (isset($payment_gateways['stripe']) && is_a($payment_gateways['stripe'], 'WC_Gateway_Stripe')) {
		$payment_gateway = $payment_gateways['stripe'];
	}
}

if (empty($payment_gateways)) exit;

// Unset any WC time limits
wc_set_time_limit(0);

// Migrate data required to capture uncaptured payments on orders
echo PHP_EOL.'Migrating uncaptured orders...'.PHP_EOL.PHP_EOL;

// Get uncaptured order ids
$uncaptured_order_ids = get_posts(array(
	'post_type'         => 'shop_order',
	'post_status'       => 'any',
	'fields'            => 'ids',
	'posts_per_page'    => -1,
	'meta_query'        => array(
		array(
			'key'       => '_subscriben_stripe_charge_captured',
			'value'     => 'no',
			'compare'   => '=',
		),
	),
));

// Get official Stripe payment gateway object
$payment_gateway = null;

// Get payment gateway
if (WC()->payment_gateways()) {

	$payment_gateways = WC()->payment_gateways()->payment_gateways();

	if (isset($payment_gateways['stripe']) && is_a($payment_gateways['stripe'], 'WC_Gateway_Stripe')) {
		$payment_gateway = $payment_gateways['stripe'];
	}
}

// Iterate over uncaptured order ids
foreach ($uncaptured_order_ids as $uncaptured_order_id) {

	if ($dry_run) {

		// Set new payment method
		echo "DRY-RUN: update_post_meta($uncaptured_order_id, '_payment_method', 'stripe');".PHP_EOL;
		echo "DRY-RUN: update_post_meta($uncaptured_order_id, '_payment_method_title', ". $payment_gateway->method_title .");".PHP_EOL;

		// Set uncaptured flag
		echo "DRY-RUN: update_post_meta($uncaptured_order_id, '_stripe_charge_captured', 'no');".PHP_EOL;

		// Set charge id
		echo "DRY-RUN: update_post_meta($uncaptured_order_id, '_transaction_id', get_post_meta($uncaptured_order_id, '_subscriben_stripe_charge_id', true));".PHP_EOL;

		// Set payment method in renewal_all_order_meta
		echo 'DRY-RUN: $renewal_order_data = get_post_meta(' . $uncaptured_order_id .', \'renewal_all_order_meta\', true);' . PHP_EOL;
		echo 'DRY-RUN: update_post_meta('. $uncaptured_order_id .', \'renewal_all_order_meta\', $renewal_order_data);' . PHP_EOL;

	} else {

		// Set new payment method
		update_post_meta($uncaptured_order_id, '_payment_method', 'stripe');
		update_post_meta($uncaptured_order_id, '_payment_method_title', $payment_gateway->method_title);

		// Set uncaptured flag
		update_post_meta($uncaptured_order_id, '_stripe_charge_captured', 'no');

		// Set charge id
		update_post_meta($uncaptured_order_id, '_transaction_id', get_post_meta($uncaptured_order_id, '_subscriben_stripe_charge_id', true));

		// Set payment method in renewal_all_order_meta
		$renewal_order_data = get_post_meta($uncaptured_order_id, 'renewal_all_order_meta', true);

		if (isset($renewal_order_data['_payment_method'])) {
			$renewal_order_data['_payment_method'] = 'stripe';
		}

		if (isset($renewal_order_data['_payment_method_title'])) {
			$renewal_order_data['_payment_method'] = $payment_gateway->method_title;
		}
		update_post_meta($uncaptured_order_id, 'renewal_all_order_meta', $renewal_order_data);

	}
	
	echo 'Migrated order #'.$uncaptured_order_id.PHP_EOL;
}

// Get existing subscriptions set to use the bundled Stripe gateway
echo PHP_EOL.'Migrating existing bundled Stripe subscriptions...'.PHP_EOL.PHP_EOL;

$bundled_subscription_ids = get_posts(array(
	'post_type'         => 'subscription',
	'post_status'       => 'any',
	'fields'            => 'ids',
	'posts_per_page'    => -1,
	'meta_query'        => array(
		array(
			'key'       => 'payment_method',
			'value'     => 'subscriben_stripe',
			'compare'   => '=',
		),
	),
));

$migrated_subscription_count = 0;

// Iterate over bundled stripe subscriptions
foreach ($bundled_subscription_ids as $bundled_subscription_id) {

	if ($dry_run) {
		echo "DRY-RUN: update_post_meta($bundled_subscription_id, 'payment_method', 'stripe');".PHP_EOL;
		echo "DRY-RUN: update_post_meta($bundled_subscription_id, 'payment_method_title', ". $payment_gateway->method_title .");".PHP_EOL;
	} else {
		update_post_meta($bundled_subscription_id, 'payment_method', 'stripe');
		update_post_meta($bundled_subscription_id, 'payment_method_title', $payment_gateway->method_title);	
	}
	
	$migrated_subscription_count++;
	
	echo "Migrated subscription #$bundled_subscription_id (total: $migrated_subscription_count)".PHP_EOL;
}

// Migrate saved cards to WooCommerce tokens

// Token class does not exist
if (!class_exists('WC_Payment_Tokens') || !class_exists('WC_Payment_Token_CC')) {
	return;
}

echo PHP_EOL.'Migrating saved card tokens...'.PHP_EOL.PHP_EOL;

// Get list of user ids that have stored cards
$user_ids = get_users(array(
	'meta_key'  => '_subscriben_stripe_customer_cards',
	'number'    => -1,
	'fields'    => 'ID',
	'orderby'   => 'ID'
));

global $table_prefix;

$migrated_token_count = 0;

// Iterate over user ids
foreach ($user_ids as $user_id) {
	
	// Make sure that the customer has an existing bundled Stripe customer ID
	$existing_stripe_customer_id = get_user_meta($user_id, '_subscriben_stripe_customer_id', true);
	if (empty($existing_stripe_customer_id)) {
		continue;
	}

	// This will only work if Stripe customer id is not set for the new gateway yet
	if (get_user_meta($user_id, $table_prefix.'_stripe_customer_id', true)) {
		continue;
	}

	// Set customer id
	if ($dry_run) {
		echo "DRY-RUN:  update_user_meta($user_id, '_stripe_customer_id', $existing_stripe_customer_id);".PHP_EOL;
	} else {
		update_user_meta($user_id, '_stripe_customer_id', $existing_stripe_customer_id);	
	}

	// Get stored cards
	$cards = get_user_meta($user_id, '_subscriben_stripe_customer_cards', true);
	$cards = !empty($cards) ? maybe_unserialize($cards) : array();

	// Get existing user tokens
	$tokens = WC_Payment_Tokens::get_customer_tokens($user_id);

	// If no tokens are set we are going to set a default token
	$default_card = empty($tokens) ? get_user_meta($user_id, '_subscriben_stripe_customer_default_card', true) : null;

	// Iterate over cards
	foreach ($cards as $card_id => $card) {
		
		// Ignore "empty" records
		if (empty($card_id)) continue;
		
		try {
			// Add card as token
			if ($dry_run) {

				echo "DRY-RUN: update_user_meta($user_id, '_stripe_customer_id', $existing_stripe_customer_id);".PHP_EOL;
				echo 'DRY-RUN: $wc_token = new WC_Payment_Token_CC();'.PHP_EOL;
				echo 'DRY-RUN: $wc_token->set_token('. $card_id .');'.PHP_EOL;
				echo 'DRY-RUN: $wc_token->set_gateway_id(stripe);'.PHP_EOL;
				echo 'DRY-RUN: $wc_token->set_card_type(strtolower('. $card['brand'] .'));'.PHP_EOL;
				echo 'DRY-RUN: $wc_token->set_last4('. $card['last4'] .');'.PHP_EOL;
				echo 'DRY-RUN: $wc_token->set_expiry_month('. $card['exp_month'] .');'.PHP_EOL;
				echo 'DRY-RUN: $wc_token->set_expiry_year('. $card['exp_year'] .');'.PHP_EOL;
				echo 'DRY-RUN: $wc_token->set_user_id('. $user_id .');'.PHP_EOL;
				echo 'DRY-RUN: $wc_token->save()'.PHP_EOL;
				// Set current token as default
				if ($card_id === $default_card) {
					echo 'DRY-RUN: WC_Payment_Tokens::set_users_default('. $user_id .', $wc_token->get_id() )'.PHP_EOL;
				}

			} else {

				update_user_meta($user_id, '_stripe_customer_id', $existing_stripe_customer_id);	
				$wc_token = new WC_Payment_Token_CC();
				$wc_token->set_token($card_id);
				$wc_token->set_gateway_id('stripe');
				$wc_token->set_card_type(strtolower($card['brand']));
				$wc_token->set_last4($card['last4']);
				$wc_token->set_expiry_month($card['exp_month']);
				$wc_token->set_expiry_year($card['exp_year']);
				$wc_token->set_user_id($user_id);
				$wc_token->save();
				// Set current token as default
				if ($card_id === $default_card) {
					WC_Payment_Tokens::set_users_default($user_id, $wc_token->get_id());
				}

			}
			
		} catch (Exception $e) {
			// Something went wrong creating a payment token for this user and card
			error_log("Subscriptio Migration: Creating payment token failed for user #$user_id and saved Subscriptio card {".print_r($card, true)."}. Error was: ".$e->getMessage());
		}
	}
	
	$migrated_count++;
	
	echo "Migrated tokens for user #$user_id (total: $migrated_token_count)\n".PHP_EOL;
}

echo PHP_EOL.'Legacy Subscriptio Stripe migration completed.'.PHP_EOL;
exit;

function print_usage() {
	echo "--abspath=<path> : Which WordPress install to use\n--dry-run : dry-run mode\n";
}
