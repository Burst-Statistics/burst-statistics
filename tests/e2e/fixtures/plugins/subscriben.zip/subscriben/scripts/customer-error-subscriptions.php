<?php
/**
 * Due to some Subscriben code not checking for _stripe_customer_id when 
 * running the prepare_order_source method in src/includes/classes/woocommerce/stripe/wc-stripe-subs-compat.class.php
 * numerous subscriptions errored with a "Customer not found" error
 * 
 * This script fixes those orders by:
 * 
 * - traversing a hardcoded set of affected subscription IDs (customer-error-subscriptions.txt)
 * - looking up if the most recent order is unpaid
 * - if so, insert a 'payment' entry in the 'events' table
 * - if it *is* paid, print out a line saying so (allowing us to eliminate it from the list of problematic subscriptions)
 * 
 * php customer-error-subscriptions.php --id=298013
 * php customer-error-subscriptions.php --dry-run
 * php customer-error-subscriptions.php
 * 
 * --id - pass in a subscription ID to be specifically processed
 *        if not passed, process the hardcodedlist of subscription IDs
 * --dry-run - feed back what *would* have been updated, if this switch wasn't passed
 */
 
/**
 * Include WordPress
 */
if (!defined('ABSPATH')) {
	define('ABSPATH', $_SERVER['DOCUMENT_ROOT'].'/');
}
require_once ABSPATH.'wp-load.php';

$options = getopt(null, ['id:', 'dry-run']);

$dryrun = isset($options['dry-run']);

$subscription_ids = array();

if (isset($options['id'])) {
    $subscription_ids[] = $options['id'];
} else {
    $subscription_ids = file(dirname(__FILE__).'/customer-error-subscriptions.txt', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
}

foreach ($subscription_ids as $subscription_id) {

    // Code taken from /src/includes/classes/event-scheduler.class.php scheduled_payment

    // Start transaction
    $transaction = new Simba_Subscriptions_Transaction(null, 'payment_due');

    // Load subscription if it's still valid
    $subscription = Simba_Subscriptions_Subscription::get_valid_subscription($subscription_id, $transaction);
    
    // Got a valid subscription object?
    if (!$subscription) {
        echo PHP_EOL . "Invalid subscription found for #" . $subscription_id . PHP_EOL;
        continue;
    }
    
    // Load related order
    $order = wc_get_order($subscription->last_order_id);
    
    if (!$order) {
        echo PHP_EOL . "Last order not found for for subscription #" . $subscription_id . PHP_EOL;
    	continue;
    } 
    
    // Make sure payment has not been received yet
    if (Simba_Subscriptions_Order_Handler::order_is_paid($order)) {
        echo PHP_EOL. "Last order for subscription #$subscription_id already paid for" . PHP_EOL;
    } else {
        if ($dryrun) {
            echo PHP_EOL. "DRY-RUN: Simba_Subscriptions_Event_Scheduler::schedule_payment($subscription_id, ".time().");" . PHP_EOL;
        } else {
            Simba_Subscriptions_Event_Scheduler::schedule_payment($subscription_id, time());
        }
        echo PHP_EOL. "Payment event scheduled for subscription #$subscription_id" . PHP_EOL;
    }
}

exit(PHP_EOL . 'customer-error-subscriptions execution ends' . PHP_EOL);