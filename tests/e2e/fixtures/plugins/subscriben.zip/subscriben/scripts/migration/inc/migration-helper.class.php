<?php
class MigrationHelper {
	/**
	 * @var string
	 */
	protected $search = 'subscriptio_';

	/**
	 * @var string
	 */
	protected $replace = 'subscriben_';

	/**
	 * @var array
	 */
	protected $items_to_update = array();

	/**
	 * @var array
	 */
	protected $migration_files = array(
		'options' => 'legacy-subscriptio-migration-options.php',
		'posts'   => 'legacy-subscriptio-migration-postmeta.php',
		'users'   => 'legacy-subscriptio-migration-usermeta.php',
		'orders'  => 'legacy-subscriptio-migration-woocommerce_order_itemmeta.php',
	);

	/**
	 * @return array
	 */
	public function get_items_to_update() {
		return $this->items_to_update;
	}

	/**
	 * @param $items
	 */
	public function set_items_to_update($items) {
		$this->items_to_update = $items;
	}

	/**
	 * @param $string
	 *
	 * @return string
	 */
	public function replace_subscriptio_with_subscriben($string) {
		if (empty($string) || !is_string($string)) {
			return $string;
		}

		return str_replace($this->search, $this->replace, $string);
	}

	/**
	 * @param $table_name
	 * @param bool $dry_run
	 * @param bool $value_column
	 */
	public function migrate_meta_items($table_name, $dry_run = false, $value_column = false) {
		global $wpdb;

		$items               = $this->items_to_update;
		$total_items         = count($items);
		$total_updated_items = 0;

		$table_column = ($value_column) ? 'meta_value' : 'meta_key';

		foreach ($items as $item_key => $item_value) {
			$sql = "UPDATE {$table_name} SET $table_column='$item_value' WHERE $table_column='$item_key'";

			if ($dry_run) {
				echo "Updating {$table_column} in table {$table_name} : {$item_key} ==> {$item_value}" . PHP_EOL;
			} else {
				if ($wpdb->query($sql)) {
					$total_updated_items ++;
				}
			}
		}

		if (!$dry_run) {
			echo 'Migrated: ' . $total_updated_items . ' out of ' . $total_items;
		}
	}


	/**
	 * The method processes the passed value and identifies the types (string, array, object)
	 * and performs the replace recursively.
	 *
	 * Inspired from https://github.com/interconnectit/Search-Replace-DB and wpmdb
	 *
	 * @param string $data
	 * @param bool $serialized
	 * @param bool $parent_serialized
	 * @param bool $filtered
	 *
	 * @return array|string
	 */
	public function recursive_unserialize_replace(
		$data,
		$serialized = false,
		$parent_serialized = false,
		$filtered = true
	) {

		$is_json           = false;
		$before_fired      = false;
		$successive_filter = $filtered;

		if (true === $filtered) {
			list($data, $before_fired, $successive_filter) = array(
				$data,
				$before_fired,
				$successive_filter,
			);
		}

		// some unserialized data cannot be re-serialized eg. SimpleXMLElements
		try {
			if (is_string($data) && ($unserialized = $this->up_unserialize($data, __METHOD__)) !== false) {
				// PHP currently has a bug that doesn't allow you to clone the DateInterval / DatePeriod classes.
				// We skip them here as they probably won't need data to be replaced anyway
				if ('object' == gettype($unserialized)) {
					if ( $unserialized instanceof \DateInterval || $unserialized instanceof \DatePeriod ) {
						return $data;
					}
				}
				$data = $this->recursive_unserialize_replace($unserialized, true, true, $successive_filter);
			} elseif (is_array($data)) {

				$_tmp = array();
				foreach ($data as $key => $value) {

					if (is_string($key) && $this->contains_subscriptio($key)) {
						$key = $this->apply_replaces( $key );
					}

					$_tmp[$key] = $this->recursive_unserialize_replace($value,
						false,
						$parent_serialized,
						$successive_filter);
				}

				$data = $_tmp;
				unset($_tmp);
			} elseif (is_object($data)) { // Submitted by Tina Matter
				$_tmp = clone $data;

				foreach ($data as $key => $value) {

					if (is_int($key)) {
						continue;
					}

					$_tmp->$key = $this->recursive_unserialize_replace($value,
						false,
						$parent_serialized,
						$successive_filter);
				}

				/**
				 * Here is a tricky part - WooCommerce stores the whole meta object in the meta value
				 * which has protected property of data. For obvious reason we cannot access them
				 * so we will use PHPs builtin Reflection class. Retrieve the value, loop over it,
				 * replace the terms and then add the meta value using WC_Meta_Data.
				 */
				if ('WC_Meta_Data' == get_class($data)) {

					$current_data = $this->accessProtected($data, 'current_data');

					$updated_current_data       = [];
					$updated_current_data_value = [];

					if (!empty($current_data) && is_array($current_data)) {
						foreach ($current_data as $meta_key => $meta_value) {
							if ('value' == $meta_key) {
								if (empty($meta_value)) { //Means it has array values in data:protected
									$value_meta_data = $this->accessProtected($data, 'data');

									foreach ($value_meta_data as $value_meta_key => $value_meta) {
										if ($value_meta_key != 'value') {
											continue;
										}
										if ($this->contains_subscriptio($value_meta)) {
											$updated_current_data_value = $this->recursive_unserialize_replace($value_meta,
												false,
												$parent_serialized,
												$successive_filter);
										} else {
											if (!$value_meta || $value_meta == 0) {
												$value_meta = 0;
											}
											$updated_current_data_value[$value_meta_key] = $value_meta;
										}
									}

									$updated_current_data[$meta_key] = $updated_current_data_value;

								} else {
									$updated_current_data[$meta_key] = $meta_value;
								}

							} else {
								if ($this->contains_subscriptio($meta_value)) {
									$updated_current_data[$meta_key] = $this->recursive_unserialize_replace($meta_value,
										false,
										$parent_serialized,
										$successive_filter);
								} else {
									$updated_current_data[$meta_key] = $meta_value;
								}
							}
						}
					}

					$wc_meta_data = new WC_Meta_Data($updated_current_data);

					$_tmp = $wc_meta_data;
				}

				$data = $_tmp;
				unset($_tmp);
			} elseif ($this->is_json($data, true)) {
				$_tmp = array();
				$data = json_decode($data, true);

				foreach ($data as $key => $value) {
					$_tmp[$key] = $this->recursive_unserialize_replace($value,
						false,
						$parent_serialized,
						$successive_filter);
				}

				$data = $_tmp;
				unset($_tmp);
				$is_json = true;
			} elseif (is_string($data)) {
				list($data, $do_replace) = array($data, true);

				if ($do_replace) {
					$data = $this->apply_replaces($data);
				}
			}

			if ($is_json) {
				$data = json_encode($data);
			}

			if ($serialized) {
				//$data = serialize( $data );
			}
		} catch (\Exception $error) {
			$error_msg     = 'Failed attempting to do the recursive unserialize replace.';
			$error_details = $error->getMessage() . "\n\n";
			$error_details .= var_export($data, true);
			$this->error_log->log_error($error_msg, $error_details);
		}

		return $data;
	}

	/**
	 * @param $obj
	 * @param $prop
	 *
	 * @return mixed
	 * @throws ReflectionException
	 */
	private function accessProtected($obj, $prop) {
		$reflection = new ReflectionClass($obj);
		$property   = $reflection->getProperty($prop);
		$property->setAccessible(true);

		return $property->getValue($obj);
	}

	/**
	 * @param $table_name
	 * @param bool $dry_run
	 * @param $meta_type
	 */
	public function migrate_serialised_meta_items($table_name, $dry_run = false, $meta_type = 'post') {
		global $wpdb;

		$total_updated_options = 0;
		foreach ($this->items_to_update as $item_key => $item_value) {
			$meta_items = $wpdb->get_results($wpdb->prepare("
				SELECT *  FROM {$table_name} 
				WHERE meta_key = '%s'
				",
				$item_value)
			);

			foreach ($meta_items as $meta_item) {

				if ($dry_run) {
					echo 'Migrating the serialised value for ' . $item_value . ' update_post_meta( $meta_item->post_id, $item_key, $serialised_meta_value ) :' . PHP_EOL;
					continue;
				}

				/**
				 * Execute only if the meta value is serialised and contains the "subscriptio_" keyword.
				 */
				if (is_serialized($meta_item->meta_value) && $this->contains_subscriptio($meta_item->meta_value)) {

					$replaced_unserialised_data = $this->recursive_unserialize_replace(
						$meta_item->meta_value
					);

					$serialised_meta_value = serialize($replaced_unserialised_data);

					if (!is_serialized( $serialised_meta_value)) {
						echo 'The mata value for ID ' . $meta_item->meta_id . ' is not serialised correctly.';
						continue;
					}

					//Finally update the post meta value
					if ($this->update_meta_value($meta_item,
						$table_name,
						$serialised_meta_value,
						$meta_type)) {

						$total_updated_options ++;
					}

				}

			}
		}

		if (!$dry_run) {
			echo "Migrated items total : {$total_updated_options}";
		}
	}

	/**
	 * @param $meta
	 * @param $table_name
	 * @param $meta_item
	 * @param $meta_type
	 *
	 * @return bool
	 */
	private function update_meta_value($meta, $table_name, $meta_item, $meta_type) {
		global $wpdb;

		$where_clause = '';
		if ($meta_type == 'post' || $meta_type == 'order') {
			$where_clause = "meta_id='$meta->meta_id'";
		} elseif ($meta_type == 'user') {
			$where_clause = "umeta_id='$meta->umeta_id'";
		}

		$sql = $wpdb->prepare("UPDATE {$table_name} SET meta_value=%s WHERE {$where_clause};", $meta_item);

		$ret = $wpdb->query($sql);
		if (false === $ret) { error_log("Bad SQL: $sql\n"); }

		return $ret ? true : false;
	}


	/**
	 * @param $string
	 *
	 * @return bool
	 */
	public function contains_subscriptio($string) {
		if (!$string || empty($string) || ! is_string($string)) {
			return false;
		}

		if (strpos($string, $this->search) !== false) {
			return true;
		}

		return false;
	}

	/**
	 * @param $serialized_string
	 * @param string $method
	 *
	 * @return bool|mixed
	 */
	private function up_unserialize($serialized_string, $method = '') {
		if (!is_serialized($serialized_string)) {
			return false;
		}

		$serialized_string = trim($serialized_string);
		$unserialized_string = @unserialize($serialized_string);

		if (false === $unserialized_string && defined('WP_DEBUG_LOG') && WP_DEBUG_LOG) {
			$scope = $method ? sprintf(__('Scope: %s().', 'wp-migrate-db'), $method) : false;
			$error = sprintf(__('WPMDB Error: Data cannot be unserialized. %s', 'wp-migrate-db'), $scope);
			error_log($error);
		}

		return $unserialized_string;
	}

	/**
	 * @param $string
	 * @param bool $strict
	 *
	 * @return bool
	 */
	private function is_json($string, $strict = false) {
		$json = @json_decode($string, true);
		if ($strict == true && ! is_array($json)) {
			return false;
		}

		return ! ($json == null || $json == false);
	}

	/**
	 * @param $subject
	 *
	 * @return string|string[]
	 */
	function apply_replaces($subject) {
		return str_ireplace($this->search, $this->replace, $subject, $count);
	}

	/**
	 * @param $option
	 *
	 * @return bool
	 */
	public function validate_subscriptio_option($option) {
		if (!$option || (is_string($option) && strlen($option) < 6)) {
			return false;
		}

		$serialised_option = serialize($option);
		if (!is_serialized($serialised_option)) {
			return false;
		}

		if (!$this->contains_subscriptio($serialised_option)) {
			return false;
		}

		return true;
	}

	/**
	 * @param $args
	 *
	 * @return null|string
	 */
	public function is_migrate_arg_exist($args) {
		if (!$args || count($args) < 1) {
			return null;
		}

		$search = '--migrate-';

		$migrateArg = '';
		foreach ($args as $arg) {
			if (strpos($arg, $search) !== false) {
				$migrateArg = str_replace($search, '', $arg);
			}
		}

		return $migrateArg;
	}

	/**
	 * @param $arg
	 *
	 * @return bool
	 */
	public function include_migration_script_by_arg($arg) {

		if (!$arg || empty($arg)) {
			return false;
		}

		if ($arg == 'all') {
			foreach ($this->migration_files as $migration_file) {
				include $migration_file;
			}

			return true;
		}

		if (array_key_exists($arg, $this->migration_files)) {
			include $this->migration_files[$arg];

			return true;
		}

		return false;
	}

}
