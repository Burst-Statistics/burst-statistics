<?php
/**
 * This script is part of the subscriptio database migration scripts
 * 
 * Look at legacy-subscriptio-migration.php for more info
 */

global $wpdb;

/**
 * Include our migration helper class
 */
$migration_helper = new MigrationHelper();

/**
 * Options
 */
$options = getopt(null, ['dry-run']);
$dry_run = isset($options['dry-run']);

echo PHP_EOL;
echo '================ ';
echo 'Started: Migrating Subscriptio Post Meta keys';
echo ' ================';
echo PHP_EOL;

$post_meta_items = array(
	'_subscriptio'                             => '_subscriben',
	'_subscriptio_price_time_value'            => '_subscriben_price_time_value', //Done - 15 in 4 files
	'_subscriptio_price_time_unit'             => '_subscriben_price_time_unit', //Done - 15 in 4 files
	'_subscriptio_stripe_charge_id'            => '_subscriben_stripe_charge_id', //Done - 4 in 2 files
	'_subscriptio_stripe_charge_captured'      => '_subscriben_stripe_charge_captured', //Done - 4 in 2 files
	'_subscriptio_renewal'                     => '_subscriben_renewal', //Done - 3 in 1 files
	'_subscriptio_paypal_ec_billing_agreement' => '_subscriben_paypal_ec_billing_agreement', //Done - 11 in 2 files
	'_subscriptio_free_trial_time_value'       => '_subscriben_free_trial_time_value', //Done - 17 in 5 files
	'_subscriptio_free_trial_time_unit'        => '_subscriben_free_trial_time_unit', //Done - 12 in 3 files
	'_subscriptio_max_length_time_value'       => '_subscriben_max_length_time_value',//Done - 13 in 4 files
	'_subscriptio_max_length_time_unit'        => '_subscriben_max_length_time_unit', //Done - 12 in 4 files
	'_subscriptio_signup_fee'                  => '_subscriben_signup_fee', //Done - 11 in 5 files
	'_subscriptio_signup_fee_EUR'              => '_subscriben_signup_fee_EUR', //Done
	'_subscriptio_signup_fee_USD'              => '_subscriben_signup_fee_USD', //Done
	'_subscriptio_signup_fee_GBP'              => '_subscriben_signup_fee_GBP', //Done
	'_subscriptio_subscription_id'             => '_subscriben_subscription_id', //Done - 9 in 3 files
	'_subscriptio_paypal_ec_transaction_id'    => '_subscriben_paypal_ec_transaction_id', //Done - 8 in 2 files
	'_subscriptio_paypal_ec_token'             => '_subscriben_paypal_ec_token', //Done - 7 in 1 files
);
$post_meta_table = $wpdb->prefix . 'postmeta';

$migration_helper->set_items_to_update($post_meta_items);
$migration_helper->migrate_meta_items($post_meta_table, $dry_run);

echo 'Ended: Migrating Subscriptio Post Meta keys';

echo PHP_EOL;
echo '================ ';
echo 'Started: Migrating Post Meta unserialised values';
echo ' ================';
echo PHP_EOL;

$post_meta_item_values = array(
	'subscriptio'   		=> 'subscriben',
	'subscriptio_stripe'    => 'subscriben_stripe', //Done - 5 in 2 files
	'subscriptio_paypal_ec' => 'subscriben_paypal_ec', //Done - 4 in 2 files
);
$migration_helper->set_items_to_update($post_meta_item_values);
$migration_helper->migrate_meta_items($post_meta_table, $dry_run, true);

//Migrate serialised data
echo PHP_EOL;
echo '================ ';
echo 'Started: Migrating Post Meta serialised data';
echo ' ================';
echo PHP_EOL;

$post_meta_serialised_item_values = array(
	0 => 'renewal_all_order_meta',
	1 => 'renewal_all_items_meta',
);

$migration_helper->set_items_to_update($post_meta_serialised_item_values);
$migration_helper->migrate_serialised_meta_items($post_meta_table, $dry_run);

echo PHP_EOL;
echo 'Ended: Migrating Post Meta values';
