<?php
/**
 * This script migrates old subscriptio references in database entries to new
 * subscriben references
 * 
 * php legacy-subscriptio-migration.php --migrate-all
 * php legacy-subscriptio-migration.php --migrate-users
 * php legacy-subscriptio-migration.php --migrate-options
 * php legacy-subscriptio-migration.php --migrate-posts
 * php legacy-subscriptio-migration.php --migrate-orders
 * 
 * Every command can use the --dry-run option to report what would have changed
 */

if ( php_sapi_name() !== 'cli' ) {
	die( "Meant to be run from command line" );
}

/**
 * Include WordPress
 */
if (!defined('ABSPATH')) {
	define('ABSPATH', $_SERVER['DOCUMENT_ROOT'].'/');
}

require_once ABSPATH.'wp-load.php';

/**
 * Include our migration helper class
 */
require_once( dirname( __FILE__ ) . '/inc/migration-helper.class.php' );
$migration_helper = new MigrationHelper();

$options = getopt(null, ['dry-run']);
$dry_run = isset($options['dry-run']);

$migrate = getopt(null, ['migrate']);

$postmeta_table = $wpdb->prefix . 'postmeta';

if ($migrateArg = $migration_helper->is_migrate_arg_exist($argv)) {
	$migration_helper->include_migration_script_by_arg($migrateArg);
}
