<?php
/**
 * This script is part of the subscriptio database migration scripts
 * 
 * Look at legacy-subscriptio-migration.php for more info
 */

global $wpdb;

/**
 * Include our migration helper class
 */
$migration_helper = new MigrationHelper();

/**
 * Options
 */
$options = getopt(null, ['dry-run']);
$dry_run = isset($options['dry-run']);

echo PHP_EOL;
echo '================ ';
echo 'Migrating WP Options names';
echo ' ================';
echo PHP_EOL;

$options = array(
	//We need to migrate its options
	'subscriptio_options' => 'subscriben_options',
	'woocommerce_subscriptio_stripe_settings' => 'woocommerce_subscriben_stripe_settings',
	// Not needed as we have replaced with subscriben_paypal_ec
	//'woocommerce_subscriptio_paypal_settings' => 'woocommerce_subscriben_paypal_settings',
	'woocommerce_subscriptio_paypal_ec_settings' => 'woocommerce_subscriben_paypal_ec_settings',
	'subscriptio_cron_unlocked' => 'subscriben_cron_unlocked',
	'subscriptio_cron_lock_time' => 'subscriben_cron_lock_time'
);
$options_table = $wpdb->prefix . 'options';

$total_options = count($options);
$total_updated_options = 0;
foreach ($options as $option_name => $option_value) {
	
	$sql = "UPDATE $options_table SET option_name='$option_value' WHERE option_name='$option_name'";
	
	if ( $dry_run ) {
		echo 'Updating "option_name" in table "_options": ' . $option_name . ' ==> ' . $option_value . PHP_EOL;
		echo $sql . PHP_EOL;
		
		continue;
	}
	
	/**
	 * to be on safe side first check if the new option name exists in the table
	 * if found then we copy the old value and then migrate to the new option
	 */
	if (get_option($option_value)) {
		$current_option_value = get_option($option_name);

		if ($current_option_value && $migration_helper->validate_subscriptio_option($current_option_value)) {
			$replaced_option_value = $migration_helper->recursive_unserialize_replace(serialize($current_option_value));

			update_option($option_value, $replaced_option_value);
		}

		continue;
	}

	if ($wpdb->query($sql)) {
		$total_updated_options ++;
	}
	
}

if (!$dry_run) {
	echo 'Migrated: ' . $total_updated_options . ' out of ' . $total_options;
}

echo "Success: Migrated options!";

echo PHP_EOL;
echo '================ ';
echo 'Migrating Subscriptio WP Options values';
echo ' ================';
echo PHP_EOL;

$option_names = array(
	'cron',
	'woocommerce_gateway_order',
	'wc_aelia_currency_switcher',
	'subscriptio_options',
	'subscriben_options',
);

foreach ($option_names as $option_name) {
	if ($dry_run) {
		echo 'Migrating the option value for ' . $option_name . PHP_EOL;
		continue;
	}

	$option = get_option($option_name);
	if ($migration_helper->validate_subscriptio_option($option)) {
		$replaced_option = $migration_helper->recursive_unserialize_replace(serialize($option));
		update_option($option_name, $replaced_option);
	}
}
