<?php
/**
 * This script is part of the subscriptio database migration scripts
 * 
 * Look at legacy-subscriptio-migration.php for more info
 */

global $wpdb;

/**
 * Include our migration helper class
 */
$migration_helper = new MigrationHelper();

/**
 * Options
 */
$options = getopt(null, ['dry-run']);
$dry_run = isset($options['dry-run']);

echo PHP_EOL;
echo '================ ';
echo 'Started: Migrating Subscriptio User Meta keys';
echo ' ================';
echo PHP_EOL;

$user_meta_items = array(
		'_subscriptio_pause_limit'                  => '_subscriben_pause_limit', //Done - 2 in 1 file
		'_subscriptio_paypal_ec_billing_agreement'  => '_subscriben_paypal_ec_billing_agreement',
		'_subscriptio_stripe_customer_id'           => '_subscriben_stripe_customer_id', //Done - 7 in 3 file
		'_subscriptio_stripe_customer_cards'        => '_subscriben_stripe_customer_cards', //Done - 12 in 3 file
		'_subscriptio_stripe_customer_default_card' => '_subscriben_stripe_customer_default_card', //Done - 10 in 3 file
);
$user_meta_table = $wpdb->prefix . 'usermeta';

$migration_helper->set_items_to_update($user_meta_items);
$migration_helper->migrate_meta_items($user_meta_table, $dry_run);

echo 'Ended: Migrating Subscriptio User Meta keys';

//Migrate serialised data
echo PHP_EOL;
echo '================ ';
echo 'Started: Migrating User Meta serialised data';
echo ' ================';
echo PHP_EOL;
$post_meta_serialised_item_values = array(
	0 => 'meta-box-order_subscription',
	1 => 'closedpostboxes_subscription',
);
$migration_helper->set_items_to_update($post_meta_serialised_item_values);
$migration_helper->migrate_serialised_meta_items($user_meta_table, $dry_run, 'user');

echo 'Ended: Migrating User Meta values';
