<?php
/**
 * This script is part of the subscriptio database migration scripts
 * 
 * Look at legacy-subscriptio-migration.php for more info
 */

global $wpdb;

/**
 * Include our migration helper class
 */
$migration_helper = new MigrationHelper();

/**
 * Options
 */
$options = getopt(null, ['dry-run']);
$dry_run = isset($options['dry-run']);

echo PHP_EOL;
echo '================ ';
echo 'Started: Migrating Subscriptio Order Meta keys';
echo ' ================';
echo PHP_EOL;

$order_meta_items = array(
	'_subscriptio_renewal_order_properties' => '_subscriben_renewal_order_properties', //Done - 3 in 1 file
);
$order_meta_table = $wpdb->prefix . 'woocommerce_order_itemmeta';

$migration_helper->set_items_to_update($order_meta_items);
$migration_helper->migrate_meta_items($order_meta_table, $dry_run);

echo 'Ended: Migrating Subscriptio Order Meta keys';
