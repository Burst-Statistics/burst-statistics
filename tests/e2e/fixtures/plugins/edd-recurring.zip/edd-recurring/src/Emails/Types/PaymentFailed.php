<?php
/**
 * Payment Failed Email
 *
 * @package   EDD\Recurring\Emails\Types
 * @copyright Copyright (c) 2025, Sandhills Development, LLC
 * @license   https://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since     2.12.4
 */

namespace EDD\Recurring\Emails\Types;

defined( 'ABSPATH' ) || exit;

/**
 * Class PaymentFailed
 * This class extends the PaymentReceived class, because the only
 * difference between the two emails is the ID.
 *
 * @since 2.12.4
 * @package EDD
 * @subpackage Emails
 */
class PaymentFailed extends PaymentReceived {

	/**
	 * The email ID.
	 *
	 * @var string
	 * @since 2.12.4
	 */
	protected $id = 'renewal_payment_failed';

	/**
	 * The email context.
	 *
	 * @var string
	 * @since 2.12.5
	 */
	protected $context = 'subscription';

	/**
	 * PaymentFailed constructor.
	 *
	 * @since 2.12.5
	 *
	 * @param int  $subscription_id The subscription ID.
	 * @param null $order_id        The order ID. For failed renewals, there will be no order ID.
	 */
	public function __construct( $subscription_id, $order_id = null ) {
		$this->subscription_id = $subscription_id;
		$this->subscription    = new \EDD\Recurring\Subscriptions\Subscription( $subscription_id );
		$this->email_object_id = $subscription_id;
	}

	/**
	 * If the email is enabled, and this same email has not been sent for this subscription in the last 48 hours, send it.
	 *
	 * @since 2.13.5
	 * @return bool
	 */
	protected function should_send() {
		if ( ! parent::should_send() ) {
			return false;
		}

		$query = new \EDD\Database\Queries\LogEmail();
		$items = $query->query(
			array(
				'object_id'   => $this->subscription_id,
				'object_type' => 'subscription',
				'email_id'    => $this->id,
				'date_query'  => array(
					'after'     => gmdate( 'Y-m-d H:i:s', strtotime( $this->get_time_period() ) ),
					'before'    => gmdate( 'Y-m-d H:i:s' ),
					'inclusive' => true,
				),
			)
		);

		return empty( $items );
	}

	/**
	 * Gets the legacy filters.
	 *
	 * @since 2.12.4
	 * @return array
	 */
	protected function get_legacy_filters() {
		return array(
			'subject' => 'edd_recurring_payment_failed_subject',
			'message' => 'edd_recurring_payment_failed_message',
		);
	}

	/**
	 * Gets the time period for the payment failed email.
	 *
	 * @since 2.13.5
	 * @return string
	 */
	private function get_time_period(): string {
		$meta  = $this->email_object->get_metadata( 'time_period' );
		$hours = ! empty( $meta ) ? (int) $meta : 48;

		return '-' . $hours . ' hours';
	}
}
