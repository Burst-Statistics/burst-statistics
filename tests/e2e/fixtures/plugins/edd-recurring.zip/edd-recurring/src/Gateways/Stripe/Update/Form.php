<?php
/**
 * @package     EDD\Recurring\Gateways\Stripe\Update
 * @copyright   Copyright Sandhills Development, LLC
 * @license     https://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       2.13.0
 */

namespace EDD\Recurring\Gateways\Stripe\Update;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit; // @codeCoverageIgnore

/**
 * Stripe Update Form
 *
 * @since 2.13.0
 */
class Form {

	/**
	 * Subscription object.
	 *
	 * @var \EDD\Recurring\Subscriptions\Subscription
	 */
	protected $subscription;

	/**
	 * Constructor.
	 *
	 * @param \EDD\Recurring\Subscriptions\Subscription $subscription Subscription object.
	 */
	public function __construct( $subscription ) {
		$this->subscription = $subscription;
	}

	/**
	 * Render the update payment method form.
	 *
	 * @since 2.13.0
	 */
	public function render() {
		// Attempt to get the full Stripe Subscription object to access its properties.
		$stripe_subscription_object = null;
		if ( ! empty( $this->subscription->profile_id ) ) {
			try {
				$stripe_subscription_object = edds_api_request(
					'Subscription',
					'retrieve',
					array(
						'id'     => $this->subscription->profile_id,
						'expand' => array( 'latest_invoice.payment_intent', 'pending_setup_intent' ),
					)
				);
			} catch ( \Exception $e ) {
				// Do nothing (we'll output an error message later).
			}
		}

		if ( ! $stripe_subscription_object ) {
			// Output error message directly if Stripe API call fails.
			echo '<p class="edd-alert edd-alert-error">' . esc_html__( 'Error retrieving subscription details from Stripe.', 'edd-recurring' ) . ' ' . esc_html( $e->getMessage() ) . '</p>';
			return;
		}

		$this->render_latest_payment_intent( $stripe_subscription_object );
		if ( 'payment-elements' === edds_get_elements_mode() ) {
			$this->render_payment_elements_form( $stripe_subscription_object );
		} else {
			$this->render_card_elements_form( $stripe_subscription_object );
		}
	}

	/**
	 * Render the payment elements form.
	 *
	 * @since 2.13.0
	 * @param \Stripe\Subscription $stripe_subscription_object Stripe subscription object.
	 */
	private function render_payment_elements_form( $stripe_subscription_object ) {
		// New Payment Elements flow.
		edd_stripe_js( true ); // Ensures Stripe SDK is loaded.

		wp_enqueue_script(
			'edd-recurring-stripe-payment-elements',
			EDD_RECURRING_PLUGIN_URL . 'assets/js/edd-recurring-stripe-payment-elements.js',
			array( 'jquery', 'edd-stripe-js', 'wp-dom-ready' ),
			EDD_RECURRING_VERSION,
			true
		);

		wp_localize_script(
			'edd-recurring-stripe-payment-elements',
			'eddRecurringStripePaymentElementsVars',
			$this->get_localization_args( $stripe_subscription_object )
		);

		?>
		<div id="edd-recurring-stripe-payment-element">
			<!-- Stripe Payment Element will be mounted here -->
		</div>
		<div id="edd-recurring-stripe-payment-error" role="alert" class="edd-alert edd-alert-error" style="display: none;"></div>
		<?php
	}

	/**
	 * Render the legacy card elements form.
	 *
	 * @since 2.13.0
	 * @param \Stripe\Subscription $stripe_subscription_object Stripe subscription object.
	 */
	private function render_card_elements_form( $stripe_subscription_object ) {
		add_filter( 'edd_is_checkout', '__return_true' );
		edd_load_scripts();
		edd_stripe_js( true );

		remove_filter( 'edd_is_checkout', '__return_true' );

		wp_enqueue_script(
			'edd-frontend-recurring-stripe',
			EDD_RECURRING_PLUGIN_URL . 'assets/js/edd-frontend-recurring-stripe.js',
			array( 'jquery', 'edd-stripe-js', 'wp-dom-ready' ),
			EDD_RECURRING_VERSION,
			true
		);

		wp_localize_script(
			'edd-frontend-recurring-stripe',
			'eddRecurringStripeVars',
			$this->get_localization_args( $stripe_subscription_object )
		);

		echo '<input type="hidden" id="edd_recurring_stripe_default_payment_method" value="' . esc_attr( $stripe_subscription_object->default_payment_method ) . '" />';

		do_action( 'edd_stripe_cc_form' );
	}

	/**
	 * Render a hidden input with the latest payment intent ID if the latest invoice is unpaid.
	 *
	 * @since 2.13.0
	 * @param \Stripe\Subscription $stripe_subscription_object Stripe subscription object.
	 */
	private function render_latest_payment_intent( $stripe_subscription_object ) {
		$latest_open_invoice = edds_api_request(
			'Invoice',
			'all',
			array(
				'subscription' => $stripe_subscription_object->id,
				'limit'        => 1,
				'status'       => 'open',
				'customer'     => $stripe_subscription_object->customer,
			)
		);

		if ( empty( $latest_open_invoice->data ) ) {
			return;
		}

		$invoice = current( $latest_open_invoice->data );
		if ( $invoice->payment_intent ) {
			$payment_intent_id = is_string( $invoice->payment_intent ) ? $invoice->payment_intent : $invoice->payment_intent->id;
			$payment_intent    = edds_api_request( 'PaymentIntent', 'retrieve', $payment_intent_id );
			if ( 'succeeded' !== $payment_intent->status ) {
				echo '<input type="hidden" name="edd_recurring_stripe_payment_intent" value="' . esc_attr( $payment_intent->id ) . '" />';
			}
		}
	}

	/**
	 * Get the localization arguments for the payment elements form.
	 *
	 * @since 2.13.0
	 * @param \Stripe\Subscription $stripe_subscription_object Stripe subscription object.
	 * @return array The localization arguments.
	 */
	private function get_localization_args( $stripe_subscription_object ): array {
		$profile_id_for_nonce = ! empty( $stripe_subscription_object->id ) ? $stripe_subscription_object->id : $this->subscription->profile_id;
		$timestamp            = time();

		return array(
			'ajax_url'        => admin_url( 'admin-ajax.php' ),
			'revert_pm_nonce' => wp_create_nonce( 'edd_recurring_revert_pm_update_' . $profile_id_for_nonce ),
			'subscription_id' => $profile_id_for_nonce, // Stripe Subscription ID.
			'currency'        => strtolower( edd_get_currency() ),
			'customer_email'  => $this->subscription->customer ? $this->subscription->customer->email : '',
			'customer_name'   => $this->subscription->customer ? $this->subscription->customer->name : '',
			'timestamp'       => $timestamp,
			'token'           => \EDD\Utils\Tokenizer::tokenize( $timestamp ),
			'i18n'            => array(
				'payment_system_unavailable'             => __( 'Error 001: Payment system is temporarily unavailable. Please contact support.', 'edd-recurring' ),
				'session_expired_refresh'                => __( 'Error 002: Your session has expired. Please refresh the page and try again.', 'edd-recurring' ),
				'payment_method_confirmation_failed'     => __( 'Error 003: Unable to confirm your new payment method:', 'edd-recurring' ),
				'outstanding_invoice_payment_failed'     => __( 'Error 004: We were unable to process payment for your outstanding invoice:', 'edd-recurring' ),
				'payment_method_updated_success'         => __( 'Your payment method has been updated for future renewals.', 'edd-recurring' ),
				'invoice_details_error_setup'            => __( 'Error 005: Unable to retrieve invoice payment details:', 'edd-recurring' ),
				'invoice_details_error_direct'           => __( 'Error 006: Unable to retrieve invoice payment details:', 'edd-recurring' ),
				'payment_confirmation_incomplete'        => __( 'Error 007: Payment method confirmation status:', 'edd-recurring' ),
				'status_unknown'                         => __( 'unknown', 'edd-recurring' ),
				'payment_method_update_failed'           => __( 'Error 008: Unable to update your payment method.', 'edd-recurring' ),
				'payment_update_general_error'           => __( 'Error 009: Something went wrong while updating your payment method. Please try again.', 'edd-recurring' ),
				'payment_details_invalid'                => __( 'Error 010: The payment information provided appears to be invalid. Please check your details and try again.', 'edd-recurring' ),
				'processing_error_occurred'              => __( 'Error 011: A processing error occurred:', 'edd-recurring' ),
				'update_process_incomplete'              => __( 'Error 012: The payment method update process could not be completed. Please contact support.', 'edd-recurring' ),
				'update_finalization_failed'             => __( 'Error 013: We were unable to finalize your payment method update. Please contact support.', 'edd-recurring' ),
				'payment_method_revert_failed'           => __( 'Error 014: Unable to restore your previous payment method due to missing information. Please contact support.', 'edd-recurring' ),
				'previous_payment_method_restore_failed' => __( 'Error 015: We were unable to restore your previous payment method:', 'edd-recurring' ),
				'contact_support_message'                => __( 'Please contact support.', 'edd-recurring' ),
				'payment_method_restore_error'           => __( 'Error 016: An error occurred while restoring your previous payment method. Please contact support.', 'edd-recurring' ),
				'error_details_unavailable'              => __( 'Error details unavailable.', 'edd-recurring' ),
			),
		);
	}
}
