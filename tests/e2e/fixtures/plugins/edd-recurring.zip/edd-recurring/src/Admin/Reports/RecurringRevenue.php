<?php
/**
 * Recurring Revenue Report
 *
 * @package EDD\Recurring\Admin\Reports
 * @copyright   Copyright (c) 2025, Sandhills Development, LLC
 * @license     https://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       2.13.0
 */

namespace EDD\Recurring\Admin\Reports;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Recurring Revenue Report
 *
 * @since 2.13.0
 */
class RecurringRevenue {

	/**
	 * Option name for MRR data.
	 *
	 * @since 2.13.2
	 * @var string
	 */
	const MRR_OPTION_NAME = 'edd_recurring_mrr_data';

	/**
	 * Option name for ARR data.
	 *
	 * @since 2.13.2
	 * @var string
	 */
	const ARR_OPTION_NAME = 'edd_recurring_arr_data';

	/**
	 * Cache timeout in seconds (1 hour).
	 *
	 * @since 2.13.2
	 * @var int
	 */
	const CACHE_TIMEOUT = 3600;

	/**
	 * Get the Monthly Recurring Revenue (MRR).
	 *
	 * @since 2.13.0
	 * @return float
	 */
	public static function get_mrr() {
		// Try to get cached data first.
		$cached_data = self::get_cached_data( self::MRR_OPTION_NAME );

		if ( false !== $cached_data ) {
			return $cached_data['value'];
		}

		// No cached data available; calculate immediately and cache.
		$mrr = self::calculate_mrr();
		self::set_cached_data( self::MRR_OPTION_NAME, $mrr );

		// Schedule background update for next time.
		self::schedule_background_calculation();

		return $mrr;
	}

	/**
	 * Get the Annual Recurring Revenue (ARR).
	 *
	 * @since 2.13.0
	 * @return float
	 */
	public static function get_arr() {
		// Try to get cached data first.
		$cached_data = self::get_cached_data( self::ARR_OPTION_NAME );
		if ( false !== $cached_data ) {
			return $cached_data['value'];
		}

		// No cached data available; calculate immediately and cache.
		$arr = self::calculate_arr();
		self::set_cached_data( self::ARR_OPTION_NAME, $arr );

		// Schedule background update for next time.
		self::schedule_background_calculation();

		return $arr;
	}

	/**
	 * Calculates MRR without caching (for background processing).
	 *
	 * @since 2.13.2
	 * @return float
	 */
	public static function calculate_mrr(): float {
		global $wpdb;

		$now = ( new \EDD\Utils\Date() )->format( 'mysql' );

		// Fixed MRR calculation that properly handles unlimited vs limited subscriptions
		// while maintaining currency conversion.
		return (float) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT
					SUM(
						CASE
							-- For unlimited subscriptions (bill_times = 0), use full recurring amount.
							WHEN s.bill_times = 0 THEN
								CASE
									WHEN s.period = 'day' THEN (s.recurring_amount / COALESCE(o.rate, 1)) * 30.4375
									WHEN s.period = 'week' THEN (s.recurring_amount / COALESCE(o.rate, 1)) * 4.34812
									WHEN s.period = 'month' THEN (s.recurring_amount / COALESCE(o.rate, 1))
									WHEN s.period = 'quarter' THEN (s.recurring_amount / COALESCE(o.rate, 1)) / 3
									WHEN s.period = 'semi-year' THEN (s.recurring_amount / COALESCE(o.rate, 1)) / 6
									WHEN s.period = 'year' THEN (s.recurring_amount / COALESCE(o.rate, 1)) / 12
									ELSE 0
								END
							-- For limited subscriptions (bill_times > 0), calculate MRR if subscription is still active.
							-- MRR represents monthly revenue rate while active, not prorated by remaining cycles.
							-- Only exclude subscriptions that have completed all their billing cycles.
							WHEN s.bill_times > 0 THEN
								CASE
									-- If subscription has remaining billing cycles, calculate full MRR
									WHEN GREATEST(0, s.bill_times - (
										(SELECT COUNT(*) FROM {$wpdb->prefix}edd_orders r
										 INNER JOIN {$wpdb->prefix}edd_ordermeta om ON r.id = om.edd_order_id
										 WHERE om.meta_key = 'subscription_id'
										 AND om.meta_value = s.id
										 AND r.status = 'edd_subscription'
										 AND r.type = 'sale') +
										CASE WHEN s.trial_period IS NULL OR s.trial_period = '' THEN 1 ELSE 0 END
									)) > 0 THEN
										CASE
											WHEN s.period = 'day' THEN (s.recurring_amount / COALESCE(o.rate, 1)) * 30.4375
											WHEN s.period = 'week' THEN (s.recurring_amount / COALESCE(o.rate, 1)) * 4.34812
											WHEN s.period = 'month' THEN (s.recurring_amount / COALESCE(o.rate, 1))
											WHEN s.period = 'quarter' THEN (s.recurring_amount / COALESCE(o.rate, 1)) / 3
											WHEN s.period = 'semi-year' THEN (s.recurring_amount / COALESCE(o.rate, 1)) / 6
											WHEN s.period = 'year' THEN (s.recurring_amount / COALESCE(o.rate, 1)) / 12
											ELSE 0
										END
									-- If subscription has completed all billing cycles, contribute $0 to MRR
									ELSE 0
								END
							ELSE 0
						END
					) AS monthly_recurring_revenue
				FROM {$wpdb->prefix}edd_subscriptions s
				LEFT JOIN {$wpdb->prefix}edd_orders o ON s.parent_payment_id = o.id
				WHERE s.status IN ('active', 'trialling')
				AND (s.expiration IS NULL OR s.expiration > %s)",
				$now
			)
		);
	}

	/**
	 * Calculates ARR without caching (for background processing).
	 *
	 * This method has been updated to fix calculation discrepancies by:
	 * 1. Keeping necessary currency conversion for multi-currency stores
	 * 2. Fixing the complex payment counting logic that was causing inflated values
	 * 3. Simplifying unlimited subscription calculation
	 * 4. More accurate handling of limited subscriptions
	 *
	 * @since 2.13.2
	 * @return float
	 */
	public static function calculate_arr(): float {
		global $wpdb;

		$now = ( new \EDD\Utils\Date() )->format( 'mysql' );

		// Fixed ARR calculation that properly handles unlimited vs limited subscriptions
		// while maintaining currency conversion and fixing the broken payment counting.
		return (float) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT
					SUM(
						CASE
							-- For unlimited subscriptions (bill_times = 0), use full recurring amount.
							WHEN s.bill_times = 0 THEN
								CASE
									WHEN s.period = 'day' THEN (s.recurring_amount / COALESCE(o.rate, 1)) * 365.25
									WHEN s.period = 'week' THEN (s.recurring_amount / COALESCE(o.rate, 1)) * 52.17857
									WHEN s.period = 'month' THEN (s.recurring_amount / COALESCE(o.rate, 1)) * 12
									WHEN s.period = 'quarter' THEN (s.recurring_amount / COALESCE(o.rate, 1)) * 4
									WHEN s.period = 'semi-year' THEN (s.recurring_amount / COALESCE(o.rate, 1)) * 2
									WHEN s.period = 'year' THEN (s.recurring_amount / COALESCE(o.rate, 1))
									ELSE 0
								END
							-- For limited subscriptions (bill_times > 0), calculate remaining value only.
							-- Account for payments already made by calculating: bill_times - times_billed
							-- times_billed = renewal orders + (1 if no trial period)
							WHEN s.bill_times > 0 THEN
								CASE
									WHEN s.period = 'day' THEN (s.recurring_amount / COALESCE(o.rate, 1)) * LEAST(365, GREATEST(0, s.bill_times - (
										(SELECT COUNT(*) FROM {$wpdb->prefix}edd_orders r
										 INNER JOIN {$wpdb->prefix}edd_ordermeta om ON r.id = om.edd_order_id
										 WHERE om.meta_key = 'subscription_id'
										 AND om.meta_value = s.id
										 AND r.status = 'edd_subscription'
										 AND r.type = 'sale') +
										CASE WHEN s.trial_period IS NULL OR s.trial_period = '' THEN 1 ELSE 0 END
									)))
									WHEN s.period = 'week' THEN (s.recurring_amount / COALESCE(o.rate, 1)) * LEAST(52, GREATEST(0, s.bill_times - (
										(SELECT COUNT(*) FROM {$wpdb->prefix}edd_orders r
										 INNER JOIN {$wpdb->prefix}edd_ordermeta om ON r.id = om.edd_order_id
										 WHERE om.meta_key = 'subscription_id'
										 AND om.meta_value = s.id
										 AND r.status = 'edd_subscription'
										 AND r.type = 'sale') +
										CASE WHEN s.trial_period IS NULL OR s.trial_period = '' THEN 1 ELSE 0 END
									)))
									WHEN s.period = 'month' THEN (s.recurring_amount / COALESCE(o.rate, 1)) * LEAST(12, GREATEST(0, s.bill_times - (
										(SELECT COUNT(*) FROM {$wpdb->prefix}edd_orders r
										 INNER JOIN {$wpdb->prefix}edd_ordermeta om ON r.id = om.edd_order_id
										 WHERE om.meta_key = 'subscription_id'
										 AND om.meta_value = s.id
										 AND r.status = 'edd_subscription'
										 AND r.type = 'sale') +
										CASE WHEN s.trial_period IS NULL OR s.trial_period = '' THEN 1 ELSE 0 END
									)))
									WHEN s.period = 'quarter' THEN (s.recurring_amount / COALESCE(o.rate, 1)) * LEAST(4, GREATEST(0, s.bill_times - (
										(SELECT COUNT(*) FROM {$wpdb->prefix}edd_orders r
										 INNER JOIN {$wpdb->prefix}edd_ordermeta om ON r.id = om.edd_order_id
										 WHERE om.meta_key = 'subscription_id'
										 AND om.meta_value = s.id
										 AND r.status = 'edd_subscription'
										 AND r.type = 'sale') +
										CASE WHEN s.trial_period IS NULL OR s.trial_period = '' THEN 1 ELSE 0 END
									)))
									WHEN s.period = 'semi-year' THEN (s.recurring_amount / COALESCE(o.rate, 1)) * LEAST(2, GREATEST(0, s.bill_times - (
										(SELECT COUNT(*) FROM {$wpdb->prefix}edd_orders r
										 INNER JOIN {$wpdb->prefix}edd_ordermeta om ON r.id = om.edd_order_id
										 WHERE om.meta_key = 'subscription_id'
										 AND om.meta_value = s.id
										 AND r.status = 'edd_subscription'
										 AND r.type = 'sale') +
										CASE WHEN s.trial_period IS NULL OR s.trial_period = '' THEN 1 ELSE 0 END
									)))
									WHEN s.period = 'year' THEN (s.recurring_amount / COALESCE(o.rate, 1)) * LEAST(1, GREATEST(0, s.bill_times - (
										(SELECT COUNT(*) FROM {$wpdb->prefix}edd_orders r
										 INNER JOIN {$wpdb->prefix}edd_ordermeta om ON r.id = om.edd_order_id
										 WHERE om.meta_key = 'subscription_id'
										 AND om.meta_value = s.id
										 AND r.status = 'edd_subscription'
										 AND r.type = 'sale') +
										CASE WHEN s.trial_period IS NULL OR s.trial_period = '' THEN 1 ELSE 0 END
									)))
									ELSE 0
								END
							ELSE 0
						END
					) AS annual_recurring_revenue
				FROM {$wpdb->prefix}edd_subscriptions s
				LEFT JOIN {$wpdb->prefix}edd_orders o ON s.parent_payment_id = o.id
				WHERE s.status IN ('active', 'trialling')
				AND (s.expiration IS NULL OR s.expiration > %s)",
				$now
			)
		);
	}

	/**
	 * Clears the cached revenue data to force recalculation.
	 *
	 * @since 2.13.5
	 * @return bool True if both caches were cleared successfully.
	 */
	public static function clear_cache(): bool {
		$mrr_cleared = delete_option( self::MRR_OPTION_NAME );
		$arr_cleared = delete_option( self::ARR_OPTION_NAME );

		return $mrr_cleared && $arr_cleared;
	}

	/**
	 * Sets cached revenue data with expiration.
	 *
	 * @since 2.13.2
	 * @param string $option_name The option name.
	 * @param mixed  $value       The value to cache.
	 * @return bool
	 */
	public static function set_cached_data( string $option_name, $value ): bool {
		$option = wp_json_encode(
			array(
				'value'        => $value,
				'timeout'      => time() + self::CACHE_TIMEOUT,
				'last_updated' => time(),
			)
		);

		return update_option( $option_name, $option, false );
	}

	/**
	 * Gets cached revenue data with expiration check.
	 *
	 * @since 2.13.2
	 * @param string $option_name The option name.
	 * @return array|false Array with 'value' and 'last_updated' keys, or false if expired/not found.
	 */
	protected static function get_cached_data( string $option_name ) {
		$option = get_option( $option_name, false );
		if ( ! $option ) {
			return false;
		}

		if ( is_string( $option ) ) {
			$option = json_decode( $option, true );
		}

		// Check if data is expired.
		if ( empty( $option['timeout'] ) || time() > $option['timeout'] ) {
			return false;
		}

		$option = array(
			'value'        => $option['value'],
			'last_updated' => isset( $option['last_updated'] ) ? $option['last_updated'] : time(),
		);

		self::maybe_schedule_background_calculation( $option );

		return $option;
	}

	/**
	 * Schedules a background calculation of recurring revenue.
	 *
	 * @since 2.13.2
	 */
	protected static function schedule_background_calculation() {
		if ( ! wp_next_scheduled( 'edd_recurring_recalculate_revenue' ) ) {
			wp_schedule_single_event( time(), 'edd_recurring_recalculate_revenue' );
		}
	}

	/**
	 * Checks if the background calculation should be scheduled.
	 *
	 * @since 2.13.2
	 * @param array $cached_data The cached data.
	 */
	private static function maybe_schedule_background_calculation( array $cached_data ) {
		if ( ( time() - $cached_data['last_updated'] ) > ( self::CACHE_TIMEOUT - ( 15 * MINUTE_IN_SECONDS ) ) ) {
			self::schedule_background_calculation();
		}
	}
}
