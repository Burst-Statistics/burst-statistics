<?php
/**
 * Stripe Subscription Sync Tool.
 *
 * @package   EDD\Recurring\Admin\Tools
 * @copyright Copyright (c) 2025, Sandhills Development, LLC
 * @license   https://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since     2.13.5
 */

namespace EDD\Recurring\Admin\Tools;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit; // @codeCoverageIgnore

use EDD\EventManagement\SubscriberInterface;

/**
 * Stripe Subscription Sync Tool.
 *
 * This class handles syncing EDD Recurring subscriptions with Stripe to fix status mismatches.
 *
 * @since 2.13.5
 */
class SubscriptionSync implements SubscriberInterface {

	/**
	 * Get the subscribed events.
	 *
	 * @since 2.13.5
	 * @return array
	 */
	public static function get_subscribed_events() {
		return array(
			'edd_tools_tab_general'     => 'tool_box',
			'edd_download_batch_export' => array( 'modify_request', -100 ),
		);
	}

	/**
	 * Render the admin UI under Downloads > Tools
	 *
	 * @since 2.13.5
	 * @return void
	 */
	public function tool_box() {
		if ( ! current_user_can( 'manage_shop_settings' ) ) {
			return;
		}

		// Only show if Stripe gateway is active.
		if ( ! edd_is_gateway_active( 'stripe' ) ) {
			return;
		}

		$stats      = $this->get_statistics();
		$in_process = (bool) get_transient( 'edd_recurring_stripe_sync_last_id' );
		?>
		<div class="postbox edd-stripe-subscription-sync">
			<h2 class="hndle"><?php esc_html_e( 'Recurring Payments - Stripe Subscription Sync', 'edd-recurring' ); ?></h2>
			<div class="inside">
				<p><?php esc_html_e( 'Use this tool to sync subscription statuses with Stripe to fix mismatches. This is useful when subscriptions show as expired locally but are still active in Stripe due to webhook failures or timing issues.', 'edd-recurring' ); ?></p>

				<?php if ( $stats['total_expired'] > 0 || $stats['total_failing'] > 0 || $stats['total_all'] > 0 ) : ?>
					<div class="edd-recurring-subscription-sync-stats">
						<p><strong><?php esc_html_e( 'Affected Subscriptions:', 'edd-recurring' ); ?></strong></p>
						<ul class="edd-list">
							<?php if ( $stats['total_expired'] > 0 ) : ?>
								<li>
									<?php
									/* translators: %d: count of expired subscriptions with future dates */
									printf( esc_html__( 'Expired with Future Dates: %d', 'edd-recurring' ), $stats['total_expired'] );
									?>
								</li>
							<?php endif; ?>
							<?php if ( $stats['total_failing'] > 0 ) : ?>
								<li>
									<?php
									/* translators: %d: count of failing subscriptions */
									printf( esc_html__( 'Failing Subscriptions: %d', 'edd-recurring' ), $stats['total_failing'] );
									?>
								</li>
							<?php endif; ?>
							<li>
								<?php
								/* translators: %d: total count of Stripe subscriptions */
								printf( esc_html__( 'Total Stripe Subscriptions: %d', 'edd-recurring' ), $stats['total_all'] );
								?>
							</li>
						</ul>
					</div>
				<?php endif; ?>

				<p class="description"><?php esc_html_e( 'A CSV file of the processed subscriptions will be available for download when processing is complete.', 'edd-recurring' ); ?></p>

				<form id="edd-stripe-subscription-sync-form" class="edd-export-form edd-import-export-form">
					<div class="edd-form-group">
						<label for="sync-mode" class="edd-form-group__label"><?php esc_html_e( 'Sync Mode', 'edd-recurring' ); ?></label>
						<div class="edd-form-group__control">
							<select name="sync_mode" id="sync-mode" class="edd-select">
								<option value="expired_future">
									<?php
									/* translators: %s: count of affected subscriptions */
									printf( esc_html__( 'Expired with Future Dates (%s)', 'edd-recurring' ), esc_html( $stats['total_expired'] ) );
									?>
								</option>
								<option value="failing">
									<?php
									/* translators: %s: count of affected subscriptions */
									printf( esc_html__( 'Failing Subscriptions (%s)', 'edd-recurring' ), esc_html( $stats['total_failing'] ) );
									?>
								</option>
								<option value="all_active">
									<?php
									/* translators: %s: count of affected subscriptions */
									printf( esc_html__( 'All Subscriptions (Full Audit) (%s)', 'edd-recurring' ), esc_html( $stats['total_all'] ) );
									?>
								</option>
							</select>
							<p class="edd-form-group__help description">
								<?php esc_html_e( 'Choose which subscriptions to sync with Stripe.', 'edd-recurring' ); ?>
							</p>
						</div>
					</div>

					<div class="edd-form-group">
						<label for="sync-date-filter" class="edd-form-group__label"><?php esc_html_e( 'Date Filter', 'edd-recurring' ); ?></label>
						<div class="edd-form-group__control">
							<label class="edd-toggle">
								<input type="checkbox" name="use_date_filter" id="use-date-filter" value="1">
								<?php esc_html_e( 'Only sync subscriptions created/modified after:', 'edd-recurring' ); ?>
							</label>
							<input type="text" name="sync_date" id="sync-date-filter" class="edd_datepicker" disabled>
							<p class="edd-form-group__help description">
								<?php esc_html_e( 'Optional: Limit sync to subscriptions created or modified after a specific date.', 'edd-recurring' ); ?>
							</p>
						</div>
					</div>

					<div class="edd-form-group">
						<label for="dry-run" class="edd-form-group__label"><?php esc_html_e( 'Dry Run', 'edd-recurring' ); ?></label>
						<div class="edd-form-group__control">
							<label class="edd-toggle">
								<input type="checkbox" name="dry_run" id="dry-run" value="1" checked>
								<?php esc_html_e( 'Preview changes without updating the database.', 'edd-recurring' ); ?>
							</label>
							<p class="edd-form-group__help description">
								<?php esc_html_e( 'Recommended: Run a dry run first to preview what will be changed.', 'edd-recurring' ); ?>
							</p>
						</div>
					</div>
					<?php
					if ( $in_process ) {
						wpautop( esc_html_e( 'A sync run is already in process.', 'edd-recurring' ) );
					}
					?>

					<div class="edd-form__actions">
						<?php wp_nonce_field( 'edd_ajax_export', 'edd_ajax_export' ); ?>
						<input type="hidden" name="edd-export-class" value="EDD\Recurring\Admin\Tools\Exports\SubscriptionSync">
						<button type="submit" class="button button-secondary"<?php disabled( $in_process ); ?>><?php esc_html_e( 'Sync Subscriptions with Stripe', 'edd-recurring' ); ?></button>
					</div>
				</form>
			</div>
		</div>

		<script type="text/javascript">
		jQuery(document).ready(function($) {
			// Enable/disable date filter
			$( '#use-date-filter' ).on( 'change', function() {
				$( '#sync-date-filter' ).prop( 'disabled', !$( this ).is( ':checked' ) );
			} );
		});
		</script>
		<?php
	}

	/**
	 * This is really hacky, but important until EDD core better supports namespaced classes.
	 * During the download, `EDD\Admin\Export` get converted to:
	 * `EDD\\\\Invoices\\\\Admin\\\\Export` . This breaks the `class_exists()`
	 * check in EDD core ( @see edd_process_batch_export_download() ). Therefore, we hook in before
	 * that runs to strip slashes, which makes everything work again. Dumb, but temporarily necessary.
	 *
	 * @link https://github.com/awesomemotive/easy-digital-downloads-pro/issues/1150
	 * @since 2.13.5
	 */
	public function modify_request() {
		if ( isset( $_REQUEST['class'] ) && \EDD\Recurring\Admin\Tools\Exports\SubscriptionSync::class === stripslashes( $_REQUEST['class'] ) ) {
			$_REQUEST['class'] = \EDD\Recurring\Admin\Tools\Exports\SubscriptionSync::class;
		}
	}

	/**
	 * Get statistics about affected subscriptions.
	 *
	 * @since 2.13.5
	 * @return array
	 */
	private function get_statistics() {
		global $wpdb;

		$current_date = current_time( 'mysql' );

		$results = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT
				 SUM(CASE WHEN status = 'expired' AND expiration > %s THEN 1 ELSE 0 END) as total_expired,
				 SUM(CASE WHEN status = 'failing' THEN 1 ELSE 0 END) as total_failing,
				 COUNT(*) as total_all
				 FROM {$wpdb->prefix}edd_subscriptions
				 WHERE gateway = 'stripe' AND profile_id != ''",
				$current_date
			)
		);

		$stats = array(
			'total_expired' => intval( $results->total_expired ),
			'total_failing' => intval( $results->total_failing ),
			'total_all'     => intval( $results->total_all ),
		);

		set_transient( 'edd_recurring_sync_totals_' . get_current_user_id(), $stats, 5 * MINUTE_IN_SECONDS );

		return $stats;
	}
}
