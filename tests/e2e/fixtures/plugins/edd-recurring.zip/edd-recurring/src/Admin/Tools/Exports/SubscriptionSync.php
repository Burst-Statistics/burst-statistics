<?php
/**
 * Stripe Subscription Sync Export.
 *
 * @package   EDD\Recurring\Admin\Tools\Exports
 * @copyright Copyright (c) 2025, Sandhills Development, LLC
 * @license   https://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since     2.13.5
 */

namespace EDD\Recurring\Admin\Tools\Exports;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit; // @codeCoverageIgnore

/**
 * Stripe Subscription Sync Export.
 *
 * @since 2.13.5
 *
 * @property bool   $done     Whether the export is complete.
 * @property string $message  Completion message.
 * @property string $filename The export filename.
 * @property int    $step     Current step number.
 */
class SubscriptionSync extends \EDD_Batch_Export {

	/**
	 * The file type, typically .csv
	 *
	 * @since 2.13.5
	 * @var string
	 */
	public $filetype = '.csv';

	/**
	 * Export type - used for export-specific filters/actions.
	 *
	 * @since 2.13.5
	 * @var string
	 */
	public $export_type = 'subscription_sync';

	/**
	 * Used to determine if the export is truly an export or just a batch process.
	 *
	 * @since 2.13.5
	 * @var bool
	 */
	public $is_void = false;

	/**
	 * The number of subscriptions to process per step.
	 *
	 * @since 2.13.5
	 * @var int
	 */
	private $per_step = 10;

	/**
	 * The sync mode: 'expired_future', 'failing', or 'all_active'.
	 *
	 * @since 2.13.5
	 * @var string
	 */
	private $sync_mode = 'expired_future';

	/**
	 * Date filter for subscriptions.
	 *
	 * @since 2.13.5
	 * @var string
	 */
	private $date_filter = '';

	/**
	 * Whether this is a dry run.
	 *
	 * @since 2.13.5
	 * @var bool
	 */
	private $dry_run = true;

	/**
	 * The last processed subscription ID (used for cursor-based pagination).
	 *
	 * @since 2.13.5
	 * @var int
	 */
	private $last_processed_id = 0;

	/**
	 * Process the current step.
	 *
	 * @since 2.13.5
	 * @return bool
	 */
	public function process_step() {
		// Check if we hit a rate limit on the previous step.
		if ( get_transient( $this->get_transient_name_rate_limited() ) ) {
			delete_transient( $this->get_transient_name_rate_limited() );
			// Return false to pause processing, allowing time before next retry.
			return false;
		}

		$processed = parent::process_step();
		if ( $processed ) {
			$this->done = false;
			return true;
		}

		$this->done = true;

		// Generate completion message.
		$stats = $this->get_sync_stats();

		if ( $this->dry_run ) {
			$this->message = sprintf(
				/* translators: %1$d: Number of subscriptions processed, %2$d: Number that would be updated */
				esc_html__( 'Dry run complete: %1$d subscriptions processed, %2$d would be updated. Review the CSV for details.', 'edd-recurring' ),
				$stats['processed'],
				$stats['updated']
			);
		} else {
			$this->message = sprintf(
				/* translators: %1$d: Number of subscriptions processed, %2$d: Number updated */
				esc_html__( 'Sync complete: %1$d subscriptions processed, %2$d updated. Download the CSV for full details.', 'edd-recurring' ),
				$stats['processed'],
				$stats['updated']
			);
		}
		delete_transient( $this->get_transient_name_stats() );
		delete_transient( $this->get_transient_name_last_id() );
		delete_transient( $this->get_transient_name_total() );
		delete_transient( 'edd_recurring_sync_totals_' . get_current_user_id() );

		return false;
	}

	/**
	 * Get the data to export.
	 *
	 * @since 2.13.5
	 * @return array|false
	 */
	public function get_data() {
		global $wpdb;

		// Build query with cursor-based pagination.
		$where_parts = $this->build_where_clauses( true );
		$where       = implode( ' AND ', $where_parts );

		// Fetch next batch of subscriptions using cursor pagination.
		$subscriptions = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM {$wpdb->prefix}edd_subscriptions WHERE {$where} ORDER BY id ASC LIMIT %d", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$this->per_step
			)
		);

		if ( empty( $subscriptions ) ) {
			return false;
		}

		$data = array();
		foreach ( $subscriptions as $sub_data ) {
			$result = $this->process_single_subscription( $sub_data );
			if ( $result ) {
				$data[] = $result;
			}
			// Update cursor to last processed ID only if result wasn't false (rate limit).
			if ( false !== $result ) {
				$this->last_processed_id = $sub_data->id;
			}
			// Add 100ms delay between each subscription to avoid hitting Stripe rate limits.
			usleep( 100000 );
		}

		// Store last processed ID for next step.
		set_transient( $this->get_transient_name_last_id(), $this->last_processed_id, HOUR_IN_SECONDS );

		return $data;
	}

	/**
	 * Process a single subscription.
	 *
	 * @since 2.13.5
	 * @param object $sub_data Subscription data from database.
	 * @return array|false Result of processing.
	 */
	private function process_single_subscription( $sub_data ) {
		$result = array(
			'id'                 => $sub_data->id,
			'profile_id'         => $sub_data->profile_id,
			'current_status'     => $sub_data->status,
			'current_expiration' => $sub_data->expiration,
			'stripe_status'      => '',
			'new_status'         => '',
			'new_expiration'     => '',
			'action'             => 'skip',
			'message'            => '',
		);

		// Get Stripe subscription.
		try {
			$stripe_sub = edds_api_request( 'Subscription', 'retrieve', $sub_data->profile_id );

			if ( ! $stripe_sub ) {
				$result['message'] = __( 'Subscription not found in Stripe', 'edd-recurring' );

				return $result;
			}

			$result['stripe_status'] = $stripe_sub->status;

			// Map Stripe status to EDD status.
			$new_status = $this->map_stripe_status( $stripe_sub->status );

			// Calculate new expiration with grace period.
			$new_expiration = '';
			if ( ! empty( $stripe_sub->current_period_end ) ) {
				$grace_period   = HOUR_IN_SECONDS * 1.5;
				$expiration_ts  = $stripe_sub->current_period_end + $grace_period;
				$new_expiration = gmdate( 'Y-m-d H:i:s', $expiration_ts );
			}

			$result['new_status']     = $new_status;
			$result['new_expiration'] = $new_expiration;

			// Determine if update is needed.
			$needs_update = false;
			$changes      = array();

			if ( $new_status !== $sub_data->status && 'paused' !== $new_status ) {
				$needs_update = true;
				$changes[]    = sprintf( 'status: %s → %s', $sub_data->status, $new_status );
			}

			// Only update expiration for expired_future mode.
			if ( 'expired_future' === $this->sync_mode && $new_expiration && $new_expiration !== $sub_data->expiration ) {
				$needs_update = true;
				$changes[]    = sprintf( 'expiration: %s → %s', $sub_data->expiration, $new_expiration );
			}

			if ( $needs_update ) {
				$result['action'] = $this->dry_run ? 'would_update' : 'updated';

				if ( ! $this->dry_run ) {
					// Update the subscription.
					$subscription = new \EDD\Recurring\Subscriptions\Subscription( $sub_data->id );

					$update_args = array();
					if ( $new_status !== $sub_data->status ) {
						$update_args['status'] = $new_status;
					}
					if ( 'expired_future' === $this->sync_mode && $new_expiration && $new_expiration !== $sub_data->expiration ) {
						$update_args['expiration'] = $new_expiration;
					}

					$updated = $subscription->update( $update_args );

					if ( $updated ) {
						$subscription->add_note(
							sprintf(
								/* translators: %s: List of changes made */
								__( 'Subscription synced with Stripe: %s', 'edd-recurring' ),
								implode( ', ', $changes )
							)
						);
						$result['message'] = implode( ', ', $changes );
					} else {
						$result['message'] = __( 'Failed to update subscription', 'edd-recurring' );
						$result['action']  = 'error';
					}
				} else {
					$result['message'] = __( 'Would update: ', 'edd-recurring' ) . implode( ', ', $changes );
				}

				// Update sync stats.
				$this->increment_sync_stat( 'updated' );
			} else {
				$result['action']  = 'skip';
				$result['message'] = __( 'Already in sync', 'edd-recurring' );
				if ( 'paused' === $new_status ) {
					$result['message'] = __( 'Subscription paused at Stripe', 'edd-recurring' );
				}
			}

			$this->increment_sync_stat( 'processed' );

		} catch ( \EDD\Vendor\Stripe\Exception\RateLimitException $e ) {
			// Handle Stripe rate limit (429) as fallback.
			// The 100ms delay should prevent this, but pause if it occurs.
			$result['message'] = __( 'Stripe rate limited. Pausing sync to retry.', 'edd-recurring' );
			$result['action']  = 'rate_limited';

			// Set transient to signal pause on next step.
			set_transient( $this->get_transient_name_rate_limited(), true, MINUTE_IN_SECONDS );

			// Return false to not advance cursor past this subscription.
			return false;
		} catch ( \Exception $e ) {
			$result['message'] = __( 'Error: ', 'edd-recurring' ) . $e->getMessage();
			$result['action']  = 'error';
			$this->increment_sync_stat( 'processed' );
			$this->increment_sync_stat( 'errors' );
		}

		return $result;
	}

	/**
	 * Map Stripe subscription status to EDD status.
	 *
	 * @since 2.13.5
	 * @param string $stripe_status Stripe subscription status.
	 * @return string EDD subscription status.
	 */
	private function map_stripe_status( $stripe_status ) {
		$status_map = array(
			'active'             => 'active',
			'trialing'           => 'trialling',
			'canceled'           => 'cancelled',
			'past_due'           => 'failing',
			'unpaid'             => 'failing',
			'incomplete'         => 'pending',
			'incomplete_expired' => 'expired',
		);

		return isset( $status_map[ $stripe_status ] ) ? $status_map[ $stripe_status ] : $stripe_status;
	}

	/**
	 * Set the CSV columns.
	 *
	 * @since 2.13.5
	 * @return array All the columns.
	 */
	public function csv_cols() {
		return array(
			'id'                 => __( 'Subscription ID', 'edd-recurring' ),
			'profile_id'         => __( 'Stripe ID', 'edd-recurring' ),
			'current_status'     => __( 'Current Status', 'edd-recurring' ),
			'current_expiration' => __( 'Current Expiration', 'edd-recurring' ),
			'stripe_status'      => __( 'Stripe Status', 'edd-recurring' ),
			'new_status'         => __( 'New Status', 'edd-recurring' ),
			'new_expiration'     => __( 'New Expiration', 'edd-recurring' ),
			'action'             => __( 'Action', 'edd-recurring' ),
			'message'            => __( 'Details', 'edd-recurring' ),
		);
	}

	/**
	 * Return the calculated completion percentage.
	 *
	 * @since 2.13.5
	 * @return int
	 */
	public function get_percentage_complete() {
		$total = get_transient( $this->get_transient_name_total() );

		if ( ! $total ) {
			return 100;
		}

		$stats      = $this->get_sync_stats();
		$processed  = isset( $stats['processed'] ) ? $stats['processed'] : 0;
		$percentage = ( $processed / $total ) * 100;

		if ( $percentage > 100 ) {
			$percentage = 100;
		}

		return (int) $percentage;
	}

	/**
	 * Set the properties specific to the export.
	 *
	 * @since 2.13.5
	 * @param array $request The form data passed into the batch processing.
	 */
	public function set_properties( $request ) {
		$this->sync_mode = isset( $request['sync_mode'] ) ? sanitize_text_field( $request['sync_mode'] ) : 'expired_future';
		$this->dry_run   = isset( $request['dry_run'] ) && '1' === $request['dry_run'];

		// Validate sync mode.
		if ( ! in_array( $this->sync_mode, array( 'expired_future', 'failing', 'all_active' ), true ) ) {
			$this->sync_mode = 'expired_future';
		}

		// Date filter.
		if ( isset( $request['use_date_filter'] ) && '1' === $request['use_date_filter'] && ! empty( $request['sync_date'] ) ) {
			$date = sanitize_text_field( $request['sync_date'] );
			// Validate date format (Y-m-d).
			if ( preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date ) ) {
				$this->date_filter = $date . ' 00:00:00';
			}
		}

		// Initialize on first step.
		if ( 1 === $this->step ) {
			$this->last_processed_id = 0;
			$total_count             = $this->get_total_subscription_count();
			set_transient( $this->get_transient_name_total(), $total_count, HOUR_IN_SECONDS );
			set_transient( $this->get_transient_name_last_id(), 0, HOUR_IN_SECONDS );
			$this->initialize_sync_stats();
		} else {
			// Restore cursor from previous step.
			$this->last_processed_id = (int) get_transient( $this->get_transient_name_last_id() );
		}
	}

	/**
	 * Whether the current user can export the data.
	 *
	 * @since 2.13.5
	 * @return bool
	 */
	public function can_export(): bool {
		return current_user_can( 'manage_shop_settings' ) && edd_is_gateway_active( 'stripe' );
	}

	/**
	 * Get total subscription count based on sync mode and filters.
	 *
	 * @since 2.13.5
	 * @return int
	 */
	private function get_total_subscription_count(): int {
		global $wpdb;

		$where_parts = $this->build_where_clauses( false );
		$where       = implode( ' AND ', $where_parts );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$count = $wpdb->get_var( "SELECT COUNT(id) FROM {$wpdb->prefix}edd_subscriptions WHERE {$where}" );

		return $count ? (int) $count : 0;
	}

	/**
	 * Build WHERE clause parts for subscription queries.
	 *
	 * @since 2.13.5
	 * @param bool $include_cursor Whether to include the cursor (id > last_processed_id) condition.
	 * @return array Array of WHERE clause parts.
	 */
	private function build_where_clauses( bool $include_cursor = false ): array {
		global $wpdb;

		$current_date = current_time( 'mysql' );
		$where_parts  = array(
			"gateway = 'stripe'",
			"profile_id != ''",
		);

		// Add cursor for pagination if requested.
		if ( $include_cursor ) {
			$where_parts[] = $wpdb->prepare( 'id > %d', $this->last_processed_id );
		}

		// Add sync mode specific conditions.
		if ( 'expired_future' === $this->sync_mode ) {
			$where_parts[] = "status = 'expired'";
			$where_parts[] = $wpdb->prepare( 'expiration > %s', $current_date );
		} elseif ( 'failing' === $this->sync_mode ) {
			$where_parts[] = "status = 'failing'";
		}

		// Add date filter if set.
		if ( ! empty( $this->date_filter ) ) {
			$where_parts[] = $wpdb->prepare( 'created >= %s', $this->date_filter );
		}

		return $where_parts;
	}

	/**
	 * Initialize sync statistics.
	 *
	 * @since 2.13.5
	 */
	private function initialize_sync_stats() {
		set_transient(
			$this->get_transient_name_stats(),
			array(
				'processed' => 0,
				'updated'   => 0,
				'errors'    => 0,
			),
			HOUR_IN_SECONDS
		);
	}

	/**
	 * Increment a sync statistic.
	 *
	 * @since 2.13.5
	 * @param string $stat The stat to increment.
	 */
	private function increment_sync_stat( $stat ) {
		$stats = get_transient( $this->get_transient_name_stats() );
		if ( ! is_array( $stats ) ) {
			$stats = array(
				'processed' => 0,
				'updated'   => 0,
				'errors'    => 0,
			);
		}

		if ( isset( $stats[ $stat ] ) ) {
			++$stats[ $stat ];
			set_transient( $this->get_transient_name_stats(), $stats, HOUR_IN_SECONDS );
		}
	}

	/**
	 * Get sync statistics.
	 *
	 * @since 2.13.5
	 * @return array
	 */
	private function get_sync_stats(): array {
		$stats = get_transient( $this->get_transient_name_stats() );
		if ( ! is_array( $stats ) ) {
			return array(
				'processed' => 0,
				'updated'   => 0,
				'errors'    => 0,
			);
		}

		return $stats;
	}

	/**
	 * Get the transient name.
	 *
	 * @since 2.13.5
	 * @return string
	 */
	private function get_transient_name_stats(): string {
		return 'edd_recurring_stripe_sync_stats';
	}

	/**
	 * Get the transient name for the last processed ID.
	 *
	 * @since 2.13.5
	 * @return string
	 */
	private function get_transient_name_last_id(): string {
		return 'edd_recurring_stripe_sync_last_id';
	}

	/**
	 * Get the transient name for the total count.
	 *
	 * @since 2.13.5
	 * @return string
	 */
	private function get_transient_name_total(): string {
		return 'edd_recurring_stripe_sync_total';
	}

	/**
	 * Get the transient name for rate limiting.
	 *
	 * @since 2.13.5
	 * @return string
	 */
	private function get_transient_name_rate_limited(): string {
		return 'edd_recurring_stripe_sync_rate_limited';
	}
}
