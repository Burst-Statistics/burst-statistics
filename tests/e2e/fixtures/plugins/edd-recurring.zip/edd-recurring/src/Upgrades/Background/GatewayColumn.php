<?php
/**
 * Background upgrade for populating the gateway column.
 *
 * @package     EDD\Upgrades\Background
 * @copyright   Copyright (c) 2025, Sandhills Development, LLC
 * @license     https://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       2.13.0
 */

namespace EDD\Recurring\Upgrades\Background;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit; // @codeCoverageIgnore

/**
 * GatewayColumn upgrade class.
 *
 * @since 2.13.0
 */
class GatewayColumn extends Upgrade {

	/**
	 * The number of database rows which should prevent the upgrade running via the background process.
	 *
	 * @var int
	 */
	protected $warning_count = 0;

	/**
	 * The number of items to process per step.
	 *
	 * @var int
	 */
	protected $per_step = 100;

	/**
	 * The name of the upgrade.
	 *
	 * @since 2.13.0
	 * @var string
	 */
	public static function get_upgrade_name(): string {
		return 'subscriptions_gateway_column';
	}

	/**
	 * Maybe schedule the background update.
	 *
	 * @since 2.13.0
	 * @return void
	 */
	public function maybe_schedule_background_update() {
		$component = edd_get_component( 'subscription' );
		if ( ! $component ) {
			return;
		}
		$table = $component->get_interface( 'table' );
		if ( ! $table ) {
			return;
		}

		if ( ! $table->column_exists( 'gateway' ) ) {
			return;
		}

		parent::maybe_schedule_background_update();
	}

	/**
	 * Process the upgrade step.
	 * The database is modified directly since Berlin will
	 * always change the date modified to the current date/time.
	 *
	 * @since 2.13.0
	 * @return void
	 */
	public function process_step(): void {
		if ( ! $this->can_process_step() ) {
			return;
		}

		$items = $this->get_items( false );
		if ( empty( $items ) ) {
			$this->mark_complete();
			return;
		}

		global $wpdb;

		foreach ( $items as $item ) {
			$gateway = $this->get_subscription_gateway( $item );
			edd_debug_log( 'Updating subscription ' . $item->id . ' with gateway: ' . $gateway );
			$wpdb->update(
				$wpdb->edd_subscriptions,
				array( 'gateway' => $gateway ),
				array( 'id' => $item->id ),
				array( '%s' ),
				array( '%d' )
			);
		}

		$this->add_or_update_initial_notification();

		// Schedule the next step.
		self::schedule_next_event( time() + MINUTE_IN_SECONDS );
	}

	/**
	 * Get the items to process.
	 *
	 * @since 2.13.0
	 * @param bool $count Whether to return the count of items.
	 * @return array|bool
	 */
	public function get_items( $count = false ) {

		if ( $count ) {
			return edd_recurring_count_subscriptions(
				array(
					'gateway' => '',
				)
			);
		}

		return edd_recurring_get_subscriptions(
			array(
				'number'  => $this->get_count_per_step(),
				'gateway' => '',
				'orderby' => 'id',
				'order'   => 'ASC',
			)
		);
	}

	/**
	 * Get the complete notification parameters.
	 *
	 * @since 2.13.0
	 * @return array
	 */
	public function get_complete_notification(): array {
		return array(
			'title'   => __( 'Subscription Upgrade Complete', 'edd-recurring' ),
			'content' => __( 'The gateway column has been populated for all subscriptions.', 'edd-recurring' ),
		);
	}

	/**
	 * Get the in progress notification parameters.
	 *
	 * @since 2.13.0
	 * @return array
	 */
	public function get_in_progress_notification(): array {
		return array(
			'title'   => __( 'Subscription Upgrade In Progress', 'edd-recurring' ),
			'content' => __( 'The gateway column is being populated for all subscriptions. This may take a long time to complete depending on the number of subscriptions but, your site will remain fully functional while it is running.', 'edd-recurring' ),
		);
	}

	/**
	 * Get the CLI notification parameters.
	 *
	 * @since 2.13.0
	 * @return array
	 */
	public function get_cli_notification(): array {
		return array();
	}

	/**
	 * Gets the subscription last modified date based on the subscription notes.
	 *
	 * @since 2.13.0
	 * @param \EDD_Subscription $subscription The subscription object.
	 * @return string
	 */
	private function get_subscription_gateway( $subscription ) {
		$order = edd_get_order( $subscription->parent_payment_id );
		if ( ! $order ) {
			return 'manual';
		}

		return $order->gateway;
	}
}
