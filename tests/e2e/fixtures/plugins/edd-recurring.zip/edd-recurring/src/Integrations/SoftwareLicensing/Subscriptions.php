<?php
/**
 * Software Licensing subscriptions trait.
 *
 * @package     EDD\Recurring\Integrations\SoftwareLicensing
 * @copyright   Copyright (c) 2025, Sandhills Development, LLC
 * @license     https://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       2.13.5
 */

namespace EDD\Recurring\Integrations\SoftwareLicensing;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit; // @codeCoverageIgnore

/**
 * Subscriptions trait.
 */
trait Subscriptions {

	/**
	 * Prevent an upgraded or manually renewed subscription from being reactivated.
	 * This overrides the gateway filter if the subscription can be reactivated.
	 *
	 * @since 2.13.5
	 * @param bool                                      $can_reactivate Whether the subscription can be reactivated.
	 * @param \EDD\Recurring\Subscriptions\Subscription $subscription   The subscription object.
	 * @return bool
	 */
	public function can_reactivate( $can_reactivate, $subscription ) {
		// Bail if the subscription can't be reactivated (handled by the gateway).
		if ( ! $can_reactivate ) {
			return $can_reactivate;
		}

		// Bail if the subscription is not cancelled or stripe.
		if ( 'cancelled' !== $subscription->status || 'stripe' !== $subscription->gateway ) {
			return $can_reactivate;
		}

		// Bail if the subscription is not tied to a license.
		$license = edd_software_licensing()->get_license_by_purchase( $subscription->parent_payment_id, $subscription->product_id, false, false );
		if ( ! $license ) {
			return $can_reactivate;
		}

		// If the license has not been upgraded or renewed, allow reactivation.
		if ( ! $license->get_meta( '_edd_sl_upgrade_date' ) && ! $license->get_meta( '_edd_sl_renewal_date' ) ) {
			return $can_reactivate;
		}

		// The license subscription will be the most recent active or trialling subscription.
		$license              = new License( $license );
		$license_subscription = $license->get_subscription();
		if ( ! $license_subscription ) {
			return $can_reactivate;
		}

		// If the subscription is not the same as the license subscription, prevent reactivation.
		if ( (int) $subscription->id !== (int) $license_subscription->id ) {
			return false;
		}

		return $can_reactivate;
	}
}
