<?php
/**
 * Software Licensing Upgrades trait.
 *
 * @package     EDD\Recurring\Integrations\SoftwareLicensing
 * @copyright   Copyright (c) 2025, Sandhills Development, LLC
 * @license     https://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       2.13.0
 */

namespace EDD\Recurring\Integrations\SoftwareLicensing;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit; // @codeCoverageIgnore

use EDD\Gateways\PayPal\Exceptions\API_Exception;

/**
 * Software Licensing Upgrades trait.
 *
 * @since 2.13.0
 */
trait Upgrades {

	/**
	 * Cancel a subscription when a license is upgraded.
	 *
	 * @since 2.13.0
	 * @param int   $license_id The license ID.
	 * @param array $args       The license upgrade arguments.
	 */
	public function cancel_subscription_on_upgrade( $license_id, $args ) {
		$license          = new License( $license_id );
		$old_subscription = $license->get_subscription(
			array(
				'parent_payment_id' => $args['old_payment_id'],
				'product_id'        => $args['old_download_id'],
				'price_id'          => $args['old_price_id'],
			)
		);
		if ( ! $old_subscription ) {
			edd_debug_log( sprintf( 'Recurring - No old subscription found for license %d for upgrade.', $license_id ) );

			return;
		}

		$cancellation_handler = new \EDD\Recurring\Subscriptions\Cancel();
		$cancellation_handler->schedule_cancellation( $old_subscription, 'license upgrade' );
	}

	/**
	 * When upgrading or manually renewing a license, set a trial period so that we avoid having a license that expires
	 * prior to the subscription, and renew the subscription at the next expiration.
	 *
	 * For upgrades: Syncs the subscription to the license's calculated expiration based on the upgrade path.
	 * For manual renewals: Extends the subscription by one term from the old subscription's expiration.
	 *
	 * This handles timing differences between Payment Elements (license renewed first) and Card Elements
	 * (subscription created first) by using the old subscription's expiration as the base calculation.
	 *
	 * @since 2.7.1
	 *
	 * @param array                      $args          Arguments used to create the subscription.
	 * @param array                      $downloads     All downloads for this order.
	 * @param string                     $gateway       Gateway slug.
	 * @param int                        $download_id   ID of the download for this subscription.
	 * @param int|false                  $price_id      Price ID for the download.
	 * @param array                      $subscription  All subscription data used for creating the subscription.
	 * @param EDD_Recurring_Gateway|null $gateway_class Gateway object.
	 *
	 * @return array
	 * @throws \Exception Thrown when a PayPal API error occurs.
	 * @throws API_Exception Thrown when a PayPal API error occurs.
	 */
	public function handle_subscription_upgrade_billing( $args, $downloads, $gateway, $download_id, $price_id, $subscription = array(), $gateway_class = null ) {

		$downloads = ! is_array( $downloads ) ? array() : $downloads;

		foreach ( $downloads as $download ) {

			$license = $this->get_license( $download, $download_id, $price_id );
			if ( false === $license ) {
				continue;
			}

			$options = $this->get_options( $download );
			edd_debug_log(
				sprintf(
					'Recurring - handle_subscription_upgrade_billing: Processing license %d. Is upgrade: %s, Is renewal: %s',
					$license->ID,
					isset( $options['is_upgrade'] ) ? 'yes' : 'no',
					isset( $options['is_renewal'] ) ? 'yes' : 'no'
				)
			);

			$license_expiration = $this->get_license_expiration( $license, $download );
			if ( false === $license_expiration ) {
				edd_debug_log( 'Recurring - handle_subscription_upgrade_billing: License expiration returned false' );
				continue;
			}

			edd_debug_log( sprintf( 'Recurring - License Expiration after Upgrade/Renewal: %s', gmdate( 'Y-m-d H:i:s', $license_expiration ) ) );

			switch ( $gateway ) {

				case 'stripe':
					// Instead of using billing_cycle_anchor to offset the start time of the next subscription, use a free trial.
					unset( $args['billing_cycle_anchor'] );
					$args['trial_end']      = $license_expiration;
					$args['needs_one_time'] = true;
					$args['license_id']     = $license->ID;
					break;

				case 'paypal_commerce':
					try {
						if ( empty( $gateway_class->paypal_product_id ) ) {
							throw new \Exception( 'Missing PayPal product ID.' );
						}

						$plan_args = \EDD_Recurring\Gateways\PayPal\_create_plan_args_for_sl_upgrade(
							new \DateTime( date( 'Y-m-d H:i:s', $license_expiration ) ), // phpcs:ignore WordPress.DateTime.RestrictedFunctions.date_date
							$gateway_class->paypal_product_id,
							$subscription
						);

						$api      = new \EDD\Gateways\PayPal\API();
						$response = $api->make_request( 'v1/billing/plans', $plan_args );

						if ( 201 !== $api->last_response_code ) {
							throw new API_Exception(
								sprintf(
									'Unexpected HTTP response code: %d; Response: %s',
									$api->last_response_code,
									json_encode( $response )
								)
							);
						}

						if ( empty( $response->id ) ) {
							throw new API_Exception( sprintf( 'Missing plan ID from PayPal response. Response: %s', json_encode( $response ) ) );
						}

						$args['plan_id'] = $response->id;
					} catch ( \Exception $e ) {
						edd_debug_log(
							sprintf(
								'PayPal - Exception while syncing subscription to license key. Message: %s',
								$e->getMessage()
							),
							true
						);
					}
					break;

				case 'paypalpro':
				case 'paypalexpress':
					$args['PROFILESTARTDATE'] = date( 'Y-m-d\Tg:i:s', $license_expiration ); // phpcs:ignore WordPress.DateTime.RestrictedFunctions.date_date
					break;

				case 'paypal':
					$current_date = new \DateTime( 'now' );
					$expiration   = new \DateTime( date( 'Y-m-d', $license_expiration ) ); // phpcs:ignore WordPress.DateTime.RestrictedFunctions.date_date
					$date_diff    = $current_date->diff( $expiration );

					$args['t1'] = 'D';
					$args['p1'] = $date_diff->days;

					/**
					 * PayPal has a maximum of 90 days for trial periods.
					 * If the trial period, likely due to a Software Licensing upgrade, is greater than 90 days,
					 * we need to split it into two trial periods.
					 *
					 * See https://github.com/easydigitaldownloads/edd-recurring/issues/769
					 */
					if ( $date_diff->days > 90 && 'D' === $args['t1'] ) {

						// Setup the default period times.
						$first_period  = $date_diff->days;
						$second_period = 0;
						$unit          = 'D';

						if ( ( $date_diff->days - 90 ) <= 90 ) {

							// t1 = D, t2 = D.
							$unit = 'D';

							$second_period = $date_diff->days - 90;
							$first_period  = 90;

						} elseif ( $date_diff->days / 7 <= 52 ) {

							// t1 = D, t2 = W.
							$unit = 'W';

							$total_weeks   = $date_diff->days / 7;
							$second_period = (int) floor( $total_weeks );
							$first_period  = (int) absint( round( ( 7 * ( $total_weeks - $second_period ) ) ) );

						} elseif ( $date_diff->days / 7 > 52 ) {

							// t1 = D, tw = M.
							$unit = 'M';

							$first_period  = $date_diff->d;
							$second_period = $date_diff->m;
						}

						// Let's reduce things to be a bit more 'human readable.
						switch ( $unit ) {
							case 'W':
								if ( 52 === $second_period ) {
									$unit          = 'Y';
									$second_period = 1;
								} elseif ( 4 === $second_period ) {
									$unit          = 'M';
									$second_period = 1;
								}

								break;

							case 'M':
								if ( 12 === $second_period ) {
									$unit          = 'Y';
									$second_period = 1;
								}
								break;
						}

						/**
						 * If we have left over days after doing the math to determine if we're over limits,
						 * we create 2 trials, if they have no left over days, we simply set the initial trial.
						 *
						 * This covers upgrading a subscription on the same day.
						 */
						if ( ! empty( $first_period ) ) {
							$args['p1'] = $first_period;
							$args['t1'] = 'D';
							$args['a2'] = 0;
							$args['p2'] = absint( $second_period );
							$args['t2'] = $unit;
						} else {
							$args['p1'] = absint( $second_period );
							$args['t1'] = $unit;
						}
					}

					break;

				case 'authorize':
					$args['subscription']['paymentSchedule']['startDate'] = date( 'Y-m-d', $license_expiration ); // phpcs:ignore WordPress.DateTime.RestrictedFunctions.date_date
					break;
			}

			break;
		}

		return $args;
	}

	/**
	 * Get the license for the download.
	 *
	 * @since 2.13.0
	 * @param array $download    The download array.
	 * @param int   $download_id The download ID.
	 * @param int   $price_id    The price ID.
	 * @return \EDD_SL_License|false
	 */
	private function get_license( $download, $download_id, $price_id ) {
		$options = $this->get_options( $download );
		// Check if this is an upgrade or a manual renewal.
		if ( ! isset( $options['is_upgrade'] ) && ! isset( $options['is_renewal'] ) ) {
			return false;
		}

		if ( (int) $download['id'] !== (int) $download_id ) {
			return false;
		}

		// Determine if there is no price_id needed to be checked.
		if ( isset( $options['price_id'] ) && is_numeric( $options['price_id'] ) ) {
			if ( (int) $price_id !== (int) $options['price_id'] ) {
				return false;
			}
		}

		$license_id = isset( $options['license_id'] ) ? $options['license_id'] : false;
		if ( empty( $license_id ) ) {
			return false;
		}

		$license = edd_software_licensing()->get_license( $license_id );
		if ( false === $license ) {
			return false;
		}

		/*
		 * If the license never expires, then exit now.
		 * This logic to sync up with the license expiration date is not necessary if there is no expiration date.
		 * @link https://github.com/easydigitaldownloads/edd-recurring/issues/1311
		 */
		if ( empty( $license->expiration ) ) {
			return false;
		}

		return $license;
	}

	/**
	 * Get the options for the download.
	 * Account for the fact that PayPal Express deals with post-payment creation, which means we have item_number in play.
	 *
	 * @since 2.13.0
	 * @param array $download The download array.
	 * @return array
	 */
	private function get_options( $download ) {
		return isset( $download['item_number']['options'] ) ? $download['item_number']['options'] : $download['options'];
	}

	/**
	 * Get the license expiration. Depending on the gateway, the license may have been upgraded, but if not,
	 * we get the expiration from the upgrade paths and new download, instead of the existing license, as it has not changed yet.
	 *
	 * @since 2.13.0
	 * @param \EDD_SL_License $license  The license object.
	 * @param array           $download The download array.
	 * @return int|false
	 */
	private function get_license_expiration( $license, $download ) {
		$options = $this->get_options( $download );

		if ( isset( $options['is_renewal'] ) ) {
			$expiration = $this->get_manual_renewal_expiration( $license, $options );

			// Store the license ID and expected expiration in a single meta key so we can sync it later when the subscription is confirmed.
			if ( ! empty( $expiration ) ) {
				$license->update_meta(
					'_edd_recurring_renewal_expiration',
					array(
						'license_id' => $license->ID,
						'expiration' => $expiration,
					)
				);
				edd_debug_log( sprintf( 'Recurring - Stored expected renewal expiration for license %d: %s', $license->ID, gmdate( 'Y-m-d H:i:s', $expiration ) ) );
			}

			return $expiration;
		}

		// For upgrades, get the expiration from the upgrade path.
		edd_debug_log( 'Recurring - get_license_expiration: Detected upgrade, processing upgrade logic' );
		$upgrade_path = $this->get_upgrade_path( $license, $download );
		if ( empty( $upgrade_path ) ) {
			return $license->expiration;
		}

		edd_debug_log( sprintf( 'Recurring - Found upgrade path: %s', print_r( $upgrade_path, true ) ) );
		$upgraded_download = new \EDD_SL_Download( $upgrade_path['download_id'] );

		if ( $upgraded_download->has_variable_prices() ) {
			$price_id             = $upgrade_path['price_id'];
			$download_is_lifetime = $upgraded_download->is_price_lifetime( $upgrade_path['price_id'] );
		} else {
			$price_id             = false;
			$download_is_lifetime = $upgraded_download->is_lifetime();
		}

		if ( $download_is_lifetime ) {
			return false;
		}

		$license_period = $this->get_license_period( $upgraded_download, $price_id );

		// Get the start time of the current period.
		$previous_start_time = strtotime( '-' . $license->license_length(), $license->expiration );

		// Sync the trial expiration to when the license expires, using the current period's start date plus the length of the upgrade.
		return strtotime( $license_period, $previous_start_time );
	}

	/**
	 * Get the manual renewal expiration.
	 *
	 * Determines the expiration for a manually renewed subscription. This works for both Payment Elements
	 * (license already renewed) and Card Elements (license not yet renewed) by calculating what the
	 * expiration SHOULD be and comparing it to the license's actual expiration.
	 *
	 * @since 2.13.5
	 * @param \EDD_SL_License $license  The license object.
	 * @param array           $options The download options.
	 * @return int|false
	 */
	private function get_manual_renewal_expiration( $license, $options ) {
		// Get the license period from the product settings, not from the license object.
		// The license object's license_length() may reflect the trial period, not the actual subscription period.
		$download       = new \EDD_SL_Download( $license->download_id );
		$price_id       = $options['price_id'] ?? false;
		$license_length = $this->get_license_period( $download, $price_id );

		// Get the old subscription to determine the original expiration date.
		$old_subscription = $this->get_old_subscription_for_renewal( $options );

		if ( $old_subscription && ! empty( $old_subscription->expiration ) ) {
			$old_expiration = strtotime( $old_subscription->expiration );
			if ( false === $old_expiration ) {
				return false;
			}

			// Calculate what the new expiration SHOULD be (old expiration + one license term).
			// Even if the old expiration is in the past, we extend from it (not from current time)
			// because this is a renewal, not a new purchase.
			$calculated_expiration = strtotime( $license_length, $old_expiration );

			// Compare the license's current expiration to what we calculated.
			// If the license expiration is at or beyond what we calculated, Software Licensing
			// has already renewed it (Payment Elements), so use the license expiration.
			// Otherwise, the license hasn't been renewed yet (Card Elements), so use our calculation.
			if ( $license->expiration >= $calculated_expiration ) {
				edd_debug_log(
					sprintf(
						'Recurring - Manual renewal: License already renewed. License exp: %s, Calculated exp: %s. Using license expiration.',
						gmdate( 'Y-m-d H:i:s', $license->expiration ),
						gmdate( 'Y-m-d H:i:s', $calculated_expiration )
					)
				);
				return $license->expiration;
			}

			edd_debug_log(
				sprintf(
					'Recurring - Manual renewal: License not yet renewed. License exp: %s, Calculated exp: %s. Using calculated expiration.',
					gmdate( 'Y-m-d H:i:s', $license->expiration ),
					gmdate( 'Y-m-d H:i:s', $calculated_expiration )
				)
			);

			return $calculated_expiration;
		}

		// Fallback: No old subscription found. Use license expiration directly if it looks reasonable,
		// otherwise calculate from current time.
		if ( $license->expiration < current_time( 'timestamp' ) ) { // phpcs:ignore WordPress.DateTime.CurrentTimeTimestamp.Requested
			// License is expired, start from current time.
			return strtotime( $license_length, current_time( 'timestamp' ) ); // phpcs:ignore WordPress.DateTime.CurrentTimeTimestamp.Requested
		}

		// License has a future expiration, use it.
		return $license->expiration;
	}

	/**
	 * Get the old subscription for a manual renewal.
	 *
	 * @since 2.13.5
	 * @param array $options The download options.
	 * @return \EDD_Subscription|false
	 */
	private function get_old_subscription_for_renewal( $options ) {
		if ( empty( $options['license_id'] ) ) {
			return false;
		}

		$license = new License( $options['license_id'] );
		return $license->get_subscription(
			array(
				'status' => array( 'active', 'trialling', 'failing', 'cancelled' ),
				'order'  => 'DESC',
			)
		);
	}

	/**
	 * Get the upgrade path for the license.
	 *
	 * @since 2.13.0
	 * @param \EDD_SL_License $license  The license object.
	 * @param array           $download The download array.
	 * @return array|false
	 */
	private function get_upgrade_path( $license, $download ) {
		$options       = $this->get_options( $download );
		$upgrade_paths = edd_sl_get_license_upgrades( $license->ID );

		edd_debug_log( sprintf( 'Recurring - License Upgrade paths: %s', print_r( $upgrade_paths, true ) ) );

		return ! empty( $upgrade_paths[ $options['upgrade_id'] ] ) ? $upgrade_paths[ $options['upgrade_id'] ] : false;
	}

	/**
	 * Get the license period.
	 *
	 * @since 2.13.5
	 * @param \EDD_SL_Download $download The download object.
	 * @return string
	 */
	private function get_license_period( $download, $price_id ) {
		$exp_unit   = $download->get_expiration_unit( $price_id ) ?? 'years';
		$exp_length = $download->get_expiration_length( $price_id ) ?? '1';

		return '+' . $exp_length . ' ' . $exp_unit;
	}
}
