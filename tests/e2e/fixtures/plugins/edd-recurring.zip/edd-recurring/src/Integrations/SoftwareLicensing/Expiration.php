<?php
/**
 * Expiration trait.
 *
 * @package EDD\Recurring\Integrations\SoftwareLicensing
 * @copyright Copyright (c) 2025, Sandhills Development, LLC
 * @license https://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since 2.13.5
 */

namespace EDD\Recurring\Integrations\SoftwareLicensing;

/**
 * Expiration trait.
 *
 * @since 2.13.5
 */
trait Expiration {

	/**
	 * Applies the correct subscription expiration for manual renewals.
	 *
	 * This hooks into `edd_recurring_pre_record_signup_args` to set the subscription expiration
	 * directly before the subscription is created. This ensures the subscription gets the correct
	 * full period expiration instead of just the trial period.
	 *
	 * @since 2.13.5
	 * @param array  $args                    The subscription creation arguments.
	 * @param object $recurring_gateway_data  The gateway data object.
	 * @return array The modified subscription arguments.
	 */
	public function handle_renewal_subscription_expiration( $args, $recurring_gateway_data ) {
		$download_id = $args['product_id'];

		foreach ( $recurring_gateway_data->purchase_data['downloads'] as $download ) {
			if ( (int) $download['id'] !== (int) $download_id ) {
				continue;
			}

			// Only process manual renewals, not upgrades (upgrades are in plugin-software-licensing.php).
			if ( ! isset( $download['options']['is_renewal'] ) ) {
				continue;
			}

			$license_id = isset( $download['options']['license_id'] ) ? $download['options']['license_id'] : false;
			$license    = edd_software_licensing()->get_license( $license_id );
			if ( ! $license ) {
				continue;
			}

			// Get the expected renewal expiration we calculated earlier.
			$expected_renewal = $license->get_meta( '_edd_recurring_renewal_expiration', true );
			if ( ! empty( $expected_renewal['expiration'] ) ) {
				// Set the subscription expiration directly, bypassing the trial period logic.
				// phpcs:ignore WordPress.DateTime.RestrictedFunctions.date_date
				$args['expiration'] = date( 'Y-m-d H:i:s', $expected_renewal['expiration'] );
				edd_debug_log(
					sprintf(
						'Recurring - Set subscription expiration for manual renewal: %s (license %d)',
						gmdate( 'Y-m-d H:i:s', $expected_renewal['expiration'] ),
						$license->ID
					)
				);
			}
		}

		return $args;
	}

	/**
	 * Corrects license expiration for manual renewals after the license is renewed.
	 *
	 * When a license is renewed, the License::renew() method calculates the new expiration
	 * based on license_length(), which can include trial periods. This hook catches that
	 * and corrects the expiration to what we calculated earlier.
	 *
	 * @since 2.13.5
	 * @param int $license_id The license ID being renewed.
	 * @param int $new_expiration The new expiration timestamp.
	 * @return void
	 */
	public function correct_license_expiration( $license_id, $new_expiration = null ) {
		$license = edd_software_licensing()->get_license( $license_id );
		if ( ! $license ) {
			return;
		}

		// Check if we have a stored expected expiration for a manual renewal.
		$expected_renewal = $license->get_meta( '_edd_recurring_renewal_expiration', true );
		if ( empty( $expected_renewal['expiration'] ) ) {
			// No manual renewal stored, nothing to do.
			return;
		}

		// Update the license expiration to our calculated value.
		if ( (int) $license->expiration !== (int) $expected_renewal['expiration'] ) {
			$original_expiration = $license->expiration;
			$license->expiration = $expected_renewal['expiration'];
			edd_debug_log(
				sprintf(
					'Recurring - Corrected license %d expiration after renewal to %s (was: %s)',
					$license->ID,
					gmdate( 'Y-m-d H:i:s', $expected_renewal['expiration'] ),
					gmdate( 'Y-m-d H:i:s', $original_expiration )
				)
			);
		}

		// Clean up the meta.
		$license->delete_meta( '_edd_recurring_renewal_expiration' );
	}

	/**
	 * Fallback: sync renewal expiration to subscription if meta still exists.
	 *
	 * For Stripe (Payment Elements) where the subscription is created after the license renewal,
	 * this ensures the license expiration is corrected when the Stripe subscription args are built.
	 *
	 * @since 2.13.5
	 * @param array  $args The Stripe subscription arguments.
	 * @param array  $purchase_data The purchase data including downloads.
	 * @param object $customer The Stripe customer object.
	 * @return array The modified subscription arguments.
	 */
	public function sync_renewal_expiration_to_subscription( $args, $purchase_data, $customer ) {
		if ( 'payment-elements' !== edds_get_elements_mode() ) {
			return $args;
		}

		foreach ( $purchase_data['downloads'] as $download ) {
			if ( ! empty( $download['options']['license_id'] ) && ! empty( $download['options']['is_renewal'] ) ) {
				$this->correct_license_expiration( $download['options']['license_id'] );
			}
		}

		return $args;
	}
}
