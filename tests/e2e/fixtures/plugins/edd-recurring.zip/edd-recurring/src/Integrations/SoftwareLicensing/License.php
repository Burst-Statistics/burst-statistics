<?php
/**
 * Software Licensing license handler.
 *
 * @package     EDD\Recurring\Integrations\SoftwareLicensing
 * @copyright   Copyright (c) 2025, Sandhills Development, LLC
 * @license     http://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       2.13.0
 */

namespace EDD\Recurring\Integrations\SoftwareLicensing;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit; // @codeCoverageIgnore

/**
 * License class.
 *
 * Wraps an EDD_SL_License object to provide recurring-specific functionality.
 *
 * Accepts either a license ID (int) or an EDD_SL_License object in the constructor.
 * Invalid types will trigger a doing_it_wrong notice and set the license to false.
 *
 * @since 2.13.0
 */
class License {

	/**
	 * The license object.
	 *
	 * @since 2.13.0
	 * @var \EDD_SL_License
	 */
	public $license;

	/**
	 * License constructor.
	 *
	 * Wraps an EDD_SL_License object to provide recurring-specific functionality.
	 *
	 * Accepts either a license ID (int) or an EDD_SL_License object. Invalid types
	 * will trigger a _doing_it_wrong() notice, log to EDD debug log, and set the
	 * license to false.
	 *
	 * @since 2.13.0
	 * @since 2.13.5 Added validation and debug logging for invalid parameters.
	 * @param int|\EDD_SL_License $license_id The license ID or object.
	 */
	public function __construct( $license_id ) {
		// Check for object first (most efficient - no database query needed).
		if ( $license_id instanceof \EDD_SL_License ) {
			$this->license = $license_id;
		} elseif ( is_numeric( $license_id ) ) {
			$this->license = edd_software_licensing()->get_license( $license_id );

			// Validate that get_license() found a valid license.
			if ( false === $this->license ) {
				// WordPress developer notice (shows in WP_DEBUG mode).
				_doing_it_wrong(
					__METHOD__,
					sprintf(
						/* translators: %d: license ID that was not found */
						__( 'License ID %d was not found or is invalid.', 'edd-recurring' ),
						$license_id
					),
					'2.13.5'
				);

				// EDD debug log (forced for critical errors).
				edd_debug_log(
					sprintf( 'EDD Recurring - Invalid License: License ID %d was not found or is invalid.', $license_id ),
					true // Force log even when debug mode is off.
				);

				$this->license = false;
			}
		} else {
			// WordPress developer notice.
			_doing_it_wrong(
				__METHOD__,
				sprintf(
					/* translators: %s: actual type passed to constructor */
					__( 'License parameter must be an integer ID or EDD_SL_License object. %s given.', 'edd-recurring' ),
					is_object( $license_id ) ? get_class( $license_id ) : gettype( $license_id )
				),
				'2.13.5'
			);

			// EDD debug log.
			edd_debug_log(
				sprintf(
					'EDD Recurring - Invalid License Parameter: License parameter must be an integer ID or EDD_SL_License object. %s given.',
					is_object( $license_id ) ? get_class( $license_id ) : gettype( $license_id )
				),
				true // Force log even when debug mode is off.
			);

			$this->license = false;
		}
	}

	/**
	 * Get a subscription from a license.
	 *
	 * @since 2.13.0
	 * @since 2.13.5 Added guard clause to validate license object before accessing properties.
	 * @param array $sub_args Optional. Arguments to pass to the EDD_Subscriptions_DB::get_subscriptions() method.
	 * @return false|\EDD_Subscription
	 */
	public function get_subscription( $sub_args = array() ) {
		// Guard clause: Check if license is valid BEFORE accessing properties.
		if ( ! $this->license instanceof \EDD_SL_License ) {
			return false;
		}

		if ( empty( $this->license->download_id ) ) {
			return false;
		}

		$payment_ids = $this->license->payment_ids;
		if ( ! is_array( $payment_ids ) ) {
			return false;
		}

		if ( ! empty( $sub_args['parent_payment_id'] ) && is_numeric( $sub_args['parent_payment_id'] ) ) {
			$sub_args['parent_payment_id'] = $this->get_parent_order_id( $sub_args['parent_payment_id'] );
		}

		$args = wp_parse_args(
			$sub_args,
			array(
				'product_id'        => $this->license->download_id,
				'status'            => array( 'active', 'trialling' ),
				'number'            => 1,
				'order'             => 'ASC',
				'customer_id'       => $this->license->customer_id,
				'parent_payment_id' => $payment_ids,
			)
		);

		$subs = edd_recurring_get_subscriptions( $args );

		return ! empty( $subs ) ? reset( $subs ) : false;
	}

	/**
	 * Get the parent order ID for the license upgrade.
	 *
	 * @since 2.13.3
	 * @param int $order_id The order ID.
	 * @return int|false
	 */
	public function get_parent_order_id( $order_id ) {
		if ( empty( $order_id ) ) {
			return false;
		}

		// If the order is a subscription renewal, use the parent order ID.
		$order = edd_get_order( $order_id );
		if ( ! empty( $order->parent ) ) {
			return $order->parent;
		}

		return $order_id;
	}
}
