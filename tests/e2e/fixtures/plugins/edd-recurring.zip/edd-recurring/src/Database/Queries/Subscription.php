<?php
/**
 * Subscription Query Class.
 *
 * @package     EDD\Recurring\Database\Queries
 * @copyright   Copyright (c) 2025, Sandhills Development, LLC
 * @license     https://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       2.13.0
 */

namespace EDD\Recurring\Database\Queries;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit; // @codeCoverageIgnore

use EDD\Database\Query;

/**
 * Class used for querying items.
 *
 * @since 2.13.0
 * @see \EDD\Database\Queries\Query::__construct() for accepted arguments.
 */
class Subscription extends Query {

	/** Table Properties ******************************************************/

	/**
	 * Name of the database table to query.
	 *
	 * @since 2.13.0
	 * @access public
	 * @var string
	 */
	protected $table_name = 'subscriptions';

	/**
	 * String used to alias the database table in MySQL statement.
	 *
	 * @since 2.13.0
	 * @access public
	 * @var string
	 */
	protected $table_alias = 'subs';

	/**
	 * Name of class used to setup the database schema
	 *
	 * @since 2.13.0
	 * @access public
	 * @var string
	 */
	protected $table_schema = '\\EDD\\Recurring\\Database\\Schemas\\Subscriptions';

	/** Item ******************************************************************/

	/**
	 * Name for a single item
	 *
	 * @since 2.13.0
	 * @access public
	 * @var string
	 */
	protected $item_name = 'subscription';

	/**
	 * Plural version for a group of items.
	 *
	 * @since 2.13.0
	 * @access public
	 * @var string
	 */
	protected $item_name_plural = 'subscriptions';

	/**
	 * Callback function for turning IDs into objects
	 *
	 * @since 2.13.0
	 * @access public
	 * @var mixed
	 */
	protected $item_shape = '\\EDD\\Recurring\\Subscriptions\\Subscription';

	/** Cache *****************************************************************/

	/**
	 * Group to cache queries and queried items in.
	 *
	 * @since 2.13.0
	 * @access public
	 * @var string
	 */
	protected $cache_group = 'edd_subscriptions';

	/**
	 * Query the database for subscriptions.
	 *
	 * @since 2.13.3
	 * @param array $args The arguments to pass to the query.
	 * @return array
	 */
	public function query( $args = array() ) {
		$query_clauses = $this->get_query_clauses_filters( $args );
		foreach ( $query_clauses as $filter ) {
			if ( $filter['condition'] ) {
				if ( 'set_null_query' === $filter['callback'] ) {
					unset( $args['price_id'] );
				}
				add_filter( 'edd_subscriptions_query_clauses', array( $this, $filter['callback'] ) );
			}
		}

		$results = parent::query( $args );

		foreach ( $query_clauses as $filter ) {
			remove_filter( 'edd_subscriptions_query_clauses', array( $this, $filter['callback'] ) );
		}

		return $results;
	}

	/**
	 * Modify the query to allow us to query for subscriptions with a null price ID.
	 *
	 * @since 2.13.3
	 * @param array $clauses The query clauses.
	 * @return array
	 */
	public function set_null_query( $clauses ) {
		if ( ! empty( $clauses['where'] ) ) {
			$clauses['where'] .= ' AND ';
		}
		$clauses['where'] .= $this->table_alias . '.price_id IS NULL';
		unset( $this->query_vars['price_id'] );

		return $clauses;
	}

	/**
	 * Get the array of possible query clause filters.
	 *
	 * @since 2.13.3
	 * @param array $query The query arguments.
	 * @return array
	 */
	private function get_query_clauses_filters( $query ) {
		return array(
			array(
				'condition' => array_key_exists( 'price_id', $query ) && ( is_null( $query['price_id'] ) || false === $query['price_id'] ),
				'callback'  => 'set_null_query',
			),
		);
	}
}
