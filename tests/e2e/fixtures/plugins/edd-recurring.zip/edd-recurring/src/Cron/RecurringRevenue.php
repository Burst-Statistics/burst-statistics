<?php
/**
 * Recurring Revenue Cron Handler
 *
 * @package EDD\Recurring\Cron
 * @copyright   Copyright (c) 2025, Sandhills Development, LLC
 * @license     https://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       2.13.2
 */

namespace EDD\Recurring\Cron;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

use EDD\Recurring\Admin\Reports\RecurringRevenue as Report;

/**
 * Recurring Revenue Cron Handler
 *
 * @since 2.13.2
 */
class RecurringRevenue {

	/**
	 * The hook name.
	 *
	 * @var string
	 */
	private static $hook = 'edd_recurring_recalculate_revenue';

	/**
	 * Calculate recurring revenue in the background.
	 *
	 * @since 2.13.2
	 */
	public static function calculate_recurring_revenue() {
		// Set time limit of 5 minutes for background processing.
		set_time_limit( 300 );

		try {
			// Calculate MRR and cache it.
			$mrr = Report::calculate_mrr();
			Report::set_cached_data( Report::MRR_OPTION_NAME, $mrr );

			// Calculate ARR and cache it.
			$arr = Report::calculate_arr();
			Report::set_cached_data( Report::ARR_OPTION_NAME, $arr );

			// Log success.
			edd_debug_log( 'EDD Recurring: Successfully calculated and cached recurring revenue data.' );

		} catch ( \Exception $e ) {
			// Log error.
			edd_debug_log( 'EDD Recurring: Error calculating recurring revenue: ' . $e->getMessage() );
		}
	}
}
