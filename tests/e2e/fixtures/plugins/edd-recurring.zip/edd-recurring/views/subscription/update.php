<?php
/**
 * The subscription update view.
 *
 * @package EDD\Recurring
 * @since 2.13.0
 * @var \EDD_Subscription $subscription The subscription object.
 */

if ( ! is_user_logged_in() ) {
	return;
}

// Get subscription.
$subscriber      = new EDD_Recurring_Subscriber( get_current_user_id(), true );
$subscription_id = filter_input( INPUT_GET, 'subscription_id', FILTER_SANITIZE_NUMBER_INT );
$subscription    = new EDD_Subscription( $subscription_id );

edd_print_errors();

if ( empty( $subscription->id ) || $subscription->customer_id != $subscriber->id ) {
	return;
}
if ( empty( $action_url ) ) {
	$action_url = remove_query_arg( array( 'subscription_id', 'view_transactions' ), edd_get_current_page_url() );
}

include 'actions.php';
?>
<h3>
	<?php
	$price_id = is_numeric( $subscription->price_id ) ? $subscription->price_id : null;
	printf(
		/* translators: %s: download title */
		wp_kses_post( __( 'Update payment method for <em>%s</em>', 'edd-recurring' ) ),
		esc_html( edd_get_download_name( $subscription->product_id, $price_id ) )
	);
	?>
</h3>
<form action="<?php echo esc_url( $action_url ); ?>" id="edd-recurring-form" method="POST">
	<input name="edd-recurring-update-gateway" type="hidden" value="<?php echo esc_attr( $subscription->gateway ); ?>" />
	<?php
	wp_nonce_field( 'update-payment', 'edd_recurring_update_nonce' );

	do_action( 'edd_recurring_before_update', $subscription_id );
	do_action( 'edd_recurring_update_payment_form', $subscription );
	do_action( 'edd_recurring_after_update', $subscription_id );
	?>

	<input type="hidden" name="edd_action" value="recurring_update_payment" />
	<input type="hidden" name="subscription_id" value="<?php echo absint( $subscription->id ); ?>" />
	<input type="hidden" name="redirect" value="<?php echo esc_url( $action_url ); ?>" />
	<input type="submit" name="edd-recurring-update-submit" id="edd-recurring-update-submit" value="<?php echo esc_attr( __( 'Update Payment Method', 'edd-recurring' ) ); ?>" />
</form>
