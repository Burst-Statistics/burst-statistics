<?php
/**
 *  EDD Template File for the Subscriptions section of [edd_receipt]
 *
 * @description: Place this template file within your theme directory under /my-theme/edd_templates/
 *
 * @copyright  : http://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since      : 2.4
 */

global $edd_receipt_args;

$deprecated_payment_hooks = has_action( 'edd_subscription_receipt_before_table' ) || has_action( 'edd_subscription_receipt_after_table' );

/** @var \EDD\Orders\Order $order */
$order = ! empty( $args['order'] ) ? $args['order'] : edd_get_order( $edd_receipt_args['id'] );

if ( $deprecated_payment_hooks ) {
	_edd_deprecated_hook( 'edd_subscription_receipt_before_table', '2.13.5', 'edd_order_subscription_receipt_before_table', 'Note: The replacement hook uses the EDD order objects, instead of payment objects. Developers will need to make adjustments accordingly.' );
	_edd_deprecated_hook( 'edd_subscription_receipt_after_table', '2.13.5', 'edd_order_subscription_receipt_after_table', 'Note: The replacement hook uses the EDD order objects, instead of payment objects. Developers will need to make adjustments accordingly.' );
	// drop deprecated warnings if we're using the deprecated hooks
	$payment = edd_get_payment( $order->id );
}

/** @var \EDD\Recurring\Subscriptions\Subscription[] $subscriptions */
$subscriptions = edd_recurring_get_subscriptions(
	array(
		'parent_payment_id' => $order->id,
		'order'             => 'ASC',
	)
);

// Sanity check: ensure this is a subscription download
if ( empty( $subscriptions ) ) {
	return;
}
?>

<h3><?php esc_html_e( 'Subscription Details', 'edd-recurring' ); ?></h3>

<?php
if ( $deprecated_payment_hooks ) {
	do_action( 'edd_subscription_receipt_before_table', $payment );
}

/**
 * Fires before the subscription details table is displayed.
 *
 * @param \EDD\Orders\Order $order The order object.
 * @param \EDD\Recurring\Subscriptions\Subscription[] $subscriptions Array of subscriptions associated with the order.
 *
 * @since 2.13.5
 */
do_action( 'edd_order_subscription_receipt_before_table', $order, $subscriptions );
?>
<table id="edd_subscription_receipt">
	<thead>
	<tr>
		<?php do_action( 'edd_subscription_receipt_header_before' ); ?>
		<th><?php _e( 'Subscription', 'edd-recurring' ); ?></th>
		<th><?php _e( 'Renewal Date', 'edd-recurring' ); ?></th>
		<th><?php _e( 'Initial Amount', 'edd-recurring' ); ?></th>
		<th><?php _e( 'Times Billed', 'edd-recurring' ); ?></th>
		<th><?php _e( 'Status', 'edd-recurring' ); ?></th>
		<?php do_action( 'edd_subscription_receipt_header_after' ); ?>
	</tr>
	</thead>
	<tbody>
	<?php
	foreach ( $subscriptions as $subscription ) :
		// Set vars
		$title        = get_the_title( $subscription->product_id );
		$renewal_date = ! empty( $subscription->expiration ) ? date_i18n( get_option( 'date_format' ), strtotime( $subscription->expiration ) ) : __( 'N/A', 'edd-recurring' );
		$frequency    = EDD_Recurring()->get_pretty_subscription_frequency( $subscription->period );
		?>
		<tr>
			<td>
				<span class="edd_subscription_name"><?php echo $title; ?></span><br/>
				<span class="edd_subscription_billing_cycle">
					<?php echo edd_currency_filter( edd_format_amount( $subscription->recurring_amount ), $order->currency ) . ' / ' . $frequency; ?>
				</span>
			</td>
			<td>
				<?php if ( 'trialling' === $subscription->status ) : ?>
					<?php _e( 'Trialling Until:', 'edd-recurring' ); ?>
				<?php endif; ?>
				<span class="edd_subscription_renewal_date"><?php echo $renewal_date; ?></span>
			</td>
			<td>
				<span class="edd_subscription_initial_amount">
					<?php echo edd_currency_filter( edd_format_amount( $subscription->initial_amount ), $order->currency ); ?>
				</span>
			</td>
			<td>
				<span class="edd_subscription_times_billed">
					<?php echo $subscription->get_times_billed() . ' / ' . ( ( $subscription->bill_times == 0 ) ? __( 'Until cancelled', 'edd-recurring' ) : $subscription->bill_times ); ?>
				</span>
			</td>
			<td>
				<span class="edd_subscription_status">
					<?php echo $subscription->get_status_label(); ?>
				</span>
			</td>
		</tr>
	<?php endforeach; ?>
	</tbody>
</table>
<?php
if ( $deprecated_payment_hooks ) {
	do_action( 'edd_subscription_receipt_after_table', $payment );
}

/**
 * Fires after the subscription details table is displayed.
 *
 * @param \EDD\Orders\Order $order The order object.
 * @param \EDD\Recurring\Subscriptions\Subscription[] $subscriptions Array of subscriptions associated with the order.
 *
 * @since 2.13.5
 */
do_action( 'edd_order_subscription_receipt_after_table', $order, $subscriptions );
