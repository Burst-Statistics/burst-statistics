document.addEventListener( 'DOMContentLoaded', function () {
	const eddRecurringStripePEVars = window.eddRecurringStripePaymentElementsVars || {};
	const {
		ajax_url,
		revert_pm_nonce,
		subscription_id,
		currency,
		customer_email,
		customer_name,
		i18n,
	} = eddRecurringStripePEVars;

	const eddStripeVars = window.edd_stripe_vars || {};
	const coreElementsCustomizations = eddStripeVars.elementsCustomizations || {};

	const eddStripeGlobal = window.eddStripe;
	const api = eddStripeGlobal ? eddStripeGlobal._plugin : null;

	const paymentElementMount = document.getElementById( 'edd-recurring-stripe-payment-element' );
	const isDebugMode = typeof eddStripeVars !== 'undefined' && 'true' === eddStripeVars.debuggingEnabled;

	if ( !eddStripeVars.publishable_key || !paymentElementMount || !currency || !i18n ) {
		return;
	}

	if ( !api ) {
		handleError( i18n.payment_system_unavailable );
		return;
	}

	const stripe = Stripe( eddStripeVars.publishable_key );

	// Construct appearance options from core EDD Stripe vars
	const appearanceRules = ( coreElementsCustomizations.rules && typeof coreElementsCustomizations.rules === 'object' && !Array.isArray( coreElementsCustomizations.rules ) )
		? coreElementsCustomizations.rules
		: {};

	const appearanceVariables = ( coreElementsCustomizations.variables && typeof coreElementsCustomizations.variables === 'object' && !Array.isArray( coreElementsCustomizations.variables ) )
		? coreElementsCustomizations.variables
		: {};

	const appearance = {
		theme: coreElementsCustomizations.theme || 'stripe',
		variables: appearanceVariables,
		rules: appearanceRules,
		labels: coreElementsCustomizations.labels || 'above',
	};

	const elementGroupOptions = {
		mode: 'setup',
		currency: currency.toLowerCase(),
		paymentMethodCreation: 'manual',
		appearance: appearance,
		fonts: coreElementsCustomizations.fonts || [],
		paymentMethodTypes: [ 'card' ],
	};

	const elements = stripe.elements( elementGroupOptions );

	const coreFieldsConfig = coreElementsCustomizations.fields || {};

	const paymentElementCreateOptions = {
		layout: coreElementsCustomizations.layout || { type: 'tabs', defaultCollapsed: false },
		wallets: coreElementsCustomizations.wallets || { applePay: 'auto', googlePay: 'auto' },
		terms: coreElementsCustomizations.terms || null,
		business: {
			name: eddStripeVars.store_name,
		},
		defaultValues: {
			billingDetails: {
				email: customer_email,
				name: customer_name,
			}
		},
		fields: {
			...coreFieldsConfig,
			billingDetails: {
				...( coreFieldsConfig.billingDetails || {} ),
				address: 'auto',
				name: 'auto',
				email: 'auto',
				phone: 'auto'
			}
		}
	};

	const paymentElement = elements.create( 'payment', paymentElementCreateOptions );
	paymentElement.mount( paymentElementMount );

	const form = document.getElementById( 'edd-recurring-form' );
	const submitButton = form ? form.querySelector( 'input[type="submit"]' ) : null;
	const errorContainer = document.getElementById( 'edd-recurring-stripe-payment-error' );

	if ( !form || !submitButton || !errorContainer ) {
		return;
	}

	const handleSubmit = async function ( event ) {
		if ( paymentElementMount.offsetParent === null ) {
			return;
		}

		event.preventDefault();
		setLoading( true );
		clearErrors();

		// Retrieve the paymentIntentId from the hidden input early, if it exists.
		const paymentIntentIdElement = document.querySelector( 'input[name="edd_recurring_stripe_payment_intent"]' );
		const paymentIntentIdValue = paymentIntentIdElement ? paymentIntentIdElement.value : null;

		try {
			const { error: submitError } = await elements.submit();
			if ( submitError ) {
				handleError( submitError.message );
				setLoading( false );
				return;
			}

			const { paymentMethod, error: createPMError } = await stripe.createPaymentMethod( {
				elements,
				params: {
					billing_details: {
						email: customer_email,
						name: customer_name,
					}
				}
			} );

			if ( createPMError ) {
				handleError( createPMError.message );
				setLoading( false );
				return;
			}

			if ( paymentMethod ) {

				// Get the nonce from the hidden field for BOTH AJAX calls now, as per Loader.php verification.
				const nonceElement = document.getElementById( 'edd_recurring_update_nonce' );
				if ( !nonceElement ) {
					handleError( i18n.session_expired_refresh );
					setLoading( false );
					return;
				}
				const nonceForAjax = nonceElement.value;

				const formData = new URLSearchParams();
				formData.append( 'action', 'edd_recurring_update_pm_elements' );
				formData.append( 'subscription_id', subscription_id );
				formData.append( 'payment_method_id', paymentMethod.id );
				formData.append( 'nonce', nonceForAjax ); // Use nonce from the hidden field
				formData.append( 'payment_method_exists', 'false' );

				// Include update token if available (for non-logged-in users)
				const updateTokenElement = document.querySelector( '[name="update_token"]' );
				if ( updateTokenElement && updateTokenElement.value ) {
					formData.append( 'update_token', updateTokenElement.value );
				}

				fetch( ajax_url, {
					method: 'POST',
					headers: {
						'Content-Type': 'application/x-www-form-urlencoded',
					},
					body: formData,
				} )
					.then( response => response.json() )
					.then( async response => {
						if ( response.success ) {
							const originalStripePM = response.data.original_payment_method_id;

							if ( response.data.setup_intent && response.data.setup_intent.client_secret ) {
								const { error: confirmSetupError, setupIntent } = await stripe.confirmSetup( {
									elements,
									clientSecret: response.data.setup_intent.client_secret,
									confirmParams: {
										return_url: window.location.href,
									},
									redirect: 'if_required'
								} );

								if ( confirmSetupError ) {
									handleError( `${ i18n.payment_method_confirmation_failed } ${ confirmSetupError.message }` );
									await revertPaymentMethod( originalStripePM );
								} else if ( setupIntent && setupIntent.status === 'succeeded' ) {

									// Attempt to pay outstanding invoice if one exists.
									if ( paymentIntentIdValue ) {
										try {
											const originalPaymentIntent = await retrievePaymentIntent( paymentIntentIdValue );
											if ( originalPaymentIntent && originalPaymentIntent.client_secret ) {
												if ( isDebugMode ) {
													console.log( 'EDD Recurring Stripe PE: Attempting to confirm payment for outstanding invoice (after SI).' );
													console.log( 'PM ID:', paymentMethod.id, 'PM Type:', paymentMethod.type );
													console.log( 'PI method types:', originalPaymentIntent.payment_method_types );
												}
												const { error: confirmPaymentError } = await stripe.confirmPayment( {
													clientSecret: originalPaymentIntent.client_secret,
													confirmParams: {
														return_url: `${ window.location.href.split( '#' )[ 0 ] }#payment-attempted`,
														payment_method: paymentMethod.id,
													},
													redirect: 'if_required'
												} );
												if ( confirmPaymentError ) {
													const errorMsg = `${ i18n.outstanding_invoice_payment_failed } ${ confirmPaymentError.message } ${ i18n.payment_method_updated_success }`;
													handleError( errorMsg, true );
													if ( isDebugMode ) {
														console.error( 'EDD Recurring Stripe PE: Error confirming payment for outstanding invoice (after SI):', confirmPaymentError );
														console.error( 'Payment method type:', paymentMethod.type );
														console.error( 'Payment intent supported types:', originalPaymentIntent.payment_method_types );
													}
												}
											} else {
												if ( isDebugMode ) console.warn( 'EDD Recurring Stripe PE: Could not retrieve outstanding Payment Intent or its client_secret (after SI).' );
											}
										} catch ( retrieveError ) {
											handleError( `${ i18n.invoice_details_error_setup } ${ retrieveError.message }`, true );
											setLoading( false );
											return;
										}
									}
									await triggerFinalUpdate( subscription_id, paymentMethod.id );
								} else {
									handleError( `${ i18n.payment_confirmation_incomplete } ${ setupIntent ? setupIntent.status : i18n.status_unknown }.` );
									await revertPaymentMethod( originalStripePM );
								}
							} else {
								// Attempt to pay outstanding invoice if one exists
								if ( paymentIntentIdValue ) {
									try {
										const originalPaymentIntent = await retrievePaymentIntent( paymentIntentIdValue );
										if ( originalPaymentIntent && originalPaymentIntent.client_secret ) {
											if ( isDebugMode ) {
												console.log( 'EDD Recurring Stripe PE: Attempting to confirm payment for outstanding invoice (no SI).' );
												console.log( 'PM ID:', paymentMethod.id, 'PM Type:', paymentMethod.type );
												console.log( 'PI method types:', originalPaymentIntent.payment_method_types );
											}
											const { error: confirmPaymentError } = await stripe.confirmPayment( {
												clientSecret: originalPaymentIntent.client_secret,
												confirmParams: {
													return_url: `${ window.location.href.split( '#' )[ 0 ] }#payment-attempted`,
													payment_method: paymentMethod.id,
												},
												redirect: 'if_required'
											} );
											if ( confirmPaymentError ) {
												const errorMsg = `${ i18n.outstanding_invoice_payment_failed } ${ confirmPaymentError.message } ${ i18n.payment_method_updated_success }`;
												handleError( errorMsg, true );
												if ( isDebugMode ) {
													console.error( 'EDD Recurring Stripe PE: Error confirming payment for outstanding invoice (no SI):', confirmPaymentError );
													console.error( 'Payment method type:', paymentMethod.type );
													console.error( 'Payment intent supported types:', originalPaymentIntent.payment_method_types );
												}
											}
										}
									} catch ( retrieveError ) {
										handleError( `${ i18n.invoice_details_error_direct } ${ retrieveError.message }`, true );
										setLoading( false );
										return;
									}
								}
								await triggerFinalUpdate( subscription_id, paymentMethod.id );
							}
						} else {
							handleError( response.data.message || i18n.payment_method_update_failed );
							setLoading( false );
						}
					} )
					.catch( ( error ) => {
						handleError( i18n.payment_update_general_error );
						setLoading( false );
					} );
			} else {
				setLoading( false );
				handleError( i18n.payment_details_invalid );
			}
		} catch ( e ) {
			handleError( `${ i18n.processing_error_occurred } ${ e.message }` );
			setLoading( false );
		}
	};

	form.addEventListener( 'submit', handleSubmit );

	async function retrievePaymentIntent ( paymentIntentId ) {
		const nonceElement = document.getElementById( 'edd_recurring_update_nonce' );
		if ( !nonceElement ) {
			throw new Error( i18n.session_expired_refresh );
		}
		const nonce = nonceElement.value;

		const formData = new URLSearchParams();
		formData.append( 'action', 'edd_recurring_get_payment_intent' );
		formData.append( 'intent_id', paymentIntentId );
		formData.append( 'nonce', nonce );

		// Include update token if available (for non-logged-in users)
		const updateTokenElement = document.querySelector( '[name="update_token"]' );
		if ( updateTokenElement && updateTokenElement.value ) {
			formData.append( 'update_token', updateTokenElement.value );
		}

		const response = await fetch( ajax_url, {
			method: 'POST',
			headers: {
				'Content-Type': 'application/x-www-form-urlencoded',
			},
			body: formData,
		} );

		const result = await response.json();
		if ( result.success ) {
			return result.data.intent;
		} else {
			throw new Error( result.data.message || i18n.payment_method_update_failed );
		}
	}

	async function triggerFinalUpdate ( stripeSubscriptionId, stripePaymentMethodId ) {
		const nonceElement = document.getElementById( 'edd_recurring_update_nonce' );
		if ( !nonceElement ) {
			handleError( i18n.update_process_incomplete );
			setLoading( false );
			return;
		}
		const nonce = nonceElement.value;

		const requestData = {
			subscription_id: stripeSubscriptionId,
			payment_method_id: stripePaymentMethodId,
			payment_method_exists: 'true',
			nonce: nonce,
		};

		// Include update token if available (for non-logged-in users)
		const updateTokenElement = document.querySelector( '[name="update_token"]' );
		if ( updateTokenElement && updateTokenElement.value ) {
			requestData.update_token = updateTokenElement.value;
		}

		try {
			await Promise.resolve( api.apiRequest( 'edd_recurring_update_subscription_payment_method', requestData ) );

			form.removeEventListener( 'submit', handleSubmit );
			form.submit();

		} catch ( error ) {
			let message = i18n.update_finalization_failed;
			if ( error && error.message ) {
				message = error.message;
			} else if ( typeof error === 'string' ) {
				message = error;
			}
			handleError( message );
			setLoading( false );
		}
	}

	async function revertPaymentMethod ( paymentMethodToRevertTo ) {
		if ( !paymentMethodToRevertTo ) {
			handleError( i18n.payment_method_revert_failed, true );
			setLoading( false );
			return;
		}

		try {
			// Use the same API request pattern as card elements for consistency
			await Promise.resolve( api.apiRequest( 'edd_recurring_revert_failed_pm_update', {
				subscription_id: subscription_id,
				original_payment_method_id: paymentMethodToRevertTo,
				nonce: revert_pm_nonce,
			} ) );
		} catch ( error ) {
			if ( error && error.message ) {
				handleError( `${ i18n.previous_payment_method_restore_failed } ${ error.message } ${ i18n.contact_support_message }`, true );
			} else {
				handleError( i18n.payment_method_restore_error, true );
			}
		} finally {
			setLoading( false );
		}
	}

	function setLoading ( isLoading ) {
		if ( !form || !submitButton ) return;

		submitButton.disabled = isLoading;

		const existingSpinner = form.querySelector( '.edd-recurring-pm-spinner' );
		if ( existingSpinner ) {
			existingSpinner.remove();
		}

		if ( isLoading ) {
			const spinner = document.createElement( 'span' );
			spinner.classList.add( 'edd-loading' );
			spinner.classList.add( 'edd-loading-ajax' );
			spinner.classList.add( 'edd-recurring-pm-spinner' );
			form.appendChild( spinner );
		}
	}

	function clearErrors () {
		errorContainer.innerHTML = '';
		errorContainer.style.display = 'none';
	}

	function handleError ( message, isAdditionalInfo = false ) {
		const p = document.createElement( 'p' );
		p.textContent = message;
		if ( !isAdditionalInfo ) {
			errorContainer.innerHTML = '';
		}
		errorContainer.appendChild( p );
		errorContainer.style.display = 'block';
	}
} );
