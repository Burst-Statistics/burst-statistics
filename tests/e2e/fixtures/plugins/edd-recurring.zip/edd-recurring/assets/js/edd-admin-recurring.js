/**
 * EDD Admin Recurring JS
 *
 * @description: JS for EDD's Recurring Add-on applied in admin download (single download post) screen
 *
 */
var EDD_Recurring_Vars;

jQuery( document ).ready( function ( $ ) {

	var EDD_Recurring = {
		init: function () {

			//Recurring select field conditionals
			this.variable_pricing();
			this.recurring_select();
			this.custom_price_toggle();
			this.free_trial_toggle();
			this.variable_price_free_trial_toggle();
			this.validate_times();
			this.edit_product_id();
			this.edit_subscription_fields();
			this.renewal_form_submit();
			this.new();
			this.delete();
			this.cancel();
			//Ensure when new rows are added recurring fields respect recurring select option
			$( '.edd_add_repeatable' ).on( 'click', this.recurring_select() );

			// Toggle display of Billing Cycle details
			$( '.edd-item-toggle-next-hidden-row' ).on( 'click', function(e) {
				e.preventDefault();
				$( this ).next( '.edd-item-hidden-row' ).slideToggle();
			});

		},

		/**
		 * Prevent double submission and show spinner when manually adding a renewal payment.
		 */
		renewal_form_submit: function () {
			// Function to check if amount field is valid and toggle button state
			const validateAmount = function( $form ) {
				const $amountField = $form.find( '#edd_recurring_amount' );
				const $buttons = $form.find( 'input[type="submit"]' );
				const amount = $amountField.val().trim();

				if ( amount === '' || parseFloat( amount ) < 0 ) {
					$buttons.prop( 'disabled', true ).addClass( 'disabled' );
				} else {
					$buttons.prop( 'disabled', false ).removeClass( 'disabled' );
				}
			};

			// Initial validation on page load
			const $form = $( '#edd-sub-add-renewal' );
			if ( $form.length ) {
				validateAmount( $form );
			}

			// Validate on amount field change
			$( document ).on( 'input change', '#edd_recurring_amount', function() {
				validateAmount( $( this ).closest( 'form' ) );
			} );

			$( document ).on( 'submit', '#edd-sub-add-renewal', function () {
				const $form    = $( this );
				const $buttons = $form.find( 'input[type="submit"]' );

				// Guard: if already submitted, block subsequent submits
				if ( $form.data( 'submitted' ) ) {
					return false;
				}
				$form.data( 'submitted', true );

				// Preserve which button was clicked before disabling
				const clickedButton = document.activeElement;
				if ( clickedButton && clickedButton.name && $buttons.is( clickedButton ) ) {
					$( '<input>' ).attr( {
						type: 'hidden',
						name: clickedButton.name,
						value: clickedButton.value
					} ).appendTo( $form );
				}

				// Disable both submit buttons to prevent double clicks
				$buttons.prop( 'disabled', true ).addClass( 'disabled' );

				// Activate existing spinner and move it before the buttons
				const $spinner = $form.find( '.edd-recurring-add-renewal-actions .spinner' );
				$spinner.addClass( 'is-active' ).css( 'visibility', 'visible' );

				// Allow the form to submit normally; the page will reload on success
				return true;
			} );
		},

		/**
		 * Toggle the single recurring fields when the variable pricing option changes.
		 */
		variable_pricing: function () {
			$( 'body' ).on( 'change', '#edd_variable_pricing:not(.edd-requirement)', function () {
				$( '.edd-recurring-single' ).toggle( !$( this ).is( ':checked' ) );
			} );
		},

		/**
		 * Recurring Select
		 * @description: Ensures that the "period", "times", and "signup fees" fields are disabled/enabled according to the "Recurring" selection yes/no option
		 */
		recurring_select: function () {
			$( 'body' ).on( 'change', '.edd-recurring-enabled select, select#edd_recurring, select#edd_custom_recurring', function () {
				var $this     = $( this ),
					fields    = $this.parents( '.edd-recurring-single' ).find( 'select,input' ),
					val       = $( 'option:selected', this ).val(),
					signupFee = $this.parents( '.edd-recurring-single' ).find( '.edd-recurring-fee' );

				if( ! $this.is(':visible') ) {
					return;
				}


				// Is this a variable select? Check parent
				if ( $this.parents( '.edd_variable_prices_wrapper' ).length > 0 ) {

					const row = $this.parents( '.edd_repeatable_row' );
					fields = row.find( '.times input, .edd-recurring-period select, .edd-recurring-free-trial input, .edd-recurring-free-trial select, .signup_fee input' );
					signupFee = row.find( '.edd-recurring-fee' );

				} else if( 'edd_custom_recurring' == $(this).attr('id') ) {

					const row = $( '.edd_recurring_custom_wrap' )
					fields = row.find( '.times input, #edd_custom_period, .signup_fee input' );
					signupFee = row.find( '.edd-recurring-fee' );

					if( $('#edd_recurring_free_trial').is(':checked') ) {
						$('.signup_fee input, #edd_signup_fee').val(0).attr('disabled', true );
					}
				}

				// Enable/disable fields based on user selection
				if ( val == 'no' ) {
					fields.attr( 'disabled', true );
					signupFee.addClass( 'edd-disabled' );
				} else {
					fields.attr( 'disabled', false );
					signupFee.removeClass( 'edd-disabled' );
				}

				$this.attr( 'disabled', false );

			} );

			// Kick it off
			$( '.edd-recurring-enabled select, select#edd_recurring, select#edd_custom_recurring' ).trigger( 'change' );

			$( 'input[name$="[times]"], input[name$=times]' ).on( 'change', function () {
				$( this ).next( '.times' ).text( $( this ).val() == 1 ? EDD_Recurring_Vars.singular : EDD_Recurring_Vars.plural );
			} );
		},

		/**
		 * Custom Price toggle
		 * @description: Hides / shows recurring options for a custom price
		 */
		custom_price_toggle: function () {
			$( 'body' ).on( 'click', '#edd_cp_custom_pricing:not(.edd-requirement)', function() {
				$( '.edd_recurring_custom_wrap' ).toggle();
			} );
		},

		/**
		 * Free trial toggle
		 * @description: Hides / shows recurring options for a free trial
		 */
		free_trial_toggle: function () {
			$('body').on('click', '#edd_recurring_free_trial', function() {
				if( $(this).is(':checked') ) {
					$('#edd_recurring_free_trial_options,#edd-sl-free-trial-length-notice').show();
					$('.signup_fee input, #edd_signup_fee').val(0).attr('disabled', true );
				} else {
					$('.signup_fee input, #edd_signup_fee').attr('disabled', false );
					$('#edd-sl-free-trial-length-notice,#edd_recurring_free_trial_options').hide();
				}
			});

			$('body').on( 'change', '#edd_variable_pricing:not(.edd-requirement)', function() {
				var checked   = $(this).is(':checked');
				var single    = $( '#edd_recurring_free_trial_options_wrap' );
				if ( checked ) {
					single.hide();
				} else {
					single.show();
				}
			});
		},

		variable_price_free_trial_toggle: function () {
			$( 'body' ).on( 'load change', '.trial-quantity', function () {
				var $this  = $( this ),
					fields = $this.parents().siblings( '.signup_fee' ).find( ':input' ),
					val    = $this.val();

				// Enable/disable fields based on user selection
				if ( val > 0 ) {
					fields.attr( 'disabled', true );
				} else {
					fields.attr( 'disabled', false );
				}

				$this.attr( 'disabled', false );
			});
		},

		/**
		 * Validate Times
		 * @description: Used for client side validation of times set for various recurring gateways
		 */
		validate_times: function () {

			var recurring_times = $( '.times' ).find( 'input[type="number"]' );

			//Validate times on times input blur (client side then server side)
			recurring_times.on( 'change', function () {

				var time_val = $( this ).val();
				var is_variable = $( 'input#edd_variable_pricing' ).prop( 'checked' );
				var recurring_option = $( this ).parents( '#edd_regular_price_field' ).find( '[id^=edd_recurring]' ).val();
				if ( is_variable ) {
					recurring_option = $( this ).parents( '.edd_variable_prices_wrapper' ).find( '[id^=edd_recurring]' ).val();
				}

				//Verify this is a recurring download first
				//Sanity check: only validate if recurring is set to Yes
				if ( recurring_option == 'no' ) {
					return false;
				}

				//Check if PayPal Standard is set & Validate times are over 1 - https://github.com/easydigitaldownloads/edd-recurring/issues/58
				if ( typeof EDD_Recurring_Vars.enabled_gateways.paypal !== 'undefined' && (time_val == 1 || time_val >= 53) ) {

					//Alert user of issue
					alert( EDD_Recurring_Vars.invalid_time.paypal );
					//Refocus on the faulty input
					$( this ).focus();

				}

			} );

		},

		edit_subscription_fields: function() {

			// Use event delegation to handle all subscription field edit buttons
			$( document ).on( 'click', '.edd-edit-subscription__field', function( e ) {
				e.preventDefault();

				var $button = $( this );
				var fieldType = $button.data( 'field' );

				if ( ! fieldType ) {
					return;
				}

				// Define field configurations
				var fieldConfigs = {
					'expiration': {
						target: '.edd-sub-expiration',
						type: 'input',
						notice: '#edd-sub-expiration-update-notice'
					},
					'profile-id': {
						target: '.edd-sub-profile-id',
						type: 'input',
						notice: '#edd-sub-profile-id-update-notice'
					},
					'transaction-id': {
						target: '.edd-sub-transaction-id',
						type: 'input'
					},
					'status': {
						target: '.edd-sub-transaction-status',
						type: 'select',
						badge: '.edd-admin-subscription-status-badge'
					},
					'gateway': {
						target: '.edd-sub-gateway',
						type: 'select',
						badge: '#edd-sub-gateway-update-notice'
					}
				};

				var config = fieldConfigs[ fieldType ];
				if ( !config ) {
					return;
				}

				var $field = $(	config.target	);
				var $input = config.type === 'input' ? $field.filter( 'input' ) : $field.filter( 'select' );

				// Handle edit/cancel toggle
				if ( $button.text() === EDD_Recurring_Vars.action_edit ) {
					// Preserve current value
					$button.data( 'current-value', $input.val() );
					// Update text to 'cancel'
					$button.text( EDD_Recurring_Vars.action_cancel );
				} else {
					// User clicked cancel, return previous value
					$input.val( $button.data( 'current-value' ) );
					// Update button text back to 'edit'
					$button.text( EDD_Recurring_Vars.action_edit );
				}

				// Toggle field visibility
				$field.toggle();

				// Handle additional elements
				if ( config.badge ) {
					$( config.badge ).toggle();
				}

				if ( config.notice ) {
					$( config.notice ).slideToggle();
				}
			});
		},

		edit_product_id: function() {

			$('.edd-sub-product-id').on('change', function(e) {
				e.preventDefault();

				$('#edd-sub-product-update-notice').slideDown();
			});

		},

		new: function() {

			$( '.edd-recurring-new-customer, .edd-recurring-select-customer, .edd-recurring-change-customer' ).on( 'click', function ( e ) {
				e.preventDefault();

				// Creation of new customer.
				if ( $( this ).hasClass( 'edd-recurring-new-customer' ) ) {
					$( '.edd-recurring-customer-wrap-existing' ).hide().find( 'select' ).prop( 'required', false );
					$( '.edd-recurring-customer-wrap-new' ).show().find( 'input' ).prop( 'required', true );
					window.edd_recurring_new_customer_mode = 'new';
				// Select existing customer.
				} else if ( $( this ).hasClass( 'edd-recurring-select-customer' ) ) {
					$( '.edd-recurring-customer-wrap-new' ).hide().find( 'input' ).prop( 'required', false );
					$( '.edd-recurring-customer-wrap-existing' ).show().find( 'select' ).prop( 'required', true );
					window.edd_recurring_new_customer_mode = 'existing';
				// Change selected customer.
				} else if ( $( this ).hasClass( 'edd-recurring-change-customer' ) ) {
					$( '.edd-recurring-selected-customer' ).hide();
					$( '.subscription-actions' ).show();
					$( '.edd-recurring-subscription__reveal' ).slideUp();
					window.edd_recurring_new_customer_mode = false;
				}

				$( '.edd-recurring-subscription__customer' ).find( 'select,input' ).val( '' );
				$( '.edd-recurring-subscription__customer .chosen-single span' ).empty();
				$( '.edd-recurring-subscription__customer:visible' ).find( 'select,input' ).focus();
			});

			$( '.edd-recurring-confirm-customer' ).on( 'click', function ( e ) {
				e.preventDefault();

				var customer_details = '';
				if ( 'new' == window.edd_recurring_new_customer_mode ) {
					if( ! $( '#edd_recurring_customer_email' )[0].reportValidity() )  {
						return false;
					}
					customer_details = $( 'input#edd_recurring_customer_email' ).val();
				} else {
					if( ! parseInt( $( '#edd_recurring_customer_id' ).val() ) ) {
						return false;
					}
					customer_details = $( '.edd-recurring-subscription__customer .chosen-single span' ).text();
				}
				$( '.edd-recurring-selected-customer-details' ).html( customer_details );
				$( '.edd-recurring-selected-customer' ).show();
				$( '.subscription-actions' ).hide();

				$( '.edd-recurring-customer-wrap-existing, .edd-recurring-customer-wrap-new' ).hide();
				$( '.edd-recurring-subscription__reveal' ).slideDown();
			} );

			$( '#edd_recurring_customer_email' ).on( 'keyup', function( e ) {
				e.preventDefault();
				if ( 13 === e.keyCode  ) {
					$( '.edd-recurring-confirm-customer' ).trigger( 'click' );
				}
			});

			$('.edd-recurring-select-payment').on('change', function(e) {
				$('.edd-recurring-payment-id').toggle().val( '' );
				$('.edd-recurring-gateway-wrap').toggle();
			});

			$('#edd-recurring-new-subscription-wrap').on('change', 'select#products', function() {

				var $this = $(this), download_id = $this.val();

				if( parseInt( download_id ) > 0 ) {

					var postData = {
						action : 'edd_check_for_download_price_variations',
						download_id: download_id
					};

					$.ajax({
						type: "POST",
						data: postData,
						url: ajaxurl,
						success: function (prices) {

							$this.parent().find( '.edd-recurring-price-option-wrap' ).html( prices );

						}

					}).fail(function (data) {
						if ( window.console && window.console.log ) {
							console.log( data );
						}
					});
				}
			} );

			$( '#edd-recurring-new-subscription-wrap' ).on( 'change', 'select#products, select[name="edd_price_option"]', function () {
				$.ajax( {
					type: 'GET',
					data: {
						action: 'edd_recurring_update_product_details',
						download_id: $( 'select#products' ).val(),
						price_id: $( 'select[name="edd_price_option"]' ).length ? $( 'select[name="edd_price_option"]' ).val() : null,
					},
					url: ajaxurl,
					success: function ( response ) {
						var price = '',
							recurring_amount = '',
							period = 'day';
						if ( response.data ) {
							price = response.data.price;
							recurring_amount = response.data.recurring_amount;
							period = response.data.period;
						}
						$( '#edd_recurring_initial_amount' ).val( price );
						$( '#edd_recurring_recurring_amount' ).val( recurring_amount );
						$( '#edd_recurring_period' ).val( period );
					}
				} );
			} );

		},

		delete: function() {

			$('.edd-delete-subscription').on('click', function(e) {

				if( confirm( EDD_Recurring_Vars.delete_subscription ) ) {
					return true;
				}

				return false;
			});

		},

		cancel: function() {

			$('.edd-cancel-subscription').on('click', function(e) {

				if( confirm( EDD_Recurring_Vars.cancel_subscription ) ) {
					return true;
				}

				return false;
			});

		}

	};

	EDD_Recurring.init();

} );
