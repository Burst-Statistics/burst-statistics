<?php
/**
 * Deprecated functions.
 *
 * @since 2.11.8
 */

defined( 'ABSPATH' ) || exit;

/**
 * Update customer ID on subscriptions when payment's customer ID is updated
 *
 * @deprecated 2.11.8 in favor of `edd_recurring_update_customer_id_edited_purchase`
 * @access      public
 * @since       2.4.15
 * @return      void
 */
function edd_recurring_update_customer_id_on_payment_update( $meta_id, $object_id, $meta_key, $meta_value ) {

	_edd_deprecated_function( __FUNCTION__, '2.11.8', 'edd_recurring_update_customer_id_edited_purchase' );
	if ( '_edd_payment_customer_id' == $meta_key ) {

		$subs_db = new EDD_Subscriptions_DB();
		$subs    = $subs_db->get_subscriptions( array( 'parent_payment_id' => $object_id ) );
		if ( $subs ) {

			foreach ( $subs as $sub ) {

				$sub->update( array( 'customer_id' => $meta_value ) );

			}
		}
	}
}

/**
 * Display Subscription Payment Notice
 *
 * @description Adds a subscription payment indicator within the single payment view "Update Payment" metabox (top)
 * @since       2.4
 * @deprecated 2.12.0
 *
 * @param $payment_id
 *
 */
function edd_display_subscription_payment_meta( $payment_id ) {

	$is_sub = edd_get_payment_meta( $payment_id, '_edd_subscription_payment' );

	if ( $is_sub ) :
		$subs_db = new EDD_Subscriptions_DB();
		$subs    = $subs_db->get_subscriptions(
			array(
				'parent_payment_id' => $payment_id,
				'order'             => 'ASC',
			)
		);
		?>
		<div id="edd-order-subscriptions" class="postbox">
			<h3 class="hndle">
				<span><?php _e( 'Subscriptions', 'edd-recurring' ); ?></span>
			</h3>
			<div class="inside">

				<?php foreach ( $subs as $sub ) : ?>
					<?php $sub_url = admin_url( 'edit.php?post_type=download&page=edd-subscriptions&id=' . $sub->id ); ?>
					<p>
						<span class="label"><span class="dashicons dashicons-update"></span> <?php printf( __( 'Subscription ID: <a href="%1$s">#%2$d</a>', 'edd_recurring' ), $sub_url, $sub->id ); ?></span> (<?php echo esc_html( $sub->get_status_label() ); ?>)
					</p>
					<?php $payments = $sub->get_child_payments(); ?>
					<?php if ( $payments ) : ?>
						<p><strong><?php _e( 'Associated Payments', 'edd-recurring' ); ?>:</strong></p>
						<ul id="edd-recurring-sub-payments">
						<?php foreach ( $payments as $payment ) : ?>
							<li>
								<span class="howto"><?php echo date_i18n( get_option( 'date_format' ), strtotime( $payment->date ) ); ?></span>
								<a href="<?php echo esc_url( admin_url( 'edit.php?post_type=download&page=edd-payment-history&view=view-order-details&id=' . $payment->ID ) ); ?>">
									<?php echo '#' . $payment->number; ?>
								</a>&nbsp;&ndash;&nbsp;
								<span><?php echo edd_currency_filter( edd_format_amount( $payment->total ) ); ?>&nbsp;&ndash;&nbsp;</span>
								<span><?php echo $payment->status_nicename; ?></span>
							</li>
						<?php endforeach; ?>
						</ul>
					<?php endif; ?>
				<?php endforeach; ?>
			</div>
		</div>
		<?php
	endif;
}

/**
 * Displays an admin notice about PHP version requirements.
 *
 * @since 3.0
 */
function edd_recurring_php_notice() {
	?>
	<div class="notice notice-error">
		<p>
			<?php
			printf(
				/* Translators: %1$s required PHP version; %2$s system PHP version; %3$s opening anchor tag; %4$s closing anchor tag */
				__( 'The Easy Digital Downloads - Recurring Payments plugin requires PHP version %1$s. You are running version %2$s. %3$sLearn more about updating PHP.%4$s', 'edd-recurring' ),
				EDD_RECURRING_MINIMUM_PHP,
				phpversion(),
				'<a href="https://wordpress.org/support/update-php/" target="_blank">',
				'</a>'
			);
			?>
		</p>
	</div>
	<?php
}

/**
 * List subscription (sub) payments of a particular parent payment
 *
 * The parent payment ID is the very first payment made. All payments made after for the profile are sub.
 *
 * @since  1.0
 * @deprecated 2.12.0
 * @param int $payment_id The current payment ID.
 * @return void
 */
function edd_recurring_display_parent_payment( $payment_id = 0 ) {

	$payment = edd_get_payment( $payment_id );
	if ( ! $payment->parent_payment ) {
		return;
	}

	$sub_id = $payment->get_meta( 'subscription_id', true );
	if ( $sub_id ) {
		$sub = new EDD_Subscription( $sub_id );
	} else {
		$subs_db = new EDD_Subscriptions_DB();
		$subs    = $subs_db->get_subscriptions(
			array(
				'parent_payment_id' => $payment->parent_payment,
				'order'             => 'ASC',
			)
		);
		$sub     = reset( $subs );
	}
	if ( ! $sub ) {
		return;
	}
	$parent_url = add_query_arg(
		array(
			'post_type' => 'download',
			'page'      => 'edd-payment-history',
			'view'      => 'view-order-details',
			'id'        => urlencode( $payment->parent_payment ),
		),
		admin_url( 'edit.php' )
	);
	$sub_url    = add_query_arg(
		array(
			'post_type' => 'download',
			'page'      => 'edd-subscriptions',
			'id'        => urlencode( $sub->id ),
		),
		admin_url( 'edit.php' )
	);
	?>
	<div id="edd-order-subscription-payments" class="postbox">
		<h3 class="hndle">
			<span><?php esc_html_e( 'Subscription', 'edd-recurring' ); ?></span>
		</h3>
		<div class="inside">
			<p>
				<span class="label"><span class="dashicons dashicons-update"></span> <?php esc_html_e( 'Subscription ID', 'edd_recurring' ); ?>: <?php printf( '<a href="%s">#%d</a>', esc_url( $sub_url ), (int) $sub->id ); ?></span> (<?php echo esc_html( $sub->get_status_label() ); ?>)
			</p>
			<p><?php esc_html_e( 'Parent Payment', 'edd-recurring' ); ?>: <?php printf( '<a href="%s">%s</a>', esc_url( $parent_url ), esc_html( edd_get_payment_number( $payment->parent_payment ) ) ); ?></p>
		</div><!-- /.inside -->
	</div><!-- /#edd-order-subscription-payments -->
	<?php
}

/**
 * Load the javascript which shows the "cancel subscription" checkbox while refunding a payment.
 * This is being done here instead of through wp_enqueue_scripts because it matches the way the
 * button for "Refund Charge in Stripe" is output. See the function called "edd_stripe_admin_js".
 *
 * @deprecated  2.12.0
 * @since       2.9.3
 * @param       int $payment_id The id of the payment being viewed, and potentially refunded.
 * @return      void
 */
function edd_recurring_cancel_subscription_during_refund_option( $payment_id = 0 ) {

	if ( ! current_user_can( 'edit_shop_payments', $payment_id ) ) {
		return;
	}

	$payment = edd_get_payment( $payment_id );

	$is_sub = edd_get_payment_meta( $payment_id, '_edd_subscription_payment' );
	$subs   = false;

	// If this payment is the parent payment of a subscription.
	if ( $is_sub ) {

		$subs_db = new EDD_Subscriptions_DB();
		$subs    = $subs_db->get_subscriptions(
			array(
				'parent_payment_id' => $payment_id,
				'order'             => 'ASC',
			)
		);

		// If this payment has a parent payment, and is possibly a renewal payment.
	} elseif ( $payment->parent_payment ) {

		// Check if there's a sub ID attached to this payment.
		$subs = $payment->get_meta( 'subscription_id', true );

		// If no subscription was found attached to this payment, try searching subscriptions using the parent payment ID.
		if ( ! $subs ) {
			$subs_db = new EDD_Subscriptions_DB();
			$subs    = $subs_db->get_subscriptions(
				array(
					'parent_payment_id' => $payment->parent_payment,
					'order'             => 'ASC',
				)
			);
		}
	}

	// If there's no subscriptions here, don't output any JS.
	if ( ! $subs ) {
		return;
	}

	wp_enqueue_script( 'jquery' );

	?>
	<script type="text/javascript">
		jQuery(document).ready(function($) {
			$('select[name=edd-payment-status]').change(function() {

				if( 'refunded' == $(this).val() ) {

					var cancel_sub_container = $(this).parent().parent().append( '<div class="edd-recurring-cancel-sub"></div>' );

					cancel_sub_container.append( '<input type="checkbox" id="edd_recurring_cancel_subscription" name="edd_recurring_cancel_subscription" value="1" style="margin-top: 0;" />' );
					cancel_sub_container.append( '<label for="edd_recurring_cancel_subscription"><?php echo esc_js( __( 'Cancel Subscription', 'edd-recurring' ) ); ?></label></div>' );

				} else {

					$('#edd_recurring_cancel_subscription').remove();
					$('label[for="edd_recurring_cancel_subscription"]').remove();

				}

			});
		});
	</script>
	<?php
}

/**
 * Cancel subscription when refunding a payment, if that was selected by the admin.
 *
 * @since       2.9.3
 * @deprecated 2.12.0
 * @param       EDD_Payment $payment The EDD_Payment object being viewed, and potentially refunded.
 * @return      void
 */
function edd_recurring_cancel_subscription_during_refund( $payment ) {

	if ( ! current_user_can( 'manage_subscriptions' ) ) {
		return;
	}

	if ( empty( $_POST['edd_recurring_cancel_subscription'] ) ) {
		return;
	}

	$should_cancel_subscription = apply_filters( 'edd_recurring_should_cancel_subscription', true, $payment->ID );

	if ( false === $should_cancel_subscription ) {
		return;
	}

	$is_sub = edd_get_payment_meta( $payment->ID, '_edd_subscription_payment' );

	// If this payment is the parent payment of a subscription.
	if ( $is_sub ) {

		$subs_db = new EDD_Subscriptions_DB();
		$subs    = $subs_db->get_subscriptions(
			array(
				'parent_payment_id' => $payment->ID,
				'order'             => 'ASC',
			)
		);

		// If there's no subscriptions here, don't do anything here.
		if ( ! $subs ) {
			return;
		}

		// Loop through each subscription in this parent payment, cancelling each one.
		foreach ( $subs as $edd_sub ) {

			$recurring = edd_recurring();
			remove_action( 'edd_subscription_cancelled', array( $recurring::$emails, 'send_subscription_cancelled' ) );
			remove_action( 'edd_subscription_cancelled', array( $recurring::$emails, 'send_subscription_cancelled_admin' ) );
			// Run the cancel method in the EDD_Subscription class. This also cancels the sub at the gateway.
			$edd_sub->cancel();

			/* translators: the subscription ID. */
			$payment->add_note( sprintf( __( 'Subscription %d cancelled because of refund.', 'edd-recurring' ), $edd_sub->id ) );

		}

		// If this payment has a parent payment, and is possibly a renewal payment.
	} elseif ( $payment->parent_payment ) {

		// Check if there's a sub ID attached to this payment.
		$sub_id = $payment->get_meta( 'subscription_id', true );

		// If no subscription was found attached to this payment, try searching subscriptions using the parent payment ID.
		if ( ! $sub_id ) {
			$subs_db = new EDD_Subscriptions_DB();
			$subs    = $subs_db->get_subscriptions(
				array(
					'parent_payment_id' => $payment->parent_payment,
					'order'             => 'ASC',
				)
			);
			$sub     = reset( $subs );
			$sub_id  = $sub->id;
		}

		// If there's really just no subscription here, don't do anything here.
		if ( ! $sub_id ) {
			return;
		}

		$recurring = edd_recurring();
		remove_action( 'edd_subscription_cancelled', array( $recurring::$emails, 'send_subscription_cancelled' ) );
		remove_action( 'edd_subscription_cancelled', array( $recurring::$emails, 'send_subscription_cancelled_admin' ) );

		// Get the EDD Subscription object that we want to cancel.
		$edd_sub = new EDD_Subscription( $sub_id );

		// Run the cancel method in the EDD_Subscription class. This also cancels the sub at the gateway.
		$edd_sub->cancel();

		/* translators: the subscription ID. */
		$payment->add_note( sprintf( __( 'Subscription %d cancelled because of refund.', 'edd-recurring' ), $sub_id ) );
	}
}


/**
 * Set colspan on submit row
 *
 * This is a little hacky, but it's the best way to adjust the colspan on the submit row to make sure it goes full width
 *
 * @since       1.0
 * @deprecated  2.12.1
 * @return      void
 */
function edd_recurring_metabox_colspan() {
	_edd_deprecated_function( __FUNCTION__, '2.12.1' );
}

/**
 * Adds a section for order subscriptions to EDD 3.0.
 *
 * @since 2.12.0
 * @deprecated 2.13.0
 * @param array     $sections
 * @param EDD_Order $order
 * @return array
 */
function edd_recurring_subscription_section( $sections, $order ) {
	if ( ! edd_is_add_order_page() ) {
		$is_parent_order  = edd_get_order_meta( $order->id, '_edd_subscription_payment', true );
		$is_renewal_order = ! empty( $order->parent ) && 'sale' === $order->type;
		if ( $is_parent_order || $is_renewal_order ) {
			$sections[] = array(
				'id'       => 'subscriptions',
				'label'    => __( 'Subscriptions', 'edd-recurring' ),
				'icon'     => 'update',
				'callback' => 'edd_recurring_display_subscription_order_details',
			);
		}
	}

	return $sections;
}

/**
 * Outputs the subscription details in EDD 3.0.
 *
 * @since 2.12.0
 * @deprecated 2.13.0
 * @param EDD_Order $order
 * @return void
 */
function edd_recurring_display_subscription_order_details( $order ) {
	remove_action( 'edd_view_order_details_sidebar_before', 'edd_display_subscription_payment_meta' );
	remove_action( 'edd_view_order_details_sidebar_before', 'edd_recurring_display_parent_payment' );
	$is_parent_order = edd_get_order_meta( $order->id, '_edd_subscription_payment', true );
	$subs_db         = new EDD_Subscriptions_DB();
	if ( $is_parent_order ) {
		$subs = $subs_db->get_subscriptions(
			array(
				'parent_payment_id' => $order->id,
				'order'             => 'ASC',
			)
		);
		foreach ( $subs as $sub ) {
			include 'views/orders/order-details.php';
		}
	} else {
		$sub_id = edd_get_order_meta( $order->id, 'subscription_id', true );
		if ( $sub_id ) {
			$sub = new EDD_Subscription( $sub_id );
		} else {
			$subs = $subs_db->get_subscriptions(
				array(
					'parent_payment_id' => $order->parent,
					'order'             => 'ASC',
				)
			);
			$sub  = reset( $subs );
		}
		include 'views/orders/order-details.php';
	}
}
