<?php
/**
 * @var EDD_Subscription $sub
 */

$link = \EDD\Recurring\Subscriptions\Update\Link::generate_for_subscription( $sub );

// If the link is empty and the requirements are met, just don't display anything, it means it's not supported.
if ( empty( $link ) && \EDD\Recurring\Subscriptions\Update\Link::requirements_met() ) {
	return;
}
?>
<div class="edd-recurring-subscription-section edd-recurring-subscription__info">
	<h2><?php esc_html_e( 'Tools', 'edd-recurring' ); ?></h2>

	<div class="edd-recurring-subscription-table">
		<div class="edd-recurring-subscription-table_column">
			<div class="edd-recurring-subscription-table_column-header"><?php esc_html_e( 'Update Card Link', 'edd-recurring' ); ?></div>
			<div class="edd-recurring-subscription-table_column-content">
				<?php
				if ( empty( $link ) && ! \EDD\Recurring\Subscriptions\Update\Link::requirements_met() ) {
					// Check if the nonces are not defined, if they aren't, then we can display an error to the admin.
					?>
					<div class="notice notice-error edd-notice inline">
						<p>
							<?php
							printf(
								/* translators: 1: Link to the WordPress.org documentation on salts, 2: Closing anchor tag */
								__( 'The update card link cannot be generated because the nonce key and/or salt are not defined. %1$sLearn more%2$s.', 'edd-recurring' ),
								'<a href="https://easydigitaldownloads.com/docs/what-are-wordpress-salts/" target="_blank">',
								'</a>'
							);
							?>
						</p>
					</div>
					<?php
				} else if ( ! empty( $link ) ) {
					$input = new \EDD\HTML\Text(
						array(
							'id'       => 'update-card-link',
							'value'    => $link,
							'class'    => array( 'large-text', 'code' ),
							'disabled' => true,
							'readonly' => true,
						)
					);
					$input->output();
				} else {
					?>
					<div class="notice notice-info edd-notice inline">
						<p>
							<?php
							esc_html_e( 'Unable to generate a secure update link at this time.', 'edd-recurring' );
							?>
						</p>
					</div>
					<?php
				}
				?>
			</div>
		</div>
	</div>

</div> <!-- ends __info !-->
