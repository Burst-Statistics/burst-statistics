<?php

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/*
|--------------------------------------------------------------------------
| Variable Prices
|--------------------------------------------------------------------------
*/


/**
 * Meta box table header
 *
 * @access      public
 * @since       1.0
 * @return      void
 */
function edd_recurring_metabox_head( $download_id ) {
	?>
	<th><?php _e( 'Recurring', 'edd-recurring' ); ?></th>
	<th><?php _e( 'Free Trial', 'edd-recurring' ); ?></th>
	<th><?php _e( 'Period', 'edd-recurring' ); ?></th>
	<th><?php echo _x( 'Times', 'Referring to billing period', 'edd-recurring' ); ?></th>
	<th><?php echo _x( 'Signup Fee', 'Referring to subscription signup fee', 'edd-recurring' ); ?></th>
	<?php
}

/**
 * Add a hook to the variable price rows that all of our other fields can hook into
 *
 * @access      public
 * @since       2.6
 * @return      void
 */
function edd_recurring_price_row_hook( $download_id, $price_id, $args ) {
	?>
	<div class="edd-custom-price-option-section">
		<?php printf( '<span class="edd-custom-price-option-section-title">%s</span>', esc_html__( 'Recurring Payments Settings', 'edd-recurring' ) ); ?>
		<div class="edd-custom-price-option-section-content edd-form-row">
		<?php
			do_action( 'edd_recurring_download_price_row', $download_id, $price_id, $args );
		?>
		</div>
	</div>
	<?php
}
add_action( 'edd_download_price_option_row', 'edd_recurring_price_row_hook', 999, 3 );

/**
 * Meta box is recurring yes/no field
 *
 * @access      public
 * @since       1.0
 * @return      void
 */
function edd_recurring_metabox_recurring( $download_id, $price_id, $args ) {

	$recurring = EDD_Recurring()->is_price_recurring( $download_id, $price_id );

	?>
	<div class="edd-form-group edd-form-row__column edd-recurring-enabled">
		<label for="edd_variable_prices[<?php echo esc_attr( $price_id ); ?>][recurring]" class="edd-form-group__label"><?php esc_html_e( 'Recurring', 'edd-recurring' ); ?></label>
		<div class="edd-form-group__control">
			<select name="edd_variable_prices[<?php echo esc_attr( $price_id ); ?>][recurring]" id="edd_variable_prices[<?php echo esc_attr( $price_id ); ?>][recurring]" class="edd-form-group__input">
				<option value="no" <?php selected( $recurring, false ); ?>><?php echo esc_attr_e( 'No', 'edd-recurring' ); ?></option>
				<option value="yes" <?php selected( $recurring, true ); ?>><?php echo esc_attr_e( 'Yes', 'edd-recurring' ); ?></option>
			</select>
		</div>
	</div>
	<?php
}
add_action( 'edd_recurring_download_price_row', 'edd_recurring_metabox_recurring', 999, 3 );


/**
 * Meta box free trial field
 *
 * @access      public
 * @since       1.0
 * @return      void
 */
function edd_recurring_metabox_free_trial( $download_id, $price_id, $args ) {

	$recurring = EDD_Recurring()->is_price_recurring( $download_id, $price_id );
	$periods   = EDD_Recurring()->singular_periods();
	$trial     = EDD_Recurring()->get_trial_period( $download_id, $price_id );
	$quantity  = empty( $trial['quantity'] ) ? '' : $trial['quantity'];
	$unit      = empty( $trial['unit'] ) ? '' : $trial['unit'];
	$disabled  = $recurring ? '' : 'disabled ';
	// Remove non-valid trial periods.
	unset( $periods['quarter'] );
	unset( $periods['semi-year'] );

	?>
	<fieldset class="edd-form-group edd-form-row__column edd-recurring-free-trial">
		<legend class="edd-form-group__label"><?php esc_html_e( 'Free Trial', 'edd-recurring' ); ?></legend>
		<div class="edd-form-group__control edd-form-group__control--is-inline edd-amount-type-wrapper">
			<label for="edd_variable_prices[<?php echo esc_attr( $price_id ); ?>][trial-quantity]" class="screen-reader-text edd-form-group__label"><?php esc_html_e( 'Trial Quantity', 'edd-recurring' ); ?></label>
			<input <?php echo $disabled; ?> name="edd_variable_prices[<?php echo esc_attr( $price_id ); ?>][trial-quantity]" class="edd-form-group__input small-text trial-quantity edd-amount-input" id="edd_variable_prices[<?php echo esc_attr( $price_id ); ?>][trial-quantity]" type="number" min="0" step="1" value="<?php echo esc_attr( $quantity ); ?>" placeholder="0"/>
			<label for="edd_variable_prices[<?php echo esc_attr( $price_id ); ?>][trial-unit]" class="screen-reader-text edd-form-group__label"><?php esc_html_e( 'Trial Period', 'edd-recurring' ); ?></label>
			<select <?php echo $disabled; ?> name="edd_variable_prices[<?php echo esc_attr( $price_id ); ?>][trial-unit]" id="edd_variable_prices[<?php echo esc_attr( $price_id ); ?>][trial-unit]">
				<?php foreach ( $periods as $key => $value ) : ?>
					<option value="<?php echo esc_attr( $key ); ?>" <?php selected( $unit, $key ); ?>><?php echo esc_attr( $value ); ?></option>
				<?php endforeach; ?>
			</select>
		</div>
	</fieldset>
	<?php
}
add_action( 'edd_recurring_download_price_row', 'edd_recurring_metabox_free_trial', 999, 3 );

/**
 * Meta box recurring period field
 *
 * @access      public
 * @since       1.0
 * @return      void
 */
function edd_recurring_metabox_period( $download_id, $price_id, $args ) {

	$recurring = EDD_Recurring()->is_price_recurring( $download_id, $price_id );
	$periods   = EDD_Recurring()->periods();
	$period    = EDD_Recurring()->get_period( $price_id );

	?>
	<div class="edd-form-group edd-form-row__column edd-recurring-period">
		<label for="edd_variable_prices[<?php echo esc_attr( $price_id ); ?>][period]" class="edd-form-group__label"><?php esc_html_e( 'Period', 'edd-recurring' ); ?></label>
		<div class="edd-form-group__control">
			<select class="edd-form-group__input" <?php echo $recurring ? '' : 'disabled '; ?>name="edd_variable_prices[<?php echo esc_attr( $price_id ); ?>][period]" id="edd_variable_prices[<?php echo esc_attr( $price_id ); ?>][period]">
				<?php foreach ( $periods as $key => $value ) : ?>
					<option value="<?php echo esc_attr( $key ); ?>" <?php selected( $period, $key ); ?>><?php echo esc_attr( $value ); ?></option>
				<?php endforeach; ?>
			</select>
		</div>
	</div>
	<?php
}
add_action( 'edd_recurring_download_price_row', 'edd_recurring_metabox_period', 999, 3 );

/**
 * Meta box recurring times field
 *
 * @access      public
 * @since       1.0
 * @return      void
 */
function edd_recurring_metabox_times( $download_id, $price_id, $args ) {

	$recurring = EDD_Recurring()->is_price_recurring( $download_id, $price_id );
	$times     = EDD_Recurring()->get_times( $price_id );
	$period    = EDD_Recurring()->get_period( $price_id );

	?>
	<div class="edd-form-row__column edd-form-group times edd-recurring-times">
		<label for="edd_variable_prices[<?php echo esc_attr( $price_id ); ?>][times]" class="edd-form-group__label"><?php echo esc_html_x( 'Times', 'Referring to billing period', 'edd-recurring' ); ?></label>
		<div class="edd-form-group__control">
			<input class="edd-form-group__input small-text" <?php echo $recurring ? '' : 'disabled '; ?>type="number" min="0" step="1" name="edd_variable_prices[<?php echo esc_attr( $price_id ); ?>][times]" id="edd_variable_prices[<?php echo esc_attr( $price_id ); ?>][times]" value="<?php echo esc_attr( $times ); ?>" />
		</div>
	</div>
	<?php
}
add_action( 'edd_recurring_download_price_row', 'edd_recurring_metabox_times', 999, 3 );

/**
 * Meta box recurring fee field
 *
 * @access      public
 * @since       1.1
 * @return      void
 */
function edd_recurring_metabox_signup_fee( $download_id, $price_id, $args ) {

	$recurring         = EDD_Recurring()->is_price_recurring( $download_id, $price_id );
	$has_trial         = EDD_Recurring()->has_free_trial( $download_id, $price_id );
	$signup_fee        = EDD_Recurring()->get_signup_fee( $price_id, $download_id );
	$currency_position = edd_get_option( 'currency_position', 'before' );
	$is_disabled       = ! $recurring || $has_trial;
	$classes           = array(
		'edd-form-group',
		'edd-form-row__column',
		'signup_fee',
		'edd-recurring-fee',
	);
	if ( $is_disabled ) {
		$classes[] = 'edd-disabled';
	}

	?>
	<div class="<?php echo esc_attr( implode( ' ', $classes ) ); ?>">
		<label for="edd_variable_prices[<?php echo esc_attr( $price_id ); ?>][signup_fee]" class="edd-form-group__label"><?php echo esc_html_x( 'Signup Fee', 'Referring to subscription signup fee', 'edd-recurring' ); ?></label>
		<div class="edd-form-group__control edd-amount-type-wrapper">
			<?php
			if ( 'before' === $currency_position ) {
				?>
				<span class="edd-amount-control__currency is-before edd-input__symbol edd-input__symbol--prefix"><?php echo esc_html( edd_currency_filter( '' ) ); ?></span>
				<input type="text" name="edd_variable_prices[<?php echo esc_attr( $price_id ); ?>][signup_fee]" id="edd_variable_prices[<?php echo esc_attr( $price_id ); ?>][signup_fee]" class="edd-form-group__input edd-price-field" value="<?php echo esc_attr( $signup_fee ); ?>"<?php disabled( $is_disabled ); ?>/>
				<?php
			} else {
				?>
				<input type="text" name="edd_variable_prices[<?php echo esc_attr( $price_id ); ?>][signup_fee]" id="edd_variable_prices[<?php echo esc_attr( $price_id ); ?>][signup_fee]" class="edd-form-group__input edd-price-field" value="<?php echo esc_attr( $signup_fee ); ?>"<?php disabled( $is_disabled ); ?>/>
				<span class="edd-amount-control__currency is-after edd-input__symbol edd-input__symbol--prefix"><?php echo esc_html( edd_currency_filter( '' ) ); ?></span>
				<?php
			}
			?>
		</div>
	</div>
	<?php
}
add_action( 'edd_recurring_download_price_row', 'edd_recurring_metabox_signup_fee', 999, 3 );

/**
 * Meta fields for EDD to save
 *
 * @access      public
 * @since       1.0
 * @return      array
 */
function edd_recurring_save_single( $fields ) {
	$fields[] = 'edd_period';
	$fields[] = 'edd_times';
	$fields[] = 'edd_recurring';
	$fields[] = 'edd_signup_fee';

	if ( defined( 'EDD_CUSTOM_PRICES' ) ) {
		$fields[] = 'edd_custom_signup_fee';
		$fields[] = 'edd_custom_recurring';
		$fields[] = 'edd_custom_times';
		$fields[] = 'edd_custom_period';
	}

	return $fields;
}
add_filter( 'edd_metabox_fields_save', 'edd_recurring_save_single' );

/**
 * Store the trial options.
 * As of 2.12.0, if the product is variable, any stray single price meta is deleted.
 *
 * @access      public
 * @since       2.6
 * @return      void
 */
function edd_recurring_save_trial_period( $post_id, $post ) {

	if ( ! current_user_can( 'edit_product', $post_id ) ) {
		return;
	}

	$variable_product = filter_input( INPUT_POST, '_variable_pricing', FILTER_VALIDATE_BOOLEAN );

	// Delete single price meta if variable pricing is enabled.
	if ( $variable_product ) {
		delete_post_meta( $post_id, 'edd_recurring' );
		delete_post_meta( $post_id, 'edd_period' );
		delete_post_meta( $post_id, 'edd_trial_period' );

		return;
	}

	if ( ! empty( $_POST['edd_recurring_free_trial'] ) ) {

		$default = array(
			'quantity' => 1,
			'unit'     => 'month',
		);

		$period             = array();
		$period['unit']     = sanitize_text_field( $_POST['edd_recurring_trial_unit'] );
		$period['quantity'] = absint( $_POST['edd_recurring_trial_quantity'] );
		$period             = wp_parse_args( $period, $default );

		update_post_meta( $post_id, 'edd_trial_period', $period );
	} else {
		delete_post_meta( $post_id, 'edd_trial_period' );
	}
}
add_action( 'edd_save_download', 'edd_recurring_save_trial_period', 10, 2 );

/*
|--------------------------------------------------------------------------
| Single Price Options
|--------------------------------------------------------------------------
*/

/**
 * Add a hook to the Prices metabox that all of our other fields can hook into
 *
 * @access      public
 * @since       2.6
 * @return      void
 */
function edd_recurring_metabox_hook( $download_id ) {
	$is_variable = edd_has_variable_prices( $download_id );
	?>
	<div class="edd-form-row edd-recurring-single"<?php echo $is_variable && ! class_exists( '\\EDD\Admin\\Downloads\\Editor\\Section' ) ? ' style="display:none;"' : ''; ?> data-edd-requires-variable-pricing="false">
		<?php do_action( 'edd_recurring_download_metabox', $download_id ); ?>
	</div>
	<?php
}
add_action( 'edd_after_price_field', 'edd_recurring_metabox_hook', 1 );


/**
 * Meta box is recurring yes/no field
 *
 * @access      public
 * @since       1.0
 * @return      void
 */
function edd_recurring_metabox_single_recurring( $download_id ) {

	$recurring = EDD_Recurring()->is_recurring( $download_id );

	?>
	<div class="edd-form-group edd-form-row__column">
		<label for="edd_recurring" class="edd-form-group__label"><?php esc_html_e( 'Recurring', 'edd-recurring' ); ?></label>
		<div class="edd-form-group__control">
			<select name="edd_recurring" id="edd_recurring" class="edd-form-group__input edd-supports" data-edd-supported="recurring">
				<option value="no" <?php selected( $recurring, false ); ?>><?php esc_attr_e( 'No', 'edd-recurring' ); ?></option>
				<option value="yes" <?php selected( $recurring, true ); ?>><?php esc_attr_e( 'Yes', 'edd-recurring' ); ?></option>
			</select>
		</div>
	</div>
	<?php
}
add_action( 'edd_recurring_download_metabox', 'edd_recurring_metabox_single_recurring' );

/**
 * Meta box recurring period field
 *
 * @access      public
 * @since       1.0
 * @return      void
 */
function edd_recurring_metabox_single_period( $download_id ) {

	$periods = EDD_Recurring()->periods();
	$period  = EDD_Recurring()->get_period_single( $download_id );
	?>
	<div class="edd-form-group edd-form-row__column">
		<label for="edd_period" class="edd-form-group__label"><?php esc_html_e( 'Period', 'edd-recurring' ); ?></label>
		<div class="edd-form-group__control">
			<select name="edd_period" id="edd_period" class="edd-form-group__input"<?php disabled( ! edd_recurring()->is_recurring( $download_id ) ); ?>>
				<?php foreach ( $periods as $key => $value ) : ?>
					<option value="<?php echo esc_attr( $key ); ?>" <?php selected( $period, $key ); ?>><?php echo esc_html( $value ); ?></option>
				<?php endforeach; ?>
			</select>
		</div>
	</div>
	<?php
}
add_action( 'edd_recurring_download_metabox', 'edd_recurring_metabox_single_period' );


/**
 * Meta box recurring times field
 *
 * @access      public
 * @since       1.0
 * @return      void
 */
function edd_recurring_metabox_single_times( $download_id ) {

	$times = EDD_Recurring()->get_times_single( $download_id );
	?>

	<div class="edd-form-group edd-form-row__column">
		<label for="edd_times" class="edd-form-group__label"><?php esc_html_e( 'Times', 'edd-recurring' ); ?></label>
		<div class="edd-form-group__control">
			<input type="number" min="0" step="1" name="edd_times" id="edd_times" class="edd-form-group__input small-text" value="<?php echo esc_attr( $times ); ?>"<?php disabled( ! edd_recurring()->is_recurring( $download_id ) ); ?>/>
		</div>
	</div>
	<?php
}
add_action( 'edd_recurring_download_metabox', 'edd_recurring_metabox_single_times' );

/**
 * Meta box recurring signup fee field
 *
 * @access      public
 * @since       1.1
 * @return      void
 */
function edd_recurring_metabox_single_signup_fee( $download_id ) {

	$has_trial         = EDD_Recurring()->has_free_trial( $download_id );
	$signup_fee        = EDD_Recurring()->get_signup_fee_single( $download_id );
	$currency_position = edd_get_option( 'currency_position', 'before' );
	$is_disabled       = ! edd_recurring()->is_recurring( $download_id ) || $has_trial;
	$classes           = array(
		'edd-form-group',
		'edd-form-row__column',
		'edd-recurring-fee',
	);
	if ( $is_disabled ) {
		$classes[] = 'edd-disabled';
	}
	?>

	<div class="<?php echo esc_attr( implode( ' ', $classes ) ); ?>">
		<label for="edd_signup_fee" class="edd-form-group__label"><?php esc_html_e( 'Signup Fee', 'edd-recurring' ); ?></label>
		<div class="edd-form-group__control edd-amount-type-wrapper">
			<?php
			if ( 'before' === $currency_position ) {
				?>
				<span class="edd-amount-control__currency is-before edd-input__symbol edd-input__symbol--prefix"><?php echo esc_html( edd_currency_filter( '' ) ); ?></span>
				<input type="text" name="edd_signup_fee" id="edd_signup_fee" class="edd-form-group__input edd-price-field" value="<?php echo esc_attr( $signup_fee ); ?>"<?php disabled( $is_disabled ); ?>/>
				<?php
			} else {
				?>
				<input type="text" name="edd_signup_fee" id="edd_signup_fee" class="edd-form-group__input edd-price-field" value="<?php echo esc_attr( $signup_fee ); ?>"<?php disabled( $is_disabled ); ?>/>
				<span class="edd-amount-control__currency is-after edd-input__symbol edd-input__symbol--suffix"><?php echo esc_html( edd_currency_filter( '' ) ); ?></span>
				<?php
			}
			?>
		</div>
	</div>
	<?php
}
add_action( 'edd_recurring_download_metabox', 'edd_recurring_metabox_single_signup_fee' );

/**
 * Free trial options
 *
 * @access      public
 * @since       2.6
 * @return      void
 */
function edd_recurring_metabox_trial_options( $download_id ) {

	$has_trial = EDD_Recurring()->has_free_trial( $download_id );
	$periods   = EDD_Recurring()->singular_periods();
	$period    = EDD_Recurring()->get_trial_period( $download_id );
	$quantity  = empty( $period['quantity'] ) ? '' : $period['quantity'];
	$unit      = empty( $period['unit'] ) ? '' : $period['unit'];

	// Remove non-valid trial periods.
	unset( $periods['quarter'] );
	unset( $periods['semi-year'] );

	$one_one_discount_help = '';
	if ( edd_get_option( 'recurring_one_time_discounts' ) ) {
		$one_one_discount_help = '<br>' . __( '<strong>Additional note</strong>: with free trials, one time discounts are not supported and discount codes for this product will apply to all payments after the trial period.', 'edd-recurring' );
	}

	$has_sections       = class_exists( '\\EDD\Admin\\Downloads\\Editor\\Section' );
	$needs_inline_style = ! $has_sections && edd_has_variable_prices( $download_id );

	?>
	<div id="edd_recurring_free_trial_options_wrap" class="edd-form-group"<?php echo $needs_inline_style ? ' style="display:none;"' : ''; ?> data-edd-requires-variable-pricing="false" data-edd-supports-recurring="yes">

		<?php if ( edd_is_gateway_active( '2checkout' ) || edd_is_gateway_active( '2checkout_onsite' ) ) : ?>
			<p class="description"><strong><?php esc_html_e( '2Checkout does not support free trial periods. Subscriptions purchased through 2Checkout cannot include free trials.', 'edd-recurring' ); ?></strong></p>
		<?php endif; ?>

		<div class="edd-form-group">
			<div class="edd-form-group__control edd-toggle">
				<input type="checkbox" name="edd_recurring_free_trial" id="edd_recurring_free_trial" class="edd-requirement" value="yes"<?php checked( true, $has_trial ); ?> data-edd-requirement="free-trial"/>
				<label for="edd_recurring_free_trial">
					<?php esc_html_e( 'Enable free trial for subscriptions', 'edd-recurring' ); ?>
					<span class="edd-help-tip dashicons dashicons-editor-help" title="
					<?php
					esc_html_e( 'Check this box to include a free trial with subscriptions for this product. When signing up for a free trial, the customer\'s payment details will be taken at checkout but the customer will not be charged until the free trial is completed. <strong>Note:</strong> this only applies when purchasing a subscription. If a price option is not set to recurring, this free trial will not be used.', 'edd-recurring' );
					echo wp_kses_post( $one_one_discount_help );
					?>
					"></span>
				</label>
			</div>
		</div>
		<fieldset id="edd_recurring_free_trial_options" class="edd-form-group"<?php echo $has_trial && ! $has_sections ? ' style="display:none;"' : ''; ?> data-edd-requires-free-trial="true">
			<legend class="screen-reader-text"><?php esc_html_e( 'Free Trial Options', 'edd-recurring' ); ?></legend>
			<div class="edd-form-group__control edd-form-group__control--is-inline edd-amount-type-wrapper">
				<label for="edd_recurring_trial_quantity" class="edd-form-group__label screen-reader-text"><?php esc_html_e( 'Trial Quantity', 'edd-recurring' ); ?></label>
				<input name="edd_recurring_trial_quantity" id="edd_recurring_trial_quantity" class="edd-form-group__input small-text edd-amount-input" type="number" min="1" step="1" value="<?php echo esc_attr( $quantity ); ?>" placeholder="1"/>
				<label for="edd_recurring_trial_unit" class="edd-form-group__label screen-reader-text"><?php esc_html_e( 'Trial Period', 'edd-recurring' ); ?></label>
				<select name="edd_recurring_trial_unit" id="edd_recurring_trial_unit" class="edd-form-group__input">
					<?php foreach ( $periods as $key => $value ) : ?>
						<option value="<?php echo esc_attr( $key ); ?>" <?php selected( $unit, $key ); ?>><?php echo esc_attr( $value ); ?></option>
					<?php endforeach; ?>
				</select>
			</div>
		</fieldset>
	</div>
	<?php
}
add_action( 'edd_after_price_field', 'edd_recurring_metabox_trial_options', 2 );

/**
 * Recurring options for Custom Prices
 *
 * @access      public
 * @since       2.5
 * @return      void
 */
function edd_recurring_metabox_custom_options( $download_id ) {

	if ( ! defined( 'EDD_CUSTOM_PRICES' ) ) {
		return;
	}

	// Custom Prices registers its own section, so if that's the case, Recurring doesn't need to add it.
	if ( 'edd_after_price_field' === current_action() && function_exists( 'edd_cp_download_editor_has_sections' ) && edd_cp_download_editor_has_sections() ) {
		return;
	}

	$custom            = get_post_meta( $download_id, '_edd_cp_custom_pricing', true );
	$recurring         = EDD_Recurring()->is_custom_recurring( $download_id );
	$periods           = EDD_Recurring()->periods();
	$period            = EDD_Recurring()->get_custom_period( $download_id );
	$times             = EDD_Recurring()->get_custom_times( $download_id );
	$signup_fee        = EDD_Recurring()->get_custom_signup_fee( $download_id );
	$currency_position = edd_get_option( 'currency_position', 'before' );
	$disabled          = ! $custom || ! $recurring;
	?>
	<fieldset id="edd_custom_recurring" class="edd_recurring_custom_wrap edd-form-row"<?php echo $custom || class_exists( 'EDD\\Admin\\Downloads\\Editor\\Section' ) ? '' : ' display:none;'; ?> data-edd-requires-custom-prices="true">
		<legend><?php esc_html_e( 'Recurring Options for Custom Prices', 'edd-recurring' ); ?></legend>
		<p><?php esc_html_e( 'Select the recurring options for customers that pay with a custom price.', 'edd-recurring' ); ?></p>
		<div class="edd-form-group edd-form-row__column">
			<label for="edd_custom_recurring" class="edd-form-group__label"><?php esc_html_e( 'Recurring', 'edd-recurring' ); ?></label>
			<div class="edd-form-group__control">
				<select name="edd_custom_recurring" id="edd_custom_recurring">
					<option value="no" <?php selected( $recurring, false ); ?>><?php esc_attr_e( 'No', 'edd-recurring' ); ?></option>
					<option value="yes" <?php selected( $recurring, true ); ?>><?php esc_attr_e( 'Yes', 'edd-recurring' ); ?></option>
				</select>
			</div>
		</div>
		<div class="edd-form-group edd-form-row__column">
			<label for="edd_custom_period" class="edd-form-group__label"><?php esc_html_e( 'Period', 'edd-recurring' ); ?></label>
			<div class="edd-form-group__control">
				<select name="edd_custom_period" id="edd_custom_period" class="edd-form-group__input"<?php disabled( $disabled ); ?>>
					<?php foreach ( $periods as $key => $value ) : ?>
						<option value="<?php echo esc_attr( $key ); ?>" <?php selected( $period, $key ); ?>><?php echo esc_html( $value ); ?></option>
					<?php endforeach; ?>
				</select>
			</div>
		</div>
		<div class="edd-form-group edd-form-row__column times">
			<label for="edd_custom_times" class="edd-form-group__label"><?php esc_html_e( 'Times', 'edd-recurring' ); ?></label>
			<div class="edd-form-group__control">
				<input type="number" min="0" step="1" name="edd_custom_times" id="edd_custom_times" class="edd-form-group__input small-text" value="<?php echo esc_attr( $times ); ?>"<?php disabled( $disabled ); ?> />
			</div>
		</div>
		<?php
		$signup_fee_classes = array(
			'edd-form-group',
			'edd-form-row__column',
			'signup_fee',
			'edd-recurring-fee',
		);
		if ( $disabled ) {
			$signup_fee_classes[] = 'edd-disabled';
		}
		?>
		<div class="<?php echo esc_attr( implode( ' ', $signup_fee_classes ) ); ?>">
			<label for="edd_custom_signup_fee" class="edd-form-group__label"><?php esc_html_e( 'Signup Fee', 'edd-recurring' ); ?></label>
			<div class="edd-form-group__control edd-amount-type-wrapper">
				<?php
				if ( 'before' === $currency_position ) {
					?>
					<span class="edd-amount-control__currency is-before edd-input__symbol edd-input__symbol--prefix"><?php echo esc_html( edd_currency_filter( '' ) ); ?></span>
					<input type="text" name="edd_custom_signup_fee" id="edd_custom_signup_fee" class="edd-form-group__input edd-price-field" value="<?php echo esc_attr( $signup_fee ); ?>"<?php disabled( $disabled ); ?>/>
					<?php
				} else {
					?>
					<input type="text" name="edd_custom_signup_fee" id="edd_custom_signup_fee" class="edd-form-group__input edd-price-field" value="<?php echo esc_attr( $signup_fee ); ?>"<?php disabled( $disabled ); ?>/>
					<span class="edd-amount-control__currency is-after edd-input__symbol edd-input__symbol--suffix"><?php echo esc_html( edd_currency_filter( '' ) ); ?></span>
					<?php
				}
				?>
			</div>
		</div>
	</fieldset>
	<?php
}
// add_action( 'edd_after_price_field', 'edd_recurring_metabox_custom_options', 10 );

/**
 * Display Subscription transaction IDs for parent payments
 *
 * @since 2.4.4
 * @param $payment_id The order ID.
 */
function edd_display_subscription_txn_ids( $payment_id ) {

	if ( ! edd_get_order_meta( $payment_id, '_edd_subscription_payment', true ) ) {
		return;
	}

	$subs = edd_recurring_get_subscriptions( array( 'parent_payment_id' => $payment_id ) );

	if ( empty( $subs ) ) {
		return;
	}
	?>
	<div class="edd-subscription-tx-id edd-admin-box-inside">
		<?php foreach ( $subs as $sub ) : ?>
			<?php
			if ( ! $sub->get_transaction_id() ) {
				continue; }
			?>
			<p>
				<span class="label"><?php esc_html_e( 'Subscription TXN ID:', 'edd-recurring' ); ?></span>
				<span><?php echo apply_filters( 'edd_payment_details_transaction_id-' . $sub->gateway, $sub->get_transaction_id(), $payment_id ); ?></span>
			</p>
		<?php endforeach; ?>
	</div>
	<?php
}
add_action( 'edd_view_order_details_payment_meta_after', 'edd_display_subscription_txn_ids', 10, 1 );
