<?php

/**
 * Load the admin javascript
 *
 * @access      public
 * @since       1.0
 * @return      void
 */
function edd_recurring_admin_scripts( $hook ) {
	global $post;
	if ( is_object( $post ) && 'download' !== $post->post_type ) {
		return;
	}

	$pages = array( 'post.php', 'post-new.php', 'download_page_edd-subscriptions', 'download_page_edd-payment-history', 'download_page_edd-customers', 'download_page_edd-tools' );

	if ( ! in_array( $hook, $pages, true ) ) {
		return;
	}

	wp_register_script( 'edd-admin-recurring', EDD_RECURRING_PLUGIN_URL . '/assets/js/edd-admin-recurring.js', array( 'jquery' ), EDD_RECURRING_VERSION );
	wp_enqueue_script( 'edd-admin-recurring' );
	wp_enqueue_style( 'edd-admin-recurring', EDD_RECURRING_PLUGIN_URL . '/assets/css/admin.css', array(), EDD_RECURRING_VERSION );

	$ajax_vars = array(
		'singular'            => _x( 'time', 'Referring to billing period', 'edd-recurring' ),
		'plural'              => _x( 'times', 'Referring to billing period', 'edd-recurring' ),
		'enabled_gateways'    => edd_get_enabled_payment_gateways(),
		'invalid_time'        => array(
			'paypal' => __( 'PayPal Standard requires recurring times to be set to 0 for indefinite subscriptions or a minimum value of 2 and a maximum value of 52 for limited subscriptions.', 'edd-recurring' ),
		),
		'cancel_subscription' => __( 'Are you sure you want to cancel this subscription?', 'edd-recurring' ),
		'delete_subscription' => __( 'Are you sure you want to delete this subscription?', 'edd-recurring' ),
		'action_edit'         => __( 'Edit', 'edd-recurring' ),
		'action_cancel'       => __( 'Cancel', 'edd-recurring' ),
	);

	wp_localize_script( 'edd-admin-recurring', 'EDD_Recurring_Vars', $ajax_vars );
}
add_action( 'admin_enqueue_scripts', 'edd_recurring_admin_scripts' );
