<?php
/**
 * Reports Chart
 *
 * @package   edd-recurring
 * @copyright Copyright (c) 2021, Sandhills Development, LLC
 * @license   GPL2+
 * @since     2.10.1
 */
class EDD_Recurring_Reports_Chart {

	/**
	 * Final array of graph data.
	 *
	 * @var array[]
	 */
	public $graph_data = array(
		'renewals' => array(), // Renewal count.
		'refunds'  => array(), // Refunded renewal count.
		'created'  => array(), // Created subscription count.
	);

	/**
	 * Date range for the query.
	 *
	 * @var array
	 */
	private $dates;

	/**
	 * Date range for chart generation (user timezone).
	 *
	 * @var array
	 */
	private $chart_dates;

	/**
	 * True if results should use day by day, otherwise false.
	 *
	 * @var bool
	 */
	private $day_by_day;

	/**
	 * True if results should use hour by hour, otherwise false.
	 *
	 * @var bool
	 */
	private $hour_by_hour;

	/**
	 * Column name to query for amounts, depending on tax filter.
	 *
	 * @var string
	 */
	private $query_column;

	/**
	 * Converted date column name.
	 *
	 * @var string
	 */
	private $converted_date;

	/**
	 * Date format for the query.
	 *
	 * @var string
	 */
	private $date_format = '%%Y-%%m';

	/**
	 * EDD_Recurring_Reports_Chart constructor.
	 */
	public function __construct() {

		$this->dates          = EDD\Reports\get_dates_filter( 'objects' );
		$this->chart_dates    = EDD\Reports\parse_dates_for_range( null, 'now', false );
		$this->day_by_day     = EDD\Reports\get_dates_filter_day_by_day();
		$this->hour_by_hour   = EDD\Reports\get_dates_filter_hour_by_hour();
		$this->query_column   = EDD\Reports\get_taxes_excluded_filter() ? 'total - tax' : 'total';
		$this->converted_date = EDD\Reports\get_column_conversion( 'edd_o.date_created' );
		if ( $this->hour_by_hour ) {
			$this->date_format = '%%Y-%%m-%%d %%H:00:00';
		} elseif ( $this->day_by_day ) {
			$this->date_format = '%%Y-%%m-%%d';
		}

		$this->query();
	}

	/**
	 * Returns the data that makes up the renewals chart.
	 *
	 * @since 2.10.1
	 * @return array[]
	 */
	public static function get_chart_data() {
		$chart = new self();

		return $chart->graph_data;
	}

	/**
	 * Queries for graph data.
	 *
	 * @since 2.10.1
	 * @return void
	 */
	private function query() {
		global $wpdb;

		/*
		 * Query for subscriptions created during the period. Including subscriptions that were eventually refunded.
		 */
		$subscription_db = new EDD_Subscriptions_DB();

		$start_date = $this->dates['start']->copy()->format( 'mysql' );
		$end_date   = $this->dates['end']->copy()->format( 'mysql' );

		/**
		 * We don't do a timezone conversion on this created column here as this isn't inserting in UTC like orders.
		 */
		$created_results = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT COUNT(subs.id) AS number, DATE_FORMAT(subs.created,\"{$this->date_format}\") AS date
				FROM {$subscription_db->table_name} subs
				WHERE subs.created >= %s AND subs.created <= %s
				GROUP BY date
				ORDER BY date",
				$start_date,
				$end_date
			)
		);

		/*
		 * Query for renewals during this period. This gets all renewals, including renewals that were
		 * eventually refunded.
		 */
		$sale_results = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT COUNT(edd_o.id) AS number, DATE_FORMAT({$this->converted_date},\"{$this->date_format}\") AS date
				FROM {$wpdb->edd_orders} edd_o
				INNER JOIN {$wpdb->edd_ordermeta} edd_ometa ON( edd_o.id = edd_ometa.edd_order_id AND edd_ometa.meta_key = 'subscription_id' )
				WHERE edd_o.type = 'sale'
				AND edd_o.status IN( 'edd_subscription', 'partially_refunded', 'refunded' )
				AND edd_o.date_created >= %s AND edd_o.date_created <= %s
				GROUP BY date
				ORDER BY date",
				$start_date,
				$end_date
			)
		);

		/*
		 * Query for renewals that were refunded during this period.
		 */
		$refund_results = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT COUNT(edd_o.id) AS number, DATE_FORMAT({$this->converted_date},\"{$this->date_format}\") AS date
				FROM {$wpdb->edd_orders} edd_o
				INNER JOIN {$wpdb->edd_ordermeta} edd_ometa ON( edd_o.parent = edd_ometa.edd_order_id AND edd_ometa.meta_key = 'subscription_id' )
				WHERE edd_o.type = 'refund'
				AND edd_o.status = 'complete'
				AND edd_o.date_created >= %s AND edd_o.date_created <= %s
				GROUP BY date
				ORDER BY date",
				$start_date,
				$end_date
			)
		);

		try {

			// If months, set to first day of month to handle leap years.
			if ( ! $this->day_by_day && ! $this->hour_by_hour ) {
				$this->chart_dates['start']->modify( 'first day of this month' );
			}

			// Initialise all arrays with timestamps and set values to 0.
			while ( strtotime( $this->chart_dates['start']->copy()->format( 'mysql' ) ) <= strtotime( $this->chart_dates['end']->copy()->format( 'mysql' ) ) ) {
				$timestamp = strtotime( $this->chart_dates['start']->copy()->format( 'mysql' ) );

				// These are counts.
				foreach ( array( 'created', 'renewals', 'refunds' ) as $key_name ) {
					$this->graph_data[ $key_name ][ $timestamp ][0] = $timestamp;
					$this->graph_data[ $key_name ][ $timestamp ][1] = 0;
				}

				$this->process_results( $created_results, $timestamp, 'created' );
				$this->process_results( $sale_results, $timestamp, 'sale' );
				$this->process_results( $refund_results, $timestamp, 'refund' );

				// Move the chart along to the next hour/day/month to get ready for the next loop.
				if ( $this->hour_by_hour ) {
					$this->chart_dates['start']->addHour( 1 );
				} elseif ( $this->day_by_day ) {
					$this->chart_dates['start']->addDays( 1 );
				} else {
					$this->chart_dates['start']->modify( 'first day of next month' );
				}
			}
		} catch ( \Exception $e ) {
			// Do nothing.
		}

		foreach ( $this->graph_data as $data_key => $data_value ) {
			$this->graph_data[ $data_key ] = array_values( $data_value );
		}
	}

	/**
	 * Processes query results to add graph data.
	 *
	 * @param array  $results    Array of database objects.
	 * @param int    $timestamp  Unix timestamp.
	 * @param string $query_type Type of query that was performed.
	 *
	 * @since 2.10.1
	 * @return void
	 */
	private function process_results( $results, $timestamp, $query_type = 'sale' ) {
		// Loop through each date there were renewals, which we queried from the database.
		foreach ( $results as $result ) {

			try {
				$timezone         = new DateTimeZone( 'UTC' );
				$date_of_db_value = new DateTime( $result->date, $timezone );
				$date_on_chart    = new DateTime( $this->chart_dates['start'], $timezone );
			} catch ( \Exception $e ) {
				continue;
			}

			if ( $this->hour_by_hour ) { // Add any data that was found in this hour.
				// If the date of this db value matches the date on this line graph/chart, set the y axis value for the chart to the number in the DB result.
				if ( $date_of_db_value->format( 'Y-m-d H' ) === $date_on_chart->format( 'Y-m-d H' ) ) {
					$this->add_graph_data( $result, $timestamp, $query_type );
				}
			} elseif ( $this->day_by_day ) { // Add any data that was found in this day.
				// If the date of this db value matches the date on this line graph/chart, set the y axis value for the chart to the number in the DB result.
				if ( $date_of_db_value->format( 'Y-m-d' ) === $date_on_chart->format( 'Y-m-d' ) ) {
					$this->add_graph_data( $result, $timestamp, $query_type );
				}
			} else { // Add any data that was found in this month.
				// If the date of this db value matches the date on this line graph/chart, set the y axis value for the chart to the number in the DB result.
				if ( $date_of_db_value->format( 'Y-m' ) === $date_on_chart->format( 'Y-m' ) ) {
					$this->add_graph_data( $result, $timestamp, $query_type );
				}
			}
		}
	}

	/**
	 * Adds data to the graph for a specific timestamp.
	 *
	 * @param object $result     Row from the database.
	 * @param int    $timestamp  Unix timestamp.
	 * @param string $query_type Type of query being performed.
	 *
	 * @since 2.10.1
	 * @return void
	 */
	public function add_graph_data( $result, $timestamp, $query_type ) {
		if ( 'sale' === $query_type ) {
			$this->graph_data['renewals'][ $timestamp ][1] += $result->number;
		} elseif ( 'refund' === $query_type ) {
			$this->graph_data['refunds'][ $timestamp ][1] += $result->number;
		} elseif ( 'created' === $query_type ) {
			$this->graph_data['created'][ $timestamp ][1] += $result->number;
		}
	}
}
